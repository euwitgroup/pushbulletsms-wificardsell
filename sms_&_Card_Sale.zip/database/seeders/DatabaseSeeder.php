<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // Seed Admin User (must be first for authentication)
        $this->call(AdminUserSeeder::class);
        
        // Seed SMS Related Data
        $this->call(SmsPackageSeeder::class);
        $this->call(SmsTemplateSeeder::class);
        $this->call(SmsPriceSeeder::class);
        
        // Seed Homepage Content
        $this->call(WhyChooseUsSeeder::class);
        $this->call(FaqSeeder::class);
        $this->call(BlogSeeder::class);
        $this->call(ComparisonFeatureSeeder::class);
        
        // Seed Contact Information
        $this->call(ContactInfoSeeder::class);
        
        // Seed WiFi Card Data
        $this->call(CardDataSeeder::class);
        
        $this->command->info('🎉 All seeders have been executed successfully!');
    }
}
