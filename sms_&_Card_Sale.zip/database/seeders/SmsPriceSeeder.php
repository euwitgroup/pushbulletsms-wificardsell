<?php

namespace Database\Seeders;

use App\Models\SmsPrice;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SmsPriceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $prices = [
            [
                'package_name' => 'NON MASKING 1',
                'package_type' => 'non_masking_1',
                'base_price' => 0.35,
                'pricing_tiers' => null,
                'minimum_buy' => 200, // 70 Tk / 200 SMS
                'features' => [
                    'MNP Charge: 6 Poisa Included',
                    'Sender ID : Dedicated',
                    'Two-factor Security : Yes (SMS/email)',
                    'HTTP API Access : Yes',
                    'Auto Backup Gateway Routing: Yes',
                    'Can Send OTP SMS: Yes',
                    'Wordpress SMS Plugin : Yes',
                    'WHMCS Plugin : Yes',
                    'Fast Delivery Speed',
                    'Delivery Report: Yes',
                    'Validity : 6 Month',
                    'File to SMS : Yes',
                    'Dynamic SMS : Yes (from xlsx/API)',
                    'Group SMS : Yes',
                    'Online Payment (Bkash Auto):Yes',
                ],
                'order' => 1,
                'is_active' => true,
                'is_featured' => false,
            ],
            [
                'package_name' => 'NON MASKING 2',
                'package_type' => 'non_masking_2',
                'base_price' => 0.33,
                'pricing_tiers' => [
                    ['quantity' => 20000, 'price' => 0.33],
                    ['quantity' => 50000, 'price' => 0.32],
                    ['quantity' => 100000, 'price' => 0.30],
                ],
                'minimum_buy' => 20000,
                'features' => [
                    'Sender Number : Dedicated',
                    'MNP Charge Included: 6 Poisa',
                    'Two-factor Security : Yes (SMS/email)',
                    'HTTP API : Yes',
                    'Auto Backup Gateway Routing: Yes',
                    'Can Send OTP SMS: Yes',
                    'Wordpress SMS Plugin : Yes',
                    'WHMCS Plugin : Yes (paid)',
                    'Fast Delivery Speed: Yes',
                    'Validity :1y to 5 Years',
                    'XLS to SMS : Yes',
                    'Group SMS : Yes',
                    'Dynamic SMS : Yes (From xlsx/API)',
                    'Online Payment (Bkash Auto):Yes',
                ],
                'order' => 2,
                'is_active' => true,
                'is_featured' => true,
            ],
            [
                'package_name' => 'MASKING PER SMS',
                'package_type' => 'masking',
                'base_price' => 0.55,
                'pricing_tiers' => [
                    ['quantity' => 5500, 'price' => 0.55],
                    ['quantity' => 20000, 'price' => 0.50],
                    ['quantity' => 100000, 'price' => 0.48],
                ],
                'minimum_buy' => 5500, // 5500 SMS (3000 Tk)
                'features' => [
                    'Minimum Buy: 5500 SMS (3000Tk)',
                    'Customise Sender ID: Yes',
                    'Masking Approval Time: 1 to 5 Working Days',
                    'MNP Charge Excluded: 6 Poisa Per Number',
                    'HTTP API Access : Yes',
                    'Processing Fee : Tk.500',
                    'Send OTP : Yes',
                    'Delivery Report: Yes',
                    'Validity :2 Years',
                    'Number Formats Support: Multiple',
                    'XLS to SMS : Yes',
                    'Group SMS : Yes',
                    'Dynamic SMS : Yes (From xlsx/API)',
                    'Online Payment (Bkash Auto):Yes',
                ],
                'order' => 3,
                'is_active' => true,
                'is_featured' => false,
            ],
        ];

        foreach ($prices as $price) {
            SmsPrice::create($price);
        }
    }
}
