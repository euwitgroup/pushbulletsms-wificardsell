<?php

namespace Database\Seeders;

use App\Models\SmsPackage;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SmsPackageSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $packages = [
            [
                'name' => 'Starter Pack',
                'sms_count' => 100,
                'price' => 100,
                'description' => 'Perfect for getting started with SMS services',
                'is_active' => true,
            ],
            [
                'name' => 'Business Pack',
                'sms_count' => 500,
                'price' => 450,
                'description' => 'Great for small businesses',
                'is_active' => true,
            ],
            [
                'name' => 'Premium Pack',
                'sms_count' => 1000,
                'price' => 850,
                'description' => 'Best value for regular users',
                'is_active' => true,
            ],
            [
                'name' => 'Enterprise Pack',
                'sms_count' => 5000,
                'price' => 4000,
                'description' => 'For large scale operations',
                'is_active' => true,
            ],
        ];

        foreach ($packages as $package) {
            SmsPackage::create($package);
        }
    }
}
