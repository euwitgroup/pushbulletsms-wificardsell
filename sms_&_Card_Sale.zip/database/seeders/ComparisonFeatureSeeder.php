<?php

namespace Database\Seeders;

use App\Models\ComparisonFeature;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ComparisonFeatureSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $features = [
            [
                'feature_name' => 'Bangla SMS Support',
                'we_have' => true,
                'competitor_have' => false,
                'order' => 1,
                'is_active' => true,
            ],
            [
                'feature_name' => 'Location Based SMS',
                'we_have' => true,
                'competitor_have' => false,
                'order' => 2,
                'is_active' => true,
            ],
            [
                'feature_name' => '24/7 Customer Support',
                'we_have' => true,
                'competitor_have' => true,
                'order' => 3,
                'is_active' => true,
            ],
            [
                'feature_name' => 'API Integration',
                'we_have' => true,
                'competitor_have' => true,
                'order' => 4,
                'is_active' => true,
            ],
            [
                'feature_name' => 'Bulk SMS from CSV/TXT',
                'we_have' => true,
                'competitor_have' => false,
                'order' => 5,
                'is_active' => true,
            ],
            [
                'feature_name' => 'Instant Payment via bKash',
                'we_have' => true,
                'competitor_have' => false,
                'order' => 6,
                'is_active' => true,
            ],
            [
                'feature_name' => 'Unlimited Sub-Accounts',
                'we_have' => true,
                'competitor_have' => false,
                'order' => 7,
                'is_active' => true,
            ],
            [
                'feature_name' => 'Long SMS Support (1500 chars)',
                'we_have' => true,
                'competitor_have' => true,
                'order' => 8,
                'is_active' => true,
            ],
            [
                'feature_name' => 'Custom Sender ID',
                'we_have' => true,
                'competitor_have' => true,
                'order' => 9,
                'is_active' => true,
            ],
            [
                'feature_name' => 'Real-time Delivery Reports',
                'we_have' => true,
                'competitor_have' => false,
                'order' => 10,
                'is_active' => true,
            ],
        ];

        foreach ($features as $feature) {
            ComparisonFeature::create($feature);
        }
    }
}
