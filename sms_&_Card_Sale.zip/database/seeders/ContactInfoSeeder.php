<?php

namespace Database\Seeders;

use App\Models\ContactInfo;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ContactInfoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $contacts = [
            // Phone Numbers
            [
                'type' => 'phone',
                'label' => 'Main Office',
                'icon' => 'fas fa-phone',
                'value' => '+880 1611-216275',
                'description' => 'Call us during business hours (9 AM - 6 PM)',
                'order' => 1,
                'is_active' => true,
            ],
            [
                'type' => 'phone',
                'label' => 'Support',
                'icon' => 'fas fa-headset',
                'value' => '+880 1711-123456',
                'description' => '24/7 Technical Support',
                'order' => 2,
                'is_active' => true,
            ],

            // Email Addresses
            [
                'type' => 'email',
                'label' => 'General Inquiry',
                'icon' => 'fas fa-envelope',
                'value' => 'info@smscardsale.com',
                'description' => 'For general questions and information',
                'order' => 3,
                'is_active' => true,
            ],
            [
                'type' => 'email',
                'label' => 'Support',
                'icon' => 'fas fa-life-ring',
                'value' => 'support@smscardsale.com',
                'description' => 'Technical support and assistance',
                'order' => 4,
                'is_active' => true,
            ],

            // Address
            [
                'type' => 'address',
                'label' => 'Office Address',
                'icon' => 'fas fa-map-marker-alt',
                'value' => 'House 123, Road 12, Dhanmondi, Dhaka - 1209, Bangladesh',
                'description' => 'Visit us during office hours',
                'order' => 5,
                'is_active' => true,
            ],

            // Working Hours
            [
                'type' => 'hours',
                'label' => 'Business Hours',
                'icon' => 'fas fa-clock',
                'value' => 'Saturday - Thursday: 9:00 AM - 6:00 PM',
                'description' => 'Friday: Closed',
                'order' => 6,
                'is_active' => true,
            ],

            // Social Media
            [
                'type' => 'social',
                'label' => 'Facebook',
                'icon' => 'fab fa-facebook-f',
                'value' => 'https://facebook.com/smscardsale',
                'description' => 'Follow us on Facebook',
                'order' => 7,
                'is_active' => true,
            ],
            [
                'type' => 'social',
                'label' => 'Twitter',
                'icon' => 'fab fa-twitter',
                'value' => 'https://twitter.com/smscardsale',
                'description' => 'Follow us on Twitter',
                'order' => 8,
                'is_active' => true,
            ],
            [
                'type' => 'social',
                'label' => 'LinkedIn',
                'icon' => 'fab fa-linkedin-in',
                'value' => 'https://linkedin.com/company/smscardsale',
                'description' => 'Connect with us on LinkedIn',
                'order' => 9,
                'is_active' => true,
            ],
            [
                'type' => 'social',
                'label' => 'Instagram',
                'icon' => 'fab fa-instagram',
                'value' => 'https://instagram.com/smscardsale',
                'description' => 'Follow us on Instagram',
                'order' => 10,
                'is_active' => true,
            ],
            [
                'type' => 'social',
                'label' => 'YouTube',
                'icon' => 'fab fa-youtube',
                'value' => 'https://youtube.com/@smscardsale',
                'description' => 'Subscribe to our channel',
                'order' => 11,
                'is_active' => true,
            ],
            [
                'type' => 'social',
                'label' => 'WhatsApp',
                'icon' => 'fab fa-whatsapp',
                'value' => 'https://wa.me/8801611216275',
                'description' => 'Chat with us on WhatsApp',
                'order' => 12,
                'is_active' => true,
            ],
        ];

        foreach ($contacts as $contact) {
            ContactInfo::create($contact);
        }
    }
}
