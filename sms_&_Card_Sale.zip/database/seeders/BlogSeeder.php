<?php

namespace Database\Seeders;

use App\Models\Blog;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class BlogSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $blogs = [
            [
                'title' => 'How to Send Bulk SMS Effectively in 2025',
                'slug' => 'how-to-send-bulk-sms-effectively-2025',
                'excerpt' => 'Learn the best practices for sending bulk SMS campaigns that get results. Tips and tricks for higher engagement rates.',
                'content' => 'Bulk SMS marketing is one of the most effective ways to reach your customers instantly. With a 98% open rate, SMS marketing outperforms email and social media. In this guide, we\'ll cover the best practices for creating effective SMS campaigns...',
                'image' => null,
                'category' => 'Tips & Tricks',
                'is_featured' => true,
                'is_active' => true,
            ],
            [
                'title' => 'Understanding SMS Gateway and Its Benefits',
                'slug' => 'understanding-sms-gateway-benefits',
                'excerpt' => 'Discover what an SMS gateway is and how it can transform your business communication strategy.',
                'content' => 'An SMS gateway is a platform that enables sending and receiving SMS messages to and from mobile devices. It acts as a bridge between your application and mobile network operators...',
                'image' => null,
                'category' => 'Industry News',
                'is_featured' => false,
                'is_active' => true,
            ],
            [
                'title' => 'Top 10 SMS Marketing Strategies for 2025',
                'slug' => 'top-10-sms-marketing-strategies-2025',
                'excerpt' => 'Explore the latest SMS marketing strategies that are driving results for businesses worldwide.',
                'content' => 'SMS marketing continues to evolve with new strategies and technologies. Here are the top 10 strategies you should implement in 2025 to maximize your ROI...',
                'image' => null,
                'category' => 'Tips & Tricks',
                'is_featured' => true,
                'is_active' => true,
            ],
            [
                'title' => 'The Future of Business Communication: SMS vs Email',
                'slug' => 'future-business-communication-sms-vs-email',
                'excerpt' => 'Compare SMS and email marketing to determine which channel is best for your business needs.',
                'content' => 'While both SMS and email are powerful marketing channels, they serve different purposes. SMS offers immediate delivery and high open rates, while email provides more detailed content...',
                'image' => null,
                'category' => 'Industry News',
                'is_featured' => false,
                'is_active' => true,
            ],
        ];

        foreach ($blogs as $blog) {
            Blog::create($blog);
        }
    }
}
