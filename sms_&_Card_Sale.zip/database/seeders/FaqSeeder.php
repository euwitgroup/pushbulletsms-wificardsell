<?php

namespace Database\Seeders;

use App\Models\Faq;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class FaqSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faqs = [
            [
                'question' => 'How to buy SMS?',
                'answer' => 'You can buy SMS by selecting a package from our pricing section or by depositing a custom amount through bKash merchant payment. Once payment is confirmed, SMS credits will be added to your account instantly.',
                'order' => 1,
                'is_active' => true,
            ],
            [
                'question' => 'What is the rate?',
                'answer' => 'Our SMS rates start from just 30 paisa per SMS. We offer the most competitive rates in Bangladesh with premium quality service and 99.9% delivery guarantee.',
                'order' => 2,
                'is_active' => true,
            ],
            [
                'question' => 'Do you support Unicode (Bangla SMS)?',
                'answer' => 'Yes! We fully support Unicode characters including Bangla SMS. You can send messages in Bangla with standard unicode character counting system.',
                'order' => 3,
                'is_active' => true,
            ],
            [
                'question' => 'What payment methods do you accept?',
                'answer' => 'We accept bKash merchant payment for 24/7 automatic SMS purchase. Payment is instant and secure. You can also contact us for bank transfer or other payment options.',
                'order' => 4,
                'is_active' => true,
            ],
            [
                'question' => 'Can I send bulk SMS?',
                'answer' => 'Yes, you can send bulk SMS to thousands of recipients at once. You can upload phone numbers via CSV or TXT file, or manually enter them in our system.',
                'order' => 5,
                'is_active' => true,
            ],
            [
                'question' => 'Is there an API available?',
                'answer' => 'Yes, we provide a developer API that you can integrate with your application (PHP, ASP, or other platforms) to send SMS programmatically.',
                'order' => 6,
                'is_active' => true,
            ],
        ];

        foreach ($faqs as $faq) {
            Faq::create($faq);
        }
    }
}
