<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\CardCategory;
use App\Models\CardType;
use App\Models\CardKey;

class CardDataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Create Card Categories
        $carnival = CardCategory::create([
            'name' => 'Carnival',
            'order' => 1,
            'is_active' => true,
        ]);

        $udoy = CardCategory::create([
            'name' => 'Udoy (ADN)',
            'order' => 2,
            'is_active' => true,
        ]);

        // Create Card Types for Carnival
        $card7tk = CardType::create([
            'card_category_id' => $carnival->id,
            'name' => '7 Taka Card',
            'price' => 7,
            'description' => 'Unlimited internet access for 7 days',
            'validity_value' => 7,
            'validity_type' => 'days',
            'order' => 1,
            'is_active' => true,
        ]);

        $card15tk = CardType::create([
            'card_category_id' => $carnival->id,
            'name' => '15 Taka Card',
            'price' => 15,
            'description' => 'Unlimited internet access for 15 days',
            'validity_value' => 15,
            'validity_type' => 'days',
            'order' => 2,
            'is_active' => true,
        ]);

        // Create Card Types for Udoy
        $card10tk = CardType::create([
            'card_category_id' => $udoy->id,
            'name' => '10 Taka Card',
            'price' => 10,
            'description' => 'High-speed internet for 24 hours',
            'validity_value' => 24,
            'validity_type' => 'hours',
            'order' => 1,
            'is_active' => true,
        ]);

        $card20tk = CardType::create([
            'card_category_id' => $udoy->id,
            'name' => '20 Taka Card',
            'price' => 20,
            'description' => 'High-speed internet for 3 days',
            'validity_value' => 3,
            'validity_type' => 'days',
            'order' => 2,
            'is_active' => true,
        ]);

        // Add sample card keys for each type
        $this->addCardKeys($card7tk->id, 10);
        $this->addCardKeys($card15tk->id, 10);
        $this->addCardKeys($card10tk->id, 10);
        $this->addCardKeys($card20tk->id, 10);

        $this->command->info('✅ Card categories, types, and keys created successfully!');
    }

    /**
     * Add card keys for a card type
     */
    private function addCardKeys($cardTypeId, $count)
    {
        for ($i = 1; $i <= $count; $i++) {
            CardKey::create([
                'card_type_id' => $cardTypeId,
                'key_code' => strtoupper(bin2hex(random_bytes(6))),
                'status' => 'available',
            ]);
        }
    }
}

