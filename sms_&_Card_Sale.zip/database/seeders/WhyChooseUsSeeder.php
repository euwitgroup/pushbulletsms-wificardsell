<?php

namespace Database\Seeders;

use App\Models\WhyChooseUs;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class WhyChooseUsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $features = [
            [
                'icon' => 'fas fa-language',
                'title' => 'Bangla SMS Support',
                'description' => 'আমার সেবার বাংলা আমি তোমায় ভালোবাসি. Standard unicode characters count system',
                'order' => 1,
                'is_active' => true,
            ],
            [
                'icon' => 'fas fa-map-marker-alt',
                'title' => 'Location Based SMS',
                'description' => 'We Can send Location Wise SMS All 500m to 50km Radius from your target location',
                'order' => 2,
                'is_active' => true,
            ],
            [
                'icon' => 'fas fa-list-ol',
                'title' => 'Long SMS Support',
                'description' => 'Send SMS Max 1500 characters, Max 10 Standard SMS part Count',
                'order' => 3,
                'is_active' => true,
            ],
            [
                'icon' => 'fas fa-users',
                'title' => 'Unlimited User',
                'description' => 'You Can Create unlimited user under your account, And your sub user also can Create sub account.',
                'order' => 4,
                'is_active' => true,
            ],
            [
                'icon' => 'fas fa-file-csv',
                'title' => 'Send SMS From CVS & TXT File',
                'description' => 'You Can send SMS from CVS or TXT file. its help to Send large SMS Volume',
                'order' => 5,
                'is_active' => true,
            ],
            [
                'icon' => 'fas fa-wallet',
                'title' => 'BKash Payment',
                'description' => 'You Can Buy SMS any time 24/7 Automatic through bkash Marchant Payment',
                'order' => 6,
                'is_active' => true,
            ],
            [
                'icon' => 'fas fa-code',
                'title' => 'Developer API',
                'description' => 'Integrate our API with Other Application,php,asp,other',
                'order' => 7,
                'is_active' => true,
            ],
            [
                'icon' => 'fas fa-headset',
                'title' => 'Great Support',
                'description' => 'You can Get Support Over Phone,Email & Online tickets',
                'order' => 8,
                'is_active' => true,
            ],
        ];

        foreach ($features as $feature) {
            WhyChooseUs::create($feature);
        }
    }
}
