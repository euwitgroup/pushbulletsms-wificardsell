<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('notifications', function (Blueprint $table) {
            $table->foreignId('sms_template_id')->nullable()->after('user_id')->constrained('sms_templates')->onDelete('set null');
            $table->boolean('send_sms')->default(false)->after('link');
            $table->boolean('sms_sent')->default(false)->after('send_sms');
            $table->timestamp('sms_sent_at')->nullable()->after('sms_sent');
            $table->text('sms_error')->nullable()->after('sms_sent_at');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('notifications', function (Blueprint $table) {
            $table->dropForeign(['sms_template_id']);
            $table->dropColumn(['sms_template_id', 'send_sms', 'sms_sent', 'sms_sent_at', 'sms_error']);
        });
    }
};
