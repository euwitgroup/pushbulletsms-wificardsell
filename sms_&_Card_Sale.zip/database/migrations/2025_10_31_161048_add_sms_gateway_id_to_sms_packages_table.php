<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('sms_packages', function (Blueprint $table) {
            $table->foreignId('sms_gateway_id')->nullable()->after('id')->constrained('sms_gateways')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('sms_packages', function (Blueprint $table) {
            $table->dropForeign(['sms_gateway_id']);
            $table->dropColumn('sms_gateway_id');
        });
    }
};
