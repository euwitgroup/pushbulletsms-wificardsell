<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('address')->nullable()->after('phone');
            $table->string('city')->nullable()->after('address');
            $table->string('state')->nullable()->after('city');
            $table->string('postal_code', 20)->nullable()->after('state');
            $table->string('country')->default('Bangladesh')->after('postal_code');
            $table->date('date_of_birth')->nullable()->after('country');
            $table->enum('gender', ['male', 'female', 'other'])->nullable()->after('date_of_birth');
            $table->string('profile_photo')->nullable()->after('gender');
            
            // KYC Fields
            $table->enum('kyc_status', ['not_submitted', 'pending', 'approved', 'rejected'])->default('not_submitted')->after('profile_photo');
            $table->string('nid_number', 20)->nullable()->after('kyc_status');
            $table->string('nid_front')->nullable()->after('nid_number');
            $table->string('nid_back')->nullable()->after('nid_front');
            $table->string('passport_number', 20)->nullable()->after('nid_back');
            $table->string('passport_photo')->nullable()->after('passport_number');
            $table->string('driving_license')->nullable()->after('passport_photo');
            $table->text('kyc_notes')->nullable()->after('driving_license');
            $table->timestamp('kyc_submitted_at')->nullable()->after('kyc_notes');
            $table->timestamp('kyc_verified_at')->nullable()->after('kyc_submitted_at');
            $table->unsignedBigInteger('kyc_verified_by')->nullable()->after('kyc_verified_at');
            
            $table->foreign('kyc_verified_by')->references('id')->on('users')->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropForeign(['kyc_verified_by']);
            $table->dropColumn([
                'address', 'city', 'state', 'postal_code', 'country', 'date_of_birth', 'gender', 'profile_photo',
                'kyc_status', 'nid_number', 'nid_front', 'nid_back', 'passport_number', 'passport_photo',
                'driving_license', 'kyc_notes', 'kyc_submitted_at', 'kyc_verified_at', 'kyc_verified_by'
            ]);
        });
    }
};
