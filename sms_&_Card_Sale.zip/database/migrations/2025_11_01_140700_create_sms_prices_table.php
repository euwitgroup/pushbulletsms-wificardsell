<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sms_prices', function (Blueprint $table) {
            $table->id();
            $table->string('package_name'); // NON MASKING 1, NON MASKING 2, MASKING PER SMS
            $table->string('package_type'); // non_masking_1, non_masking_2, masking
            $table->decimal('base_price', 10, 2); // 0.35, 0.33, 0.55
            $table->text('pricing_tiers')->nullable(); // JSON format for bulk pricing
            $table->integer('minimum_buy'); // Minimum SMS purchase
            $table->text('features'); // JSON format for all features
            $table->integer('order')->default(0);
            $table->boolean('is_active')->default(true);
            $table->boolean('is_featured')->default(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sms_prices');
    }
};
