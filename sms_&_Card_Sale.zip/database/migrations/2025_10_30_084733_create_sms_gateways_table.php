<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sms_gateways', function (Blueprint $table) {
            $table->id();
            $table->string('gateway_name')->unique(); // 'bulksmsbd' or 'pushbullet'
            $table->string('api_key')->nullable();
            $table->string('sender_id')->nullable();
            $table->string('api_url')->nullable();
            $table->string('message_type')->default('text'); // text or unicode
            $table->string('device_name')->nullable();
            $table->string('device_id')->nullable();
            $table->boolean('is_active')->default(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sms_gateways');
    }
};
