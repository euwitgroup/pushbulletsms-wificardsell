<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('transactions', function (Blueprint $table) {
            $table->decimal('base_amount', 10, 2)->nullable()->after('amount')->comment('Original amount before gateway fee');
            $table->decimal('gateway_fee', 10, 2)->default(0)->after('base_amount')->comment('Gateway processing fee');
            $table->decimal('gateway_fee_percentage', 5, 2)->nullable()->after('gateway_fee')->comment('Gateway fee percentage');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('transactions', function (Blueprint $table) {
            $table->dropColumn(['base_amount', 'gateway_fee', 'gateway_fee_percentage']);
        });
    }
};
