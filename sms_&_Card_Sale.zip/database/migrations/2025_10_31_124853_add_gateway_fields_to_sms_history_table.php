<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('sms_history', function (Blueprint $table) {
            $table->foreignId('sms_gateway_id')->nullable()->after('user_id')->constrained('sms_gateways')->onDelete('set null');
            $table->integer('sms_count')->default(1)->after('cost');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('sms_history', function (Blueprint $table) {
            $table->dropForeign(['sms_gateway_id']);
            $table->dropColumn(['sms_gateway_id', 'sms_count']);
        });
    }
};
