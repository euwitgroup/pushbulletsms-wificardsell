<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\InstallController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Auth\SocialLoginController;
use App\Http\Controllers\Auth\ForgotPasswordController;
use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Admin\UserController as AdminUserController;
use App\Http\Controllers\Admin\SettingController;
use App\Http\Controllers\Admin\SmsPackageController;
use App\Http\Controllers\Admin\SmsTemplateController;
use App\Http\Controllers\Admin\SmsGatewayController;
use App\Http\Controllers\Admin\PaymentGatewayController;
use App\Http\Controllers\Admin\InvoiceController;
use App\Http\Controllers\Admin\TestPaymentController;
use App\Http\Controllers\Admin\NotificationController as AdminNotificationController;
use App\Http\Controllers\Admin\KycController as AdminKycController;
use App\Http\Controllers\Admin\HeroSliderController;
use App\Http\Controllers\Admin\WhyChooseUsController;
use App\Http\Controllers\Admin\FaqController;
use App\Http\Controllers\Admin\BlogController;
use App\Http\Controllers\Admin\ComparisonController;
use App\Http\Controllers\Admin\SmsPriceController;
use App\Http\Controllers\User\DashboardController as UserDashboardController;
use App\Http\Controllers\User\SmsController;
use App\Http\Controllers\User\PaymentController;
use App\Http\Controllers\User\NotificationController as UserNotificationController;
use App\Http\Controllers\User\ProfileController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\BlogController as FrontendBlogController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\Admin\ContactInfoController;
use App\Http\Controllers\Admin\WifiCardController;
use App\Http\Controllers\Admin\CardCategoryController;
use App\Http\Controllers\Admin\CardTypeController;
use App\Http\Controllers\Admin\CardKeyController;
use App\Http\Controllers\Admin\CardInventoryController;
use App\Http\Controllers\Admin\CardHistoryController;
use App\Http\Controllers\Admin\CardTransactionController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// ========================================
// Installation Routes
// ========================================
Route::prefix('install')->name('install.')->group(function () {
    Route::get('/', [InstallController::class, 'index'])->name('index');
    Route::get('/requirements', [InstallController::class, 'requirements'])->name('requirements');
    Route::get('/database', [InstallController::class, 'database'])->name('database');
    Route::post('/test-database', [InstallController::class, 'testDatabase'])->name('test-database');
    Route::post('/setup-database', [InstallController::class, 'setupDatabase'])->name('setup-database');
    Route::get('/site-config', [InstallController::class, 'siteConfig'])->name('site-config');
    Route::post('/save-site-config', [InstallController::class, 'saveSiteConfig'])->name('save-site-config');
    Route::get('/complete', [InstallController::class, 'complete'])->name('complete');
});

// Guest routes
Route::get('/', [HomeController::class, 'index'])->name('home');

// Blog Routes (Public)
Route::get('/blog', [FrontendBlogController::class, 'index'])->name('blog.index');
Route::get('/blog/{slug}', [FrontendBlogController::class, 'show'])->name('blog.show');

// Contact Route (Public)
Route::get('/contact', [ContactController::class, 'index'])->name('contact');

// WiFi Cards Routes (Public)
Route::get('/wifi-cards', [\App\Http\Controllers\WifiCardController::class, 'index'])->name('wifi-cards.index');
Route::get('/wifi-cards/{id}/checkout', [\App\Http\Controllers\WifiCardController::class, 'checkout'])->name('wifi-cards.checkout');
Route::post('/wifi-cards/{id}/process-payment', [\App\Http\Controllers\WifiCardController::class, 'processPayment'])->name('wifi-cards.process-payment');
Route::get('/wifi-cards/payment/success', [\App\Http\Controllers\WifiCardController::class, 'paymentSuccess'])->name('wifi-cards.payment.success');
Route::get('/wifi-cards/payment/cancel', [\App\Http\Controllers\WifiCardController::class, 'paymentCancel'])->name('wifi-cards.payment.cancel');
Route::post('/wifi-cards/payment/webhook', [\App\Http\Controllers\WifiCardController::class, 'paymentWebhook'])->name('wifi-cards.payment.webhook');

// Authentication Routes
Route::middleware('guest')->group(function () {
    Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [LoginController::class, 'login']);
    Route::get('/register', [RegisterController::class, 'showRegistrationForm'])->name('register');
    Route::post('/register', [RegisterController::class, 'register']);
    Route::post('/register/send-otp', [RegisterController::class, 'sendOtp'])->name('register.send-otp');
    
    // OTP Verification Routes
    Route::get('/verify-otp', [RegisterController::class, 'showOtpForm'])->name('verify.otp');
    Route::post('/verify-otp', [RegisterController::class, 'verifyOtp'])->name('verify.otp.submit');
    Route::post('/resend-otp', [RegisterController::class, 'resendOtp'])->name('resend.otp');
    
    // Forgot Password Routes
    Route::get('/forgot-password', [ForgotPasswordController::class, 'showForgotForm'])->name('password.request');
    Route::post('/forgot-password', [ForgotPasswordController::class, 'sendOtp'])->name('password.send-otp');
    Route::get('/reset-password', [ForgotPasswordController::class, 'showResetForm'])->name('password.reset');
    Route::post('/reset-password', [ForgotPasswordController::class, 'resetPassword'])->name('password.update');
    
    // Social Login Routes
    Route::get('/auth/google', [SocialLoginController::class, 'redirectToGoogle'])->name('auth.google');
    Route::get('/auth/google/callback', [SocialLoginController::class, 'handleGoogleCallback'])->name('auth.google.callback');
    Route::get('/auth/facebook', [SocialLoginController::class, 'redirectToFacebook'])->name('auth.facebook');
    Route::get('/auth/facebook/callback', [SocialLoginController::class, 'handleFacebookCallback'])->name('auth.facebook.callback');
});

Route::post('/logout', [LoginController::class, 'logout'])->name('logout')->middleware('auth');

// Admin Routes
Route::prefix('admin')->name('admin.')->middleware(['auth', 'admin'])->group(function () {
    Route::get('/dashboard', [AdminDashboardController::class, 'index'])->name('dashboard');
    
    // User Management
    Route::resource('users', AdminUserController::class);
    Route::post('users/{user}/toggle-status', [AdminUserController::class, 'toggleStatus'])->name('users.toggle-status');
    Route::post('users/{user}/add-balance', [AdminUserController::class, 'addBalance'])->name('users.add-balance');
    
    // SMS Package Management
    Route::resource('packages', SmsPackageController::class);
    Route::post('packages/{package}/toggle-status', [SmsPackageController::class, 'toggleStatus'])->name('packages.toggle-status');
    
    // Settings
    Route::get('/settings', [SettingController::class, 'index'])->name('settings');
    Route::post('/settings', [SettingController::class, 'update'])->name('settings.update');
    Route::post('/settings/test-mail', [SettingController::class, 'testMail'])->name('settings.test-mail');
    
    // Reports
    Route::get('/transactions', [AdminDashboardController::class, 'transactions'])->name('transactions');
    Route::get('/transactions/export', [AdminDashboardController::class, 'exportTransactions'])->name('transactions.export');
    Route::get('/sms-history', [AdminDashboardController::class, 'smsHistory'])->name('sms-history');
    
    // SMS Management
    Route::resource('sms-templates', SmsTemplateController::class);
    Route::post('sms-templates/{smsTemplate}/toggle-status', [SmsTemplateController::class, 'toggleStatus'])->name('sms-templates.toggle-status');
    
    // SMS Gateway
    Route::get('/sms-gateway', [SmsGatewayController::class, 'index'])->name('sms-gateway.index');
    Route::get('/sms-gateway/{gateway}/edit', [SmsGatewayController::class, 'edit'])->name('sms-gateway.edit');
    Route::get('/sms-gateway/{gateway}/test', [SmsGatewayController::class, 'test'])->name('sms-gateway.test');
    Route::put('/sms-gateway/{gateway}', [SmsGatewayController::class, 'update'])->name('sms-gateway.update');
    Route::post('/sms-gateway/{gateway}/toggle-status', [SmsGatewayController::class, 'toggleStatus'])->name('sms-gateway.toggle-status');
    Route::post('/sms-gateway/{gateway}/test-send', [SmsGatewayController::class, 'testSend'])->name('sms-gateway.test-send');
    Route::get('/sms-gateway/{gateway}/devices', [SmsGatewayController::class, 'getDevices'])->name('sms-gateway.devices');
    
    // SMS Management
    Route::get('/sms-management', [SmsGatewayController::class, 'management'])->name('sms-management');
    Route::post('/sms-management/{gateway}/update-cost', [SmsGatewayController::class, 'updateCost'])->name('sms-management.update-cost');
    
    // Payment Gateway
    Route::get('/payment-methods', [PaymentGatewayController::class, 'list'])->name('payment-methods');
    Route::get('/payment-gateway', [PaymentGatewayController::class, 'index'])->name('payment-gateway');
    Route::post('/payment-gateway/{gateway}/update', [PaymentGatewayController::class, 'update'])->name('payment-gateway.update');
    Route::post('/payment-gateway/{gateway}/test', [PaymentGatewayController::class, 'testConnection'])->name('payment-gateway.test');
    
    // Invoices
    Route::get('/invoices', [InvoiceController::class, 'index'])->name('invoices');
    Route::get('/invoices/export', [InvoiceController::class, 'export'])->name('invoices.export');
    Route::get('/invoices/{id}/download', [InvoiceController::class, 'download'])->name('invoices.download');
    
    // Test Payment
    Route::get('/test-payment', [TestPaymentController::class, 'index'])->name('test-payment');
    Route::post('/test-payment/initiate', [TestPaymentController::class, 'initiatePayment'])->name('test-payment.initiate');
    
    // Notifications
    Route::get('/notifications', [AdminNotificationController::class, 'index'])->name('notifications.index');
    Route::post('/notifications/{id}/read', [AdminNotificationController::class, 'markAsRead'])->name('notifications.read');
    Route::post('/notifications/mark-all-read', [AdminNotificationController::class, 'markAllAsRead'])->name('notifications.mark-all-read');
    Route::delete('/notifications/{id}', [AdminNotificationController::class, 'destroy'])->name('notifications.destroy');
    Route::delete('/notifications/delete-all-read', [AdminNotificationController::class, 'deleteAllRead'])->name('notifications.delete-all-read');
    Route::get('/notifications/unread-count', [AdminNotificationController::class, 'getUnreadCount'])->name('notifications.unread-count');
    Route::get('/notifications/recent', [AdminNotificationController::class, 'getRecent'])->name('notifications.recent');
    
    // KYC Management
    Route::get('/kyc', [AdminKycController::class, 'index'])->name('kyc.index');
    Route::get('/kyc/{id}', [AdminKycController::class, 'show'])->name('kyc.show');
    Route::post('/kyc/{id}/approve', [AdminKycController::class, 'approve'])->name('kyc.approve');
    Route::post('/kyc/{id}/reject', [AdminKycController::class, 'reject'])->name('kyc.reject');
    Route::post('/kyc/{id}/resubmit', [AdminKycController::class, 'requestResubmission'])->name('kyc.resubmit');
    
    // Hero Slider Management
    Route::resource('hero-sliders', HeroSliderController::class);
    Route::post('hero-sliders/{heroSlider}/toggle-status', [HeroSliderController::class, 'toggleStatus'])->name('hero-sliders.toggle-status');
    
    // Why Choose Us Management
    Route::resource('why-choose-us', WhyChooseUsController::class);
    Route::post('why-choose-us/{whyChooseUs}/toggle-status', [WhyChooseUsController::class, 'toggleStatus'])->name('why-choose-us.toggle-status');
    
    // FAQ Management
    Route::resource('faqs', FaqController::class);
    Route::post('faqs/{faq}/toggle-status', [FaqController::class, 'toggleStatus'])->name('faqs.toggle-status');
    
    // Blog Management
    Route::resource('blogs', BlogController::class);
    Route::post('blogs/{blog}/toggle-status', [BlogController::class, 'toggleStatus'])->name('blogs.toggle-status');
    
    // Comparison Management
    Route::resource('comparisons', ComparisonController::class);
    Route::post('comparisons/{comparison}/toggle-status', [ComparisonController::class, 'toggleStatus'])->name('comparisons.toggle-status');
    
    // SMS Pricing Management
    Route::resource('sms-prices', SmsPriceController::class);
    Route::post('sms-prices/{smsPrice}/toggle-status', [SmsPriceController::class, 'toggleStatus'])->name('sms-prices.toggle-status');
    
    // Contact Information Management
    Route::resource('contact-info', ContactInfoController::class);
    Route::post('contact-info/{contactInfo}/toggle-status', [ContactInfoController::class, 'toggleStatus'])->name('contact-info.toggle-status');
    
    // WiFi Card Management
    Route::get('wifi-cards', [WifiCardController::class, 'index'])->name('wifi-cards.index');
    
    // Card Categories
    Route::resource('card-categories', CardCategoryController::class)->except(['show', 'create']);
    Route::post('card-categories/{cardCategory}/toggle-status', [CardCategoryController::class, 'toggleStatus'])->name('card-categories.toggle-status');
    
    // Card Types
    Route::resource('card-types', CardTypeController::class)->except(['show', 'create']);
    Route::post('card-types/{cardType}/toggle-status', [CardTypeController::class, 'toggleStatus'])->name('card-types.toggle-status');
    
    // Card Keys (Service Keys)
    Route::get('card-keys', [CardKeyController::class, 'index'])->name('card-keys.index');
    Route::post('card-keys', [CardKeyController::class, 'store'])->name('card-keys.store');
    Route::delete('card-keys/{cardKey}', [CardKeyController::class, 'destroy'])->name('card-keys.destroy');
    Route::post('card-keys/bulk-delete', [CardKeyController::class, 'bulkDelete'])->name('card-keys.bulk-delete');
    Route::get('card-types-by-category/{categoryId}', [CardKeyController::class, 'getCardTypes'])->name('card-types-by-category');
    
    // Inventory
    Route::get('card-inventory', [CardInventoryController::class, 'index'])->name('card-inventory.index');
    
    // Card History
    Route::get('card-history', [CardHistoryController::class, 'index'])->name('card-history.index');
    
    // Card Transactions
    Route::get('card-transactions', [CardTransactionController::class, 'index'])->name('card-transactions.index');
    Route::get('card-transactions/{transaction}', [CardTransactionController::class, 'show'])->name('card-transactions.show');
    Route::post('card-transactions/{transaction}/update-status', [CardTransactionController::class, 'updateStatus'])->name('card-transactions.update-status');
});

// User Routes
Route::prefix('user')->name('user.')->middleware(['auth', 'user'])->group(function () {
    Route::get('/dashboard', [UserDashboardController::class, 'index'])->name('dashboard');
    
    // SMS Management
    Route::get('/send-sms', [SmsController::class, 'create'])->name('sms.create');
    Route::post('/send-sms', [SmsController::class, 'store'])->name('sms.store');
    Route::post('/send-sms/bulk', [SmsController::class, 'bulk'])->name('sms.bulk');
    Route::get('/sms-template-download', [SmsController::class, 'downloadTemplate'])->name('sms.template');
    Route::get('/sms-history', [SmsController::class, 'history'])->name('sms.history');
    
    // Payment/Balance
    Route::get('/buy-balance', [PaymentController::class, 'showPackages'])->name('payment.packages');
    Route::post('/buy-balance', [PaymentController::class, 'initiate'])->name('payment.initiate');
    Route::get('/transactions', [PaymentController::class, 'transactions'])->name('transactions');
    
    // Notifications
    Route::get('/notifications', [UserNotificationController::class, 'index'])->name('notifications.index');
    Route::post('/notifications/{id}/read', [UserNotificationController::class, 'markAsRead'])->name('notifications.read');
    Route::post('/notifications/mark-all-read', [UserNotificationController::class, 'markAllAsRead'])->name('notifications.mark-all-read');
    Route::delete('/notifications/{id}', [UserNotificationController::class, 'destroy'])->name('notifications.destroy');
    Route::delete('/notifications/delete-all-read', [UserNotificationController::class, 'deleteAllRead'])->name('notifications.delete-all-read');
    Route::get('/notifications/unread-count', [UserNotificationController::class, 'getUnreadCount'])->name('notifications.unread-count');
    Route::get('/notifications/recent', [UserNotificationController::class, 'getRecent'])->name('notifications.recent');
    
    // Profile & KYC
    Route::get('/profile', [ProfileController::class, 'index'])->name('profile');
    Route::post('/profile/update', [ProfileController::class, 'updateProfile'])->name('profile.update');
    Route::post('/profile/password', [ProfileController::class, 'updatePassword'])->name('profile.password');
    Route::post('/profile/kyc', [ProfileController::class, 'submitKyc'])->name('profile.kyc');
    Route::post('/profile/send-verification-email', [ProfileController::class, 'sendVerificationEmail'])->name('profile.send-verification');
    Route::get('/email/verify/{id}/{hash}', [ProfileController::class, 'verifyEmail'])->name('verification.verify');
});

// Payment Callback Routes
Route::get('/payment/success', [PaymentController::class, 'success'])->middleware('auth')->name('payment.success');
Route::get('/payment/cancel', [PaymentController::class, 'cancel'])->middleware('auth')->name('payment.cancel');
Route::post('/payment/webhook', [PaymentController::class, 'webhook'])->name('payment.webhook'); // No auth for webhook
