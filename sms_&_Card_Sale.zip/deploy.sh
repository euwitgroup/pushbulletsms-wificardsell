#!/bin/bash

# ========================================
# SMS & Card Sale - Deployment Script
# ========================================
# This script automates the deployment process
# Run with: bash deploy.sh

echo "=================================="
echo " SMS & Card Sale - Deployment"
echo "=================================="
echo ""

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}Please run as root (sudo bash deploy.sh)${NC}"
    exit 1
fi

echo -e "${YELLOW}Step 1: Entering maintenance mode...${NC}"
php artisan down || echo "Maintenance mode not enabled"
echo ""

echo -e "${YELLOW}Step 2: Pulling latest changes from Git...${NC}"
git pull origin main
echo ""

echo -e "${YELLOW}Step 3: Installing Composer dependencies...${NC}"
composer install --no-dev --optimize-autoloader
echo ""

echo -e "${YELLOW}Step 4: Installing NPM dependencies...${NC}"
npm install
echo ""

echo -e "${YELLOW}Step 5: Building assets...${NC}"
npm run production
echo ""

echo -e "${YELLOW}Step 6: Running database migrations...${NC}"
php artisan migrate --force
echo ""

echo -e "${YELLOW}Step 7: Clearing caches...${NC}"
php artisan cache:clear
php artisan config:clear
php artisan route:clear
php artisan view:clear
echo ""

echo -e "${YELLOW}Step 8: Caching for production...${NC}"
php artisan config:cache
php artisan route:cache
php artisan view:cache
echo ""

echo -e "${YELLOW}Step 9: Creating storage link...${NC}"
php artisan storage:link
echo ""

echo -e "${YELLOW}Step 10: Setting permissions...${NC}"
chown -R www-data:www-data storage bootstrap/cache
chmod -R 775 storage bootstrap/cache
echo ""

echo -e "${YELLOW}Step 11: Restarting services...${NC}"
systemctl restart nginx || systemctl restart apache2
supervisorctl restart sms-card-sale-worker:* 2>/dev/null || echo "Queue workers not configured"
echo ""

echo -e "${YELLOW}Step 12: Bringing application back online...${NC}"
php artisan up
echo ""

echo -e "${GREEN}=================================="
echo " Deployment Completed Successfully!"
echo "==================================${NC}"
echo ""
echo "Next steps:"
echo "1. Test your website: https://yourdomain.com"
echo "2. Check logs: tail -f storage/logs/laravel.log"
echo "3. Monitor server: htop"
echo ""

