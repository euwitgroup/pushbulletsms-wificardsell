# 🚀 SMS & Card Sale - Live Server Deployment Guide

## 📋 Pre-Deployment Checklist

### ✅ Before You Deploy

- [ ] Backup your local database
- [ ] Test all features locally
- [ ] Review all environment variables
- [ ] Update payment gateway credentials
- [ ] Update SMS gateway credentials
- [ ] Set up domain and SSL certificate
- [ ] Prepare database for production
- [ ] Review security settings

---

## 🖥️ Server Requirements

### Minimum Requirements:
- **PHP**: 8.1 or higher
- **MySQL**: 5.7 or higher (or MariaDB 10.3+)
- **Composer**: Latest version
- **Node.js**: 14.x or higher (for asset compilation)
- **Web Server**: Apache 2.4+ or Nginx 1.18+

### PHP Extensions Required:
```
- BCMath
- Ctype
- Fileinfo
- JSON
- Mbstring
- OpenSSL
- PDO
- Tokenizer
- XML
- GD
- Curl
- Zip
```

### Recommended:
- **RAM**: Minimum 2GB
- **Storage**: Minimum 10GB
- **SSL Certificate**: Let's Encrypt (Free)

---

## 📦 Step 1: Server Setup

### For Ubuntu/Debian Server:

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install PHP 8.2 and required extensions
sudo apt install -y php8.2-fpm php8.2-mysql php8.2-mbstring php8.2-xml php8.2-bcmath php8.2-curl php8.2-gd php8.2-zip php8.2-tokenizer

# Install MySQL
sudo apt install -y mysql-server

# Install Composer
curl -sS https://getcomposer.org/installer | sudo php -- --install-dir=/usr/local/bin --filename=composer

# Install Nginx
sudo apt install -y nginx

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs
```

---

## 🗂️ Step 2: Upload Project Files

### Option A: Using Git (Recommended)

```bash
# On your server
cd /var/www/
sudo git clone YOUR_REPOSITORY_URL sms-card-sale
cd sms-card-sale
sudo chown -R www-data:www-data /var/www/sms-card-sale
```

### Option B: Using FTP/SFTP

1. Use FileZilla or similar FTP client
2. Upload all files to `/var/www/sms-card-sale/`
3. Set proper permissions (see Step 4)

### Option C: Using SCP

```bash
# From your local machine
scp -r /path/to/project username@your-server-ip:/var/www/sms-card-sale
```

---

## ⚙️ Step 3: Install Dependencies

```bash
cd /var/www/sms-card-sale

# Install PHP dependencies
composer install --optimize-autoloader --no-dev

# Install Node.js dependencies
npm install

# Build assets for production
npm run production
```

---

## 🔐 Step 4: Set Permissions

```bash
# Set ownership
sudo chown -R www-data:www-data /var/www/sms-card-sale

# Set directory permissions
sudo find /var/www/sms-card-sale -type d -exec chmod 755 {} \;

# Set file permissions
sudo find /var/www/sms-card-sale -type f -exec chmod 644 {} \;

# Set storage and cache permissions
sudo chmod -R 775 /var/www/sms-card-sale/storage
sudo chmod -R 775 /var/www/sms-card-sale/bootstrap/cache
```

---

## 🔧 Step 5: Configure Environment

```bash
# Copy environment file
cp .env.example .env

# Generate application key
php artisan key:generate

# Edit environment file
nano .env
```

### Update these values in `.env`:

```env
APP_NAME="SMS & Card Sale"
APP_ENV=production
APP_DEBUG=false
APP_URL=https://yourdomain.com

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=your_database_name
DB_USERNAME=your_database_user
DB_PASSWORD=your_secure_password

# Email Configuration (Use your SMTP or service)
MAIL_MAILER=smtp
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=noreply@yourdomain.com
MAIL_FROM_NAME="${APP_NAME}"

# Payment Gateway (RupantorPay)
RUPANTORPAY_API_KEY=your_live_api_key

# Pushbullet (Optional)
PUSHBULLET_ACCESS_TOKEN=your_pushbullet_token

# Session & Cache
SESSION_DRIVER=file
CACHE_DRIVER=file
QUEUE_CONNECTION=database

# Security
SESSION_SECURE_COOKIE=true
SESSION_HTTP_ONLY=true
```

---

## 🗄️ Step 6: Database Setup

```bash
# Create database
mysql -u root -p

# In MySQL prompt:
CREATE DATABASE sms_card_sale CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'smsadmin'@'localhost' IDENTIFIED BY 'your_secure_password';
GRANT ALL PRIVILEGES ON sms_card_sale.* TO 'smsadmin'@'localhost';
FLUSH PRIVILEGES;
EXIT;

# Run migrations
php artisan migrate --force

# Seed essential data (Admin user, settings, etc.)
php artisan db:seed --force
```

---

## 🌐 Step 7: Configure Web Server

### For Nginx:

Create file: `/etc/nginx/sites-available/sms-card-sale`

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name yourdomain.com www.yourdomain.com;
    root /var/www/sms-card-sale/public;

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";

    index index.php;

    charset utf-8;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }

    error_page 404 /index.php;

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }

    # Security headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css text/xml text/javascript application/json application/javascript application/xml+rss application/rss+xml font/truetype font/opentype application/vnd.ms-fontobject image/svg+xml;

    # Client max body size (for file uploads)
    client_max_body_size 20M;
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/sms-card-sale /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

### For Apache:

Create file: `/etc/apache2/sites-available/sms-card-sale.conf`

```apache
<VirtualHost *:80>
    ServerName yourdomain.com
    ServerAlias www.yourdomain.com
    DocumentRoot /var/www/sms-card-sale/public

    <Directory /var/www/sms-card-sale/public>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    # Security headers
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-XSS-Protection "1; mode=block"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"

    ErrorLog ${APACHE_LOG_DIR}/sms-card-sale-error.log
    CustomLog ${APACHE_LOG_DIR}/sms-card-sale-access.log combined
</VirtualHost>
```

```bash
# Enable required modules
sudo a2enmod rewrite headers

# Enable site
sudo a2ensite sms-card-sale.conf

# Restart Apache
sudo systemctl restart apache2
```

---

## 🔒 Step 8: Install SSL Certificate (HTTPS)

### Using Let's Encrypt (Free):

```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-nginx

# For Nginx:
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# For Apache:
sudo apt install python3-certbot-apache
sudo certbot --apache -d yourdomain.com -d www.yourdomain.com

# Auto-renewal (already set up by Certbot)
sudo systemctl status certbot.timer
```

---

## ⚡ Step 9: Optimize for Production

```bash
# Cache configuration
php artisan config:cache

# Cache routes
php artisan route:cache

# Cache views
php artisan view:cache

# Optimize autoloader
composer dump-autoload --optimize
```

---

## 🔄 Step 10: Set Up Scheduled Tasks

```bash
# Edit crontab
sudo crontab -e -u www-data

# Add this line:
* * * * * cd /var/www/sms-card-sale && php artisan schedule:run >> /dev/null 2>&1
```

This will run:
- **Auto-release expired pending cards** (every minute)
- Any other scheduled tasks you add

---

## 🔄 Step 11: Set Up Queue Workers (Optional but Recommended)

### Create Supervisor Configuration:

```bash
sudo nano /etc/supervisor/conf.d/sms-card-sale-worker.conf
```

Add this content:

```ini
[program:sms-card-sale-worker]
process_name=%(program_name)s_%(process_num)02d
command=php /var/www/sms-card-sale/artisan queue:work database --sleep=3 --tries=3 --max-time=3600
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
user=www-data
numprocs=2
redirect_stderr=true
stdout_logfile=/var/www/sms-card-sale/storage/logs/worker.log
stopwaitsecs=3600
```

```bash
# Update supervisor
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start sms-card-sale-worker:*
```

---

## 📊 Step 12: Configure Logging

```bash
# Create log rotation
sudo nano /etc/logrotate.d/laravel

# Add:
/var/www/sms-card-sale/storage/logs/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 www-data www-data
    sharedscripts
}
```

---

## 🔥 Step 13: Configure Firewall

```bash
# Install UFW
sudo apt install ufw

# Allow SSH (IMPORTANT - Do this first!)
sudo ufw allow 22/tcp

# Allow HTTP and HTTPS
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Enable firewall
sudo ufw enable

# Check status
sudo ufw status
```

---

## 🔐 Step 14: Security Hardening

### 1. Secure MySQL:
```bash
sudo mysql_secure_installation
```

### 2. Disable Directory Listing:
Already configured in Nginx/Apache config above

### 3. Hide Laravel Version:
```bash
# Edit public/index.php - Remove or obfuscate version info
```

### 4. Set Up Fail2Ban (Prevent brute force):
```bash
sudo apt install fail2ban
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

---

## 🧪 Step 15: Test Your Deployment

### Check these URLs:

1. **Homepage**: `https://yourdomain.com`
2. **Admin Login**: `https://yourdomain.com/login`
3. **WiFi Cards**: `https://yourdomain.com/wifi-cards`
4. **Blog**: `https://yourdomain.com/blog`
5. **Contact**: `https://yourdomain.com/contact`

### Test functionality:

- [ ] Admin can login
- [ ] Users can register
- [ ] SMS sending works
- [ ] WiFi card purchase works
- [ ] Payment gateway works
- [ ] Email notifications work
- [ ] File uploads work
- [ ] All images load correctly

---

## 📈 Step 16: Monitoring & Maintenance

### Set up monitoring:

```bash
# Check disk space
df -h

# Check memory
free -h

# Check running processes
htop

# Check logs
tail -f /var/www/sms-card-sale/storage/logs/laravel.log
```

### Daily maintenance:

```bash
# Backup database
mysqldump -u smsadmin -p sms_card_sale > backup_$(date +%Y%m%d).sql

# Clean old logs
php artisan telescope:prune
```

---

## 🆘 Troubleshooting

### Issue: "500 Internal Server Error"
```bash
# Check Laravel logs
tail -100 /var/www/sms-card-sale/storage/logs/laravel.log

# Check Nginx/Apache logs
sudo tail -100 /var/log/nginx/error.log
sudo tail -100 /var/log/apache2/error.log

# Clear cache
php artisan cache:clear
php artisan config:clear
php artisan route:clear
php artisan view:clear
```

### Issue: "Storage link not working"
```bash
php artisan storage:link
```

### Issue: "Permission denied"
```bash
sudo chmod -R 775 storage bootstrap/cache
sudo chown -R www-data:www-data storage bootstrap/cache
```

### Issue: "Database connection error"
- Check `.env` database credentials
- Verify MySQL service is running: `sudo systemctl status mysql`
- Test connection: `mysql -u username -p`

---

## 🔄 Updating Your Application

When you need to update your live site:

```bash
cd /var/www/sms-card-sale

# Pull latest changes (if using Git)
sudo git pull origin main

# Update dependencies
composer install --no-dev --optimize-autoloader
npm install && npm run production

# Run migrations
php artisan migrate --force

# Clear and cache
php artisan config:clear
php artisan cache:clear
php artisan config:cache
php artisan route:cache
php artisan view:cache

# Restart services
sudo systemctl restart nginx
sudo supervisorctl restart sms-card-sale-worker:*
```

---

## 📞 Support

If you encounter issues:
1. Check Laravel logs: `storage/logs/laravel.log`
2. Check web server logs
3. Enable debug mode temporarily (ONLY in .env, NEVER commit)
4. Review this guide carefully

---

## ✅ Post-Deployment Checklist

- [ ] SSL certificate installed and working
- [ ] Database backed up
- [ ] All features tested
- [ ] Admin account accessible
- [ ] Payment gateway tested
- [ ] SMS gateway tested
- [ ] Email sending tested
- [ ] Cron jobs running
- [ ] Queue workers running (if enabled)
- [ ] Monitoring set up
- [ ] Firewall configured
- [ ] Backups automated
- [ ] Documentation updated

---

## 🎉 Congratulations!

Your SMS & Card Sale application is now live! 

**Next Steps:**
1. Configure your payment gateway with live credentials
2. Add your SMS gateway API keys
3. Test all critical features
4. Set up automated backups
5. Monitor application performance

---

**Need Help?** Review the troubleshooting section or check Laravel logs for detailed error messages.

