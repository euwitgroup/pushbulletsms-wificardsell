# ⚡ Quick Production Setup Guide

**5-Minute Production Deployment for Experienced Developers**

---

## 🎯 Prerequisites

- Ubuntu 20.04/22.04 server with root access
- Domain pointed to your server IP
- Basic knowledge of Linux/Laravel

---

## 🚀 Rapid Deployment (Copy & Paste Commands)

### 1. Install Stack (5 minutes)

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install PHP 8.2 + Extensions
sudo apt install -y software-properties-common
sudo add-apt-repository ppa:ondrej/php -y
sudo apt update
sudo apt install -y php8.2-fpm php8.2-mysql php8.2-mbstring php8.2-xml php8.2-bcmath php8.2-curl php8.2-gd php8.2-zip

# Install MySQL
sudo apt install -y mysql-server

# Install Nginx
sudo apt install -y nginx

# Install Composer
curl -sS https://getcomposer.org/installer | sudo php -- --install-dir=/usr/local/bin --filename=composer

# Install Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs
```

### 2. Upload & Configure Project (3 minutes)

```bash
# Clone or upload your project
cd /var/www/
sudo git clone YOUR_REPO_URL sms-card-sale
cd sms-card-sale

# Install dependencies
composer install --no-dev --optimize-autoloader
npm install && npm run production

# Configure environment
cp ENV_PRODUCTION_TEMPLATE.txt .env
nano .env  # Update: APP_URL, DB_*, MAIL_*, RUPANTORPAY_API_KEY
php artisan key:generate
```

### 3. Database Setup (2 minutes)

```bash
# Secure MySQL & Create Database
sudo mysql_secure_installation

# Create database
sudo mysql -u root -p
```

```sql
CREATE DATABASE sms_card_sale CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'smsadmin'@'localhost' IDENTIFIED BY 'YOUR_STRONG_PASSWORD';
GRANT ALL PRIVILEGES ON sms_card_sale.* TO 'smsadmin'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

```bash
# Update .env with database credentials, then:
php artisan migrate --force
php artisan db:seed --force
```

### 4. Permissions (30 seconds)

```bash
sudo chown -R www-data:www-data /var/www/sms-card-sale
sudo chmod -R 775 storage bootstrap/cache
php artisan storage:link
```

### 5. Nginx Configuration (2 minutes)

```bash
# Copy and edit config
sudo cp nginx.conf.example /etc/nginx/sites-available/sms-card-sale
sudo nano /etc/nginx/sites-available/sms-card-sale
# Replace: yourdomain.com with your actual domain
# Update: SSL paths (after getting certificate)

# Enable site
sudo ln -s /etc/nginx/sites-available/sms-card-sale /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 6. SSL Certificate (2 minutes)

```bash
# Install Certbot
sudo apt install -y certbot python3-certbot-nginx

# Get certificate
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
# Follow prompts, select "Redirect HTTP to HTTPS"
```

### 7. Cron & Optimization (1 minute)

```bash
# Setup cron
sudo crontab -e -u www-data
# Add this line:
* * * * * cd /var/www/sms-card-sale && php artisan schedule:run >> /dev/null 2>&1

# Cache for production
cd /var/www/sms-card-sale
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

### 8. Firewall (1 minute)

```bash
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

---

## ✅ Quick Test

```bash
# Check if site is running
curl -I https://yourdomain.com

# Check Laravel logs
tail -f /var/www/sms-card-sale/storage/logs/laravel.log
```

Visit: `https://yourdomain.com`

**Admin Login**: `https://yourdomain.com/login`
- Email: `admin@example.com`
- Password: `password` (Change immediately!)

---

## 🔄 Quick Update Script

Save this as `update.sh`:

```bash
#!/bin/bash
cd /var/www/sms-card-sale
php artisan down
git pull origin main
composer install --no-dev --optimize-autoloader
npm install && npm run production
php artisan migrate --force
php artisan config:cache
php artisan route:cache
php artisan view:cache
sudo systemctl restart nginx
php artisan up
echo "✅ Update complete!"
```

---

## 🐛 Quick Troubleshooting

```bash
# Check logs
tail -100 /var/www/sms-card-sale/storage/logs/laravel.log
sudo tail -100 /var/log/nginx/error.log

# Clear everything
php artisan cache:clear
php artisan config:clear
php artisan route:clear
php artisan view:clear

# Fix permissions
sudo chown -R www-data:www-data storage bootstrap/cache
sudo chmod -R 775 storage bootstrap/cache

# Restart services
sudo systemctl restart php8.2-fpm
sudo systemctl restart nginx
```

---

## 📋 Production Checklist

- [ ] `.env` updated with production values
- [ ] `APP_DEBUG=false`
- [ ] `APP_ENV=production`
- [ ] SSL certificate installed
- [ ] Cron job configured
- [ ] Firewall enabled
- [ ] Admin password changed
- [ ] All features tested
- [ ] Backups configured

---

## 🎉 Done!

**Total Time: ~15 minutes**

For detailed instructions, see [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)

---

## 💡 Pro Tips

1. **Use deployment script**: `sudo bash deploy.sh`
2. **Monitor logs**: `tail -f storage/logs/laravel.log`
3. **Daily backup**: `mysqldump -u smsadmin -p sms_card_sale > backup_$(date +%Y%m%d).sql`
4. **Performance**: Install Redis for caching
5. **Monitoring**: Set up uptime monitoring (UptimeRobot, Pingdom)

---

**Need Help?** Check [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) for detailed instructions.

