# Quick Payment Test Guide

## ✅ The Fix Is Complete!

Your payment system now **automatically adds balance** when `status=completed` is received.

---

## 🧪 Quick Test (Without Real Payment)

### Step 1: Login as User
```
Email: user@example.com
Password: password
```

### Step 2: Check Current Balance
- Look at the sidebar or dashboard
- Note your current balance (should be ৳100.00)

### Step 3: Try to Buy a Package
1. Go to "Buy Balance"
2. Click "Buy Now" on any package
3. This will create a PENDING transaction

### Step 4: Manually Test Success URL

Open your browser and visit this URL (replace the amount with your package amount):

**For ৳100 package:**
```
http://127.0.0.1:8000/payment/success?status=completed&transactionId=TEST123456&paymentAmount=100&paymentMethod=bkash
```

**For ৳450 package:**
```
http://127.0.0.1:8000/payment/success?status=completed&transactionId=TEST789012&paymentAmount=450&paymentMethod=nagad
```

### Step 5: Verify Results

After visiting the URL, you should see:

✅ **Success Page Shows:**
- Green checkmark icon
- "Payment completed successfully! Your balance has been updated."
- Updated balance amount

✅ **Sidebar Shows:**
- New increased balance

✅ **Transaction History Shows:**
- Transaction status: Completed (green badge)
- Payment method included

---

## 📊 Database Verification

### Check Transaction Status
```sql
SELECT id, user_id, amount, status, description, created_at 
FROM transactions 
WHERE user_id = 2 
ORDER BY created_at DESC 
LIMIT 5;
```

**Expected:** Status should be 'completed'

### Check User Balance
```sql
SELECT id, name, balance 
FROM users 
WHERE id = 2;
```

**Expected:** Balance should be increased

---

## 🔍 View Logs

To see detailed payment processing:

```bash
tail -f storage/logs/laravel.log
```

Look for:
```
[INFO] Payment success callback received
  - status: completed
  - transactionId: TEST123456
  - amount: 100
  - method: bkash
  - user_id: 2

[INFO] Payment processed successfully
  - transaction_id: 1
  - amount: 100
  - new_balance: 200
```

---

## 🌐 Real Payment Test (With RupantorPay API Key)

### Prerequisites:
1. Configure RupantorPay API key in Admin Settings
2. Ensure your localhost is accessible (use ngrok for testing)

### Steps:
1. Login as user
2. Go to "Buy Balance"
3. Select a package
4. Click "Buy Now"
5. Complete payment on RupantorPay page
6. System will redirect back with real parameters
7. Balance will be added **AUTOMATICALLY**

---

## 🎯 Expected URL After Real Payment

RupantorPay will redirect to:
```
http://127.0.0.1:8000/payment/success?
  paymentMethod=bkash
  &transactionId=UF0UA6742464
  &paymentAmount=450
  &paymentFee=0
  &currency=BDT
  &status=completed
```

System will:
1. ✅ Read all parameters
2. ✅ Find pending transaction by amount (৳450)
3. ✅ Update transaction to 'completed'
4. ✅ Add ৳450 to user balance
5. ✅ Show success message

---

## 🐛 Troubleshooting

### Issue: "No pending transaction found"

**Reason:** Transaction doesn't exist or already completed

**Solution:**
1. Check transaction history
2. Try buying a new package
3. Don't refresh success URL multiple times

### Issue: "Payment status is being verified"

**Reason:** `status` parameter is missing or not 'completed'

**Solution:**
- Ensure URL has `status=completed`
- Check URL parameters are correct

### Issue: Balance not showing updated

**Reason:** Page cache or session issue

**Solution:**
- Refresh the page (F5)
- Logout and login again
- Clear browser cache

---

## ✨ Test Different Scenarios

### Scenario 1: Successful Payment
```
?status=completed&transactionId=ABC123&paymentAmount=100&paymentMethod=bkash
```
**Result:** ✅ Balance added, success message

### Scenario 2: Failed Payment
```
?status=failed&transactionId=DEF456&paymentAmount=100&paymentMethod=bkash
```
**Result:** ❌ Redirect to cancel page, no balance added

### Scenario 3: Cancelled Payment
```
?status=cancelled&transactionId=GHI789&paymentAmount=100&paymentMethod=nagad
```
**Result:** ⚠️ Cancel page, cancellation message

### Scenario 4: Duplicate Request
Visit the same success URL twice
**Result:** ℹ️ "This payment has already been processed"

---

## 📸 What You Should See

### Success Page:
```
✅ Payment Successful!
Payment completed successfully! Your balance has been updated.

Current Balance: ৳200.00

[Go to Dashboard] [Send SMS]
```

### Dashboard (After Success):
```
Current Balance
৳200.00
[Add Balance]
```

### Transaction History:
```
ADMIN-1234-2    Balance added    Credit    +৳100.00    Completed    Oct 29, 6:30 PM
```

---

## 🎉 Success Indicators

✅ Success message displayed  
✅ Balance increased in sidebar  
✅ Transaction marked 'completed'  
✅ Can immediately send SMS with new balance  
✅ Transaction appears in history  

---

## 📞 Need Help?

Check logs for errors:
```bash
tail -f storage/logs/laravel.log | grep -E "Payment|Error"
```

All payment attempts are logged with full details!

---

**Ready to Test!** 🚀

Start with the manual test URL above to verify everything works!
