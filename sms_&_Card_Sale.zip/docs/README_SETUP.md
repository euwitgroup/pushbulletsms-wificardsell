# SMS & Card Sale - Bulk SMS Web Application

A comprehensive Laravel 9 application for bulk SMS sending with payment integration using Pushbullet API for SMS delivery and RupantorPay for payments.

## Features

### Admin Panel
- **Dashboard**: Overview of users, transactions, and SMS statistics
- **User Management**: Create, edit, delete users and manage their balance
- **SMS Package Management**: Create and manage SMS packages for purchase
- **Settings**: Configure Pushbullet API, RupantorPay API, and SMS pricing
- **Reports**: View all transactions and SMS history

### User Panel
- **Dashboard**: View balance, SMS sent, and recent activity
- **Send SMS**: Send SMS messages via Pushbullet API
- **Buy Balance**: Purchase SMS packages via RupantorPay payment gateway
- **SMS History**: View all sent SMS with status
- **Transactions**: View payment and SMS transaction history

## Technology Stack

- **Framework**: Laravel 9
- **Database**: MySQL
- **SMS API**: Pushbullet API (https://docs.pushbullet.com/)
- **Payment Gateway**: RupantorPay (https://rupantorpay.com/developers/docs)
- **Authentication**: Laravel built-in with role-based access control

## Installation & Setup

### 1. Database Setup

Configure your database in `.env` file:
```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=sms_card_sale
DB_USERNAME=root
DB_PASSWORD=
```

### 2. Run Migrations

```bash
php artisan migrate
```

### 3. Seed Database

```bash
php artisan db:seed --class=AdminUserSeeder
php artisan db:seed --class=SmsPackageSeeder
```

### 4. Default Credentials

**Admin:**
- Email: admin@example.com
- Password: password

**Test User:**
- Email: user@example.com
- Password: password

### 5. Configure API Keys

Login as admin and navigate to Settings to configure:

1. **Pushbullet API Settings:**
   - `pushbullet_api_key`: Your Pushbullet API key
   - `pushbullet_device_iden`: Your device identifier
   - `pushbullet_user_iden`: Your user identifier

2. **RupantorPay Settings:**
   - `rupantorpay_api_key`: Your RupantorPay API key

3. **SMS Settings:**
   - `sms_cost_per_message`: Cost per SMS (default: 1.00)

### 6. Getting Pushbullet API Credentials

1. Go to https://www.pushbullet.com/
2. Create an account and login
3. Visit https://www.pushbullet.com/#settings/account
4. Create Access Token (this is your `pushbullet_api_key`)
5. Install Pushbullet app on your Android device
6. Use the API to get devices: 
   ```bash
   curl -u YOUR_ACCESS_TOKEN: https://api.pushbullet.com/v2/devices
   ```
7. Note the `iden` of your device (this is `pushbullet_device_iden`)
8. Get user info:
   ```bash
   curl -u YOUR_ACCESS_TOKEN: https://api.pushbullet.com/v2/users/me
   ```
9. Note the `iden` from response (this is `pushbullet_user_iden`)

### 7. Getting RupantorPay API Key

1. Visit https://rupantorpay.com/
2. Create merchant account
3. Navigate to Developer/API section
4. Copy your API key

## Database Structure

### Tables:

1. **users**: User accounts with role (admin/user), balance, and status
2. **transactions**: Payment and SMS transaction records
3. **sms_history**: All SMS sending attempts with status
4. **sms_packages**: Available packages for purchase
5. **settings**: Application configuration (API keys, settings)

## API Integration Details

### Pushbullet SMS API

The application uses Pushbullet's ephemeral messaging system to send SMS:

```php
POST https://api.pushbullet.com/v2/ephemerals
{
  "type": "push",
  "push": {
    "type": "messaging_extension_reply",
    "package_name": "com.pushbullet.android",
    "source_user_iden": "YOUR_USER_IDEN",
    "target_device_iden": "YOUR_DEVICE_IDEN",
    "conversation_iden": "+1234567890",
    "message": "Your message here"
  }
}
```

### RupantorPay Payment API

Payment creation:

```php
POST https://payment.rupantorpay.com/api/payment/checkout
Headers:
  X-API-KEY: YOUR_API_KEY
  Content-Type: application/json
  X-CLIENT: your-domain.com
Body:
{
  "success_url": "http://yoursite.com/payment/success",
  "cancel_url": "http://yoursite.com/payment/cancel",
  "webhook_url": "http://yoursite.com/payment/webhook",
  "metadata": {...},
  "amount": "100"
}
```

## Routes

### Guest Routes
- `/` - Home page (redirects based on auth)
- `/login` - Login page
- `/register` - Registration page

### Admin Routes (Prefix: `/admin`)
- `/admin/dashboard` - Admin dashboard
- `/admin/users` - User management
- `/admin/packages` - SMS package management
- `/admin/settings` - System settings
- `/admin/transactions` - All transactions
- `/admin/sms-history` - All SMS history

### User Routes (Prefix: `/user`)
- `/user/dashboard` - User dashboard
- `/user/send-sms` - Send SMS form
- `/user/sms-history` - User's SMS history
- `/user/buy-balance` - View packages and buy balance
- `/user/transactions` - User's transactions

### Payment Callback Routes
- `/payment/success` - Payment success handler
- `/payment/cancel` - Payment cancellation handler
- `/payment/webhook` - Payment webhook (for RupantorPay)

## Important Files

### Services
- `app/Services/PushbulletService.php` - Pushbullet API integration
- `app/Services/RupantorPayService.php` - RupantorPay API integration

### Models
- `app/Models/User.php` - User model with relationships
- `app/Models/Transaction.php` - Transaction model
- `app/Models/SmsHistory.php` - SMS history model
- `app/Models/SmsPackage.php` - SMS package model
- `app/Models/Setting.php` - Settings model with helper methods

### Middleware
- `app/Http/Middleware/AdminMiddleware.php` - Admin access control
- `app/Http/Middleware/UserMiddleware.php` - User access control

### Controllers
- `app/Http/Controllers/Admin/*` - Admin panel controllers
- `app/Http/Controllers/User/*` - User panel controllers
- `app/Http/Controllers/Auth/*` - Authentication controllers

## Running the Application

### Development Server

```bash
php artisan serve
```

Visit: http://localhost:8000

### Using XAMPP

1. Make sure Apache and MySQL are running
2. Access via: http://localhost/sms_&_Card_Sale/public

## Security Notes

1. **Change default passwords** after installation
2. **Keep API keys secure** - never commit them to version control
3. **Use HTTPS** in production
4. **Configure CSRF** protection properly
5. **Set proper file permissions** on storage and bootstrap/cache directories

## Troubleshooting

### SMS Not Sending
1. Verify Pushbullet API key is correct
2. Ensure device is connected and online
3. Check device identifier is correct
4. Verify user identifier is correct

### Payment Not Working
1. Check RupantorPay API key
2. Verify webhook URL is accessible
3. Check callback URLs are correct
4. Ensure proper SSL certificate if using HTTPS

### Database Errors
1. Run migrations: `php artisan migrate`
2. Clear cache: `php artisan config:clear`
3. Check database credentials in `.env`

## Support

For issues or questions:
- Check Laravel 9 documentation: https://laravel.com/docs/9.x
- Pushbullet API docs: https://docs.pushbullet.com/
- RupantorPay docs: https://rupantorpay.com/developers/docs

## License

This project is open-sourced software.
