# 📋 Pre-Deployment Checklist for SMS & Card Sale

## Before You Deploy - Complete This Checklist

### ✅ Local Development

- [ ] All features tested locally and working
- [ ] No console errors in browser
- [ ] All forms validated properly
- [ ] Database migrations tested
- [ ] Seeders working correctly
- [ ] No Laravel errors in `storage/logs/laravel.log`
- [ ] All images loading correctly
- [ ] Mobile responsive design verified

---

### ✅ Code Quality

- [ ] Remove all `dd()` and `dump()` statements
- [ ] Remove all `console.log()` statements
- [ ] Remove commented-out code
- [ ] Check for hardcoded values (use config/env)
- [ ] All routes are named
- [ ] Controllers follow naming conventions
- [ ] Models have proper relationships defined

---

### ✅ Security

- [ ] `.env` file is in `.gitignore`
- [ ] No sensitive data committed to Git
- [ ] Strong database password prepared
- [ ] Strong admin password prepared
- [ ] CSRF protection enabled on all forms
- [ ] SQL injection prevention (using Eloquent/Query Builder)
- [ ] XSS protection (using `{{ }}` not `{!! !!}` unless needed)
- [ ] File upload validation implemented
- [ ] Password hashing with bcrypt

---

### ✅ Environment Configuration

- [ ] `.env.example` updated with all required variables
- [ ] APP_ENV will be set to `production`
- [ ] APP_DEBUG will be set to `false`
- [ ] APP_KEY will be generated on server
- [ ] Database credentials prepared
- [ ] MAIL credentials prepared (SMTP)
- [ ] Payment gateway API key (RupantorPay) - LIVE KEY
- [ ] SMS gateway credentials prepared
- [ ] Pushbullet token prepared (optional)

---

### ✅ Database

- [ ] Database backup created
- [ ] Migration files reviewed
- [ ] Seeders reviewed
- [ ] Database name decided
- [ ] Database user created with proper privileges
- [ ] Foreign key constraints checked
- [ ] Indexes added where needed

---

### ✅ Third-Party Services

#### Payment Gateway (RupantorPay)
- [ ] Live API key obtained
- [ ] Webhook URL configured
- [ ] Success/Cancel URLs tested
- [ ] Test transaction completed

#### SMS Gateways
- [ ] Live API credentials obtained
- [ ] SMS templates created
- [ ] Sender ID approved
- [ ] Test SMS sent successfully

#### Email Service (SMTP)
- [ ] SMTP credentials obtained
- [ ] From email configured
- [ ] Test email sent successfully
- [ ] Email templates verified

---

### ✅ Server Requirements

- [ ] PHP 8.1+ available
- [ ] MySQL 5.7+ available
- [ ] Composer installed
- [ ] Node.js 14+ installed
- [ ] Web server installed (Nginx/Apache)
- [ ] SSL certificate planned (Let's Encrypt recommended)
- [ ] Domain name configured and pointing to server
- [ ] Server has at least 2GB RAM
- [ ] Server has at least 10GB storage

---

### ✅ Files & Directories

- [ ] `storage/` directory writable
- [ ] `bootstrap/cache/` directory writable
- [ ] `public/` directory is web root
- [ ] `.htaccess` file present in public/
- [ ] `storage/app/public` will be linked
- [ ] Uploaded files backed up

---

### ✅ Performance Optimization

- [ ] Run `composer install --optimize-autoloader --no-dev`
- [ ] Run `npm run production` (not `npm run dev`)
- [ ] Images optimized (compressed)
- [ ] Unnecessary packages removed
- [ ] Caching strategy planned
  - [ ] Config cache: `php artisan config:cache`
  - [ ] Route cache: `php artisan route:cache`
  - [ ] View cache: `php artisan view:cache`

---

### ✅ Monitoring & Logging

- [ ] Laravel logging configured (daily rotation recommended)
- [ ] Error tracking service planned (optional: Sentry)
- [ ] Server monitoring planned (optional: New Relic, Datadog)
- [ ] Uptime monitoring planned (optional: Pingdom, UptimeRobot)
- [ ] Google Analytics added (optional)

---

### ✅ Backup Strategy

- [ ] Database backup plan created
  - [ ] Daily automated backups
  - [ ] Backup location decided (local/cloud)
  - [ ] Backup restoration tested
- [ ] File backup plan created
  - [ ] Uploaded files backed up
  - [ ] Backup frequency decided
- [ ] Backup monitoring planned

---

### ✅ Scheduled Tasks

- [ ] Cron job for Laravel scheduler configured
- [ ] Queue workers configured (if using queues)
- [ ] Auto-restock command scheduled (every minute)
- [ ] Log rotation configured
- [ ] Database backup scheduled

---

### ✅ Testing on Server

After deployment, test these:

- [ ] Homepage loads correctly
- [ ] All assets loading (CSS, JS, images)
- [ ] Admin login works
- [ ] User registration works
- [ ] User login works
- [ ] Email verification works
- [ ] Password reset works
- [ ] Profile update works
- [ ] SMS sending works
- [ ] Payment gateway works
- [ ] WiFi card purchase works (guest)
- [ ] WiFi card purchase works (logged in)
- [ ] Card key delivery via SMS works
- [ ] Auto-restock feature works (2 min timeout)
- [ ] Admin panel accessible
- [ ] All admin features work
- [ ] File uploads work
- [ ] Database queries executing properly
- [ ] No errors in logs

---

### ✅ Post-Deployment

- [ ] Change default admin password
- [ ] Add real content (not dummy data)
- [ ] Configure all settings in admin panel
- [ ] Add real SMS packages
- [ ] Add real WiFi card categories/types
- [ ] Add blog posts
- [ ] Update contact information
- [ ] Update social media links
- [ ] Submit sitemap to Google
- [ ] Test all forms
- [ ] Monitor error logs for 24 hours
- [ ] Check server resource usage
- [ ] Verify SSL certificate is working
- [ ] Test from mobile devices
- [ ] Test from different browsers

---

### ✅ Documentation

- [ ] Admin user guide created/updated
- [ ] API documentation created (if applicable)
- [ ] Deployment notes documented
- [ ] Known issues documented
- [ ] Emergency contacts list created
- [ ] Server access credentials stored securely

---

### ✅ Rollback Plan

- [ ] Database backup before deployment
- [ ] Previous version code backed up
- [ ] Rollback procedure documented
- [ ] Testing server available for staging

---

### ✅ Legal & Compliance

- [ ] Privacy policy page created
- [ ] Terms of service page created
- [ ] Cookie consent implemented (if required)
- [ ] GDPR compliance verified (if applicable)
- [ ] Payment security compliance (PCI DSS)

---

## 🚨 Critical Reminders

### NEVER Do This in Production:

❌ Set `APP_DEBUG=true`  
❌ Commit `.env` file  
❌ Use weak passwords  
❌ Skip database backups  
❌ Disable CSRF protection  
❌ Use `dd()` or `var_dump()` in code  
❌ Leave test data in production  
❌ Skip SSL certificate  
❌ Ignore security updates  
❌ Deploy without testing  

### ALWAYS Do This:

✅ Set `APP_DEBUG=false`  
✅ Use HTTPS  
✅ Use strong passwords  
✅ Enable all security features  
✅ Keep Laravel & dependencies updated  
✅ Monitor logs regularly  
✅ Test before deploying  
✅ Have a backup strategy  
✅ Document everything  
✅ Keep `.env` secure  

---

## 📞 Emergency Contacts

- **Hosting Provider Support**: _______________
- **Domain Registrar Support**: _______________
- **Developer Contact**: _______________
- **Server Admin Contact**: _______________
- **Database Admin Contact**: _______________

---

## 🎉 Ready to Deploy?

Once all items are checked off:

1. Follow the **DEPLOYMENT_GUIDE.md**
2. Use the **deploy.sh** script
3. Monitor logs for the first 24 hours
4. Test all critical features
5. Celebrate! 🎊

---

**Last Updated**: November 2, 2025  
**Version**: 1.0  
**Project**: SMS & Card Sale

