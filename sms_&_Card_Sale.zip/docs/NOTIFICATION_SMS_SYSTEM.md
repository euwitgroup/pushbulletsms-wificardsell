# Notification & SMS Template System - Implementation Guide

## Overview
This document outlines the comprehensive notification and SMS template system that has been integrated into the SMS & Card Sale platform. The system supports 100 pre-configured SMS templates and automatic SMS sending with notifications.

---

## 📋 Features Implemented

### 1. **100 SMS Templates** ✅
- Created 100 diverse SMS templates covering various use cases
- Templates are organized into categories:
  - **OTP & Verification** (10 templates): Phone verification, login OTP, password reset, etc.
  - **Welcome & Registration** (10 templates): Welcome messages, account creation, onboarding
  - **Balance & Transactions** (15 templates): Balance alerts, deposits, withdrawals, refunds
  - **Package & Purchase** (15 templates): Package purchases, renewals, upgrades, trials
  - **SMS Service** (15 templates): SMS sent confirmations, bulk SMS, campaign reports
  - **Account & Security** (15 templates): Password changes, account locks, KYC verification
  - **Promotional** (15 templates): Flash sales, referrals, birthday offers, cashback
  - **System & Service** (5 templates): Maintenance alerts, support tickets

### 2. **SMS Template Management** ✅
- Each template includes:
  - Name and type
  - Message content with placeholders (e.g., `{user_name}`, `{otp_code}`, `{amount}`)
  - Variable list for easy reference
  - Active/inactive status
  - Creation/update timestamps

### 3. **Notification System with SMS Integration** ✅
- **Database Schema**:
  - Added `sms_template_id` to link notifications with SMS templates
  - Added `send_sms` flag to enable/disable SMS for each notification
  - Added `sms_sent` status to track successful SMS delivery
  - Added `sms_sent_at` timestamp
  - Added `sms_error` field to store error messages

### 4. **NotificationService Enhancements** ✅
- Automatic SMS sending when creating notifications
- Template-based SMS with variable substitution
- Error handling and logging
- Optional SMS sending (can be disabled per notification)
- Support for both user and admin notifications

### 5. **User & Admin Notification Pages** ✅
- Display notifications with SMS status badges:
  - ✅ **SMS Sent** (green badge)
  - ❌ **SMS Failed** (red badge with error tooltip)
  - ⏳ **SMS Pending** (yellow badge)
- Show SMS template name used for each notification
- Filter by read/unread status
- Bulk actions: Mark all as read, Delete all read
- Pagination support

---

## 📊 Database Schema

### Migration: `add_sms_template_to_notifications_table`
```sql
ALTER TABLE notifications ADD COLUMN sms_template_id BIGINT UNSIGNED NULL;
ALTER TABLE notifications ADD COLUMN send_sms BOOLEAN DEFAULT false;
ALTER TABLE notifications ADD COLUMN sms_sent BOOLEAN DEFAULT false;
ALTER TABLE notifications ADD COLUMN sms_sent_at TIMESTAMP NULL;
ALTER TABLE notifications ADD COLUMN sms_error TEXT NULL;
```

---

## 🚀 Usage Examples

### Creating a Notification with SMS

#### Example 1: User Registration with Welcome SMS
```php
$notificationService->userRegistered($user, true);
// This will:
// 1. Create a notification for the user
// 2. Send SMS using "Welcome Message" template
// 3. Create admin notification (no SMS)
```

#### Example 2: Balance Deposit with SMS
```php
$notificationService->balanceDeposited($userId, 500, 'TXN12345', true);
// This will:
// 1. Create notification with balance update
// 2. Send SMS using "Balance Added" template
// 3. Create admin notification
```

#### Example 3: Package Purchase with SMS
```php
$notificationService->packagePurchased($userId, 'Premium Pack', 1000, 500, true);
// This will:
// 1. Create notification about package purchase
// 2. Send SMS using "Package Purchase Confirmation" template
// 3. Create admin notification
```

### Creating Custom Notification with SMS
```php
$notificationService->create(
    $userId,
    'custom_type',
    'Your Title',
    'Your message content',
    ['custom_var' => 'value'], // Data for template variables
    'fa-icon-name',
    'success',
    route('some.route'),
    true, // Send SMS
    'transactional' // Template type
);
```

---

## 📝 Available SMS Templates by Type

### OTP Templates (`type: 'otp'`)
1. OTP Verification
2. Phone Verification
3. Email Verification Code
4. Login Verification
5. Password Reset OTP
6. Transaction OTP
7. Account Activation Code
8. Two-Factor Authentication
9. Withdrawal Confirmation OTP
10. Account Security Alert OTP

### Transactional Templates (`type: 'transactional'`)
1. Welcome Message
2. Registration Success
3. Balance Added
4. Payment Received
5. Low Balance Alert
6. Package Purchased
7. SMS Sent Successfully
8. Password Changed
9. Account Locked/Unlocked
10. And many more...

### Promotional Templates (`type: 'promotional'`)
1. Promotional Offer
2. Flash Sale
3. Seasonal Offer
4. Referral Bonus
5. Birthday Offer
6. Loyalty Reward
7. Cashback Offer
8. And more...

---

## 🔧 Template Variables

Common variables used across templates:
- `{company_name}` - Site name from settings
- `{user_name}` - User's name
- `{otp_code}` - OTP code
- `{amount}` - Transaction amount
- `{balance}` - Current balance
- `{phone}` - Phone number
- `{package_name}` - Package name
- `{transaction_id}` - Transaction ID
- `{date}` - Date
- `{time}` - Time
- `{expiry_minutes}` - OTP expiry time
- And many more...

---

## 🎨 UI Features

### Notification List View
- **Card-based design** with notification icons
- **Color-coded** based on notification type
- **Unread highlighting** with blue background
- **SMS Status Badges**:
  - Green badge: SMS successfully sent
  - Red badge: SMS failed (hover for error details)
  - Yellow badge: SMS pending
- **Template information** displayed below message
- **Action buttons**: Mark as read, Delete
- **Bulk actions**: Mark all as read, Delete all read

### Notification Icons & Colors
- **Registration**: Blue, `fa-user-plus`
- **Deposit**: Green, `fa-wallet`
- **Purchase**: Info, `fa-shopping-cart`
- **SMS Sent**: Success, `fa-paper-plane`
- **Low Balance**: Warning, `fa-exclamation-triangle`
- **Account Status**: Dynamic based on status

---

## 🔐 Security & Performance

### Security
- ✅ User-specific notification filtering
- ✅ Admin notifications are separate (no user_id)
- ✅ SMS errors are logged securely
- ✅ CSRF protection on all forms

### Performance
- ✅ Eager loading of SMS templates (prevents N+1 queries)
- ✅ Pagination for large notification lists
- ✅ Indexed database columns
- ✅ Efficient query scopes

---

## 📱 SMS Gateway Integration

The system works with your existing SMS gateways:
- **BulkSMSBD**: Fully integrated
- **Pushbullet**: Fallback option
- Templates are parsed before sending
- Variables are replaced with actual values
- Errors are logged and displayed in notifications

---

## 🧪 Testing

### To Test the System:

1. **Register a New User**:
   - Go to registration page
   - Complete registration with phone verification
   - Check notifications page
   - Verify SMS was sent (check SMS badge)

2. **Add Balance**:
   - Deposit balance to a user account
   - Check user notifications
   - Verify SMS notification with "Balance Added" template

3. **Purchase Package**:
   - Buy an SMS package
   - Check notifications
   - Verify SMS confirmation

4. **View Admin Notifications**:
   - Login as admin
   - Go to `/admin/notifications`
   - View all system notifications
   - Check SMS status for user notifications

---

## 📊 Seeder Data

Run the seeder to populate templates:
```bash
php artisan db:seed --class=SmsTemplateSeeder
```

This will create/update 100 SMS templates in the database.

---

## 🛠️ Files Modified/Created

### New Files:
1. `database/migrations/2025_10_31_105047_add_sms_template_to_notifications_table.php`
2. `NOTIFICATION_SMS_SYSTEM.md` (this file)

### Modified Files:
1. `database/seeders/SmsTemplateSeeder.php` - Added 100 templates
2. `app/Models/Notification.php` - Added SMS-related fields and relationship
3. `app/Services/NotificationService.php` - Added SMS sending capability
4. `app/Http/Controllers/Admin/NotificationController.php` - Added template eager loading
5. `app/Http/Controllers/User/NotificationController.php` - Added template eager loading
6. `resources/views/admin/notifications/index.blade.php` - Added SMS status display
7. `resources/views/user/notifications/index.blade.php` - Added SMS status display

---

## 🎯 Next Steps (Optional)

### Suggested Enhancements:
1. **Real-time Notifications**: Integrate Pusher/WebSockets
2. **Email Notifications**: Add email sending alongside SMS
3. **Notification Preferences**: Let users choose which notifications to receive
4. **SMS Rate Tracking**: Track SMS costs per notification
5. **Retry Failed SMS**: Add button to retry failed SMS
6. **Template Editor**: Allow admins to edit templates from UI
7. **Notification Scheduling**: Schedule notifications for future delivery
8. **Notification Categories**: Group notifications by category
9. **Export Notifications**: Export notification history to CSV/PDF
10. **Push Notifications**: Add browser push notifications

---

## 📞 Support

For any issues or questions:
- Check Laravel logs: `storage/logs/laravel.log`
- Check SMS gateway configuration: `/admin/sms-gateway`
- Check SMS templates: `/admin/sms-templates`
- Check notification settings in database

---

## ✅ Verification Checklist

- [x] 100 SMS templates created and seeded
- [x] Notification table updated with SMS columns
- [x] NotificationService updated to send SMS
- [x] Notification models updated with relationships
- [x] Admin notification page shows SMS status
- [x] User notification page shows SMS status
- [x] SMS templates are linked to notifications
- [x] Error handling for failed SMS
- [x] Migration successfully applied
- [x] No linter errors

---

## 🎉 Conclusion

Your SMS & Card Sale platform now has a comprehensive notification system with:
- ✅ 100 pre-configured SMS templates
- ✅ Automatic SMS sending with notifications
- ✅ Visual status indicators for SMS delivery
- ✅ Template-based messaging with variable substitution
- ✅ Separate admin and user notification pages
- ✅ Full error tracking and logging

The system is production-ready and fully functional! 🚀

