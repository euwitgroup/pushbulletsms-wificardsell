# Quick Start Guide - SMS & Card Sale Application

## 🚀 Immediate Setup Steps

### Step 1: Database Migration
```bash
cd c:\xampp\htdocs\sms_&_Card_Sale
php artisan migrate
```

### Step 2: Seed Initial Data
```bash
php artisan db:seed --class=AdminUserSeeder
php artisan db:seed --class=SmsPackageSeeder
```

### Step 3: Access the Application

**Login URLs:**
- Admin: http://localhost/sms_&_Card_Sale/public/login
- Or if using `php artisan serve`: http://127.0.0.1:8000/login

**Default Credentials:**
```
Admin Account:
Email: admin@example.com
Password: password

Test User Account:
Email: user@example.com
Password: password
```

### Step 4: Configure API Settings (Important!)

1. Login as admin
2. Go to Settings page
3. Configure the following:

**Pushbullet API (for SMS):**
- Get your API key from: https://www.pushbullet.com/#settings/account
- `pushbullet_api_key`: Your access token
- `pushbullet_device_iden`: Your Android device identifier
- `pushbullet_user_iden`: Your user identifier

**RupantorPay (for payments):**
- Get your API key from: https://rupantorpay.com/
- `rupantorpay_api_key`: Your merchant API key

**SMS Pricing:**
- `sms_cost_per_message`: Set your price per SMS (e.g., 1.00)

## 📱 Admin Panel Features

### Dashboard
- View total users, active users, SMS sent, and revenue
- Monitor recent transactions
- Track recent SMS activity

### User Management (`/admin/users`)
- Create new users
- Edit user details
- Add balance to user accounts
- Enable/disable user accounts
- View user transaction history

### SMS Package Management (`/admin/packages`)
- Create SMS packages (e.g., 100 SMS for $100)
- Edit existing packages
- Activate/deactivate packages
- Set package pricing and descriptions

### Settings (`/admin/settings`)
- Configure Pushbullet API credentials
- Configure RupantorPay API credentials
- Set SMS pricing
- Configure site information

### Reports
- View all transactions (`/admin/transactions`)
- View all SMS history (`/admin/sms-history`)

## 👥 User Panel Features

### Dashboard
- View current balance
- See total SMS sent
- Check total spent amount
- View recent transactions and SMS

### Send SMS (`/user/send-sms`)
1. Enter phone number (with country code)
2. Type your message
3. Click Send
4. Cost will be deducted from balance automatically

### Buy Balance (`/user/buy-balance`)
1. Select an SMS package
2. Click "Buy Now"
3. Complete payment via RupantorPay
4. Balance will be added automatically after successful payment

### SMS History (`/user/sms-history`)
- View all sent SMS
- Check delivery status
- See costs for each SMS

### Transactions (`/user/transactions`)
- View all payment transactions
- See balance additions
- Check SMS charges

## 🔧 Testing the Application

### Test SMS Sending (Without Real API)

If you haven't configured Pushbullet yet, you can test the flow:
1. Login as user (user@example.com / password)
2. User has 100 balance already
3. Go to Send SMS
4. Enter a phone number and message
5. The system will try to send via Pushbullet (will fail without API key, but transaction is recorded)

### Test Payment Flow (Without Real Payment)

To fully test payments, you need RupantorPay credentials. Alternatively:
1. Login as admin
2. Go to Users
3. Manually add balance to test user
4. Use that balance to send SMS

## 📋 Application Structure

```
app/
├── Http/
│   ├── Controllers/
│   │   ├── Admin/          # Admin panel controllers
│   │   │   ├── DashboardController.php
│   │   │   ├── UserController.php
│   │   │   ├── SettingController.php
│   │   │   └── SmsPackageController.php
│   │   ├── User/           # User panel controllers
│   │   │   ├── DashboardController.php
│   │   │   ├── SmsController.php
│   │   │   └── PaymentController.php
│   │   └── Auth/           # Authentication controllers
│   └── Middleware/
│       ├── AdminMiddleware.php
│       └── UserMiddleware.php
├── Models/
│   ├── User.php
│   ├── Transaction.php
│   ├── SmsHistory.php
│   ├── SmsPackage.php
│   └── Setting.php
└── Services/
    ├── PushbulletService.php
    └── RupantorPayService.php

database/
├── migrations/
│   ├── *_add_role_and_balance_to_users_table.php
│   ├── *_create_transactions_table.php
│   ├── *_create_sms_history_table.php
│   ├── *_create_settings_table.php
│   └── *_create_sms_packages_table.php
└── seeders/
    ├── AdminUserSeeder.php
    └── SmsPackageSeeder.php

routes/
└── web.php                 # All application routes
```

## ⚠️ Common Issues & Solutions

### Issue: SMS not sending
**Solution:** 
1. Check Pushbullet API key in Settings
2. Ensure device is online and connected
3. Verify device and user identifiers are correct
4. Check error messages in SMS History

### Issue: Payment not completing
**Solution:**
1. Verify RupantorPay API key
2. Check callback URLs are accessible
3. Ensure webhook URL is publicly accessible (use ngrok for local testing)

### Issue: Can't login
**Solution:**
1. Ensure database is migrated: `php artisan migrate`
2. Ensure seeders are run: `php artisan db:seed --class=AdminUserSeeder`
3. Clear cache: `php artisan config:clear`

### Issue: Routes not working
**Solution:**
1. Check if using Apache: Ensure mod_rewrite is enabled
2. If using `php artisan serve`: Use http://127.0.0.1:8000
3. Clear route cache: `php artisan route:clear`

## 🔐 Security Checklist

- [ ] Change default admin password
- [ ] Configure .env file properly
- [ ] Set APP_ENV=production for live site
- [ ] Set APP_DEBUG=false for live site
- [ ] Keep API keys secure
- [ ] Use HTTPS in production
- [ ] Set proper file permissions (755 for directories, 644 for files)
- [ ] Secure storage and bootstrap/cache folders

## 📞 Next Steps

1. **Configure APIs**: Get your Pushbullet and RupantorPay credentials
2. **Customize Packages**: Edit SMS packages to match your pricing
3. **Test System**: Send test SMS and complete test payments
4. **Create Views**: You'll need to create Blade view files for all the pages
5. **Add Frontend**: Integrate Bootstrap/Tailwind for UI
6. **Deploy**: Move to production server when ready

## 🎯 Production Deployment

When ready for production:

1. Set environment to production in `.env`:
   ```
   APP_ENV=production
   APP_DEBUG=false
   ```

2. Optimize application:
   ```bash
   php artisan config:cache
   php artisan route:cache
   php artisan view:cache
   composer install --optimize-autoloader --no-dev
   ```

3. Set up proper SSL certificate

4. Configure proper backup system for database

5. Set up monitoring and logging

## 📚 Documentation

- Full README: See `README_SETUP.md`
- Environment Configuration: See `.env.configuration.txt`
- Laravel 9 Docs: https://laravel.com/docs/9.x
- Pushbullet API: https://docs.pushbullet.com/
- RupantorPay API: https://rupantorpay.com/developers/docs

---

**Note:** This application includes the complete backend structure. You will need to create the Blade view templates for the frontend interface to make it fully functional. The controllers, models, services, and routes are all ready to use.
