<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Services\CardRestockService;

class ReleaseExpiredPendingCards extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cards:release-expired-pending';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Release pending card keys back to available status after 2 minutes of inactivity';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->info('🔍 Checking for expired pending card keys...');
        
        $releasedCount = CardRestockService::releaseExpiredPendingCards();
        
        if ($releasedCount > 0) {
            $this->info("✅ Released {$releasedCount} expired pending card key(s) back to available stock.");
        } else {
            $this->info("ℹ️  No expired pending card keys found.");
        }
        
        return Command::SUCCESS;
    }
}
