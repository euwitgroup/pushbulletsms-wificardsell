<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SmsTemplate extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'type',
        'message',
        'variables',
        'status',
    ];

    protected $casts = [
        'status' => 'boolean',
    ];
    
    /**
     * Get active template by type
     */
    public static function getByType($type)
    {
        return self::where('type', $type)->where('status', true)->first();
    }
    
    /**
     * Get active template by name
     */
    public static function getByName($name)
    {
        return self::where('name', $name)->where('status', true)->first();
    }
    
    /**
     * Replace variables in template message
     */
    public function parseMessage($variables = [])
    {
        $message = $this->message;
        
        foreach ($variables as $key => $value) {
            // Support both {key} and {{key}} formats
            $message = str_replace(['{' . $key . '}', '{{' . $key . '}}'], $value, $message);
        }
        
        return $message;
    }
    
    /**
     * Get list of variables in template
     */
    public function getVariablesList()
    {
        preg_match_all('/\{([^}]+)\}/', $this->message, $matches);
        return $matches[1] ?? [];
    }
}
