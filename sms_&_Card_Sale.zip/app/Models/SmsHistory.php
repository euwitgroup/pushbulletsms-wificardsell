<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SmsHistory extends Model
{
    use HasFactory;

    protected $table = 'sms_history';

    protected $fillable = [
        'user_id',
        'sms_gateway_id',
        'phone_number',
        'message',
        'status',
        'cost',
        'sms_count',
        'pushbullet_device_iden',
        'error_message',
    ];

    protected $casts = [
        'cost' => 'decimal:2',
        'sms_count' => 'integer',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function smsGateway()
    {
        return $this->belongsTo(SmsGateway::class);
    }
}
