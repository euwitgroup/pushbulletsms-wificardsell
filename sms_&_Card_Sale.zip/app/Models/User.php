<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'phone',
        'password',
        'role',
        'balance',
        'status',
        'phone_verified_at',
        'otp_code',
        'otp_expires_at',
        'address',
        'city',
        'state',
        'postal_code',
        'country',
        'date_of_birth',
        'gender',
        'profile_photo',
        'kyc_status',
        'nid_number',
        'nid_front',
        'nid_back',
        'passport_number',
        'passport_photo',
        'driving_license',
        'kyc_notes',
        'kyc_submitted_at',
        'kyc_verified_at',
        'kyc_verified_by',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'phone_verified_at' => 'datetime',
        'otp_expires_at' => 'datetime',
        'balance' => 'decimal:2',
        'status' => 'boolean',
        'date_of_birth' => 'date',
        'kyc_submitted_at' => 'datetime',
        'kyc_verified_at' => 'datetime',
    ];
    
    /**
     * Check if phone is verified
     */
    public function hasVerifiedPhone()
    {
        return !is_null($this->phone_verified_at);
    }
    
    /**
     * Mark phone as verified
     */
    public function markPhoneAsVerified()
    {
        $this->phone_verified_at = now();
        $this->otp_code = null;
        $this->otp_expires_at = null;
        $this->save();
    }
    
    /**
     * Check if email is verified
     */
    public function hasVerifiedEmail()
    {
        return !is_null($this->email_verified_at);
    }
    
    /**
     * Mark email as verified
     */
    public function markEmailAsVerified()
    {
        $this->email_verified_at = now();
        $this->save();
        
        return true;
    }
    
    /**
     * Generate OTP code
     */
    public function generateOtp()
    {
        $length = \App\Models\Setting::get('otp_length', '6');
        $expiryMinutes = \App\Models\Setting::get('otp_expiry_minutes', '5');
        
        $this->otp_code = str_pad(random_int(0, pow(10, $length) - 1), $length, '0', STR_PAD_LEFT);
        $this->otp_expires_at = now()->addMinutes($expiryMinutes);
        $this->save();
        
        return $this->otp_code;
    }
    
    /**
     * Verify OTP code
     */
    public function verifyOtp($code)
    {
        if ($this->otp_code === $code && now()->lessThan($this->otp_expires_at)) {
            $this->markPhoneAsVerified();
            return true;
        }
        
        return false;
    }

    /**
     * Check if user is admin
     */
    public function isAdmin()
    {
        return $this->role === 'admin';
    }

    /**
     * Relationships
     */
    public function transactions()
    {
        return $this->hasMany(Transaction::class);
    }

    public function smsHistory()
    {
        return $this->hasMany(SmsHistory::class);
    }

    public function notifications()
    {
        return $this->hasMany(Notification::class);
    }

    public function kycVerifiedBy()
    {
        return $this->belongsTo(User::class, 'kyc_verified_by');
    }

    /**
     * KYC Helper Methods
     */
    public function isKycVerified()
    {
        return $this->kyc_status === 'approved';
    }

    public function isKycPending()
    {
        return $this->kyc_status === 'pending';
    }

    public function isKycRejected()
    {
        return $this->kyc_status === 'rejected';
    }

    public function kycNotSubmitted()
    {
        return $this->kyc_status === 'not_submitted';
    }

    public function getKycStatusBadgeAttribute()
    {
        $badges = [
            'not_submitted' => '<span class="badge bg-secondary">Not Submitted</span>',
            'pending' => '<span class="badge bg-warning">Pending Review</span>',
            'approved' => '<span class="badge bg-success">Verified</span>',
            'rejected' => '<span class="badge bg-danger">Rejected</span>',
        ];
        
        return $badges[$this->kyc_status] ?? $badges['not_submitted'];
    }
}
