<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CardTransaction extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'card_type_id',
        'card_key_id',
        'amount',
        'base_amount',
        'gateway_fee',
        'gateway_fee_percentage',
        'payment_method',
        'transaction_id',
        'status',
        'customer_name',
        'customer_phone',
        'customer_email',
        'purchased_at',
        'notes',
    ];

    protected $casts = [
        'purchased_at' => 'datetime',
        'amount' => 'decimal:2',
        'base_amount' => 'decimal:2',
        'gateway_fee' => 'decimal:2',
        'gateway_fee_percentage' => 'decimal:2',
    ];

    public function scopeCompleted($query)
    {
        return $query->where('status', 'completed');
    }

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    public function scopeFailed($query)
    {
        return $query->where('status', 'failed');
    }

    public function scopeByUser($query, $userId)
    {
        return $query->where('user_id', $userId);
    }

    // Relationships
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function cardType()
    {
        return $this->belongsTo(CardType::class);
    }

    public function cardKey()
    {
        return $this->belongsTo(CardKey::class);
    }
}

