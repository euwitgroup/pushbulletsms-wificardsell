<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CardKey extends Model
{
    use HasFactory;

    protected $fillable = [
        'card_type_id',
        'key_code',
        'status',
        'sold_to_user_id',
        'sold_at',
        'expires_at',
    ];

    protected $casts = [
        'sold_at' => 'datetime',
        'expires_at' => 'datetime',
    ];

    public function scopeAvailable($query)
    {
        return $query->where('status', 'available');
    }

    public function scopeSold($query)
    {
        return $query->where('status', 'sold');
    }

    public function scopeExpired($query)
    {
        return $query->where('status', 'expired');
    }

    public function scopeByCardType($query, $cardTypeId)
    {
        return $query->where('card_type_id', $cardTypeId);
    }

    // Relationships
    public function cardType()
    {
        return $this->belongsTo(CardType::class);
    }

    public function soldToUser()
    {
        return $this->belongsTo(User::class, 'sold_to_user_id');
    }

    public function transaction()
    {
        return $this->hasOne(CardTransaction::class);
    }

    // Helper methods
    public function markAsSold($userId)
    {
        $this->update([
            'status' => 'sold',
            'sold_to_user_id' => $userId,
            'sold_at' => now(),
        ]);
    }

    public function markAsExpired()
    {
        $this->update([
            'status' => 'expired',
            'expires_at' => now(),
        ]);
    }
}

