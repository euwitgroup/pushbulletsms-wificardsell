<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SmsPrice extends Model
{
    use HasFactory;

    protected $fillable = [
        'package_name',
        'package_type',
        'base_price',
        'pricing_tiers',
        'minimum_buy',
        'features',
        'order',
        'is_active',
        'is_featured',
    ];

    protected $casts = [
        'pricing_tiers' => 'array',
        'features' => 'array',
        'is_active' => 'boolean',
        'is_featured' => 'boolean',
    ];

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeOrdered($query)
    {
        return $query->orderBy('order', 'asc');
    }

    public function scopeFeatured($query)
    {
        return $query->where('is_featured', true);
    }
}
