<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SmsPackage extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'sms_gateway_id',
        'sms_count',
        'price',
        'description',
        'is_active',
        'status',
        'is_featured',
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'is_active' => 'boolean',
        'status' => 'boolean',
        'is_featured' => 'boolean',
    ];

    public function scopeActive($query)
    {
        return $query->where('status', true);
    }

    public function smsGateway()
    {
        return $this->belongsTo(SmsGateway::class, 'sms_gateway_id');
    }
}
