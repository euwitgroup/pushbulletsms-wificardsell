<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'sms_template_id',
        'type',
        'title',
        'message',
        'data',
        'icon',
        'color',
        'link',
        'send_sms',
        'sms_sent',
        'sms_sent_at',
        'sms_error',
        'is_read',
        'read_at',
    ];

    protected $casts = [
        'data' => 'array',
        'is_read' => 'boolean',
        'send_sms' => 'boolean',
        'sms_sent' => 'boolean',
        'read_at' => 'datetime',
        'sms_sent_at' => 'datetime',
    ];

    /**
     * Get the user that owns the notification
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the SMS template for this notification
     */
    public function smsTemplate()
    {
        return $this->belongsTo(SmsTemplate::class);
    }

    /**
     * Mark notification as read
     */
    public function markAsRead()
    {
        $this->update([
            'is_read' => true,
            'read_at' => now(),
        ]);
    }

    /**
     * Scope for unread notifications
     */
    public function scopeUnread($query)
    {
        return $query->where('is_read', false);
    }

    /**
     * Scope for read notifications
     */
    public function scopeRead($query)
    {
        return $query->where('is_read', true);
    }

    /**
     * Scope for specific user
     */
    public function scopeForUser($query, $userId)
    {
        return $query->where('user_id', $userId);
    }

    /**
     * Scope for admin notifications (user_id is null)
     */
    public function scopeForAdmin($query)
    {
        return $query->whereNull('user_id');
    }

    /**
     * Scope for specific type
     */
    public function scopeOfType($query, $type)
    {
        return $query->where('type', $type);
    }

    /**
     * Get icon HTML
     */
    public function getIconHtml()
    {
        $icon = $this->icon ?? 'fa-bell';
        $color = $this->color ?? 'info';
        
        $colorMap = [
            'success' => 'success',
            'info' => 'info',
            'warning' => 'warning',
            'danger' => 'danger',
            'primary' => 'primary',
        ];
        
        $bgColor = $colorMap[$color] ?? 'info';
        
        return '<div class="notification-icon bg-' . $bgColor . '"><i class="fas ' . $icon . '"></i></div>';
    }

    /**
     * Get time ago
     */
    public function getTimeAgo()
    {
        return $this->created_at->diffForHumans();
    }
}

