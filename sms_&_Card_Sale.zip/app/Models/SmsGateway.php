<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SmsGateway extends Model
{
    use HasFactory;

    protected $fillable = [
        'gateway_name',
        'api_key',
        'sender_id',
        'api_url',
        'message_type',
        'device_name',
        'device_id',
        'is_active',
        'cost_per_sms',
    ];

    protected $casts = [
        'is_active' => 'boolean',
    ];
}
