<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CardType extends Model
{
    use HasFactory;

    protected $fillable = [
        'card_category_id',
        'name',
        'price',
        'image',
        'description',
        'validity_value',
        'validity_type',
        'order',
        'is_active',
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'is_active' => 'boolean',
    ];

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeOrdered($query)
    {
        return $query->orderBy('order', 'asc');
    }

    // Relationships
    public function category()
    {
        return $this->belongsTo(CardCategory::class, 'card_category_id');
    }

    public function cardCategory()
    {
        return $this->belongsTo(CardCategory::class, 'card_category_id');
    }

    public function cardKeys()
    {
        return $this->hasMany(CardKey::class);
    }

    public function availableKeys()
    {
        return $this->hasMany(CardKey::class)->where('status', 'available');
    }

    public function soldKeys()
    {
        return $this->hasMany(CardKey::class)->where('status', 'sold');
    }

    public function transactions()
    {
        return $this->hasMany(CardTransaction::class);
    }

    // Helper methods
    public function getAvailableStockAttribute()
    {
        return $this->availableKeys()->count();
    }

    public function getSoldCountAttribute()
    {
        return $this->soldKeys()->count();
    }
}

