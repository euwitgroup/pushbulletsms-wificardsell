<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class InvoicesExport implements FromCollection, WithHeadings, WithMapping, WithStyles
{
    protected $invoices;

    public function __construct($invoices)
    {
        $this->invoices = $invoices;
    }

    public function collection()
    {
        return $this->invoices;
    }

    public function headings(): array
    {
        return [
            'Invoice #',
            'User Name',
            'User Email',
            'Package Name',
            'SMS Count',
            'Amount (৳)',
            'Payment Method',
            'Status',
            'Date',
            'Time'
        ];
    }

    public function map($invoice): array
    {
        return [
            'INV-' . str_pad($invoice->id, 6, '0', STR_PAD_LEFT),
            $invoice->user->name ?? 'N/A',
            $invoice->user->email ?? 'N/A',
            $invoice->description ?? 'SMS Package',
            $invoice->sms_count ?? 0,
            number_format($invoice->amount, 2),
            ucfirst($invoice->payment_method ?? 'N/A'),
            ucfirst($invoice->status),
            $invoice->created_at->format('M d, Y'),
            $invoice->created_at->format('h:i A')
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => ['font' => ['bold' => true]],
        ];
    }
}
