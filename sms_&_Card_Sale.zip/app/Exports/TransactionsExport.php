<?php

namespace App\Exports;

use App\Models\Transaction;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class TransactionsExport implements FromCollection, WithHeadings, WithMapping, WithStyles
{
    protected $transactions;

    public function __construct($transactions)
    {
        $this->transactions = $transactions;
    }

    public function collection()
    {
        return $this->transactions;
    }

    public function headings(): array
    {
        return [
            'ID',
            'Transaction ID',
            'User Name',
            'User Email',
            'Type',
            'Amount (৳)',
            'Status',
            'Description',
            'Date',
            'Time'
        ];
    }

    public function map($transaction): array
    {
        return [
            $transaction->id,
            $transaction->transaction_id,
            $transaction->user->name ?? 'N/A',
            $transaction->user->email ?? 'N/A',
            ucfirst($transaction->type),
            number_format($transaction->amount, 2),
            ucfirst($transaction->status),
            $transaction->description ?? '-',
            $transaction->created_at->format('M d, Y'),
            $transaction->created_at->format('h:i A')
        ];
    }

    public function styles(Worksheet $sheet)
    {
        return [
            1 => ['font' => ['bold' => true]],
        ];
    }
}
