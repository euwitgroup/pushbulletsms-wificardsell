<?php

namespace App\Http\Controllers;

use App\Models\ContactInfo;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    /**
     * Display the contact page
     */
    public function index()
    {
        $phones = ContactInfo::active()->byType('phone')->ordered()->get();
        $emails = ContactInfo::active()->byType('email')->ordered()->get();
        $addresses = ContactInfo::active()->byType('address')->ordered()->get();
        $hours = ContactInfo::active()->byType('hours')->ordered()->get();
        $socials = ContactInfo::active()->byType('social')->ordered()->get();
        
        return view('contact', compact('phones', 'emails', 'addresses', 'hours', 'socials'));
    }
}

