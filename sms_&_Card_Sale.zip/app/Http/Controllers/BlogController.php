<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use Illuminate\Http\Request;

class BlogController extends Controller
{
    /**
     * Display a listing of all blogs
     */
    public function index()
    {
        $blogs = Blog::active()->latest()->paginate(12);
        
        return view('blogs.index', compact('blogs'));
    }

    /**
     * Display the specified blog post
     */
    public function show($slug)
    {
        $blog = Blog::where('slug', $slug)->where('is_active', true)->firstOrFail();
        
        // Get related blogs from the same category
        $relatedBlogs = Blog::active()
            ->where('category', $blog->category)
            ->where('id', '!=', $blog->id)
            ->latest()
            ->limit(3)
            ->get();
        
        return view('blogs.show', compact('blog', 'relatedBlogs'));
    }
}

