<?php

namespace App\Http\Controllers;

use App\Models\CardCategory;
use App\Models\CardType;
use App\Models\CardKey;
use App\Models\CardTransaction;
use App\Models\Setting;
use App\Services\GuestRupantorPayService;
use App\Services\SmsService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class WifiCardController extends Controller
{
    protected $rupantorPay;
    protected $smsService;

    public function __construct(GuestRupantorPayService $rupantorPay, SmsService $smsService)
    {
        $this->rupantorPay = $rupantorPay;
        $this->smsService = $smsService;
    }

    /**
     * Display WiFi cards page
     */
    public function index(Request $request)
    {
        $categories = CardCategory::where('is_active', true)
            ->orderBy('order')
            ->get();

        $selectedCategory = $request->get('category');
        
        $cardTypes = CardType::with('cardCategory')
            ->where('is_active', true)
            ->when($selectedCategory, function ($query) use ($selectedCategory) {
                return $query->where('card_category_id', $selectedCategory);
            })
            ->withCount([
                'cardKeys as available_keys' => function ($query) {
                    $query->where('status', 'available');
                }
            ])
            ->orderBy('order')
            ->get();

        return view('wifi-cards.index', compact('categories', 'cardTypes', 'selectedCategory'));
    }

    /**
     * Show checkout page
     */
    public function checkout($id)
    {
        $cardType = CardType::with('cardCategory')
            ->where('is_active', true)
            ->findOrFail($id);

        // Check if cards are available
        $availableKeys = $cardType->cardKeys()->where('status', 'available')->count();
        
        if ($availableKeys == 0) {
            return redirect()->route('wifi-cards.index')
                ->with('error', 'Sorry, this card is currently out of stock.');
        }

        $gatewayFeePercentage = Setting::get('rupantorpay_payment_charge', 0);
        $gatewayFee = ($cardType->price * $gatewayFeePercentage) / 100;
        $totalAmount = $cardType->price + $gatewayFee;

        return view('wifi-cards.checkout', compact('cardType', 'gatewayFeePercentage', 'gatewayFee', 'totalAmount'));
    }

    /**
     * Process payment
     */
    public function processPayment(Request $request, $id)
    {
        $request->validate([
            'customer_name' => 'required|string|max:255',
            'customer_phone' => 'required|string|max:20',
            'customer_email' => 'nullable|email|max:255',
        ]);

        $cardType = CardType::with('cardCategory')
            ->where('is_active', true)
            ->findOrFail($id);

        // Check if cards are available
        $availableKey = $cardType->cardKeys()
            ->where('status', 'available')
            ->first();
        
        if (!$availableKey) {
            return back()->with('error', 'Sorry, this card is currently out of stock.');
        }

        // Calculate amounts
        $gatewayFeePercentage = Setting::get('rupantorpay_payment_charge', 0);
        $gatewayFee = ($cardType->price * $gatewayFeePercentage) / 100;
        $totalAmount = $cardType->price + $gatewayFee;

        try {
            DB::beginTransaction();

            // Create transaction
            $transaction = CardTransaction::create([
                'card_type_id' => $cardType->id,
                'card_key_id' => $availableKey->id,
                'amount' => $totalAmount,
                'base_amount' => $cardType->price,
                'gateway_fee' => $gatewayFee,
                'gateway_fee_percentage' => $gatewayFeePercentage,
                'payment_method' => 'RupantorPay',
                'status' => 'pending',
                'customer_name' => $request->customer_name,
                'customer_phone' => $request->customer_phone,
                'customer_email' => $request->customer_email,
                'transaction_id' => 'WIFI-' . time() . '-' . $availableKey->id,
            ]);

            // Reserve the key (mark as pending)
            $availableKey->update(['status' => 'pending']);

            DB::commit();

            // Create payment with RupantorPay
            $result = $this->rupantorPay->createPayment(
                $totalAmount,
                [
                    'transaction_id' => $transaction->transaction_id,
                    'card_transaction_id' => $transaction->id,
                    'card_type_id' => $cardType->id,
                    'card_key_id' => $availableKey->id,
                    'customer_name' => $request->customer_name,
                    'customer_phone' => $request->customer_phone,
                ]
            );

            if ($result['success']) {
                // Redirect to payment gateway
                return redirect($result['data']['payment_url'] ?? $result['data']['url']);
            } else {
                // Payment initiation failed, rollback
                $transaction->update(['status' => 'failed']);
                $availableKey->update(['status' => 'available']);
                
                return back()->with('error', 'Payment initiation failed: ' . $result['error']);
            }

        } catch (\Exception $e) {
            DB::rollback();
            Log::error('WiFi Card Payment Error: ' . $e->getMessage());
            return back()->with('error', 'An error occurred. Please try again.');
        }
    }

    /**
     * Payment success callback
     */
    public function paymentSuccess(Request $request)
    {
        // RupantorPay sends transactionId (not transaction_id)
        $rupantorPayId = $request->get('transactionId');
        $status = $request->get('status');
        
        Log::info('WiFi Card Payment Success Callback', [
            'transactionId' => $rupantorPayId,
            'status' => $status,
            'all_params' => $request->all()
        ]);

        // If we have the transaction_id in metadata (from our system)
        if ($request->has('transaction_id')) {
            $transactionId = $request->get('transaction_id');
        } else {
            // Try to find by the most recent pending transaction
            $transaction = CardTransaction::where('status', 'pending')
                ->orderBy('created_at', 'desc')
                ->first();
            
            if (!$transaction) {
                return redirect()->route('wifi-cards.index')
                    ->with('error', 'Transaction not found. Please contact support with Transaction ID: ' . $rupantorPayId);
            }
            
            $transactionId = $transaction->transaction_id;
        }

        $transaction = CardTransaction::where('transaction_id', $transactionId)->first();

        if (!$transaction) {
            return redirect()->route('wifi-cards.index')
                ->with('error', 'Transaction not found.');
        }

        // If already processed, just show success
        if ($transaction->status === 'completed') {
            return view('wifi-cards.success', compact('transaction'));
        }

        // Only process if payment status is completed
        if ($status !== 'completed') {
            return redirect()->route('wifi-cards.index')
                ->with('error', 'Payment was not completed. Status: ' . $status);
        }

        // Process the transaction
        try {
            DB::beginTransaction();

            // Update transaction status
            $transaction->update([
                'status' => 'completed',
                'purchased_at' => now(),
            ]);

            // Mark card key as sold
            $cardKey = $transaction->cardKey;
            $cardKey->update([
                'status' => 'sold',
                'sold_at' => now(),
            ]);

            DB::commit();

            // Send SMS with card key
            $this->sendCardKeySms($transaction);

            Log::info('WiFi Card Purchase Completed', [
                'transaction_id' => $transaction->transaction_id,
                'customer_phone' => $transaction->customer_phone,
                'card_key' => $cardKey->key_code
            ]);

            return view('wifi-cards.success', compact('transaction'));

        } catch (\Exception $e) {
            DB::rollback();
            Log::error('WiFi Card Success Processing Error: ' . $e->getMessage());
            
            return redirect()->route('wifi-cards.index')
                ->with('error', 'An error occurred processing your purchase.');
        }
    }

    /**
     * Payment cancel callback
     */
    public function paymentCancel(Request $request)
    {
        $rupantorPayId = $request->get('transactionId');
        
        Log::info('WiFi Card Payment Cancelled', [
            'transactionId' => $rupantorPayId,
            'all_params' => $request->all()
        ]);
        
        // Try to find by transaction_id in request or most recent pending
        if ($request->has('transaction_id')) {
            $transactionId = $request->get('transaction_id');
        } else {
            $transaction = CardTransaction::where('status', 'pending')
                ->orderBy('created_at', 'desc')
                ->first();
            $transactionId = $transaction ? $transaction->transaction_id : null;
        }
        
        if ($transactionId) {
            $transaction = CardTransaction::where('transaction_id', $transactionId)->first();
            
            if ($transaction && $transaction->status === 'pending') {
                $transaction->update(['status' => 'cancelled']);
                
                // Release the card key
                if ($transaction->cardKey) {
                    $transaction->cardKey->update(['status' => 'available']);
                }
                
                Log::info('WiFi Card transaction cancelled and key released', [
                    'transaction_id' => $transaction->transaction_id
                ]);
            }
        }

        return redirect()->route('wifi-cards.index')
            ->with('error', 'Payment was cancelled.');
    }

    /**
     * Payment webhook
     */
    public function paymentWebhook(Request $request)
    {
        try {
            $data = $request->all();
            
            Log::info('WiFi Card Payment webhook received', ['data' => $data]);

            $paymentStatus = $data['status'] ?? $data['payment_status'] ?? null;
            
            if ($paymentStatus === 'completed' || $paymentStatus === 'success') {
                $metadata = $data['metadata'] ?? [];
                $transactionId = $metadata['transaction_id'] ?? null;
                
                if ($transactionId) {
                    $transaction = CardTransaction::where('transaction_id', $transactionId)->first();

                    if ($transaction && $transaction->status === 'pending') {
                        DB::beginTransaction();
                        
                        // Update transaction
                        $transaction->update([
                            'status' => 'completed',
                            'purchased_at' => now(),
                        ]);

                        // Mark card key as sold
                        $cardKey = $transaction->cardKey;
                        $cardKey->update([
                            'status' => 'sold',
                            'sold_at' => now(),
                        ]);

                        DB::commit();

                        // Send SMS
                        $this->sendCardKeySms($transaction);
                        
                        Log::info('WiFi Card payment processed successfully via webhook', [
                            'transaction_id' => $transactionId
                        ]);
                    }
                }
            } elseif ($paymentStatus === 'failed') {
                $metadata = $data['metadata'] ?? [];
                $transactionId = $metadata['transaction_id'] ?? null;
                
                if ($transactionId) {
                    $transaction = CardTransaction::where('transaction_id', $transactionId)->first();
                    
                    if ($transaction && $transaction->status === 'pending') {
                        $transaction->update(['status' => 'failed']);
                        
                        // Release the card key
                        if ($transaction->cardKey) {
                            $transaction->cardKey->update(['status' => 'available']);
                        }
                    }
                }
            }

            return response()->json(['status' => 'success']);

        } catch (\Exception $e) {
            Log::error('WiFi Card webhook error: ' . $e->getMessage());
            return response()->json(['status' => 'error'], 500);
        }
    }

    /**
     * Send SMS with card key to customer
     */
    protected function sendCardKeySms($transaction)
    {
        try {
            $cardKey = $transaction->cardKey;
            $cardType = $transaction->cardType;
            
            $variables = [
                'company_name' => Setting::get('site_name', 'SMS & Card Sale'),
                'wifi_card_key' => $cardKey->key_code,
                'card_name' => $cardType->name,
                'card_price' => '৳' . number_format($cardType->price, 2),
            ];

            // Try to get WiFi Card template by name first
            $template = \App\Models\SmsTemplate::where('name', 'Wifi Card')
                ->where('status', true)
                ->first();

            if ($template) {
                $message = $template->parseMessage($variables);
                $this->smsService->send($transaction->customer_phone, $message);
                Log::info('WiFi Card SMS sent', [
                    'phone' => $transaction->customer_phone,
                    'card_key' => $cardKey->key_code
                ]);
            } else {
                Log::warning('WiFi Card SMS template not found');
            }

        } catch (\Exception $e) {
            Log::error('WiFi Card SMS sending error: ' . $e->getMessage());
        }
    }
}

