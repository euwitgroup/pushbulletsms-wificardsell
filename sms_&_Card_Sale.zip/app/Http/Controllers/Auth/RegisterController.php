<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Setting;
use App\Services\SmsService;
use App\Services\NotificationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Session;

class RegisterController extends Controller
{
    public function showRegistrationForm()
    {
        // Check if registration is enabled
        $enableRegistration = Setting::get('enable_registration', '1');
        
        if ($enableRegistration != '1') {
            return view('auth.register');
        }
        
        return view('auth.register');
    }

    public function sendOtp(Request $request)
    {
        $request->validate([
            'phone' => ['required', 'string', 'regex:/^01[0-9]{9}$/', 'unique:users,phone']
        ], [
            'phone.regex' => 'Please enter a valid Bangladeshi phone number (01XXXXXXXXX)',
            'phone.unique' => 'This phone number is already registered.'
        ]);

        $phone = $request->phone;
        $otpLength = Setting::get('otp_length', '6');
        $otpExpiryMinutes = Setting::get('otp_expiry_minutes', '5');
        
        // Generate OTP
        $otp = str_pad(random_int(0, pow(10, $otpLength) - 1), $otpLength, '0', STR_PAD_LEFT);
        
        // Store OTP in cache
        Cache::put('otp_' . $phone, $otp, now()->addMinutes($otpExpiryMinutes));
        
        // Send OTP using SMS Service with template
        $smsService = new SmsService();
        $sent = $smsService->sendOtp($phone, $otp);
        
        if ($sent) {
            return response()->json([
                'success' => true,
                'message' => 'OTP sent successfully to your phone number.'
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Failed to send OTP. Please check your SMS gateway configuration and templates.'
            ], 500);
        }
    }

    public function register(Request $request)
    {
        $passwordMinLength = Setting::get('password_min_length', '8');
        $phoneVerificationRequired = Setting::get('phone_verification_required', '1');
        $enableRecaptcha = Setting::get('enable_recaptcha', '0');

        // Validation rules
        $rules = [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'phone' => ['required', 'string', 'regex:/^01[0-9]{9}$/', 'unique:users,phone'],
            'password' => ['required', 'string', 'min:' . $passwordMinLength, 'confirmed'],
        ];

        // Add reCAPTCHA validation if enabled
        if ($enableRecaptcha == '1') {
            $rules['g-recaptcha-response'] = ['required'];
        }

        $request->validate($rules, [
            'phone.regex' => 'Please enter a valid Bangladeshi phone number (01XXXXXXXXX)',
            'phone.unique' => 'This phone number is already registered.',
            'g-recaptcha-response.required' => 'Please complete the reCAPTCHA verification.'
        ]);

        // Verify reCAPTCHA if enabled
        if ($enableRecaptcha == '1') {
            $recaptchaSecret = Setting::get('recaptcha_secret_key', '');
            $recaptchaResponse = $request->input('g-recaptcha-response');
            
            $response = Http::asForm()->post('https://www.google.com/recaptcha/api/siteverify', [
                'secret' => $recaptchaSecret,
                'response' => $recaptchaResponse,
                'remoteip' => $request->ip()
            ]);

            $recaptchaData = $response->json();
            
            if (!$recaptchaData['success']) {
                return back()->withErrors(['g-recaptcha-response' => 'reCAPTCHA verification failed.'])->withInput();
            }
        }

        // If phone verification is required, send OTP and redirect to verification page
        if ($phoneVerificationRequired == '1') {
            // Store registration data in session
            Session::put('register_data', [
                'name' => $request->name,
                'email' => $request->email,
                'phone' => $request->phone,
                'password' => $request->password,
            ]);

            // Generate and send OTP
            $otpLength = Setting::get('otp_length', '6');
            $otpExpiryMinutes = Setting::get('otp_expiry_minutes', '5');
            $otp = str_pad(random_int(0, pow(10, $otpLength) - 1), $otpLength, '0', STR_PAD_LEFT);
            
            Cache::put('otp_' . $request->phone, $otp, now()->addMinutes($otpExpiryMinutes));
            
            // Send OTP via SMS
            $smsService = new SmsService();
            $sent = $smsService->sendOtp($request->phone, $otp);
            
            if (!$sent) {
                return back()->with('error', 'Failed to send OTP. Please try again.')->withInput();
            }

            Session::put('otp_phone', $request->phone);
            return redirect()->route('verify.otp')
                ->with('success', 'OTP sent to your phone number. Please verify to complete registration.');
        }

        // If phone verification is not required, create user directly
        return $this->createUser($request->all());
    }

    /**
     * Show OTP verification form
     */
    public function showOtpForm()
    {
        if (!Session::has('register_data')) {
            return redirect()->route('register')
                ->with('error', 'Please complete the registration form first.');
        }

        return view('auth.verify-otp');
    }

    /**
     * Verify OTP and create user account
     */
    public function verifyOtp(Request $request)
    {
        $request->validate([
            'otp' => ['required', 'string', 'size:' . Setting::get('otp_length', '6')],
        ]);

        $registerData = Session::get('register_data');
        $phone = Session::get('otp_phone');

        if (!$registerData || !$phone) {
            return redirect()->route('register')
                ->with('error', 'Session expired. Please register again.');
        }

        // Verify OTP
        $storedOtp = Cache::get('otp_' . $phone);
        
        if (!$storedOtp || $storedOtp !== $request->otp) {
            return back()->with('error', 'Invalid or expired OTP code.');
        }

        // Clear OTP from cache
        Cache::forget('otp_' . $phone);

        // Create user
        $userData = array_merge($registerData, ['phone_verified_at' => now()]);
        $user = $this->createUser($userData);

        // Clear session data
        Session::forget('register_data');
        Session::forget('otp_phone');

        // Log the user in
        Auth::login($user);

        return redirect()->route('user.dashboard')
            ->with('success', 'Registration successful! Welcome to ' . Setting::get('site_name', 'SMS & Card Sale') . '.');
    }

    /**
     * Resend OTP
     */
    public function resendOtp(Request $request)
    {
        $phone = Session::get('otp_phone');
        
        if (!$phone) {
            return response()->json([
                'success' => false,
                'message' => 'Session expired. Please start registration again.'
            ], 400);
        }

        // Generate new OTP
        $otpLength = Setting::get('otp_length', '6');
        $otpExpiryMinutes = Setting::get('otp_expiry_minutes', '5');
        $otp = str_pad(random_int(0, pow(10, $otpLength) - 1), $otpLength, '0', STR_PAD_LEFT);
        
        Cache::put('otp_' . $phone, $otp, now()->addMinutes($otpExpiryMinutes));
        
        // Send OTP via SMS
        $smsService = new SmsService();
        $sent = $smsService->sendOtp($phone, $otp);
        
        if ($sent) {
            return response()->json([
                'success' => true,
                'message' => 'OTP resent successfully to your phone number.'
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Failed to send OTP. Please try again.'
            ], 500);
        }
    }

    /**
     * Create user account
     */
    protected function createUser($data)
    {
        $user = User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'password' => Hash::make($data['password']),
            'role' => 'user',
            'balance' => 0,
            'status' => true,
            'phone_verified_at' => $data['phone_verified_at'] ?? null,
        ]);

        // Send registration notifications
        $notificationService = new NotificationService();
        $notificationService->userRegistered($user);

        return $user;
    }
}
