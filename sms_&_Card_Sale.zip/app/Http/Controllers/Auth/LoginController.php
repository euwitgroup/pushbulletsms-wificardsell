<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Validation\ValidationException;

class LoginController extends Controller
{
    public function showLoginForm()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $enableRecaptcha = Setting::get('enable_recaptcha', '0');
        $maxLoginAttempts = Setting::get('max_login_attempts', '5');
        $loginRateLimit = Setting::get('login_rate_limit', '5');
        
        // Validate input
        $rules = [
            'email' => ['required', 'email'],
            'password' => ['required'],
        ];
        
        if ($enableRecaptcha == '1') {
            $rules['g-recaptcha-response'] = ['required'];
        }
        
        $request->validate($rules, [
            'g-recaptcha-response.required' => 'Please complete the reCAPTCHA verification.'
        ]);

        // Verify reCAPTCHA if enabled
        if ($enableRecaptcha == '1') {
            if (!$this->verifyRecaptcha($request)) {
                return back()->withErrors(['g-recaptcha-response' => 'reCAPTCHA verification failed.'])->withInput($request->only('email'));
            }
        }

        // Check rate limiting
        $throttleKey = 'login.' . $request->ip();
        
        if (RateLimiter::tooManyAttempts($throttleKey, $loginRateLimit)) {
            $seconds = RateLimiter::availableIn($throttleKey);
            
            return back()->withErrors([
                'email' => 'Too many login attempts. Please try again in ' . ceil($seconds / 60) . ' minutes.',
            ])->withInput($request->only('email'));
        }

        // Check failed login attempts for this email
        $failedAttemptsKey = 'failed_login_attempts.' . $request->email;
        $failedAttempts = Cache::get($failedAttemptsKey, 0);
        
        if ($failedAttempts >= $maxLoginAttempts) {
            $lockoutTime = Cache::get('login_lockout.' . $request->email);
            $remainingTime = $lockoutTime ? ceil(($lockoutTime - time()) / 60) : 0;
            
            if ($remainingTime > 0) {
                return back()->withErrors([
                    'email' => "Your account is temporarily locked due to too many failed login attempts. Please try again in {$remainingTime} minutes.",
                ])->withInput($request->only('email'));
            } else {
                // Reset failed attempts if lockout time has passed
                Cache::forget($failedAttemptsKey);
                Cache::forget('login_lockout.' . $request->email);
            }
        }

        // Attempt login
        $credentials = $request->only('email', 'password');
        
        if (Auth::attempt($credentials, $request->boolean('remember'))) {
            $request->session()->regenerate();

            $user = Auth::user();
            
            // Check if user account is active
            if (!$user->status) {
                Auth::logout();
                return back()->withErrors([
                    'email' => 'Your account has been disabled. Please contact support.',
                ])->withInput($request->only('email'));
            }
            
            // Check if phone verification is required (only for non-admin users)
            if (!$user->isAdmin()) {
                $phoneVerificationRequired = Setting::get('phone_verification_required', '1');
                if ($phoneVerificationRequired == '1' && !$user->hasVerifiedPhone()) {
                    Auth::logout();
                    return back()->withErrors([
                        'email' => 'Please verify your phone number before logging in.',
                    ])->withInput($request->only('email'));
                }
            }

            // Clear rate limiting and failed attempts on successful login
            RateLimiter::clear($throttleKey);
            Cache::forget($failedAttemptsKey);
            Cache::forget('login_lockout.' . $request->email);

            // Redirect based on user role
            if ($user->isAdmin()) {
                return redirect()->intended(route('admin.dashboard'));
            }

            return redirect()->intended(route('user.dashboard'));
        }

        // Increment rate limiter
        RateLimiter::hit($throttleKey, 60);
        
        // Track failed login attempts
        $failedAttempts++;
        Cache::put($failedAttemptsKey, $failedAttempts, now()->addMinutes(30));
        
        // Lock account if max attempts reached
        if ($failedAttempts >= $maxLoginAttempts) {
            $lockoutTime = time() + (30 * 60); // 30 minutes lockout
            Cache::put('login_lockout.' . $request->email, $lockoutTime, now()->addMinutes(30));
            
            return back()->withErrors([
                'email' => 'Too many failed login attempts. Your account has been temporarily locked for 30 minutes.',
            ])->withInput($request->only('email'));
        }

        // Return error with remaining attempts
        $remainingAttempts = $maxLoginAttempts - $failedAttempts;
        
        return back()->withErrors([
            'email' => "The provided credentials do not match our records. {$remainingAttempts} attempts remaining.",
        ])->withInput($request->only('email'));
    }

    protected function verifyRecaptcha(Request $request)
    {
        try {
            $recaptchaSecret = Setting::get('recaptcha_secret_key', '');
            $recaptchaResponse = $request->input('g-recaptcha-response');
            
            if (empty($recaptchaResponse)) {
                return false;
            }
            
            $response = Http::asForm()->post('https://www.google.com/recaptcha/api/siteverify', [
                'secret' => $recaptchaSecret,
                'response' => $recaptchaResponse,
                'remoteip' => $request->ip()
            ]);

            $data = $response->json();
            
            return isset($data['success']) && $data['success'] === true;
        } catch (\Exception $e) {
            \Log::error('reCAPTCHA verification error: ' . $e->getMessage());
            return false;
        }
    }

    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login')->with('success', 'You have been logged out successfully.');
    }
}
