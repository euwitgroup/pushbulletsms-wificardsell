<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\SmsService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class ForgotPasswordController extends Controller
{
    protected $smsService;

    public function __construct(SmsService $smsService)
    {
        $this->smsService = $smsService;
    }

    /**
     * Show forgot password form
     */
    public function showForgotForm()
    {
        return view('auth.forgot-password');
    }

    /**
     * Send OTP to phone number
     */
    public function sendOtp(Request $request)
    {
        $request->validate([
            'phone' => 'required|string'
        ]);

        // Find user by phone
        $user = User::where('phone', $request->phone)->first();

        if (!$user) {
            return back()->with('error', 'No account found with this phone number.');
        }

        // Generate OTP
        $user->generateOtp();

        // Send OTP via SMS
        try {
            $this->smsService->sendOtp($user->phone, $user->otp_code);
            
            // Store phone in session for verification
            Session::put('reset_phone', $user->phone);
            
            return redirect()->route('password.reset')
                ->with('success', 'OTP sent to your phone number.');
        } catch (\Exception $e) {
            return back()->with('error', 'Failed to send OTP. Please try again.');
        }
    }

    /**
     * Show reset password form
     */
    public function showResetForm()
    {
        if (!Session::has('reset_phone')) {
            return redirect()->route('password.request')
                ->with('error', 'Please enter your phone number first.');
        }

        return view('auth.reset-password');
    }

    /**
     * Reset password
     */
    public function resetPassword(Request $request)
    {
        $request->validate([
            'otp' => 'required|string|size:6',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $phone = Session::get('reset_phone');
        
        if (!$phone) {
            return redirect()->route('password.request')
                ->with('error', 'Session expired. Please try again.');
        }

        // Find user
        $user = User::where('phone', $phone)->first();

        if (!$user) {
            return redirect()->route('password.request')
                ->with('error', 'User not found.');
        }

        // Verify OTP
        if (!$user->verifyOtp($request->otp)) {
            return back()->with('error', 'Invalid or expired OTP.');
        }

        // Update password
        $user->password = Hash::make($request->password);
        $user->otp_code = null;
        $user->otp_expires_at = null;
        $user->save();

        // Clear session
        Session::forget('reset_phone');

        return redirect()->route('login')
            ->with('success', 'Password reset successfully. Please login with your new password.');
    }
}
