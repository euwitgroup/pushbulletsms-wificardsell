<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Config;

class InstallController extends Controller
{
    /**
     * Show installation welcome page
     */
    public function index()
    {
        // Check if already installed
        if ($this->isInstalled()) {
            return redirect('/')->with('error', 'Application is already installed!');
        }

        return view('install.welcome');
    }

    /**
     * Show requirements check page
     */
    public function requirements()
    {
        $requirements = $this->checkRequirements();
        $permissions = $this->checkPermissions();
        
        $allRequirementsMet = !in_array(false, array_column($requirements['php'], 'status')) &&
                              !in_array(false, array_column($requirements['extensions'], 'status'));
        
        $allPermissionsMet = !in_array(false, array_column($permissions, 'status'));
        
        return view('install.requirements', compact('requirements', 'permissions', 'allRequirementsMet', 'allPermissionsMet'));
    }

    /**
     * Show database configuration page
     */
    public function database()
    {
        return view('install.database');
    }

    /**
     * Test database connection
     */
    public function testDatabase(Request $request)
    {
        $request->validate([
            'db_host' => 'required',
            'db_port' => 'required|numeric',
            'db_name' => 'required',
            'db_username' => 'required',
            'db_password' => 'nullable',
        ]);

        try {
            // Test connection
            $pdo = new \PDO(
                "mysql:host={$request->db_host};port={$request->db_port};dbname={$request->db_name}",
                $request->db_username,
                $request->db_password
            );

            return response()->json([
                'success' => true,
                'message' => 'Database connection successful!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Database connection failed: ' . $e->getMessage()
            ], 400);
        }
    }

    /**
     * Save database configuration and run migrations
     */
    public function setupDatabase(Request $request)
    {
        $request->validate([
            'db_host' => 'required',
            'db_port' => 'required|numeric',
            'db_name' => 'required',
            'db_username' => 'required',
            'db_password' => 'nullable',
        ]);

        try {
            // Update .env file
            $this->updateEnv([
                'DB_HOST' => $request->db_host,
                'DB_PORT' => $request->db_port,
                'DB_DATABASE' => $request->db_name,
                'DB_USERNAME' => $request->db_username,
                'DB_PASSWORD' => $request->db_password,
            ]);

            // Clear config cache
            Artisan::call('config:clear');

            // Test connection with new credentials
            DB::reconnect();
            DB::connection()->getPdo();

            // Run migrations
            Artisan::call('migrate', ['--force' => true]);

            // Run seeders
            Artisan::call('db:seed', ['--force' => true]);

            return response()->json([
                'success' => true,
                'message' => 'Database setup completed successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Database setup failed: ' . $e->getMessage()
            ], 400);
        }
    }

    /**
     * Show site configuration page
     */
    public function siteConfig()
    {
        return view('install.site-config');
    }

    /**
     * Save site configuration
     */
    public function saveSiteConfig(Request $request)
    {
        $request->validate([
            'app_name' => 'required|string|max:255',
            'app_url' => 'required|url',
            'admin_email' => 'required|email',
            'admin_password' => 'required|min:8|confirmed',
        ]);

        try {
            // Update .env file
            $this->updateEnv([
                'APP_NAME' => '"' . $request->app_name . '"',
                'APP_URL' => $request->app_url,
                'APP_ENV' => 'production',
                'APP_DEBUG' => 'false',
            ]);

            // Generate app key if not exists
            if (empty(env('APP_KEY'))) {
                Artisan::call('key:generate', ['--force' => true]);
            }

            // Update admin credentials
            DB::table('users')
                ->where('role', 'admin')
                ->update([
                    'email' => $request->admin_email,
                    'password' => bcrypt($request->admin_password),
                    'updated_at' => now(),
                ]);

            // Clear all caches
            Artisan::call('config:clear');
            Artisan::call('cache:clear');
            Artisan::call('route:clear');
            Artisan::call('view:clear');

            return response()->json([
                'success' => true,
                'message' => 'Site configuration saved successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Configuration failed: ' . $e->getMessage()
            ], 400);
        }
    }

    /**
     * Complete installation
     */
    public function complete()
    {
        try {
            // Create installation lock file
            File::put(storage_path('installed'), date('Y-m-d H:i:s'));

            // Create storage link
            Artisan::call('storage:link');

            // Cache config for production
            Artisan::call('config:cache');
            Artisan::call('route:cache');
            Artisan::call('view:cache');

            return view('install.complete');
        } catch (\Exception $e) {
            return back()->with('error', 'Installation completion failed: ' . $e->getMessage());
        }
    }

    /**
     * Check if application is already installed
     */
    private function isInstalled()
    {
        return File::exists(storage_path('installed'));
    }

    /**
     * Check system requirements
     */
    private function checkRequirements()
    {
        $requirements = [
            'php' => [
                [
                    'name' => 'PHP Version (>= 8.1)',
                    'status' => version_compare(PHP_VERSION, '8.1.0', '>='),
                    'current' => PHP_VERSION,
                    'required' => '8.1.0'
                ]
            ],
            'extensions' => []
        ];

        // Check required PHP extensions
        $extensions = [
            'OpenSSL', 'PDO', 'Mbstring', 'Tokenizer', 'XML', 'Ctype', 
            'JSON', 'BCMath', 'Fileinfo', 'GD', 'Curl', 'Zip'
        ];

        foreach ($extensions as $extension) {
            $requirements['extensions'][] = [
                'name' => $extension,
                'status' => extension_loaded(strtolower($extension))
            ];
        }

        return $requirements;
    }

    /**
     * Check directory permissions
     */
    private function checkPermissions()
    {
        $permissions = [];

        $folders = [
            'storage/app' => storage_path('app'),
            'storage/framework' => storage_path('framework'),
            'storage/logs' => storage_path('logs'),
            'bootstrap/cache' => base_path('bootstrap/cache'),
        ];

        foreach ($folders as $name => $path) {
            $permissions[] = [
                'name' => $name,
                'path' => $path,
                'status' => is_writable($path),
                'permission' => substr(sprintf('%o', fileperms($path)), -4)
            ];
        }

        return $permissions;
    }

    /**
     * Update .env file
     */
    private function updateEnv(array $data)
    {
        $envPath = base_path('.env');
        
        // If .env doesn't exist, copy from .env.example
        if (!File::exists($envPath)) {
            File::copy(base_path('.env.example'), $envPath);
        }

        $envContent = File::get($envPath);

        foreach ($data as $key => $value) {
            // Check if key exists
            if (preg_match("/^{$key}=/m", $envContent)) {
                // Update existing key
                $envContent = preg_replace(
                    "/^{$key}=.*/m",
                    "{$key}={$value}",
                    $envContent
                );
            } else {
                // Add new key
                $envContent .= "\n{$key}={$value}";
            }
        }

        File::put($envPath, $envContent);
    }
}
