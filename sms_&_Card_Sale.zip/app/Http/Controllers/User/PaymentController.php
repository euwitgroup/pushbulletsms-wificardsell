<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\SmsPackage;
use App\Models\Transaction;
use App\Models\Setting;
use App\Services\RupantorPayService;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    protected $rupantorPay;

    public function __construct(RupantorPayService $rupantorPay)
    {
        $this->rupantorPay = $rupantorPay;
    }

    public function showPackages()
    {
        $packages = SmsPackage::with('smsGateway')->active()->get();
        $gatewayFeePercentage = Setting::get('rupantorpay_payment_charge', 0);
        return view('user.payment.packages', compact('packages', 'gatewayFeePercentage'));
    }

    public function initiate(Request $request)
    {
        // Validate for either package_id or custom_amount
        $request->validate([
            'package_id' => 'nullable|exists:sms_packages,id',
            'custom_amount' => 'nullable|numeric|min:1|max:25000',
        ]);

        // Check if either package_id or custom_amount is provided
        if (!$request->has('package_id') && !$request->has('custom_amount')) {
            return back()->with('error', 'Please select a package or enter a custom amount.');
        }

        $user = auth()->user();
        $baseAmount = 0;
        $description = '';
        $metadata = [];

        // Handle package purchase
        if ($request->has('package_id')) {
            $package = SmsPackage::findOrFail($request->package_id);
            $baseAmount = $package->price;
            $description = 'Purchase ' . $package->name;
            $metadata = [
                'type' => 'package',
                'package_id' => $package->id,
                'package_name' => $package->name,
                'sms_count' => $package->sms_count,
            ];
        }
        // Handle custom amount deposit
        else if ($request->has('custom_amount')) {
            $baseAmount = $request->custom_amount;
            $description = 'Custom Balance Deposit';
            $metadata = [
                'type' => 'custom',
                'amount' => $baseAmount,
            ];
        }

        // Calculate gateway fee (currently using RupantorPay)
        $gatewayFeePercentage = Setting::get('rupantorpay_payment_charge', 0);
        $gatewayFee = ($baseAmount * $gatewayFeePercentage) / 100;
        $totalAmount = $baseAmount + $gatewayFee;

        // Create pending transaction
        $transaction = Transaction::create([
            'user_id' => $user->id,
            'transaction_id' => 'PAY-' . time() . '-' . $user->id,
            'payment_method' => 'RupantorPay',
            'base_amount' => $baseAmount,
            'gateway_fee' => $gatewayFee,
            'gateway_fee_percentage' => $gatewayFeePercentage,
            'amount' => $totalAmount,
            'type' => 'credit',
            'status' => 'pending',
            'description' => $description,
            'metadata' => $metadata,
        ]);

        try {
            $result = $this->rupantorPay->createPayment(
                $totalAmount,
                [
                    'transaction_id' => $transaction->transaction_id,
                    'user_id' => $user->id,
                    'base_amount' => $baseAmount,
                    'gateway_fee' => $gatewayFee,
                ]
            );

            if ($result['success']) {
                // Redirect to payment gateway
                return redirect($result['data']['payment_url'] ?? $result['data']['url']);
            } else {
                $transaction->update(['status' => 'failed']);
                return back()->with('error', 'Payment initiation failed: ' . $result['error']);
            }
        } catch (\Exception $e) {
            $transaction->update(['status' => 'failed']);
            return back()->with('error', 'Error: ' . $e->getMessage());
        }
    }

    public function success(Request $request)
    {
        try {
            // Get payment parameters from RupantorPay callback
            $paymentStatus = $request->query('status'); // completed, failed, cancelled
            $transactionId = $request->query('transactionId'); // RupantorPay transaction ID
            $paymentAmount = $request->query('paymentAmount');
            $paymentMethod = $request->query('paymentMethod');
            
            \Log::info('Payment success callback received', [
                'status' => $paymentStatus,
                'transactionId' => $transactionId,
                'amount' => $paymentAmount,
                'method' => $paymentMethod,
                'user_id' => auth()->id()
            ]);

            // Check if payment is completed
            if ($paymentStatus === 'completed' || $paymentStatus === 'success') {
                // Find the pending transaction for this user
                // Try to match by amount first
                $transaction = Transaction::where('user_id', auth()->id())
                    ->where('status', 'pending')
                    ->where('type', 'credit')
                    ->where('amount', $paymentAmount)
                    ->latest()
                    ->first();

                // If not found by amount, get the most recent pending transaction
                if (!$transaction) {
                    $transaction = Transaction::where('user_id', auth()->id())
                        ->where('status', 'pending')
                        ->where('type', 'credit')
                        ->latest()
                        ->first();
                }

                if ($transaction && $transaction->status === 'pending') {
                    // Update transaction status and add RupantorPay transaction ID
                    $transaction->update([
                        'status' => 'completed',
                        'payment_method' => $paymentMethod ?? 'RupantorPay',
                        'description' => $transaction->description . ' (TxnID: ' . $transactionId . ')'
                    ]);

                    // Add base amount to user (not including gateway fee)
                    $creditAmount = $transaction->base_amount ?? $transaction->amount;
                    $transaction->user->increment('balance', $creditAmount);

                    \Log::info('Payment processed successfully', [
                        'transaction_id' => $transaction->id,
                        'total_paid' => $transaction->amount,
                        'credited_amount' => $creditAmount,
                        'gateway_fee' => $transaction->gateway_fee,
                        'new_balance' => $transaction->user->balance
                    ]);

                    // Show breakdown in success message
                    $message = 'Payment successful! ৳' . number_format($creditAmount, 2) . ' has been added to your balance.';
                    if ($transaction->gateway_fee > 0) {
                        $message .= ' (Gateway fee: ৳' . number_format($transaction->gateway_fee, 2) . ')';
                    }

                    // Redirect to buy-balance page with success message
                    return redirect()->route('user.payment.packages')->with('success', $message);
                } elseif ($transaction && $transaction->status === 'completed') {
                    return redirect()->route('user.payment.packages')->with('info', 'This payment has already been processed.');
                } else {
                    \Log::warning('No pending transaction found for payment', [
                        'user_id' => auth()->id(),
                        'amount' => $paymentAmount
                    ]);
                    return redirect()->route('user.payment.packages')->with('warning', 'Payment received but no pending transaction found. Please contact support if your balance was not updated.');
                }
            } elseif ($paymentStatus === 'failed') {
                \Log::info('Payment failed', ['transactionId' => $transactionId]);
                return redirect()->route('payment.cancel')->with('error', 'Payment failed. Please try again.');
            } elseif ($paymentStatus === 'cancelled') {
                \Log::info('Payment cancelled', ['transactionId' => $transactionId]);
                return redirect()->route('payment.cancel')->with('error', 'Payment was cancelled.');
            }

        } catch (\Exception $e) {
            \Log::error('Payment success handler error: ' . $e->getMessage(), [
                'request' => $request->all()
            ]);
            return redirect()->route('user.payment.packages')->with('error', 'Error processing payment. Please contact support if your balance was not updated.');
        }

        return redirect()->route('user.payment.packages')->with('info', 'Payment status is being verified. Your balance will be updated shortly.');
    }

    public function cancel()
    {
        return view('user.payment.cancel')->with('error', 'Payment was cancelled.');
    }

    public function webhook(Request $request)
    {
        try {
            $data = $request->all();
            
            // Log webhook data for debugging
            \Log::info('Payment webhook received', ['data' => $data]);

            // Check payment status (handle different response formats)
            $paymentStatus = $data['status'] ?? $data['payment_status'] ?? null;
            
            if ($paymentStatus === 'completed' || $paymentStatus === 'success') {
                // Try to get transaction ID from metadata
                $metadata = $data['metadata'] ?? [];
                $transactionId = $metadata['transaction_id'] ?? null;
                
                if ($transactionId) {
                    $transaction = Transaction::where('transaction_id', $transactionId)->first();

                    if ($transaction && $transaction->status === 'pending') {
                        $transaction->update(['status' => 'completed']);
                        // Credit base amount (not including gateway fee)
                        $creditAmount = $transaction->base_amount ?? $transaction->amount;
                        $transaction->user->increment('balance', $creditAmount);
                        
                        \Log::info('Payment processed successfully via webhook', [
                            'transaction_id' => $transactionId,
                            'total_paid' => $transaction->amount,
                            'credited_amount' => $creditAmount,
                            'gateway_fee' => $transaction->gateway_fee
                        ]);
                    }
                } else {
                    \Log::warning('Webhook received without transaction_id in metadata');
                }
            } elseif ($paymentStatus === 'failed') {
                // Handle failed payment
                $metadata = $data['metadata'] ?? [];
                $transactionId = $metadata['transaction_id'] ?? null;
                
                if ($transactionId) {
                    $transaction = Transaction::where('transaction_id', $transactionId)->first();
                    if ($transaction && $transaction->status === 'pending') {
                        $transaction->update(['status' => 'failed']);
                        \Log::info('Payment marked as failed', ['transaction_id' => $transactionId]);
                    }
                }
            }

            return response()->json(['status' => 'success', 'message' => 'Webhook processed']);
        } catch (\Exception $e) {
            \Log::error('Webhook processing error: ' . $e->getMessage(), [
                'data' => $request->all()
            ]);
            return response()->json(['status' => 'error', 'message' => 'Webhook processing failed'], 500);
        }
    }

    public function transactions()
    {
        $transactions = auth()->user()->transactions()
            ->latest()
            ->paginate(20);

        return view('user.transactions', compact('transactions'));
    }
}
