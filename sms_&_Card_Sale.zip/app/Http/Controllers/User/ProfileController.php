<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Mail\VerifyEmail;
use App\Services\NotificationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class ProfileController extends Controller
{
    protected $notificationService;

    public function __construct(NotificationService $notificationService)
    {
        $this->notificationService = $notificationService;
    }

    /**
     * Show user profile
     */
    public function index()
    {
        $user = Auth::user();
        return view('user.profile.index', compact('user'));
    }

    /**
     * Update profile information
     */
    public function updateProfile(Request $request)
    {
        $user = Auth::user();

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => ['required', 'email', Rule::unique('users')->ignore($user->id)],
            'phone' => ['required', 'string', 'max:20', Rule::unique('users')->ignore($user->id)],
            'address' => 'nullable|string|max:500',
            'city' => 'nullable|string|max:100',
            'state' => 'nullable|string|max:100',
            'postal_code' => 'nullable|string|max:20',
            'country' => 'required|string|max:100',
            'date_of_birth' => 'nullable|date|before:today',
            'gender' => 'nullable|in:male,female,other',
            'profile_photo' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);

        $data = $request->except(['profile_photo']);

        // Handle profile photo upload
        if ($request->hasFile('profile_photo')) {
            // Delete old photo
            if ($user->profile_photo) {
                Storage::disk('public')->delete($user->profile_photo);
            }

            $path = $request->file('profile_photo')->store('profile_photos', 'public');
            $data['profile_photo'] = $path;
        }

        $user->update($data);

        return back()->with('success', 'Profile updated successfully!');
    }

    /**
     * Update password
     */
    public function updatePassword(Request $request)
    {
        $request->validate([
            'current_password' => 'required',
            'new_password' => 'required|string|min:8|confirmed',
        ]);

        $user = Auth::user();

        if (!Hash::check($request->current_password, $user->password)) {
            return back()->withErrors(['current_password' => 'Current password is incorrect.']);
        }

        $user->update([
            'password' => Hash::make($request->new_password)
        ]);

        // Send notification
        $this->notificationService->create(
            $user->id,
            'security',
            'Password Changed',
            'Your password has been changed successfully. If this wasn\'t you, please contact support immediately.',
            [],
            'fa-lock',
            'warning',
            null,
            false
        );

        return back()->with('success', 'Password updated successfully!');
    }

    /**
     * Submit KYC verification
     */
    public function submitKyc(Request $request)
    {
        $user = Auth::user();

        // Check if KYC is already approved
        if ($user->isKycVerified()) {
            return back()->with('error', 'Your KYC is already verified.');
        }

        $request->validate([
            'nid_number' => 'required_without:passport_number|nullable|string|max:20',
            'nid_front' => 'required_with:nid_number|nullable|image|mimes:jpeg,png,jpg,pdf|max:5120',
            'nid_back' => 'required_with:nid_number|nullable|image|mimes:jpeg,png,jpg,pdf|max:5120',
            'passport_number' => 'required_without:nid_number|nullable|string|max:20',
            'passport_photo' => 'required_with:passport_number|nullable|image|mimes:jpeg,png,jpg,pdf|max:5120',
            'driving_license' => 'nullable|image|mimes:jpeg,png,jpg,pdf|max:5120',
        ], [
            'nid_number.required_without' => 'Either NID or Passport is required.',
            'passport_number.required_without' => 'Either NID or Passport is required.',
            'nid_front.required_with' => 'NID front image is required when NID number is provided.',
            'nid_back.required_with' => 'NID back image is required when NID number is provided.',
            'passport_photo.required_with' => 'Passport photo is required when passport number is provided.',
        ]);

        $data = [
            'kyc_status' => 'pending',
            'kyc_submitted_at' => now(),
        ];

        // Handle NID uploads
        if ($request->filled('nid_number')) {
            $data['nid_number'] = $request->nid_number;

            if ($request->hasFile('nid_front')) {
                if ($user->nid_front) {
                    Storage::disk('public')->delete($user->nid_front);
                }
                $data['nid_front'] = $request->file('nid_front')->store('kyc/nid', 'public');
            }

            if ($request->hasFile('nid_back')) {
                if ($user->nid_back) {
                    Storage::disk('public')->delete($user->nid_back);
                }
                $data['nid_back'] = $request->file('nid_back')->store('kyc/nid', 'public');
            }
        }

        // Handle Passport upload
        if ($request->filled('passport_number')) {
            $data['passport_number'] = $request->passport_number;

            if ($request->hasFile('passport_photo')) {
                if ($user->passport_photo) {
                    Storage::disk('public')->delete($user->passport_photo);
                }
                $data['passport_photo'] = $request->file('passport_photo')->store('kyc/passport', 'public');
            }
        }

        // Handle Driving License upload
        if ($request->hasFile('driving_license')) {
            if ($user->driving_license) {
                Storage::disk('public')->delete($user->driving_license);
            }
            $data['driving_license'] = $request->file('driving_license')->store('kyc/license', 'public');
        }

        $user->update($data);

        // Notify admin
        $this->notificationService->createAdminNotification(
            'kyc_submission',
            'New KYC Submission',
            "{$user->name} has submitted KYC documents for verification.",
            ['user_id' => $user->id, 'user_name' => $user->name],
            'fa-id-card',
            'info',
            route('admin.kyc.show', $user->id)
        );

        return back()->with('success', 'KYC documents submitted successfully! We will review them shortly.');
    }

    /**
     * Send email verification link
     */
    public function sendVerificationEmail(Request $request)
    {
        $user = Auth::user();

        // Check if email is already verified
        if ($user->hasVerifiedEmail()) {
            return back()->with('info', 'Your email is already verified.');
        }

        try {
            // Send verification email using configured mail settings
            Mail::to($user->email)->send(new VerifyEmail($user));

            // Create notification
            $this->notificationService->create(
                $user->id,
                'email_verification',
                'Verification Email Sent',
                'A verification link has been sent to your email address. Please check your inbox and spam folder.',
                [],
                'fa-envelope',
                'info',
                null,
                false
            );

            return back()->with('success', 'Verification email sent successfully! Please check your inbox.');
        } catch (\Exception $e) {
            \Log::error('Email verification send failed: ' . $e->getMessage());
            return back()->with('error', 'Failed to send verification email. Please check mail settings or try again later.');
        }
    }

    /**
     * Verify email address
     */
    public function verifyEmail(Request $request, $id, $hash)
    {
        // Find user
        $user = \App\Models\User::findOrFail($id);

        // Verify hash matches email
        if (!hash_equals((string) $hash, sha1($user->email))) {
            return redirect()->route('user.profile')->with('error', 'Invalid verification link.');
        }

        // Check if email is already verified
        if ($user->hasVerifiedEmail()) {
            return redirect()->route('user.profile')->with('info', 'Your email is already verified.');
        }

        // Mark email as verified
        $user->markEmailAsVerified();

        // Create notification
        $this->notificationService->create(
            $user->id,
            'email_verification',
            'Email Verified',
            'Your email address has been verified successfully!',
            [],
            'fa-check-circle',
            'success',
            null,
            false
        );

        return redirect()->route('user.profile')->with('success', 'Email verified successfully!');
    }
}
