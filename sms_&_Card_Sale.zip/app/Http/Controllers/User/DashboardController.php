<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Transaction;
use App\Models\SmsHistory;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        $stats = [
            'balance' => $user->balance,
            'total_sms_sent' => $user->smsHistory()->where('status', 'sent')->count(),
            'total_spent' => $user->transactions()
                ->where('type', 'debit')
                ->where('status', 'completed')
                ->sum('amount'),
            'recent_transactions' => $user->transactions()->latest()->take(5)->get(),
            'recent_sms' => $user->smsHistory()->latest()->take(5)->get(),
        ];

        return view('user.dashboard', compact('stats'));
    }
}
