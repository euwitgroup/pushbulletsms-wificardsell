<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Services\NotificationService;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    protected $notificationService;

    public function __construct(NotificationService $notificationService)
    {
        $this->notificationService = $notificationService;
    }

    /**
     * Display user notifications
     */
    public function index()
    {
        $user = auth()->user();
        
        $notifications = Notification::forUser($user->id)
            ->with('smsTemplate')
            ->latest()
            ->paginate(20);

        $unreadCount = $this->notificationService->getUnreadCount($user->id);

        return view('user.notifications.index', compact('notifications', 'unreadCount'));
    }

    /**
     * Mark notification as read
     */
    public function markAsRead($id)
    {
        $user = auth()->user();
        $notification = Notification::forUser($user->id)->findOrFail($id);
        $notification->markAsRead();

        if ($notification->link) {
            return redirect($notification->link);
        }

        return back()->with('success', 'Notification marked as read.');
    }

    /**
     * Mark all as read
     */
    public function markAllAsRead()
    {
        $user = auth()->user();
        $this->notificationService->markAllAsRead($user->id);

        return back()->with('success', 'All notifications marked as read.');
    }

    /**
     * Delete notification
     */
    public function destroy($id)
    {
        $user = auth()->user();
        $notification = Notification::forUser($user->id)->findOrFail($id);
        $notification->delete();

        return back()->with('success', 'Notification deleted successfully.');
    }

    /**
     * Delete all read notifications
     */
    public function deleteAllRead()
    {
        $user = auth()->user();
        Notification::forUser($user->id)->read()->delete();

        return back()->with('success', 'All read notifications deleted.');
    }

    /**
     * Get unread count (AJAX)
     */
    public function getUnreadCount()
    {
        $user = auth()->user();
        $count = $this->notificationService->getUnreadCount($user->id);

        return response()->json([
            'count' => $count
        ]);
    }

    /**
     * Get recent notifications (AJAX)
     */
    public function getRecent()
    {
        $user = auth()->user();
        
        $notifications = Notification::forUser($user->id)
            ->latest()
            ->limit(10)
            ->get();

        return response()->json([
            'notifications' => $notifications->map(function ($notification) {
                return [
                    'id' => $notification->id,
                    'title' => $notification->title,
                    'message' => $notification->message,
                    'icon' => $notification->icon,
                    'color' => $notification->color,
                    'link' => $notification->link,
                    'is_read' => $notification->is_read,
                    'time_ago' => $notification->getTimeAgo(),
                ];
            })
        ]);
    }
}

