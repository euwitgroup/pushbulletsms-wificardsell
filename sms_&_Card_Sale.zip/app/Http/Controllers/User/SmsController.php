<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Models\SmsHistory;
use App\Models\Transaction;
use App\Models\Setting;
use App\Models\SmsGateway;
use App\Models\SmsTemplate;
use App\Services\SmsService;
use App\Services\NotificationService;
use Illuminate\Http\Request;

class SmsController extends Controller
{
    protected $smsService;
    protected $notificationService;

    public function __construct(SmsService $smsService, NotificationService $notificationService)
    {
        $this->smsService = $smsService;
        $this->notificationService = $notificationService;
    }

    public function create()
    {
        // Get all active gateways for sender ID selection
        $gateways = SmsGateway::where('is_active', true)->get();
        
        // Get SMS templates for selection
        $templates = SmsTemplate::where('status', true)->get();
        
        return view('user.sms.create', compact('gateways', 'templates'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'sender_id' => 'required|exists:sms_gateways,id',
            'phone_number' => 'required|string',
            'message' => 'required|string|max:1000',
        ]);

        $user = auth()->user();
        
        // Check KYC verification
        if (!$user->isKycVerified()) {
            return back()->with('error', 'KYC verification is required to send SMS. Please complete your KYC verification first.');
        }
        
        // Get selected gateway
        $gateway = SmsGateway::findOrFail($request->sender_id);
        if (!$gateway->is_active) {
            return back()->with('error', 'Selected SMS gateway is not active.');
        }
        
        // Calculate SMS cost based on message length
        $message = $request->message;
        $isUnicode = $this->containsUnicode($message);
        $messageLength = mb_strlen($message);
        
        // Calculate number of SMS parts
        $singleLimit = $isUnicode ? 70 : 160;
        $multiLimit = $isUnicode ? 67 : 153;
        
        $smsCount = 1;
        if ($messageLength > $singleLimit) {
            $smsCount = ceil($messageLength / $multiLimit);
        }
        
        $totalCost = floatval($gateway->cost_per_sms) * $smsCount;

        // Check balance
        if ($user->balance < $totalCost) {
            return back()->with('error', 'Insufficient balance. You need ৳' . number_format($totalCost, 2) . ' but have ৳' . number_format($user->balance, 2));
        }

        // Create SMS history record
        $smsHistory = SmsHistory::create([
            'user_id' => $user->id,
            'sms_gateway_id' => $gateway->id,
            'phone_number' => $request->phone_number,
            'message' => $message,
            'status' => 'pending',
            'cost' => $totalCost,
            'sms_count' => $smsCount,
        ]);

        try {
            // Send SMS using SMS Service with specific gateway
            $sent = $this->smsService->sendWithGateway($request->phone_number, $message, $gateway);

            if ($sent) {
                // Deduct balance
                $user->decrement('balance', $totalCost);

                // Update SMS status
                $smsHistory->update(['status' => 'sent']);

                // Create transaction record
                Transaction::create([
                    'user_id' => $user->id,
                    'transaction_id' => 'SMS-' . time() . '-' . $user->id,
                    'payment_method' => 'SMS Service - ' . $gateway->gateway_name,
                    'amount' => $totalCost,
                    'type' => 'debit',
                    'status' => 'completed',
                    'description' => "SMS sent to {$request->phone_number} ({$smsCount} parts)",
                ]);

                // Send notification
                $this->notificationService->smsSent($user->id, $request->phone_number, $totalCost);

                return redirect()->route('user.sms.history')
                    ->with('success', "SMS sent successfully! ({$smsCount} parts, ৳{$totalCost})");
            } else {
                $smsHistory->update([
                    'status' => 'failed',
                    'error_message' => 'Failed to send via gateway'
                ]);

                return back()->with('error', 'Failed to send SMS. Please check gateway configuration.');
            }
        } catch (\Exception $e) {
            $smsHistory->update([
                'status' => 'failed',
                'error_message' => $e->getMessage()
            ]);

            return back()->with('error', 'Error sending SMS: ' . $e->getMessage());
        }
    }

    public function bulk(Request $request)
    {
        $request->validate([
            'sender_id' => 'required|exists:sms_gateways,id',
            'message' => 'required|string|max:1000',
            'excel_file' => 'required|file|mimes:xlsx,xls,csv|max:5120', // 5MB max
        ]);

        $user = auth()->user();
        
        // Check KYC verification
        if (!$user->isKycVerified()) {
            return back()->with('error', 'KYC verification is required to send bulk SMS. Please complete your KYC verification first.');
        }
        
        // Get selected gateway
        $gateway = SmsGateway::findOrFail($request->sender_id);
        if (!$gateway->is_active) {
            return back()->with('error', 'Selected SMS gateway is not active.');
        }

        // Get message from form (same for all numbers)
        $message = trim($request->message);

        // Calculate SMS count for the message (same for all)
        $isUnicode = $this->containsUnicode($message);
        $messageLength = mb_strlen($message);
        $singleLimit = $isUnicode ? 70 : 160;
        $multiLimit = $isUnicode ? 67 : 153;
        
        $smsCount = 1;
        if ($messageLength > $singleLimit) {
            $smsCount = ceil($messageLength / $multiLimit);
        }

        $costPerNumber = floatval($gateway->cost_per_sms) * $smsCount;

        try {
            // Load Excel file
            $file = $request->file('excel_file');
            $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($file->getRealPath());
            $sheet = $spreadsheet->getActiveSheet();
            $rows = $sheet->toArray();

            // Remove header row
            array_shift($rows);

            // Collect phone numbers
            $phoneNumbers = [];
            foreach ($rows as $index => $row) {
                if (empty($row[0])) {
                    continue; // Skip empty rows
                }

                $phoneNumber = trim($row[0]);
                if (!empty($phoneNumber)) {
                    $phoneNumbers[] = $phoneNumber;
                }
            }

            if (empty($phoneNumbers)) {
                return back()->with('error', 'No valid phone numbers found in Excel file.');
            }

            // Calculate total cost
            $totalNumbers = count($phoneNumbers);
            $totalCost = $totalNumbers * $costPerNumber;
            $totalSmsCount = $totalNumbers * $smsCount;

            // Check balance
            if ($user->balance < $totalCost) {
                return back()->with('error', "Insufficient balance. You need ৳" . number_format($totalCost, 2) . " but have ৳" . number_format($user->balance, 2));
            }

            // Process bulk SMS
            $successCount = 0;
            $failedCount = 0;
            $failedNumbers = [];

            foreach ($phoneNumbers as $phoneNumber) {
                // Create SMS history record
                $smsHistory = SmsHistory::create([
                    'user_id' => $user->id,
                    'sms_gateway_id' => $gateway->id,
                    'phone_number' => $phoneNumber,
                    'message' => $message,
                    'status' => 'pending',
                    'cost' => $costPerNumber,
                    'sms_count' => $smsCount,
                ]);

                try {
                    // Send SMS
                    $sent = $this->smsService->sendWithGateway($phoneNumber, $message, $gateway);

                    if ($sent) {
                        $smsHistory->update(['status' => 'sent']);
                        $user->decrement('balance', $costPerNumber);
                        $successCount++;

                        // Create transaction record
                        Transaction::create([
                            'user_id' => $user->id,
                            'transaction_id' => 'BULK-SMS-' . time() . '-' . $user->id . '-' . $successCount,
                            'payment_method' => 'Bulk SMS - ' . $gateway->gateway_name,
                            'amount' => $costPerNumber,
                            'type' => 'debit',
                            'status' => 'completed',
                            'description' => "Bulk SMS sent to {$phoneNumber} ({$smsCount} parts)",
                        ]);
                    } else {
                        $smsHistory->update([
                            'status' => 'failed',
                            'error_message' => 'Failed to send via gateway'
                        ]);
                        $failedCount++;
                        $failedNumbers[] = $phoneNumber;
                    }
                } catch (\Exception $e) {
                    $smsHistory->update([
                        'status' => 'failed',
                        'error_message' => $e->getMessage()
                    ]);
                    $failedCount++;
                    $failedNumbers[] = $phoneNumber;
                }

                // Small delay to avoid rate limiting
                usleep(500000); // 0.5 seconds
            }

            // Send notification about bulk SMS
            $this->notificationService->bulkSmsSent($user->id, $successCount, $failedCount, $totalCost);

            $message = "Bulk SMS completed! Success: {$successCount}, Failed: {$failedCount}, Total Cost: ৳" . number_format($totalCost, 2);
            
            if ($failedCount > 0) {
                $message .= " | Failed numbers: " . implode(', ', array_slice($failedNumbers, 0, 5));
                if (count($failedNumbers) > 5) {
                    $message .= "... (+" . (count($failedNumbers) - 5) . " more)";
                }
            }

            return redirect()->route('user.sms.history')->with('success', $message);

        } catch (\Exception $e) {
            return back()->with('error', 'Error processing Excel file: ' . $e->getMessage());
        }
    }

    public function downloadTemplate()
    {
        $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        // Set header
        $sheet->setCellValue('A1', 'phone_number');

        // Style header
        $sheet->getStyle('A1')->getFont()->setBold(true);
        $sheet->getStyle('A1')->getFill()
            ->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)
            ->getStartColor()->setRGB('667eea');
        $sheet->getStyle('A1')->getFont()->getColor()->setRGB('FFFFFF');

        // Add sample data
        $sheet->setCellValue('A2', '+8801712345678');
        $sheet->setCellValue('A3', '+8801812345678');
        $sheet->setCellValue('A4', '+8801912345678');

        // Auto-size column
        $sheet->getColumnDimension('A')->setWidth(20);

        // Create writer
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);

        // Set headers for download
        $fileName = 'bulk_sms_numbers_template_' . date('Y-m-d') . '.xlsx';
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $fileName . '"');
        header('Cache-Control: max-age=0');

        $writer->save('php://output');
        exit;
    }

    private function containsUnicode($str)
    {
        // Check for non-ASCII characters (Bangla, Arabic, etc.)
        return preg_match('/[^\x00-\x7F]/', $str);
    }

    public function history()
    {
        $smsHistory = auth()->user()->smsHistory()
            ->latest()
            ->paginate(20);

        return view('user.sms.history', compact('smsHistory'));
    }
}
