<?php

namespace App\Http\Controllers;

use App\Models\HeroSlider;
use App\Models\SmsPackage;
use App\Models\Setting;
use App\Models\WhyChooseUs;
use App\Models\Faq;
use App\Models\Blog;
use App\Models\ComparisonFeature;
use App\Models\SmsPrice;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Display the homepage
     */
    public function index()
    {
        // Get active hero sliders
        $sliders = HeroSlider::active()->ordered()->get();
        
        // Get featured packages for pricing section
        $packages = SmsPackage::where('is_featured', true)
            ->where('is_active', true)
            ->limit(4)
            ->get();
        
        // Get Why Choose Us features
        $features = WhyChooseUs::active()->ordered()->get();
        
        // Get SMS Pricing
        $smsPrices = SmsPrice::active()->ordered()->get();
        
        // Get FAQs
        $faqs = Faq::active()->ordered()->limit(6)->get();
        
        // Get latest blogs
        $blogs = Blog::active()->latest()->limit(4)->get();
        
        // Get comparison features
        $comparisons = ComparisonFeature::active()->ordered()->get();
        
        // Get site settings
        $siteName = Setting::get('site_name', 'SMS & Card Sale');
        $siteTagline = Setting::get('site_tagline', 'Send SMS instantly. Manage contacts efficiently. Grow your business effortlessly.');
        $videoUrl = Setting::get('demo_video_url', 'https://www.youtube.com/embed/dQw4w9WgXcQ');
        
        return view('home', compact(
            'sliders',
            'packages',
            'features',
            'smsPrices',
            'faqs',
            'blogs',
            'comparisons',
            'siteName',
            'siteTagline',
            'videoUrl'
        ));
    }
}
