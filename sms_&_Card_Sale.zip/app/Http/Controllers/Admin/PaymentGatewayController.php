<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;

class PaymentGatewayController extends Controller
{
    public function list()
    {
        // Define all available payment gateways
        $allGateways = collect([
            [
                'id' => 'rupantorpay',
                'name' => 'RupantorPay',
                'icon' => '💳',
                'color' => '#667eea',
                'charge' => Setting::get('rupantorpay_payment_charge', 0) . '%',
                'limit' => '৳' . Setting::get('rupantorpay_minimum_payment', 10) . '+ (No Limit)',
                'api_key' => Setting::get('rupantorpay_api_key'),
                'success_url' => Setting::get('rupantorpay_success_url', url('/payment/success')),
                'cancel_url' => Setting::get('rupantorpay_cancel_url', url('/payment/cancel')),
                'minimum_payment' => Setting::get('rupantorpay_minimum_payment', 10),
                'payment_charge' => Setting::get('rupantorpay_payment_charge', 0),
                'is_active' => Setting::get('rupantorpay_active') == '1' || Setting::get('rupantorpay_active') === true,
                'is_sandbox' => Setting::get('rupantorpay_sandbox') == '1' || Setting::get('rupantorpay_sandbox') === true,
            ],
            [
                'id' => 'sslcommerz',
                'name' => 'SSLCommerz',
                'icon' => '🔒',
                'color' => '#10b981',
                'charge' => Setting::get('ssl_payment_charge', 0) . '%',
                'limit' => '৳' . Setting::get('ssl_minimum_payment', 10) . '+ (No Limit)',
                'store_id' => Setting::get('ssl_store_id'),
                'store_password' => Setting::get('ssl_store_password'),
                'minimum_payment' => Setting::get('ssl_minimum_payment', 10),
                'payment_charge' => Setting::get('ssl_payment_charge', 0),
                'is_active' => Setting::get('ssl_active') == '1' || Setting::get('ssl_active') === true,
                'is_sandbox' => Setting::get('ssl_sandbox') == '1' || Setting::get('ssl_sandbox') === true,
            ],
            [
                'id' => 'stripe',
                'name' => 'Stripe',
                'icon' => '💰',
                'color' => '#3b82f6',
                'charge' => Setting::get('stripe_payment_charge', 0) . '%',
                'limit' => '৳' . Setting::get('stripe_minimum_payment', 10) . '+ (No Limit)',
                'publishable_key' => Setting::get('stripe_publishable_key'),
                'secret_key' => Setting::get('stripe_secret_key'),
                'minimum_payment' => Setting::get('stripe_minimum_payment', 10),
                'payment_charge' => Setting::get('stripe_payment_charge', 0),
                'is_active' => Setting::get('stripe_active') == '1' || Setting::get('stripe_active') === true,
            ],
            [
                'id' => 'paypal',
                'name' => 'PayPal',
                'icon' => '💵',
                'color' => '#0070ba',
                'charge' => Setting::get('paypal_payment_charge', 0) . '%',
                'limit' => '৳' . Setting::get('paypal_minimum_payment', 10) . '+ (No Limit)',
                'client_id' => Setting::get('paypal_client_id'),
                'client_secret' => Setting::get('paypal_client_secret'),
                'minimum_payment' => Setting::get('paypal_minimum_payment', 10),
                'payment_charge' => Setting::get('paypal_payment_charge', 0),
                'is_active' => Setting::get('paypal_active') == '1' || Setting::get('paypal_active') === true,
            ],
            [
                'id' => 'bkash',
                'name' => 'bKash',
                'icon' => '📱',
                'color' => '#e91e63',
                'charge' => Setting::get('bkash_payment_charge', 0) . '%',
                'limit' => '৳' . Setting::get('bkash_minimum_payment', 10) . '+ (No Limit)',
                'app_key' => Setting::get('bkash_app_key'),
                'app_secret' => Setting::get('bkash_app_secret'),
                'minimum_payment' => Setting::get('bkash_minimum_payment', 10),
                'payment_charge' => Setting::get('bkash_payment_charge', 0),
                'is_active' => Setting::get('bkash_active') == '1' || Setting::get('bkash_active') === true,
            ],
            [
                'id' => 'nagad',
                'name' => 'Nagad',
                'icon' => '🏦',
                'color' => '#ff6b00',
                'charge' => Setting::get('nagad_payment_charge', 0) . '%',
                'limit' => '৳' . Setting::get('nagad_minimum_payment', 10) . '+ (No Limit)',
                'merchant_id' => Setting::get('nagad_merchant_id'),
                'merchant_number' => Setting::get('nagad_merchant_number'),
                'minimum_payment' => Setting::get('nagad_minimum_payment', 10),
                'payment_charge' => Setting::get('nagad_payment_charge', 0),
                'is_active' => Setting::get('nagad_active') == '1' || Setting::get('nagad_active') === true,
            ],
        ]);
        
        // Paginate the collection (10 items per page)
        $perPage = 10;
        $currentPage = request()->get('page', 1);
        $gateways = new \Illuminate\Pagination\LengthAwarePaginator(
            $allGateways->forPage($currentPage, $perPage),
            $allGateways->count(),
            $perPage,
            $currentPage,
            ['path' => request()->url(), 'query' => request()->query()]
        );
        
        return view('admin.payment.index', compact('gateways', 'allGateways'));
    }
    
    public function index()
    {
        // Get all payment gateway settings from database
        $settings = [
            'rupantorpay_api_key' => Setting::get('rupantorpay_api_key'),
            'rupantorpay_success_url' => Setting::get('rupantorpay_success_url', url('/payment/success')),
            'rupantorpay_cancel_url' => Setting::get('rupantorpay_cancel_url', url('/payment/cancel')),
            'rupantorpay_active' => Setting::get('rupantorpay_active', false),
            'rupantorpay_sandbox' => Setting::get('rupantorpay_sandbox', true),
            
            'ssl_store_id' => Setting::get('ssl_store_id'),
            'ssl_store_password' => Setting::get('ssl_store_password'),
            'ssl_active' => Setting::get('ssl_active', false),
            'ssl_sandbox' => Setting::get('ssl_sandbox', true),
            
            'stripe_publishable_key' => Setting::get('stripe_publishable_key'),
            'stripe_secret_key' => Setting::get('stripe_secret_key'),
            'stripe_active' => Setting::get('stripe_active', false),
        ];

        return view('admin.payment-gateway', compact('settings'));
    }

    public function update(Request $request, $gateway)
    {
        // Validate based on gateway (only if fields are present)
        $rules = [];
        
        if ($gateway === 'rupantorpay') {
            if ($request->has('api_key')) {
                $rules = [
                    'api_key' => 'nullable|string',
                    'success_url' => 'nullable|url',
                    'cancel_url' => 'nullable|url',
                ];
            }
        } elseif ($gateway === 'sslcommerz') {
            if ($request->has('store_id')) {
                $rules = [
                    'store_id' => 'nullable|string',
                    'store_password' => 'nullable|string',
                ];
            }
        } elseif ($gateway === 'stripe') {
            if ($request->has('publishable_key')) {
                $rules = [
                    'publishable_key' => 'nullable|string',
                    'secret_key' => 'nullable|string',
                ];
            }
        }
        
        if (!empty($rules)) {
            $request->validate($rules);
        }
        
        // Save settings with gateway prefix
        $prefix = $gateway . '_';
        
        foreach ($request->except(['_token', 'gateway_id']) as $key => $value) {
            $settingKey = $prefix . $key;
            $type = in_array($key, ['api_key', 'secret_key', 'store_password']) ? 'password' : 'text';
            Setting::set($settingKey, $value, $type);
        }
        
        // Handle checkbox fields that might not be present when unchecked
        // If is_sandbox is not in request and we're updating gateway settings (not just toggling), set it to 0
        if ($request->has('minimum_payment') && !$request->has('is_sandbox')) {
            Setting::set($prefix . 'is_sandbox', '0', 'text');
        }
        
        // Return JSON response for AJAX requests
        if ($request->expectsJson()) {
            return response()->json([
                'success' => true,
                'message' => ucfirst($gateway) . ' gateway settings updated successfully!'
            ]);
        }
        
        return back()->with('success', ucfirst($gateway) . ' gateway settings updated successfully!');
    }

    public function testConnection(Request $request, $gateway)
    {
        try {
            // Implement gateway-specific connection test
            switch ($gateway) {
                case 'rupantorpay':
                    return $this->testRupantorPay();
                case 'sslcommerz':
                    return $this->testSSLCommerz();
                case 'stripe':
                    return $this->testStripe();
                default:
                    return response()->json([
                        'success' => false,
                        'message' => 'Unknown gateway'
                    ], 400);
            }
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Connection failed: ' . $e->getMessage()
            ], 500);
        }
    }

    private function testRupantorPay()
    {
        $apiKey = Setting::get('rupantorpay_api_key');
        
        if (!$apiKey) {
            return response()->json([
                'success' => false,
                'message' => 'API Key not configured. Please save your settings first.'
            ]);
        }
        
        try {
            // Test API connection by making a minimal request
            $response = \Http::withHeaders([
                'X-API-KEY' => $apiKey,
                'Content-Type' => 'application/json',
                'X-CLIENT' => request()->getHost(),
            ])->post('https://payment.rupantorpay.com/api/payment/checkout', [
                'amount' => '1',
                'success_url' => url('/payment/success'),
                'cancel_url' => url('/payment/cancel'),
                'webhook_url' => url('/webhook/rupantorpay'),
                'metadata' => ['test' => true]
            ]);
            
            if ($response->successful()) {
                return response()->json([
                    'success' => true,
                    'message' => 'RupantorPay connection successful! API key is valid.'
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Connection failed: ' . ($response->json()['message'] ?? 'Invalid API credentials')
                ]);
            }
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Connection failed: ' . $e->getMessage()
            ]);
        }
    }

    private function testSSLCommerz()
    {
        // Implement SSLCommerz API test
        return response()->json([
            'success' => true,
            'message' => 'SSLCommerz connection successful!'
        ]);
    }

    private function testStripe()
    {
        // Implement Stripe API test
        return response()->json([
            'success' => true,
            'message' => 'Stripe connection successful!'
        ]);
    }
}
