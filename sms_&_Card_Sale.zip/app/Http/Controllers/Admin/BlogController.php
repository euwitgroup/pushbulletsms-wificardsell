<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Blog;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;

class BlogController extends Controller
{
    public function index()
    {
        $blogs = Blog::latest()->paginate(15);
        return view('admin.blogs.index', compact('blogs'));
    }

    public function store(Request $request)
    {
        try {
            $request->validate([
                'title' => 'required|string|max:255',
                'slug' => 'nullable|string|max:255|unique:blogs,slug',
                'excerpt' => 'nullable|string',
                'content' => 'required|string',
                'image' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:5120',
                'category' => 'required|string|max:255',
                'is_featured' => 'nullable|in:0,1',
                'is_active' => 'nullable|in:0,1',
            ]);

            $data = $request->only(['title', 'excerpt', 'content', 'category']);
            $data['slug'] = $request->slug ?: Str::slug($request->title);
            $data['is_featured'] = $request->input('is_featured', 0);
            $data['is_active'] = $request->input('is_active', 0);

            if ($request->hasFile('image')) {
                $data['image'] = $request->file('image')->store('blogs', 'public');
            }

            Blog::create($data);

            return response()->json([
                'success' => true,
                'message' => 'Blog created successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    public function edit(Blog $blog)
    {
        return response()->json($blog);
    }

    public function update(Request $request, Blog $blog)
    {
        try {
            $request->validate([
                'title' => 'required|string|max:255',
                'slug' => 'nullable|string|max:255|unique:blogs,slug,' . $blog->id,
                'excerpt' => 'nullable|string',
                'content' => 'required|string',
                'image' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:5120',
                'category' => 'required|string|max:255',
                'is_featured' => 'nullable|in:0,1',
                'is_active' => 'nullable|in:0,1',
            ]);

            $data = $request->only(['title', 'excerpt', 'content', 'category']);
            $data['slug'] = $request->slug ?: Str::slug($request->title);
            $data['is_featured'] = $request->input('is_featured', 0);
            $data['is_active'] = $request->input('is_active', 0);

            if ($request->hasFile('image')) {
                if ($blog->image) {
                    Storage::disk('public')->delete($blog->image);
                }
                $data['image'] = $request->file('image')->store('blogs', 'public');
            }

            $blog->update($data);

            return response()->json([
                'success' => true,
                'message' => 'Blog updated successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    public function destroy(Blog $blog)
    {
        if ($blog->image) {
            Storage::disk('public')->delete($blog->image);
        }
        $blog->delete();
        return redirect()->route('admin.blogs.index')
            ->with('success', 'Blog deleted successfully!');
    }

    public function toggleStatus(Blog $blog)
    {
        $blog->update(['is_active' => !$blog->is_active]);
        return back()->with('success', 'Blog status updated successfully!');
    }
}
