<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\HeroSlider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class HeroSliderController extends Controller
{
    /**
     * Display a listing of hero sliders.
     */
    public function index()
    {
        $sliders = HeroSlider::ordered()->paginate(15);
        return view('admin.hero-sliders.index', compact('sliders'));
    }

    /**
     * Show the form for creating a new slider.
     */
    public function create()
    {
        // Not used - handled by modal
        return redirect()->route('admin.hero-sliders.index');
    }

    /**
     * Store a newly created slider in storage.
     */
    public function store(Request $request)
    {
        try {
            $request->validate([
                'image' => 'required|image|mimes:jpeg,png,jpg,webp|max:5120',
                'title' => 'nullable|string|max:255',
                'link' => 'nullable|url|max:255',
                'order' => 'nullable|integer|min:0',
                'is_active' => 'nullable|in:0,1',
            ]);

            $data = $request->only(['title', 'link', 'order']);
            $data['is_active'] = $request->input('is_active', 0);
            $data['order'] = $request->order ?? 0;

            // Handle image upload
            if ($request->hasFile('image')) {
                $data['image'] = $request->file('image')->store('hero-sliders', 'public');
            }

            HeroSlider::create($data);

            return response()->json([
                'success' => true,
                'message' => 'Slider created successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    /**
     * Show the form for editing the specified slider.
     */
    public function edit(HeroSlider $heroSlider)
    {
        // Return JSON for modal
        return response()->json($heroSlider);
    }

    /**
     * Update the specified slider in storage.
     */
    public function update(Request $request, HeroSlider $heroSlider)
    {
        try {
            $request->validate([
                'image' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:5120',
                'title' => 'nullable|string|max:255',
                'link' => 'nullable|url|max:255',
                'order' => 'nullable|integer|min:0',
                'is_active' => 'nullable|in:0,1',
            ]);

            $data = $request->only(['title', 'link', 'order']);
            $data['is_active'] = $request->input('is_active', 0);
            $data['order'] = $request->order ?? 0;

            // Handle image upload
            if ($request->hasFile('image')) {
                // Delete old image
                if ($heroSlider->image) {
                    Storage::disk('public')->delete($heroSlider->image);
                }
                $data['image'] = $request->file('image')->store('hero-sliders', 'public');
            }

            $heroSlider->update($data);

            return response()->json([
                'success' => true,
                'message' => 'Slider updated successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    /**
     * Remove the specified slider from storage.
     */
    public function destroy(HeroSlider $heroSlider)
    {
        // Delete image
        if ($heroSlider->image) {
            Storage::disk('public')->delete($heroSlider->image);
        }

        $heroSlider->delete();

        return redirect()->route('admin.hero-sliders.index')
            ->with('success', 'Slider deleted successfully!');
    }

    /**
     * Toggle slider status
     */
    public function toggleStatus(HeroSlider $heroSlider)
    {
        $heroSlider->update(['is_active' => !$heroSlider->is_active]);

        return back()->with('success', 'Slider status updated successfully!');
    }
}
