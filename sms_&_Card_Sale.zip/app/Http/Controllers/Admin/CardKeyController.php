<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CardCategory;
use App\Models\CardType;
use App\Models\CardKey;
use App\Services\CardRestockService;
use Illuminate\Http\Request;

class CardKeyController extends Controller
{
    public function index(Request $request)
    {
        // Auto-release expired pending cards
        CardRestockService::releaseExpiredPendingCards();
        
        $categories = CardCategory::active()->ordered()->get();
        
        // Build query - Automatically hide sold and expired cards
        $query = CardKey::with(['cardType.category'])
            ->whereIn('status', ['available', 'pending']);
        
        // Filter by category
        if ($request->filled('category_id')) {
            $query->whereHas('cardType', function($q) use ($request) {
                $q->where('card_category_id', $request->category_id);
            });
        }
        
        // Filter by card type
        if ($request->filled('type_id')) {
            $query->where('card_type_id', $request->type_id);
        }
        
        // Filter by status (optional - for showing only available or pending)
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        
        $cardKeys = $query->latest()->paginate(50);
        
        // Get card types for filter dropdown
        if ($request->filled('category_id')) {
            $cardTypes = CardType::where('card_category_id', $request->category_id)
                ->active()
                ->ordered()
                ->get();
        } else {
            $cardTypes = CardType::with('category')->active()->ordered()->get();
        }
        
        // Count keys by status
        $availableCount = CardKey::where('status', 'available')->count();
        $pendingCount = CardKey::where('status', 'pending')->count();
        $soldCount = CardKey::where('status', 'sold')->count();
        
        return view('admin.cards.keys.index', compact(
            'cardKeys', 
            'categories', 
            'cardTypes', 
            'availableCount',
            'pendingCount',
            'soldCount'
        ));
    }

    public function getCardTypes($categoryId)
    {
        $cardTypes = CardType::where('card_category_id', $categoryId)
            ->active()
            ->ordered()
            ->get(['id', 'name', 'price']);
            
        return response()->json($cardTypes);
    }

    public function store(Request $request)
    {
        try {
            $request->validate([
                'card_type_id' => 'required|exists:card_types,id',
                'card_keys' => 'required|string',
            ]);

            // Split keys by new line and clean them
            $keys = array_filter(array_map('trim', explode("\n", $request->card_keys)));
            
            $created = 0;
            $duplicates = 0;

            foreach ($keys as $key) {
                // Check if key already exists
                if (CardKey::where('key_code', $key)->exists()) {
                    $duplicates++;
                    continue;
                }

                CardKey::create([
                    'card_type_id' => $request->card_type_id,
                    'key_code' => $key,
                    'status' => 'available',
                ]);
                
                $created++;
            }

            return response()->json([
                'success' => true,
                'message' => "Successfully added {$created} keys!" . ($duplicates > 0 ? " ({$duplicates} duplicates skipped)" : "")
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    public function destroy(CardKey $cardKey)
    {
        try {
            if ($cardKey->status !== 'available') {
                return response()->json([
                    'success' => false,
                    'message' => 'Cannot delete sold or expired keys!'
                ], 422);
            }

            $cardKey->delete();
            
            return response()->json([
                'success' => true,
                'message' => 'Card key deleted successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    public function bulkDelete(Request $request)
    {
        try {
            $request->validate([
                'ids' => 'required|array',
                'ids.*' => 'exists:card_keys,id',
            ]);

            $deleted = CardKey::whereIn('id', $request->ids)
                ->where('status', 'available')
                ->delete();

            return response()->json([
                'success' => true,
                'message' => "Successfully deleted {$deleted} card key(s)!"
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }
}

