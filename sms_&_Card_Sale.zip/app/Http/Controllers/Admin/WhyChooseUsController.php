<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\WhyChooseUs;
use Illuminate\Http\Request;

class WhyChooseUsController extends Controller
{
    /**
     * Display a listing of features.
     */
    public function index()
    {
        $features = WhyChooseUs::ordered()->paginate(15);
        return view('admin.why-choose-us.index', compact('features'));
    }

    /**
     * Store a newly created feature.
     */
    public function store(Request $request)
    {
        try {
            $request->validate([
                'icon' => 'required|string|max:255',
                'title' => 'required|string|max:255',
                'description' => 'required|string',
                'order' => 'nullable|integer|min:0',
                'is_active' => 'nullable|in:0,1',
            ]);

            $data = $request->only(['icon', 'title', 'description', 'order']);
            $data['is_active'] = $request->input('is_active', 0);
            $data['order'] = $request->order ?? 0;

            WhyChooseUs::create($data);

            return response()->json([
                'success' => true,
                'message' => 'Feature created successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    /**
     * Show the form for editing the specified feature.
     */
    public function edit(WhyChooseUs $whyChooseUs)
    {
        return response()->json($whyChooseUs);
    }

    /**
     * Update the specified feature.
     */
    public function update(Request $request, WhyChooseUs $whyChooseUs)
    {
        try {
            $request->validate([
                'icon' => 'required|string|max:255',
                'title' => 'required|string|max:255',
                'description' => 'required|string',
                'order' => 'nullable|integer|min:0',
                'is_active' => 'nullable|in:0,1',
            ]);

            $data = $request->only(['icon', 'title', 'description', 'order']);
            $data['is_active'] = $request->input('is_active', 0);
            $data['order'] = $request->order ?? 0;

            $whyChooseUs->update($data);

            return response()->json([
                'success' => true,
                'message' => 'Feature updated successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    /**
     * Remove the specified feature.
     */
    public function destroy(WhyChooseUs $whyChooseUs)
    {
        $whyChooseUs->delete();

        return redirect()->route('admin.why-choose-us.index')
            ->with('success', 'Feature deleted successfully!');
    }

    /**
     * Toggle feature status
     */
    public function toggleStatus(WhyChooseUs $whyChooseUs)
    {
        $whyChooseUs->update(['is_active' => !$whyChooseUs->is_active]);

        return back()->with('success', 'Feature status updated successfully!');
    }
}
