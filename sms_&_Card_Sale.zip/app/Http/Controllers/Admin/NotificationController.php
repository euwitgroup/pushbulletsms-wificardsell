<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Services\NotificationService;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    protected $notificationService;

    public function __construct(NotificationService $notificationService)
    {
        $this->notificationService = $notificationService;
    }

    /**
     * Display admin notifications
     */
    public function index()
    {
        $notifications = Notification::forAdmin()
            ->with('smsTemplate')
            ->latest()
            ->paginate(20);

        $unreadCount = $this->notificationService->getAdminUnreadCount();

        return view('admin.notifications.index', compact('notifications', 'unreadCount'));
    }

    /**
     * Mark notification as read
     */
    public function markAsRead($id)
    {
        $notification = Notification::forAdmin()->findOrFail($id);
        $notification->markAsRead();

        if ($notification->link) {
            return redirect($notification->link);
        }

        return back()->with('success', 'Notification marked as read.');
    }

    /**
     * Mark all as read
     */
    public function markAllAsRead()
    {
        $this->notificationService->markAllAdminAsRead();

        return back()->with('success', 'All notifications marked as read.');
    }

    /**
     * Delete notification
     */
    public function destroy($id)
    {
        $notification = Notification::forAdmin()->findOrFail($id);
        $notification->delete();

        return back()->with('success', 'Notification deleted successfully.');
    }

    /**
     * Delete all read notifications
     */
    public function deleteAllRead()
    {
        Notification::forAdmin()->read()->delete();

        return back()->with('success', 'All read notifications deleted.');
    }

    /**
     * Get unread count (AJAX)
     */
    public function getUnreadCount()
    {
        $count = $this->notificationService->getAdminUnreadCount();

        return response()->json([
            'count' => $count
        ]);
    }

    /**
     * Get recent notifications (AJAX)
     */
    public function getRecent()
    {
        $notifications = Notification::forAdmin()
            ->latest()
            ->limit(10)
            ->get();

        return response()->json([
            'notifications' => $notifications->map(function ($notification) {
                return [
                    'id' => $notification->id,
                    'title' => $notification->title,
                    'message' => $notification->message,
                    'icon' => $notification->icon,
                    'color' => $notification->color,
                    'link' => $notification->link,
                    'is_read' => $notification->is_read,
                    'time_ago' => $notification->getTimeAgo(),
                ];
            })
        ]);
    }
}

