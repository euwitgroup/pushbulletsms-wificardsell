<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\NotificationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class KycController extends Controller
{
    protected $notificationService;

    public function __construct(NotificationService $notificationService)
    {
        $this->notificationService = $notificationService;
    }

    /**
     * Display all KYC submissions
     */
    public function index(Request $request)
    {
        $status = $request->get('status', 'all');

        $query = User::where('role', 'user');

        if ($status !== 'all') {
            $query->where('kyc_status', $status);
        }

        $users = $query->orderBy('kyc_submitted_at', 'desc')
                       ->paginate(20);

        $stats = [
            'pending' => User::where('role', 'user')->where('kyc_status', 'pending')->count(),
            'approved' => User::where('role', 'user')->where('kyc_status', 'approved')->count(),
            'rejected' => User::where('role', 'user')->where('kyc_status', 'rejected')->count(),
            'not_submitted' => User::where('role', 'user')->where('kyc_status', 'not_submitted')->count(),
        ];

        return view('admin.kyc.index', compact('users', 'stats', 'status'));
    }

    /**
     * Show KYC details for a specific user
     */
    public function show($id)
    {
        $user = User::with('kycVerifiedBy')->findOrFail($id);

        return view('admin.kyc.show', compact('user'));
    }

    /**
     * Approve KYC
     */
    public function approve(Request $request, $id)
    {
        $user = User::findOrFail($id);

        if ($user->isKycVerified()) {
            return back()->with('error', 'KYC is already approved.');
        }

        $user->update([
            'kyc_status' => 'approved',
            'kyc_verified_at' => now(),
            'kyc_verified_by' => Auth::id(),
            'kyc_notes' => $request->notes,
        ]);

        // Notify user
        $this->notificationService->create(
            $user->id,
            'kyc_approved',
            'KYC Verification Approved',
            'Congratulations! Your KYC verification has been approved. All features are now unlocked.',
            ['user_id' => $user->id],
            'fa-check-circle',
            'success',
            route('user.profile'),
            true, // Send SMS
            'transactional'
        );

        return back()->with('success', 'KYC approved successfully!');
    }

    /**
     * Reject KYC
     */
    public function reject(Request $request, $id)
    {
        $request->validate([
            'reason' => 'required|string|max:500',
        ]);

        $user = User::findOrFail($id);

        $user->update([
            'kyc_status' => 'rejected',
            'kyc_verified_at' => null,
            'kyc_verified_by' => Auth::id(),
            'kyc_notes' => $request->reason,
        ]);

        // Notify user
        $this->notificationService->create(
            $user->id,
            'kyc_rejected',
            'KYC Verification Rejected',
            "Your KYC verification has been rejected. Reason: {$request->reason}. Please resubmit with correct documents.",
            ['user_id' => $user->id, 'reason' => $request->reason],
            'fa-times-circle',
            'danger',
            route('user.profile'),
            true, // Send SMS
            'transactional'
        );

        return back()->with('success', 'KYC rejected and user notified.');
    }

    /**
     * Request KYC resubmission
     */
    public function requestResubmission(Request $request, $id)
    {
        $request->validate([
            'message' => 'required|string|max:500',
        ]);

        $user = User::findOrFail($id);

        $user->update([
            'kyc_status' => 'not_submitted',
            'kyc_notes' => $request->message,
        ]);

        // Notify user
        $this->notificationService->create(
            $user->id,
            'kyc_resubmission',
            'KYC Resubmission Required',
            "Please resubmit your KYC documents. Message from admin: {$request->message}",
            ['user_id' => $user->id, 'message' => $request->message],
            'fa-redo',
            'warning',
            route('user.profile'),
            true, // Send SMS
            'transactional'
        );

        return back()->with('success', 'Resubmission request sent to user.');
    }
}
