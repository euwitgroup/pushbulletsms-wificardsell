<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ComparisonFeature;
use Illuminate\Http\Request;

class ComparisonController extends Controller
{
    public function index()
    {
        $comparisons = ComparisonFeature::ordered()->paginate(15);
        return view('admin.comparisons.index', compact('comparisons'));
    }

    public function store(Request $request)
    {
        try {
            $request->validate([
                'feature_name' => 'required|string|max:255',
                'we_have' => 'nullable|in:0,1',
                'competitor_have' => 'nullable|in:0,1',
                'order' => 'nullable|integer|min:0',
                'is_active' => 'nullable|in:0,1',
            ]);

            $data = $request->only(['feature_name', 'order']);
            $data['we_have'] = $request->input('we_have', 1);
            $data['competitor_have'] = $request->input('competitor_have', 0);
            $data['is_active'] = $request->input('is_active', 0);
            $data['order'] = $request->order ?? 0;

            ComparisonFeature::create($data);

            return response()->json([
                'success' => true,
                'message' => 'Comparison feature created successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    public function edit(ComparisonFeature $comparison)
    {
        return response()->json($comparison);
    }

    public function update(Request $request, ComparisonFeature $comparison)
    {
        try {
            $request->validate([
                'feature_name' => 'required|string|max:255',
                'we_have' => 'nullable|in:0,1',
                'competitor_have' => 'nullable|in:0,1',
                'order' => 'nullable|integer|min:0',
                'is_active' => 'nullable|in:0,1',
            ]);

            $data = $request->only(['feature_name', 'order']);
            $data['we_have'] = $request->input('we_have', 1);
            $data['competitor_have'] = $request->input('competitor_have', 0);
            $data['is_active'] = $request->input('is_active', 0);
            $data['order'] = $request->order ?? 0;

            $comparison->update($data);

            return response()->json([
                'success' => true,
                'message' => 'Comparison feature updated successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    public function destroy(ComparisonFeature $comparison)
    {
        $comparison->delete();
        return redirect()->route('admin.comparisons.index')
            ->with('success', 'Comparison feature deleted successfully!');
    }

    public function toggleStatus(ComparisonFeature $comparison)
    {
        $comparison->update(['is_active' => !$comparison->is_active]);
        return back()->with('success', 'Comparison status updated successfully!');
    }
}
