<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ContactInfo;
use Illuminate\Http\Request;

class ContactInfoController extends Controller
{
    public function index()
    {
        $contacts = ContactInfo::orderBy('order')->paginate(20);
        return view('admin.contact-info.index', compact('contacts'));
    }

    public function store(Request $request)
    {
        try {
            $request->validate([
                'type' => 'required|in:phone,email,address,hours,social',
                'label' => 'required|string|max:255',
                'icon' => 'nullable|string|max:255',
                'value' => 'required|string',
                'description' => 'nullable|string',
                'order' => 'nullable|integer',
                'is_active' => 'nullable|in:0,1',
            ]);

            $data = $request->only(['type', 'label', 'icon', 'value', 'description', 'order']);
            $data['is_active'] = $request->input('is_active', 0);

            ContactInfo::create($data);

            return response()->json([
                'success' => true,
                'message' => 'Contact info created successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    public function edit(ContactInfo $contactInfo)
    {
        return response()->json($contactInfo);
    }

    public function update(Request $request, ContactInfo $contactInfo)
    {
        try {
            $request->validate([
                'type' => 'required|in:phone,email,address,hours,social',
                'label' => 'required|string|max:255',
                'icon' => 'nullable|string|max:255',
                'value' => 'required|string',
                'description' => 'nullable|string',
                'order' => 'nullable|integer',
                'is_active' => 'nullable|in:0,1',
            ]);

            $data = $request->only(['type', 'label', 'icon', 'value', 'description', 'order']);
            $data['is_active'] = $request->input('is_active', 0);

            $contactInfo->update($data);

            return response()->json([
                'success' => true,
                'message' => 'Contact info updated successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    public function destroy(ContactInfo $contactInfo)
    {
        $contactInfo->delete();
        return redirect()->route('admin.contact-info.index')
            ->with('success', 'Contact info deleted successfully!');
    }

    public function toggleStatus(ContactInfo $contactInfo)
    {
        $contactInfo->update(['is_active' => !$contactInfo->is_active]);
        return back()->with('success', 'Contact info status updated successfully!');
    }
}

