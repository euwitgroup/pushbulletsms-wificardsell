<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CardCategory;
use App\Models\CardType;
use App\Models\CardKey;
use App\Models\CardTransaction;
use App\Services\CardRestockService;
use Illuminate\Http\Request;

class WifiCardController extends Controller
{
    public function index(Request $request)
    {
        // Auto-release expired pending cards
        CardRestockService::releaseExpiredPendingCards();
        
        $query = CardType::with(['category'])
            ->withCount([
                'cardKeys as total_keys',
                'cardKeys as available_keys' => function ($q) {
                    $q->where('status', 'available');
                },
                'cardKeys as sold_keys' => function ($q) {
                    $q->where('status', 'sold');
                }
            ]);

        // Filter by category
        if ($request->filled('category_id')) {
            $query->where('card_category_id', $request->category_id);
        }

        // Search
        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        $cards = $query->paginate(20);
        $categories = CardCategory::active()->ordered()->get();

        // Dashboard statistics
        $totalCategories = CardCategory::count();
        $totalTypes = CardType::count();
        $availableKeys = CardKey::where('status', 'available')->count();
        $soldKeys = CardKey::where('status', 'sold')->count();
        $totalTransactions = CardTransaction::count();
        $totalRevenue = CardTransaction::where('status', 'completed')->sum('amount') ?? 0;

        // Recent activities
        $recentActivities = [];
        
        // Recent card key additions
        $recentKeys = CardKey::with(['cardType.category'])
            ->latest()
            ->take(3)
            ->get();
        
        foreach ($recentKeys as $key) {
            $recentActivities[] = [
                'type' => 'info',
                'icon' => 'fa-key',
                'title' => "New card key added: {$key->cardType->name}",
                'time' => $key->created_at->diffForHumans(),
            ];
        }
        
        // Recent transactions
        $recentTransactions = CardTransaction::with(['user', 'cardType'])
            ->latest()
            ->take(2)
            ->get();
        
        foreach ($recentTransactions as $transaction) {
            // Handle both authenticated user and guest purchases
            $customerName = $transaction->user 
                ? $transaction->user->name 
                : $transaction->customer_name;
            
            $recentActivities[] = [
                'type' => $transaction->status === 'completed' ? 'success' : 'warning',
                'icon' => $transaction->status === 'completed' ? 'fa-check-circle' : 'fa-clock',
                'title' => "{$customerName} purchased {$transaction->cardType->name}",
                'time' => $transaction->created_at->diffForHumans(),
            ];
        }
        
        // Sort by time
        usort($recentActivities, function($a, $b) {
            return 0; // Keep insertion order
        });
        
        $recentActivities = array_slice($recentActivities, 0, 5);

        return view('admin.cards.index', compact(
            'cards', 
            'categories', 
            'totalCategories',
            'totalTypes',
            'availableKeys',
            'soldKeys',
            'totalTransactions',
            'totalRevenue',
            'recentActivities'
        ));
    }
}

