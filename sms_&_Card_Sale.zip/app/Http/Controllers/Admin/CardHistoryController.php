<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CardKey;
use App\Models\CardCategory;
use App\Services\CardRestockService;
use Illuminate\Http\Request;

class CardHistoryController extends Controller
{
    public function index(Request $request)
    {
        // Auto-release expired pending cards
        CardRestockService::releaseExpiredPendingCards();
        
        $query = CardKey::with(['cardType.category', 'soldToUser']);

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        } else {
            // Default: show sold and expired keys
            $query->whereIn('status', ['sold', 'expired']);
        }

        // Filter by category
        if ($request->filled('category_id')) {
            $query->whereHas('cardType', function ($q) use ($request) {
                $q->where('card_category_id', $request->category_id);
            });
        }

        // Filter by date range
        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }
        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $cardKeys = $query->latest()->paginate(50);
        $categories = CardCategory::active()->ordered()->get();

        // Statistics
        $stats = [
            'total_added' => CardKey::count(),
            'available' => CardKey::where('status', 'available')->count(),
            'sold' => CardKey::where('status', 'sold')->count(),
            'expired' => CardKey::where('status', 'expired')->count(),
        ];

        return view('admin.cards.history.index', compact('cardKeys', 'categories', 'stats'));
    }
}

