<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SmsGateway;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class SmsGatewayController extends Controller
{
    public function index()
    {
        // Ensure default gateways exist
        SmsGateway::firstOrCreate(
            ['gateway_name' => 'bulksmsbd'],
            [
                'api_url' => 'http://bulksmsbd.net/api/smsapi',
                'message_type' => 'text',
                'is_active' => false,
                'cost_per_sms' => 1.00,
            ]
        );

        SmsGateway::firstOrCreate(
            ['gateway_name' => 'pushbullet'],
            [
                'api_url' => 'https://api.pushbullet.com/v2/pushes',
                'is_active' => false,
                'cost_per_sms' => 1.00,
            ]
        );

        $gateways = SmsGateway::all();
        return view('admin.sms-gateway.index', compact('gateways'));
    }

    public function edit($id)
    {
        $gateway = SmsGateway::findOrFail($id);
        return view('admin.sms-gateway.edit', compact('gateway'));
    }

    public function test($id)
    {
        $gateway = SmsGateway::findOrFail($id);
        return view('admin.sms-gateway.test', compact('gateway'));
    }

    public function toggleStatus($id)
    {
        $gateway = SmsGateway::findOrFail($id);
        
        // Toggle the gateway status - allow multiple gateways to be active
        $gateway->update(['is_active' => !$gateway->is_active]);

        return response()->json([
            'success' => true,
            'message' => 'Gateway status updated successfully',
            'is_active' => $gateway->is_active
        ]);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'api_key' => 'nullable|string',
            'sender_id' => 'nullable|string',
            'message_type' => 'nullable|string',
            'device_name' => 'nullable|string',
            'device_id' => 'nullable|string',
        ]);

        $gateway = SmsGateway::findOrFail($id);
        
        $gateway->update($request->only([
            'api_key',
            'sender_id',
            'message_type',
            'device_name',
            'device_id',
        ]));

        return redirect()
            ->route('admin.sms-gateway.index')
            ->with('success', ucfirst($gateway->gateway_name) . ' settings updated successfully.');
    }

    public function regenerateApiKey($gateway)
    {
        $smsGateway = SmsGateway::where('gateway_name', $gateway)->firstOrFail();
        
        // Generate a random API key
        $newApiKey = 'GEN_' . bin2hex(random_bytes(16));
        
        $smsGateway->update(['api_key' => $newApiKey]);

        return response()->json([
            'success' => true,
            'api_key' => $newApiKey,
            'message' => 'API key regenerated successfully'
        ]);
    }

    public function testSend(Request $request, $id)
    {
        $request->validate([
            'phone' => 'required|string',
            'message' => 'required|string',
        ]);

        $gateway = SmsGateway::findOrFail($id);

        if ($gateway->gateway_name === 'bulksmsbd') {
            return $this->testBulkSmsBd($gateway, $request->phone, $request->message);
        } elseif ($gateway->gateway_name === 'pushbullet') {
            return $this->testPushbullet($gateway, $request->phone, $request->message);
        }

        return response()->json(['success' => false, 'message' => 'Unknown gateway'], 400);
    }

    private function testBulkSmsBd($gateway, $phone, $message)
    {
        try {
            // Use POST request as per BulkSMSBD API documentation
            $response = Http::asForm()->post($gateway->api_url, [
                'api_key' => $gateway->api_key,
                'senderid' => $gateway->sender_id,
                'number' => $phone,
                'message' => $message
            ]);

            $responseBody = $response->body();
            
            // Try to parse as JSON
            $jsonResponse = json_decode($responseBody, true);
            
            if ($jsonResponse && isset($jsonResponse['response_code'])) {
                // JSON response format
                $statusCode = (string)$jsonResponse['response_code'];
                $errorMessage = $jsonResponse['error_message'] ?? '';
                $successMessage = $jsonResponse['success_message'] ?? '';
                
                return response()->json([
                    'success' => $statusCode == '202',
                    'code' => $statusCode,
                    'message' => $errorMessage ?: ($successMessage ?: $this->getBulkSmsBdMessage($statusCode)),
                    'gateway' => 'BulkSMSBD'
                ]);
            } else {
                // Plain text response format
                $statusCode = trim($responseBody);
                
                return response()->json([
                    'success' => $statusCode == '202',
                    'code' => $statusCode,
                    'message' => $this->getBulkSmsBdMessage($statusCode),
                    'gateway' => 'BulkSMSBD'
                ]);
            }
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Connection failed: ' . $e->getMessage()
            ], 500);
        }
    }

    private function testPushbullet($gateway, $phone, $message)
    {
        try {
            if (!$gateway->device_id) {
                return response()->json([
                    'success' => false,
                    'message' => 'Please select a device first'
                ], 400);
            }

            // Use Pushbullet SMS API endpoint
            $response = Http::withHeaders([
                'Access-Token' => $gateway->api_key,
                'Content-Type' => 'application/json',
            ])->post('https://api.pushbullet.com/v2/texts', [
                'data' => [
                    'target_device_iden' => $gateway->device_id,
                    'addresses' => [$phone],
                    'message' => $message
                ]
            ]);

            $responseData = $response->json();

            if ($response->successful()) {
                return response()->json([
                    'success' => true,
                    'message' => 'SMS sent successfully via device: ' . $gateway->device_name,
                    'gateway' => 'Pushbullet'
                ]);
            } else {
                $errorMessage = $responseData['error']['message'] ?? 'Failed to send SMS';
                return response()->json([
                    'success' => false,
                    'message' => $errorMessage
                ], 400);
            }
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Connection failed: ' . $e->getMessage()
            ], 500);
        }
    }

    public function getDevices(Request $request, $gateway)
    {
        // Try to get API key from request first, then from database
        $apiKey = $request->input('api_key');
        
        if (!$apiKey) {
            $smsGateway = SmsGateway::where('gateway_name', $gateway)->first();
            $apiKey = $smsGateway ? $smsGateway->api_key : null;
        }

        if (!$apiKey) {
            return response()->json([
                'success' => false,
                'message' => 'Please provide API key first'
            ], 400);
        }

        try {
            $response = Http::withHeaders([
                'Access-Token' => $apiKey,
            ])->get('https://api.pushbullet.com/v2/devices');

            if ($response->successful()) {
                $devices = $response->json()['devices'] ?? [];
                
                return response()->json([
                    'success' => true,
                    'devices' => array_map(function($device) {
                        return [
                            'id' => $device['iden'],
                            'name' => $device['nickname'] ?? $device['model'] ?? 'Unknown Device',
                            'manufacturer' => $device['manufacturer'] ?? '',
                            'model' => $device['model'] ?? '',
                        ];
                    }, $devices)
                ]);
            }

            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch devices. Please check your API key.'
            ], 400);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Connection failed: ' . $e->getMessage()
            ], 500);
        }
    }

    public function management()
    {
        $gateways = SmsGateway::all();
        return view('admin.sms-management', compact('gateways'));
    }

    public function updateCost(Request $request, $gateway)
    {
        $request->validate([
            'cost_per_sms' => 'required|numeric|min:0',
        ]);

        $smsGateway = SmsGateway::findOrFail($gateway);
        
        $smsGateway->update([
            'cost_per_sms' => $request->cost_per_sms
        ]);

        return response()->json([
            'success' => true,
            'message' => 'SMS cost updated successfully for ' . ucfirst($smsGateway->gateway_name),
            'cost' => $smsGateway->cost_per_sms
        ]);
    }

    private function getBulkSmsBdMessage($code)
    {
        $messages = [
            '202' => '✅ SMS Submitted Successfully',
            '1001' => '❌ Invalid Number',
            '1002' => '❌ Sender ID not correct/disabled',
            '1003' => '❌ Required fields missing',
            '1005' => '❌ Internal Error',
            '1006' => '❌ Balance Validity Not Available',
            '1007' => '❌ Balance Insufficient',
            '1011' => '❌ User ID not found',
            '1012' => '❌ Masking SMS must be sent in Bengali',
            '1013' => '❌ Sender ID not found in Gateway',
            '1031' => '❌ Account Not Verified',
            '1032' => '❌ IP Not Whitelisted. Please whitelist your IP from BulkSMSBD Phonebook',
        ];

        return $messages[$code] ?? '❌ Unknown response code: ' . $code;
    }
}
