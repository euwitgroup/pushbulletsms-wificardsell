<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CardCategory;
use App\Models\CardType;
use App\Models\CardKey;
use App\Services\CardRestockService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CardInventoryController extends Controller
{
    public function index(Request $request)
    {
        // Auto-release expired pending cards
        CardRestockService::releaseExpiredPendingCards();
        
        $query = CardType::with('category')
            ->withCount([
                'cardKeys as total_keys',
                'cardKeys as available_keys' => function ($q) {
                    $q->where('status', 'available');
                },
                'cardKeys as sold_keys' => function ($q) {
                    $q->where('status', 'sold');
                },
                'cardKeys as expired_keys' => function ($q) {
                    $q->where('status', 'expired');
                }
            ]);

        // Filter by category
        if ($request->filled('category_id')) {
            $query->where('card_category_id', $request->category_id);
        }

        // Filter by stock status
        if ($request->filled('stock_status')) {
            if ($request->stock_status === 'low') {
                $query->having('available_keys', '<', 10);
            } elseif ($request->stock_status === 'out') {
                $query->having('available_keys', '=', 0);
            } elseif ($request->stock_status === 'in_stock') {
                $query->having('available_keys', '>', 0);
            }
        }

        $inventory = $query->orderBy('name')->get();
        $categories = CardCategory::active()->ordered()->get();

        // Calculate totals
        $totalKeys = CardKey::count();
        $availableKeys = CardKey::where('status', 'available')->count();
        $soldKeys = CardKey::where('status', 'sold')->count();
        $totalCardTypes = CardType::count();

        return view('admin.cards.inventory.index', compact('inventory', 'categories', 'totalKeys', 'availableKeys', 'soldKeys', 'totalCardTypes'));
    }
}

