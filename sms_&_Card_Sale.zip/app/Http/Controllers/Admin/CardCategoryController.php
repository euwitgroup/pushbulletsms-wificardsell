<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CardCategory;
use Illuminate\Http\Request;

class CardCategoryController extends Controller
{
    public function index()
    {
        $categories = CardCategory::orderBy('order')->paginate(20);
        return view('admin.cards.categories.index', compact('categories'));
    }

    public function store(Request $request)
    {
        try {
            $request->validate([
                'name' => 'required|string|max:255',
                'description' => 'nullable|string',
                'order' => 'nullable|integer',
                'is_active' => 'nullable|in:0,1',
            ]);

            CardCategory::create([
                'name' => $request->name,
                'description' => $request->description,
                'order' => $request->order ?? 0,
                'is_active' => $request->input('is_active', 1),
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Card category created successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    public function edit(CardCategory $cardCategory)
    {
        return response()->json($cardCategory);
    }

    public function update(Request $request, CardCategory $cardCategory)
    {
        try {
            $request->validate([
                'name' => 'required|string|max:255',
                'description' => 'nullable|string',
                'order' => 'nullable|integer',
                'is_active' => 'nullable|in:0,1',
            ]);

            $cardCategory->update([
                'name' => $request->name,
                'description' => $request->description,
                'order' => $request->order ?? 0,
                'is_active' => $request->input('is_active', 1),
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Card category updated successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    public function destroy(CardCategory $cardCategory)
    {
        // Check if category has card types
        if ($cardCategory->cardTypes()->count() > 0) {
            return back()->with('error', 'Cannot delete category with existing card types!');
        }

        $cardCategory->delete();
        return back()->with('success', 'Card category deleted successfully!');
    }

    public function toggleStatus(CardCategory $cardCategory)
    {
        $cardCategory->update(['is_active' => !$cardCategory->is_active]);
        return back()->with('success', 'Category status updated successfully!');
    }
}

