<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Transaction;
use App\Models\Setting;
use Illuminate\Http\Request;
use PDF;
use Excel;
use App\Exports\InvoicesExport;

class InvoiceController extends Controller
{
    public function index(Request $request)
    {
        $query = Transaction::with('user')->where('type', 'credit')->latest();

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Filter by date range
        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }
        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        // Filter by user
        if ($request->filled('user')) {
            $query->whereHas('user', function($q) use ($request) {
                $q->where('name', 'like', '%' . $request->user . '%')
                  ->orWhere('email', 'like', '%' . $request->user . '%');
            });
        }

        $invoices = $query->paginate(20);
        
        // Get settings for invoice display
        $settings = [
            'site_email' => Setting::get('site_email', 'admin@example.com'),
            'site_name' => Setting::get('site_name', config('app.name')),
        ];

        return view('admin.invoices', compact('invoices', 'settings'));
    }

    public function download($id)
    {
        $invoice = Transaction::with('user')->findOrFail($id);
        
        $settings = [
            'site_email' => Setting::get('site_email', 'admin@example.com'),
            'site_name' => Setting::get('site_name', config('app.name')),
        ];

        $pdf = PDF::loadView('admin.exports.invoice-pdf', compact('invoice', 'settings'));
        return $pdf->download('invoice-' . str_pad($id, 6, '0', STR_PAD_LEFT) . '.pdf');
    }

    public function export(Request $request)
    {
        $query = Transaction::with('user')->where('type', 'credit')->latest();

        // Apply same filters
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }
        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }
        if ($request->filled('user')) {
            $query->whereHas('user', function($q) use ($request) {
                $q->where('name', 'like', '%' . $request->user . '%')
                  ->orWhere('email', 'like', '%' . $request->user . '%');
            });
        }

        $invoices = $query->get();
        $format = $request->get('format', 'excel');

        if ($format === 'excel') {
            return Excel::download(
                new InvoicesExport($invoices),
                'invoices_' . date('Y-m-d_H-i-s') . '.xlsx'
            );
        } elseif ($format === 'pdf') {
            $settings = [
                'site_email' => Setting::get('site_email', 'admin@example.com'),
                'site_name' => Setting::get('site_name', config('app.name')),
            ];
            $pdf = PDF::loadView('admin.exports.invoices-pdf', compact('invoices', 'settings'));
            return $pdf->download('invoices_' . date('Y-m-d_H-i-s') . '.pdf');
        }

        return back()->with('error', 'Invalid export format');
    }
}
