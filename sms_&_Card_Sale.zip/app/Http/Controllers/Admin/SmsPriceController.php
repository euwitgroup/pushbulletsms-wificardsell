<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SmsPrice;
use Illuminate\Http\Request;

class SmsPriceController extends Controller
{
    public function index()
    {
        $prices = SmsPrice::ordered()->paginate(15);
        return view('admin.sms-prices.index', compact('prices'));
    }

    public function store(Request $request)
    {
        try {
            $request->validate([
                'package_name' => 'required|string|max:255',
                'package_type' => 'required|string|max:255',
                'base_price' => 'required|numeric|min:0',
                'minimum_buy' => 'required|integer|min:0',
                'order' => 'nullable|integer|min:0',
                'is_active' => 'nullable|in:0,1',
                'is_featured' => 'nullable|in:0,1',
            ]);

            $data = $request->only(['package_name', 'package_type', 'base_price', 'minimum_buy', 'order']);
            
            // Handle pricing tiers (if provided as JSON string)
            $pricingTiers = $request->input('pricing_tiers');
            if ($pricingTiers) {
                $data['pricing_tiers'] = is_string($pricingTiers) ? json_decode($pricingTiers, true) : $pricingTiers;
    }

            // Handle features (if provided as array or JSON string)
            $features = $request->input('features');
            if ($features) {
                $data['features'] = is_string($features) ? json_decode($features, true) : $features;
            }

            $data['is_active'] = $request->input('is_active', 0);
            $data['is_featured'] = $request->input('is_featured', 0);
            $data['order'] = $request->order ?? 0;

            SmsPrice::create($data);

            return response()->json([
                'success' => true,
                'message' => 'SMS price package created successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    public function edit(SmsPrice $smsPrice)
    {
        return response()->json($smsPrice);
    }

    public function update(Request $request, SmsPrice $smsPrice)
    {
        try {
            $request->validate([
                'package_name' => 'required|string|max:255',
                'package_type' => 'required|string|max:255',
                'base_price' => 'required|numeric|min:0',
                'minimum_buy' => 'required|integer|min:0',
                'order' => 'nullable|integer|min:0',
                'is_active' => 'nullable|in:0,1',
                'is_featured' => 'nullable|in:0,1',
            ]);

            $data = $request->only(['package_name', 'package_type', 'base_price', 'minimum_buy', 'order']);
            
            // Handle pricing tiers
            $pricingTiers = $request->input('pricing_tiers');
            if ($pricingTiers) {
                $data['pricing_tiers'] = is_string($pricingTiers) ? json_decode($pricingTiers, true) : $pricingTiers;
            }

            // Handle features
            $features = $request->input('features');
            if ($features) {
                $data['features'] = is_string($features) ? json_decode($features, true) : $features;
            }

            $data['is_active'] = $request->input('is_active', 0);
            $data['is_featured'] = $request->input('is_featured', 0);

            $smsPrice->update($data);

            return response()->json([
                'success' => true,
                'message' => 'SMS price package updated successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    public function destroy(SmsPrice $smsPrice)
    {
        try {
            $smsPrice->delete();

            return response()->json([
                'success' => true,
                'message' => 'SMS price package deleted successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    public function toggleStatus(SmsPrice $smsPrice)
    {
        try {
            $smsPrice->update(['is_active' => !$smsPrice->is_active]);

            return response()->json([
                'success' => true,
                'message' => 'Status updated successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }
}
