<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;

class TestPaymentController extends Controller
{
    public function index()
    {
        $paymentCharge = Setting::get('rupantorpay_payment_charge', 0);
        $minimumPayment = Setting::get('rupantorpay_minimum_payment', 10);
        $isActive = Setting::get('rupantorpay_active') == '1' || Setting::get('rupantorpay_active') === true;
        
        return view('admin.test-payment', compact('paymentCharge', 'minimumPayment', 'isActive'));
    }
    
    public function initiatePayment(Request $request)
    {
        $baseAmount = $request->input('amount', 1); // Base amount selected by user
        
        // Get RupantorPay settings
        $apiKey = Setting::get('rupantorpay_api_key');
        $successUrl = Setting::get('rupantorpay_success_url', url('/payment/success'));
        $cancelUrl = Setting::get('rupantorpay_cancel_url', url('/payment/cancel'));
        $isSandbox = Setting::get('rupantorpay_sandbox');
        $paymentCharge = Setting::get('rupantorpay_payment_charge', 0); // Get payment charge %
        $minimumPayment = Setting::get('rupantorpay_minimum_payment', 10);
        
        if (!$apiKey) {
            return back()->with('error', 'RupantorPay API Key not configured. Please configure it first.');
        }
        
        // Check minimum payment
        if ($baseAmount < $minimumPayment) {
            return back()->with('error', "Minimum payment amount is ৳{$minimumPayment}");
        }
        
        // Calculate payment charge
        $chargeAmount = ($baseAmount * $paymentCharge) / 100;
        $totalAmount = $baseAmount + $chargeAmount;
        
        try {
            // Prepare payment data
            $paymentData = [
                'amount' => round($totalAmount, 2), // Total amount including charge
                'success_url' => $successUrl,
                'cancel_url' => $cancelUrl,
                'webhook_url' => url('/webhook/rupantorpay'),
                'metadata' => [
                    'test' => true,
                    'user_id' => auth()->id(),
                    'base_amount' => $baseAmount,
                    'charge_amount' => round($chargeAmount, 2),
                    'charge_percentage' => $paymentCharge,
                    'description' => 'Test Payment - ৳' . $baseAmount . ' + ৳' . round($chargeAmount, 2) . ' (Charge)'
                ]
            ];
            
            // Make API request to RupantorPay
            $response = \Http::withHeaders([
                'X-API-KEY' => $apiKey,
                'Content-Type' => 'application/json',
                'X-CLIENT' => request()->getHost(),
            ])->post('https://payment.rupantorpay.com/api/payment/checkout', $paymentData);
            
            if ($response->successful()) {
                $data = $response->json();
                
                // Check if payment URL is returned
                if (isset($data['payment_url'])) {
                    return redirect($data['payment_url']);
                } elseif (isset($data['url'])) {
                    return redirect($data['url']);
                } else {
                    return back()->with('error', 'Payment URL not found in response: ' . json_encode($data));
                }
            } else {
                return back()->with('error', 'Payment initialization failed: ' . $response->body());
            }
        } catch (\Exception $e) {
            return back()->with('error', 'Error: ' . $e->getMessage());
        }
    }
}
