<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    public function index()
    {
        $settings = [
            // Basic Settings
            'site_name' => Setting::get('site_name', 'SMS & Card Sale'),
            'user_site_name' => Setting::get('user_site_name', 'SMS & Card Sale'),
            'site_phone' => Setting::get('site_phone', '+8801XXXXXXXXX'),
            'site_email' => Setting::get('site_email', 'admin@example.com'),
            'site_address' => Setting::get('site_address', 'Dhaka, Bangladesh'),
            'timezone' => Setting::get('timezone', 'Asia/Dhaka'),
            'date_format' => Setting::get('date_format', 'd M, Y'),
            'time_format' => Setting::get('time_format', 'h:i A'),
            'country' => Setting::get('country', 'Bangladesh'),
            'data_per_page' => Setting::get('data_per_page', '10'),
            'web_visitors' => Setting::get('web_visitors', '0'),
            'maintenance_title' => Setting::get('maintenance_title', 'Site Under Maintenance'),
            'maintenance_description' => Setting::get('maintenance_description', 'We are currently performing scheduled maintenance. We will be back soon.'),
            'copyright_text' => Setting::get('copyright_text', '© 2025 SMS & Card Sale. All rights reserved.'),
            'google_adsense_id' => Setting::get('google_adsense_id', ''),
            'google_analytics_id' => Setting::get('google_analytics_id', ''),
            'google_map_api_key' => Setting::get('google_map_api_key', ''),
            
            // SEO Settings
            'meta_title' => Setting::get('meta_title', 'SMS & Card Sale'),
            'meta_description' => Setting::get('meta_description', ''),
            'meta_keywords' => Setting::get('meta_keywords', ''),
            'og_image' => Setting::get('og_image', ''),
            
            // Logging Settings
            'enable_activity_logs' => Setting::get('enable_activity_logs', '1'),
            'log_retention_days' => Setting::get('log_retention_days', '30'),
            'enable_error_logs' => Setting::get('enable_error_logs', '1'),
            
            // Rate Limiting
            'api_rate_limit' => Setting::get('api_rate_limit', '60'),
            'login_rate_limit' => Setting::get('login_rate_limit', '5'),
            'sms_rate_limit' => Setting::get('sms_rate_limit', '100'),
            'enable_rate_limiting' => Setting::get('enable_rate_limiting', '1'),
            
            // Theme Settings
            'primary_color' => Setting::get('primary_color', '#667eea'),
            'secondary_color' => Setting::get('secondary_color', '#764ba2'),
            'default_theme' => Setting::get('default_theme', 'light'),
            'enable_dark_mode' => Setting::get('enable_dark_mode', '1'),
            
            // Storage Settings
            'storage_driver' => Setting::get('storage_driver', 'local'),
            'max_upload_size' => Setting::get('max_upload_size', '10'),
            'allowed_file_types' => Setting::get('allowed_file_types', 'jpg,jpeg,png,pdf,doc,docx'),
            
            // Recaptcha Settings
            'enable_recaptcha' => Setting::get('enable_recaptcha', '0'),
            'recaptcha_site_key' => Setting::get('recaptcha_site_key', ''),
            'recaptcha_secret_key' => Setting::get('recaptcha_secret_key', ''),
            'recaptcha_version' => Setting::get('recaptcha_version', 'v2'),
            
            // Social Login Settings
            'enable_google_login' => Setting::get('enable_google_login', '0'),
            'google_client_id' => Setting::get('google_client_id', ''),
            'google_client_secret' => Setting::get('google_client_secret', ''),
            'enable_facebook_login' => Setting::get('enable_facebook_login', '0'),
            'facebook_app_id' => Setting::get('facebook_app_id', ''),
            'facebook_app_secret' => Setting::get('facebook_app_secret', ''),
            
            // Login Settings
            'enable_registration' => Setting::get('enable_registration', '1'),
            'email_verification_required' => Setting::get('email_verification_required', '0'),
            'phone_verification_required' => Setting::get('phone_verification_required', '1'),
            'otp_expiry_minutes' => Setting::get('otp_expiry_minutes', '5'),
            'otp_length' => Setting::get('otp_length', '6'),
            'password_min_length' => Setting::get('password_min_length', '8'),
            'session_timeout' => Setting::get('session_timeout', '120'),
            'max_login_attempts' => Setting::get('max_login_attempts', '5'),
            
            // Logo Settings
            'site_logo' => Setting::get('site_logo', ''),
            'site_favicon' => Setting::get('site_favicon', ''),
            'logo_width' => Setting::get('logo_width', '150'),
            
            // Ticket Settings
            'enable_tickets' => Setting::get('enable_tickets', '1'),
            'default_ticket_priority' => Setting::get('default_ticket_priority', 'medium'),
            'ticket_auto_close_days' => Setting::get('ticket_auto_close_days', '30'),
            'ticket_notification_email' => Setting::get('ticket_notification_email', ''),
            
            // Mail Settings
            'mail_driver' => Setting::get('mail_driver', 'smtp'),
            'mail_host' => Setting::get('mail_host', 'smtp.gmail.com'),
            'mail_port' => Setting::get('mail_port', '587'),
            'mail_username' => Setting::get('mail_username', ''),
            'mail_password' => Setting::get('mail_password', ''),
            'mail_encryption' => Setting::get('mail_encryption', 'tls'),
            'mail_from_address' => Setting::get('mail_from_address', ''),
            'mail_from_name' => Setting::get('mail_from_name', 'SMS & Card Sale'),
            'admin_email' => Setting::get('admin_email', ''),
        ];

        return view('admin.settings', compact('settings'));
    }

    public function update(Request $request)
    {
        $request->validate([
            // Basic Settings
            'site_name' => 'nullable|string|max:255',
            'user_site_name' => 'nullable|string|max:255',
            'site_phone' => 'nullable|string|max:20',
            'site_email' => 'nullable|email|max:255',
            'site_address' => 'nullable|string|max:500',
            'timezone' => 'nullable|string',
            'date_format' => 'nullable|string',
            'time_format' => 'nullable|string',
            'country' => 'nullable|string',
            'data_per_page' => 'nullable|integer|min:1|max:100',
            'web_visitors' => 'nullable|integer|min:0',
            'maintenance_title' => 'nullable|string|max:255',
            'maintenance_description' => 'nullable|string|max:500',
            'copyright_text' => 'nullable|string',
            'google_adsense_id' => 'nullable|string|max:255',
            'google_analytics_id' => 'nullable|string|max:255',
            'google_map_api_key' => 'nullable|string|max:255',
            
            // SEO Settings
            'meta_title' => 'nullable|string|max:255',
            'meta_description' => 'nullable|string',
            'meta_keywords' => 'nullable|string',
            'og_image' => 'nullable|url',
            
            // Logging Settings
            'enable_activity_logs' => 'nullable|in:0,1',
            'log_retention_days' => 'nullable|integer|min:1',
            'enable_error_logs' => 'nullable|in:0,1',
            
            // Rate Limiting
            'api_rate_limit' => 'nullable|integer|min:1',
            'login_rate_limit' => 'nullable|integer|min:1',
            'sms_rate_limit' => 'nullable|integer|min:1',
            'enable_rate_limiting' => 'nullable|in:0,1',
            
            // Theme Settings
            'primary_color' => 'nullable|string',
            'secondary_color' => 'nullable|string',
            'default_theme' => 'nullable|in:light,dark',
            'enable_dark_mode' => 'nullable|in:0,1',
            
            // Storage Settings
            'storage_driver' => 'nullable|in:local,s3,digitalocean',
            'max_upload_size' => 'nullable|integer|min:1',
            'allowed_file_types' => 'nullable|string',
            
            // Recaptcha Settings
            'enable_recaptcha' => 'nullable|in:0,1',
            'recaptcha_site_key' => 'nullable|string',
            'recaptcha_secret_key' => 'nullable|string',
            'recaptcha_version' => 'nullable|in:v2,v3',
            
            // Social Login Settings
            'enable_google_login' => 'nullable|in:0,1',
            'google_client_id' => 'nullable|string',
            'google_client_secret' => 'nullable|string',
            'enable_facebook_login' => 'nullable|in:0,1',
            'facebook_app_id' => 'nullable|string',
            'facebook_app_secret' => 'nullable|string',
            
            // Login Settings
            'enable_registration' => 'nullable|in:0,1',
            'email_verification_required' => 'nullable|in:0,1',
            'phone_verification_required' => 'nullable|in:0,1',
            'otp_expiry_minutes' => 'nullable|integer|min:1|max:30',
            'otp_length' => 'nullable|integer|min:4|max:8',
            'password_min_length' => 'nullable|integer|min:6|max:20',
            'session_timeout' => 'nullable|integer|min:1',
            'max_login_attempts' => 'nullable|integer|min:3|max:10',
            
            // Logo Settings
            'site_logo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'site_favicon' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg,ico|max:1024',
            'logo_width' => 'nullable|integer|min:50|max:500',
            
            // Ticket Settings
            'enable_tickets' => 'nullable|in:0,1',
            'default_ticket_priority' => 'nullable|in:low,medium,high',
            'ticket_auto_close_days' => 'nullable|integer|min:1',
            'ticket_notification_email' => 'nullable|email',
            
            // Mail Settings
            'mail_driver' => 'nullable|in:smtp,sendmail,mailgun,ses,log',
            'mail_host' => 'nullable|string|max:255',
            'mail_port' => 'nullable|integer|min:1|max:65535',
            'mail_username' => 'nullable|string|max:255',
            'mail_password' => 'nullable|string|max:255',
            'mail_encryption' => 'nullable|in:tls,ssl,',
            'mail_from_address' => 'nullable|email|max:255',
            'mail_from_name' => 'nullable|string|max:255',
            'admin_email' => 'nullable|email|max:255',
        ]);

        // Handle file uploads
        if ($request->hasFile('site_logo')) {
            $logo = $request->file('site_logo');
            $logoPath = $logo->store('logos', 'public');
            Setting::set('site_logo', $logoPath, 'text');
        }

        if ($request->hasFile('site_favicon')) {
            $favicon = $request->file('site_favicon');
            $faviconPath = $favicon->store('favicons', 'public');
            Setting::set('site_favicon', $faviconPath, 'text');
        }

        // Save all other settings
        foreach ($request->except(['_token', 'site_logo', 'site_favicon']) as $key => $value) {
            if ($value !== null) {
                Setting::set($key, $value, 'text');
            }
        }

        return back()->with('success', 'Settings updated successfully.');
    }
    
    public function testMail(Request $request)
    {
        $request->validate([
            'email' => 'required|email'
        ]);

        try {
            // Get mail settings from database
            $mailConfig = [
                'driver' => Setting::get('mail_driver', 'smtp'),
                'host' => Setting::get('mail_host', 'smtp.gmail.com'),
                'port' => Setting::get('mail_port', '587'),
                'username' => Setting::get('mail_username', ''),
                'password' => Setting::get('mail_password', ''),
                'encryption' => Setting::get('mail_encryption', 'tls'),
                'from' => [
                    'address' => Setting::get('mail_from_address', ''),
                    'name' => Setting::get('mail_from_name', 'SMS & Card Sale'),
                ],
            ];

            // Update Laravel mail configuration at runtime
            config(['mail.default' => $mailConfig['driver']]);
            config(['mail.mailers.smtp' => [
                'transport' => 'smtp',
                'host' => $mailConfig['host'],
                'port' => $mailConfig['port'],
                'encryption' => $mailConfig['encryption'],
                'username' => $mailConfig['username'],
                'password' => $mailConfig['password'],
            ]]);
            config(['mail.from' => $mailConfig['from']]);

            // Send test email
            \Mail::raw('This is a test email from your SMS & Card Sale application. If you received this, your mail configuration is working correctly!', function ($message) use ($request, $mailConfig) {
                $message->to($request->email)
                    ->subject('Test Email - ' . config('app.name', 'SMS & Card Sale'))
                    ->from($mailConfig['from']['address'], $mailConfig['from']['name']);
            });

            return response()->json([
                'success' => true,
                'message' => 'Test email sent successfully to ' . $request->email
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to send email: ' . $e->getMessage()
            ], 500);
        }
    }
}
