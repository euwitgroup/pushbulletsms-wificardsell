<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CardTransaction;
use App\Models\CardCategory;
use App\Services\CardRestockService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CardTransactionController extends Controller
{
    public function index(Request $request)
    {
        // Auto-release expired pending cards
        CardRestockService::releaseExpiredPendingCards();
        
        $query = CardTransaction::with(['user', 'cardType.category', 'cardKey']);

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Filter by user
        if ($request->filled('user_id')) {
            $query->where('user_id', $request->user_id);
        }

        // Filter by category
        if ($request->filled('category_id')) {
            $query->whereHas('cardType', function ($q) use ($request) {
                $q->where('card_category_id', $request->category_id);
            });
        }

        // Filter by date range
        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }
        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $transactions = $query->latest()->paginate(50);
        $categories = CardCategory::active()->ordered()->get();

        // Calculate statistics
        $totalTransactions = CardTransaction::count();
        $completedTransactions = CardTransaction::where('status', 'completed')->count();
        $pendingTransactions = CardTransaction::where('status', 'pending')->count();
        $totalRevenue = CardTransaction::where('status', 'completed')->sum('amount') ?? 0;

        return view('admin.cards.transactions.index', compact(
            'transactions', 
            'categories', 
            'totalTransactions',
            'completedTransactions',
            'pendingTransactions',
            'totalRevenue'
        ));
    }

    public function show($id)
    {
        $transaction = CardTransaction::with(['user', 'cardType.category', 'cardKey'])->findOrFail($id);
        return response()->json($transaction);
    }

    public function updateStatus(Request $request, CardTransaction $transaction)
    {
        try {
            $request->validate([
                'status' => 'required|in:pending,completed,failed,refunded',
            ]);

            $transaction->update([
                'status' => $request->status,
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Transaction status updated successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }
}

