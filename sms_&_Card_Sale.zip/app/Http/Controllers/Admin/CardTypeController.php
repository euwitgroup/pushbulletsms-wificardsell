<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CardCategory;
use App\Models\CardType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class CardTypeController extends Controller
{
    public function index()
    {
        $cardTypes = CardType::with('category')->orderBy('order')->paginate(20);
        $categories = CardCategory::active()->ordered()->get();
        return view('admin.cards.types.index', compact('cardTypes', 'categories'));
    }

    public function store(Request $request)
    {
        try {
            $request->validate([
                'card_category_id' => 'required|exists:card_categories,id',
                'name' => 'required|string|max:255',
                'price' => 'required|numeric|min:0',
                'image' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:5120',
                'description' => 'nullable|string',
                'validity_value' => 'required|integer|min:1',
                'validity_type' => 'required|in:hours,days',
                'order' => 'nullable|integer',
                'is_active' => 'nullable|in:0,1',
            ]);

            $data = $request->only(['card_category_id', 'name', 'price', 'description', 'validity_value', 'validity_type', 'order']);
            $data['is_active'] = $request->input('is_active', 1);

            if ($request->hasFile('image')) {
                $data['image'] = $request->file('image')->store('cards', 'public');
            }

            CardType::create($data);

            return response()->json([
                'success' => true,
                'message' => 'Card type created successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    public function edit(CardType $cardType)
    {
        return response()->json($cardType);
    }

    public function update(Request $request, CardType $cardType)
    {
        try {
            $request->validate([
                'card_category_id' => 'required|exists:card_categories,id',
                'name' => 'required|string|max:255',
                'price' => 'required|numeric|min:0',
                'image' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:5120',
                'description' => 'nullable|string',
                'validity_value' => 'required|integer|min:1',
                'validity_type' => 'required|in:hours,days',
                'order' => 'nullable|integer',
                'is_active' => 'nullable|in:0,1',
            ]);

            $data = $request->only(['card_category_id', 'name', 'price', 'description', 'validity_value', 'validity_type', 'order']);
            $data['is_active'] = $request->input('is_active', 1);

            if ($request->hasFile('image')) {
                // Delete old image
                if ($cardType->image) {
                    Storage::disk('public')->delete($cardType->image);
                }
                $data['image'] = $request->file('image')->store('cards', 'public');
            }

            $cardType->update($data);

            return response()->json([
                'success' => true,
                'message' => 'Card type updated successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    public function destroy(CardType $cardType)
    {
        // Check if card type has keys
        if ($cardType->cardKeys()->count() > 0) {
            return response()->json([
                'success' => false,
                'message' => 'Cannot delete card type with existing keys!'
            ], 422);
        }

        // Delete image
        if ($cardType->image) {
            Storage::disk('public')->delete($cardType->image);
        }

        $cardType->delete();
        return response()->json([
            'success' => true,
            'message' => 'Card type deleted successfully!'
        ]);
    }

    public function toggleStatus(CardType $cardType)
    {
        $cardType->update(['is_active' => !$cardType->is_active]);
        return response()->json([
            'success' => true,
            'message' => 'Card type status updated successfully!'
        ]);
    }
}

