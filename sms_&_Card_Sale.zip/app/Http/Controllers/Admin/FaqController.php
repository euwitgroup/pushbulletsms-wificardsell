<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Faq;
use Illuminate\Http\Request;

class FaqController extends Controller
{
    public function index()
    {
        $faqs = Faq::ordered()->paginate(15);
        return view('admin.faqs.index', compact('faqs'));
    }

    public function store(Request $request)
    {
        try {
            $request->validate([
                'question' => 'required|string|max:255',
                'answer' => 'required|string',
                'order' => 'nullable|integer|min:0',
                'is_active' => 'nullable|in:0,1',
            ]);

            $data = $request->only(['question', 'answer', 'order']);
            $data['is_active'] = $request->input('is_active', 0);
            $data['order'] = $request->order ?? 0;

            Faq::create($data);

            return response()->json([
                'success' => true,
                'message' => 'FAQ created successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    public function edit(Faq $faq)
    {
        return response()->json($faq);
    }

    public function update(Request $request, Faq $faq)
    {
        try {
            $request->validate([
                'question' => 'required|string|max:255',
                'answer' => 'required|string',
                'order' => 'nullable|integer|min:0',
                'is_active' => 'nullable|in:0,1',
            ]);

            $data = $request->only(['question', 'answer', 'order']);
            $data['is_active'] = $request->input('is_active', 0);
            $data['order'] = $request->order ?? 0;

            $faq->update($data);

            return response()->json([
                'success' => true,
                'message' => 'FAQ updated successfully!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], 422);
        }
    }

    public function destroy(Faq $faq)
    {
        $faq->delete();
        return redirect()->route('admin.faqs.index')
            ->with('success', 'FAQ deleted successfully!');
    }

    public function toggleStatus(Faq $faq)
    {
        $faq->update(['is_active' => !$faq->is_active]);
        return back()->with('success', 'FAQ status updated successfully!');
    }
}
