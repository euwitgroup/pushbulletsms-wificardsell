<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Transaction;
use App\Models\SmsHistory;
use Illuminate\Http\Request;
use App\Exports\TransactionsExport;
use Maatwebsite\Excel\Facades\Excel;
use PDF;

class DashboardController extends Controller
{
    public function index()
    {
        // Get statistics
        $stats = [
            'total_users' => User::where('role', 'user')->count(),
            'active_users' => User::where('role', 'user')->where('status', true)->count(),
            'total_sms_sent' => SmsHistory::where('status', 'sent')->count(),
            'total_sms_failed' => SmsHistory::where('status', 'failed')->count(),
            'total_sms_pending' => SmsHistory::where('status', 'pending')->count(),
            'total_revenue' => Transaction::where('type', 'credit')
                ->where('status', 'completed')
                ->sum('amount'),
            'today_sms' => SmsHistory::whereDate('created_at', today())->count(),
            'today_revenue' => Transaction::where('type', 'credit')
                ->where('status', 'completed')
                ->whereDate('created_at', today())
                ->sum('amount'),
        ];

        // Recent transactions
        $recent_transactions = Transaction::with('user')
            ->latest()
            ->take(10)
            ->get();

        // Recent SMS
        $recent_sms = SmsHistory::with('user')
            ->latest()
            ->take(10)
            ->get();
        
        // SMS stats by month for chart
        $monthly_sms = SmsHistory::selectRaw('DATE_FORMAT(created_at, "%Y-%m") as month, COUNT(*) as count')
            ->where('created_at', '>=', now()->subMonths(12))
            ->groupBy('month')
            ->orderBy('month')
            ->get();
        
        // Top users by SMS sent
        $top_users = SmsHistory::selectRaw('user_id, COUNT(*) as sms_count')
            ->groupBy('user_id')
            ->orderByDesc('sms_count')
            ->limit(5)
            ->with('user')
            ->get();

        return view('admin.dashboard', compact('stats', 'recent_transactions', 'recent_sms', 'monthly_sms', 'top_users'));
    }

    public function transactions(Request $request)
    {
        $query = Transaction::with('user')->latest();

        // Filter by type
        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Filter by date range
        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }
        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $transactions = $query->paginate(20);

        return view('admin.transactions', compact('transactions'));
    }

    public function exportTransactions(Request $request)
    {
        $query = Transaction::with('user')->latest();

        // Apply same filters as transactions list
        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }
        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $transactions = $query->get();
        $format = $request->get('format', 'excel');

        if ($format === 'excel') {
            return Excel::download(
                new TransactionsExport($transactions),
                'transactions_' . date('Y-m-d_H-i-s') . '.xlsx'
            );
        } elseif ($format === 'pdf') {
            $pdf = PDF::loadView('admin.exports.transactions-pdf', compact('transactions'));
            return $pdf->download('transactions_' . date('Y-m-d_H-i-s') . '.pdf');
        }

        return back()->with('error', 'Invalid export format');
    }

    public function smsHistory(Request $request)
    {
        $query = SmsHistory::with(['user', 'smsGateway'])->latest();
        
        // Filter by status if provided
        if ($request->has('status') && $request->status != '') {
            $query->where('status', $request->status);
        }
        
        $smsHistory = $query->paginate(20);
        
        // Get total counts for all statuses (for stat cards)
        $stats = [
            'sent' => SmsHistory::where('status', 'sent')->count(),
            'pending' => SmsHistory::where('status', 'pending')->count(),
            'failed' => SmsHistory::where('status', 'failed')->count(),
            'total' => SmsHistory::count(),
        ];

        return view('admin.sms-history', compact('smsHistory', 'stats'));
    }
}
