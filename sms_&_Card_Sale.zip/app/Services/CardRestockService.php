<?php

namespace App\Services;

use App\Models\CardKey;
use App\Models\CardTransaction;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CardRestockService
{
    /**
     * Release expired pending card keys back to available stock
     * 
     * @param int $minutes Number of minutes before a pending transaction is considered expired
     * @return int Number of cards released
     */
    public static function releaseExpiredPendingCards($minutes = 2)
    {
        $expirationTime = Carbon::now()->subMinutes($minutes);
        
        try {
            DB::beginTransaction();
            
            // Find all pending transactions older than specified minutes
            $expiredTransactions = CardTransaction::where('status', 'pending')
                ->where('created_at', '<=', $expirationTime)
                ->with('cardKey')
                ->get();
            
            $releasedCount = 0;
            
            foreach ($expiredTransactions as $transaction) {
                // Update transaction status to cancelled
                $transaction->update(['status' => 'cancelled']);
                
                // Release the card key back to available
                if ($transaction->cardKey && $transaction->cardKey->status === 'pending') {
                    $transaction->cardKey->update([
                        'status' => 'available',
                        'sold_at' => null,
                        'sold_to_user_id' => null,
                    ]);
                    
                    $releasedCount++;
                    
                    Log::info('Released expired pending card key', [
                        'transaction_id' => $transaction->transaction_id,
                        'card_key_id' => $transaction->cardKey->id,
                        'key_code' => $transaction->cardKey->key_code,
                        'expired_after_minutes' => $minutes,
                    ]);
                }
            }
            
            DB::commit();
            
            if ($releasedCount > 0) {
                Log::info("Released {$releasedCount} expired pending card keys");
            }
            
            return $releasedCount;
            
        } catch (\Exception $e) {
            DB::rollback();
            
            Log::error('Error releasing expired pending cards: ' . $e->getMessage(), [
                'exception' => $e,
            ]);
            
            return 0;
        }
    }
    
    /**
     * Check and release expired pending cards, then return statistics
     * 
     * @return array
     */
    public static function checkAndReleaseExpired()
    {
        $released = self::releaseExpiredPendingCards();
        
        return [
            'released' => $released,
            'message' => $released > 0 
                ? "{$released} expired pending card(s) released back to stock" 
                : null
        ];
    }
}

