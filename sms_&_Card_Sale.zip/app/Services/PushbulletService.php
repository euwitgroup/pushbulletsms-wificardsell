<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use App\Models\Setting;

class PushbulletService
{
    protected $apiKey;
    protected $baseUrl = 'https://api.pushbullet.com/v2';

    public function __construct()
    {
        $this->apiKey = Setting::get('pushbullet_api_key');
    }

    /**
     * Send SMS via Pushbullet (New API)
     * Docs: https://docs.pushbullet.com/#create-text
     */
    public function sendSms($phoneNumber, $message, $deviceIden = null)
    {
        if (!$this->apiKey) {
            throw new \Exception('Pushbullet API key not configured');
        }

        if (!$deviceIden) {
            $deviceIden = Setting::get('pushbullet_device_iden');
        }

        if (!$deviceIden) {
            throw new \Exception('Pushbullet device identifier not configured');
        }

        // New API format using /texts endpoint
        $payload = [
            'data' => [
                'addresses' => [$phoneNumber],
                'message' => $message,
                'target_device_iden' => $deviceIden
            ]
        ];

        try {
            $response = Http::withHeaders([
                'Access-Token' => $this->apiKey,
                'Content-Type' => 'application/json',
            ])->post($this->baseUrl . '/texts', $payload);

            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $response->json()
                ];
            }

            // Handle error response
            $errorData = $response->json();
            $errorMessage = $errorData['error']['message'] ?? 
                           $errorData['message'] ?? 
                           'Failed to send SMS';

            return [
                'success' => false,
                'error' => $errorMessage,
                'error_data' => $errorData
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Get devices
     */
    public function getDevices()
    {
        try {
            $response = Http::withHeaders([
                'Access-Token' => $this->apiKey,
            ])->get($this->baseUrl . '/devices');

            if ($response->successful()) {
                return [
                    'success' => true,
                    'devices' => $response->json()['devices']
                ];
            }

            return [
                'success' => false,
                'error' => 'Failed to fetch devices'
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Get current user info
     */
    public function getCurrentUser()
    {
        try {
            $response = Http::withHeaders([
                'Access-Token' => $this->apiKey,
            ])->get($this->baseUrl . '/users/me');

            if ($response->successful()) {
                return [
                    'success' => true,
                    'user' => $response->json()
                ];
            }

            return [
                'success' => false,
                'error' => 'Failed to fetch user info'
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
}
