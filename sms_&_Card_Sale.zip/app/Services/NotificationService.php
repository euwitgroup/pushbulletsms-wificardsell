<?php

namespace App\Services;

use App\Models\Notification;
use App\Models\User;
use App\Models\SmsTemplate;

class NotificationService
{
    protected $smsService;

    public function __construct(SmsService $smsService = null)
    {
        $this->smsService = $smsService ?? new SmsService();
    }

    /**
     * Create a notification
     */
    public function create($userId, $type, $title, $message, $data = [], $icon = null, $color = 'info', $link = null, $sendSms = false, $smsTemplateType = null)
    {
        $notification = Notification::create([
            'user_id' => $userId,
            'type' => $type,
            'title' => $title,
            'message' => $message,
            'data' => $data,
            'icon' => $icon,
            'color' => $color,
            'link' => $link,
            'send_sms' => $sendSms,
        ]);

        // Send SMS if requested
        if ($sendSms && $userId) {
            $this->sendNotificationSms($notification, $smsTemplateType);
        }

        return $notification;
    }

    /**
     * Send SMS notification using template
     */
    protected function sendNotificationSms($notification, $templateType = null)
    {
        try {
            $user = User::find($notification->user_id);
            
            if (!$user || !$user->phone) {
                $notification->update(['sms_error' => 'User phone number not found']);
                return false;
            }

            // Get SMS template
            $template = $templateType 
                ? SmsTemplate::getByType($templateType)
                : SmsTemplate::getByType($notification->type);

            if (!$template) {
                $notification->update(['sms_error' => 'SMS template not found']);
                return false;
            }

            // Prepare template variables
            $variables = array_merge(
                $notification->data ?? [],
                [
                    'user_name' => $user->name,
                    'company_name' => \App\Models\Setting::get('site_name', 'SMS & Card Sale'),
                ]
            );

            // Send SMS
            $sent = $this->smsService->sendWithTemplate($user->phone, $template->type, $variables);

            if ($sent) {
                $notification->update([
                    'sms_template_id' => $template->id,
                    'sms_sent' => true,
                    'sms_sent_at' => now(),
                ]);
            } else {
                $notification->update(['sms_error' => 'Failed to send SMS']);
            }

            return $sent;

        } catch (\Exception $e) {
            $notification->update(['sms_error' => $e->getMessage()]);
            \Log::error('Notification SMS error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Create admin notification (no specific user)
     */
    public function createAdminNotification($type, $title, $message, $data = [], $icon = null, $color = 'info', $link = null)
    {
        return $this->create(null, $type, $title, $message, $data, $icon, $color, $link);
    }

    /**
     * User Registration Notification
     */
    public function userRegistered(User $user, $sendWelcomeSms = true)
    {
        // Notification for admin
        $this->createAdminNotification(
            'registration',
            'New User Registration',
            "{$user->name} has registered on the platform.",
            ['user_id' => $user->id, 'email' => $user->email],
            'fa-user-plus',
            'success',
            route('admin.users.index')
        );

        // Welcome notification for user (with optional SMS)
        $this->create(
            $user->id,
            'welcome',
            'Welcome to ' . \App\Models\Setting::get('site_name', 'SMS & Card Sale'),
            'Thank you for registering! Start by purchasing SMS packages to send messages.',
            ['user_id' => $user->id, 'user_name' => $user->name],
            'fa-hand-wave',
            'success',
            route('user.payment.packages'),
            $sendWelcomeSms,
            'transactional'
        );
    }

    /**
     * Balance Deposit Notification
     */
    public function balanceDeposited($userId, $amount, $transactionId, $sendSms = true)
    {
        $user = User::find($userId);
        
        // Notification for user (with optional SMS)
        $this->create(
            $userId,
            'deposit',
            'Balance Added Successfully',
            "৳{$amount} has been added to your account. New balance: ৳" . number_format($user->balance, 2),
            [
                'amount' => $amount,
                'balance' => number_format($user->balance, 2),
                'transaction_id' => $transactionId
            ],
            'fa-wallet',
            'success',
            route('user.transactions'),
            $sendSms,
            'transactional'
        );

        // Notification for admin
        $this->createAdminNotification(
            'deposit',
            'New Balance Deposit',
            "{$user->name} deposited ৳{$amount}.",
            ['user_id' => $userId, 'amount' => $amount, 'transaction_id' => $transactionId],
            'fa-money-bill-wave',
            'info',
            route('admin.transactions')
        );
    }

    /**
     * Package Purchase Notification
     */
    public function packagePurchased($userId, $packageName, $amount, $smsCount, $sendSms = true)
    {
        $user = User::find($userId);
        
        // Notification for user (with optional SMS)
        $this->create(
            $userId,
            'purchase',
            'Package Purchased Successfully',
            "You've purchased {$packageName} for ৳{$amount}. {$smsCount} SMS credits added.",
            ['package_name' => $packageName, 'amount' => $amount, 'sms_count' => $smsCount],
            'fa-shopping-cart',
            'success',
            route('user.dashboard'),
            $sendSms,
            'transactional'
        );

        // Notification for admin
        $this->createAdminNotification(
            'purchase',
            'New Package Purchase',
            "{$user->name} purchased {$packageName} for ৳{$amount}.",
            ['user_id' => $userId, 'package_name' => $packageName, 'amount' => $amount],
            'fa-box',
            'info',
            route('admin.transactions')
        );
    }

    /**
     * SMS Sent Notification
     */
    public function smsSent($userId, $phone, $cost)
    {
        $this->create(
            $userId,
            'sms_sent',
            'SMS Sent Successfully',
            "SMS sent to {$phone}. Cost: ৳{$cost}",
            ['phone' => $phone, 'cost' => $cost],
            'fa-paper-plane',
            'success',
            route('user.sms.history')
        );
    }

    /**
     * Bulk SMS Completion Notification
     */
    public function bulkSmsSent($userId, $successCount, $failedCount, $totalCost)
    {
        $color = $failedCount > 0 ? 'warning' : 'success';
        $icon = $failedCount > 0 ? 'fa-exclamation-triangle' : 'fa-check-circle';
        
        $message = "Bulk SMS completed. Success: {$successCount}, Failed: {$failedCount}. Total Cost: ৳" . number_format($totalCost, 2);
        
        $this->create(
            $userId,
            'bulk_sms_sent',
            'Bulk SMS Completed',
            $message,
            [
                'success_count' => $successCount,
                'failed_count' => $failedCount,
                'total_cost' => $totalCost
            ],
            $icon,
            $color,
            route('user.sms.history')
        );
    }

    /**
     * Low Balance Alert
     */
    public function lowBalance($userId, $currentBalance)
    {
        $this->create(
            $userId,
            'low_balance',
            'Low Balance Alert',
            "Your balance is running low (৳{$currentBalance}). Please recharge to continue sending SMS.",
            ['balance' => $currentBalance],
            'fa-exclamation-triangle',
            'warning',
            route('user.payment.packages')
        );
    }

    /**
     * Account Status Changed
     */
    public function accountStatusChanged($userId, $status)
    {
        $statusText = $status ? 'activated' : 'deactivated';
        $color = $status ? 'success' : 'danger';
        
        $this->create(
            $userId,
            'account_status',
            'Account Status Changed',
            "Your account has been {$statusText}.",
            ['status' => $status],
            'fa-user-shield',
            $color,
            null
        );
    }

    /**
     * Transaction Failed
     */
    public function transactionFailed($userId, $amount, $reason)
    {
        $this->create(
            $userId,
            'transaction_failed',
            'Transaction Failed',
            "Transaction of ৳{$amount} failed. Reason: {$reason}",
            ['amount' => $amount, 'reason' => $reason],
            'fa-times-circle',
            'danger',
            route('user.transactions')
        );
    }

    /**
     * System Maintenance Notification
     */
    public function systemMaintenance($title, $message, $scheduledTime = null)
    {
        // Send to all users
        User::where('status', true)->chunk(100, function ($users) use ($title, $message, $scheduledTime) {
            foreach ($users as $user) {
                $this->create(
                    $user->id,
                    'maintenance',
                    $title,
                    $message,
                    ['scheduled_time' => $scheduledTime],
                    'fa-tools',
                    'warning',
                    null
                );
            }
        });

        // Admin notification
        $this->createAdminNotification(
            'maintenance',
            $title,
            $message,
            ['scheduled_time' => $scheduledTime],
            'fa-tools',
            'warning',
            null
        );
    }

    /**
     * Get unread count for user
     */
    public function getUnreadCount($userId)
    {
        return Notification::forUser($userId)->unread()->count();
    }

    /**
     * Get unread count for admin
     */
    public function getAdminUnreadCount()
    {
        return Notification::forAdmin()->unread()->count();
    }

    /**
     * Mark all as read for user
     */
    public function markAllAsRead($userId)
    {
        return Notification::forUser($userId)->unread()->update([
            'is_read' => true,
            'read_at' => now(),
        ]);
    }

    /**
     * Mark all as read for admin
     */
    public function markAllAdminAsRead()
    {
        return Notification::forAdmin()->unread()->update([
            'is_read' => true,
            'read_at' => now(),
        ]);
    }

    /**
     * Delete old read notifications
     */
    public function deleteOldNotifications($days = 30)
    {
        return Notification::read()
            ->where('read_at', '<', now()->subDays($days))
            ->delete();
    }
}

