<?php

namespace App\Services;

use App\Models\SmsGateway;
use App\Models\SmsTemplate;
use App\Models\Setting;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class SmsService
{
    protected $gateway;
    
    public function __construct()
    {
        // Get active gateway
        $this->gateway = SmsGateway::where('is_active', true)->first();
    }
    
    /**
     * Send SMS using template
     *
     * @param string $phone Phone number
     * @param string $templateType Template type (otp, transactional, promotional)
     * @param array $variables Variables to replace in template
     * @return bool
     */
    public function sendWithTemplate($phone, $templateType, $variables = [])
    {
        try {
            // Get template
            $template = SmsTemplate::getByType($templateType);
            
            if (!$template) {
                Log::error("SMS Template not found for type: {$templateType}");
                return false;
            }
            
            // Parse message with variables
            $message = $template->parseMessage($variables);
            
            // Send SMS
            return $this->send($phone, $message);
            
        } catch (\Exception $e) {
            Log::error('SMS sending error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Send SMS with custom message
     *
     * @param string $phone Phone number
     * @param string $message Message to send
     * @return bool
     */
    public function send($phone, $message)
    {
        try {
            if (!$this->gateway) {
                Log::error('No active SMS gateway configured');
                return false;
            }
            
            Log::info("Sending SMS via {$this->gateway->gateway_name} to {$phone}");
            
            // Send based on gateway type
            $gatewayName = strtolower($this->gateway->gateway_name);
            
            switch ($gatewayName) {
                case 'bulksmsbd':
                    return $this->sendViaBulkSMSBD($phone, $message);
                    
                case 'pushbullet':
                    return $this->sendViaPushbullet($phone, $message);
                    
                default:
                    Log::error("Unsupported gateway type: {$gatewayName}");
                    return false;
            }
            
        } catch (\Exception $e) {
            Log::error('SMS sending error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Send SMS with specific gateway
     *
     * @param string $phone Phone number
     * @param string $message Message to send
     * @param SmsGateway $gateway Gateway to use
     * @return bool
     */
    public function sendWithGateway($phone, $message, SmsGateway $gateway)
    {
        try {
            if (!$gateway) {
                Log::error('No SMS gateway provided');
                return false;
            }
            
            Log::info("Sending SMS via {$gateway->gateway_name} to {$phone}");
            
            // Send based on gateway type
            $gatewayName = strtolower($gateway->gateway_name);
            
            switch ($gatewayName) {
                case 'bulksmsbd':
                    return $this->sendViaBulkSMSBDWithGateway($phone, $message, $gateway);
                    
                case 'pushbullet':
                    return $this->sendViaPushbulletWithGateway($phone, $message, $gateway);
                    
                default:
                    Log::error("Unsupported gateway type: {$gatewayName}");
                    return false;
            }
            
        } catch (\Exception $e) {
            Log::error('SMS sending error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Send OTP SMS
     *
     * @param string $phone Phone number
     * @param string $otp OTP code
     * @return bool
     */
    public function sendOtp($phone, $otp)
    {
        $variables = [
            'company_name' => Setting::get('site_name', 'SMS & Card Sale'),
            'otp_code' => $otp,
            'otp' => $otp,
            'expiry_minutes' => Setting::get('otp_expiry_minutes', '5'),
        ];
        
        return $this->sendWithTemplate($phone, 'otp', $variables);
    }
    
    /**
     * Send welcome message
     *
     * @param string $phone Phone number
     * @param string $userName User name
     * @return bool
     */
    public function sendWelcome($phone, $userName)
    {
        $variables = [
            'company_name' => Setting::get('site_name', 'SMS & Card Sale'),
            'user_name' => $userName,
            'name' => $userName,
        ];
        
        return $this->sendWithTemplate($phone, 'transactional', $variables);
    }
    
    /**
     * Send package purchase confirmation
     *
     * @param string $phone Phone number
     * @param array $data Package data
     * @return bool
     */
    public function sendPackagePurchase($phone, $data)
    {
        $variables = [
            'company_name' => Setting::get('site_name', 'SMS & Card Sale'),
            'package_name' => $data['package_name'] ?? '',
            'amount' => $data['amount'] ?? '',
            'sms_count' => $data['sms_count'] ?? '',
        ];
        
        return $this->sendWithTemplate($phone, 'transactional', $variables);
    }
    
    /**
     * Send via BulkSMSBD gateway
     */
    protected function sendViaBulkSMSBD($phone, $message)
    {
        try {
            $apiUrl = $this->gateway->api_url ?? 'http://bulksmsbd.net/api/smsapi';
            
            Log::info('BulkSMSBD API Request', [
                'url' => $apiUrl,
                'phone' => $phone,
                'sender_id' => $this->gateway->sender_id,
                'message_length' => strlen($message)
            ]);
            
            $response = Http::timeout(30)->get($apiUrl, [
                'api_key' => $this->gateway->api_key,
                'senderid' => $this->gateway->sender_id,
                'message' => $message,
                'number' => $phone,
                'type' => $this->gateway->message_type ?? 'text'
            ]);
            
            Log::info('BulkSMSBD Response: ' . $response->body());
            
            if ($response->successful()) {
                $data = $response->json();
                
                // Check for various success indicators
                if (
                    (isset($data['status_code']) && $data['status_code'] == 200) ||
                    (isset($data['response_code']) && $data['response_code'] == 202) ||
                    (isset($data['success']) && $data['success'] == true) ||
                    (isset($data['status']) && strtolower($data['status']) == 'success')
                ) {
                    Log::info("SMS sent successfully to {$phone}");
                    return true;
                }
                
                Log::error('BulkSMSBD API error: ' . json_encode($data));
                return false;
            }
            
            Log::error("BulkSMSBD HTTP error: {$response->status()} - {$response->body()}");
            return false;
            
        } catch (\Exception $e) {
            Log::error('BulkSMSBD sending error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Send via Pushbullet gateway (Actual SMS via Android device)
     */
    protected function sendViaPushbullet($phone, $message)
    {
        try {
            // Clean phone number (remove spaces, dashes, etc.)
            $cleanPhone = preg_replace('/[^0-9+]/', '', $phone);
            
            Log::info('Pushbullet SMS Request', [
                'phone' => $cleanPhone,
                'device_iden' => $this->gateway->device_id,
                'message_length' => strlen($message)
            ]);
            
            // Use /v2/texts endpoint to send actual SMS
            $response = Http::withHeaders([
                'Access-Token' => $this->gateway->api_key,
                'Content-Type' => 'application/json'
            ])->post('https://api.pushbullet.com/v2/texts', [
                'data' => [
                    'target_device_iden' => $this->gateway->device_id,
                    'addresses' => [$cleanPhone],
                    'message' => $message
                ]
            ]);
            
            Log::info('Pushbullet Response: ' . $response->body());
            
            if ($response->successful()) {
                Log::info("SMS sent via Pushbullet to {$cleanPhone} through device {$this->gateway->device_name}");
                return true;
            }
            
            Log::error('Pushbullet API error: ' . $response->body());
            return false;
            
        } catch (\Exception $e) {
            Log::error('Pushbullet sending error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Send via BulkSMSBD gateway with specific gateway instance
     */
    protected function sendViaBulkSMSBDWithGateway($phone, $message, $gateway)
    {
        try {
            $apiUrl = $gateway->api_url ?? 'http://bulksmsbd.net/api/smsapi';
            
            Log::info('BulkSMSBD API Request', [
                'url' => $apiUrl,
                'phone' => $phone,
                'sender_id' => $gateway->sender_id,
                'message_length' => strlen($message)
            ]);
            
            $response = Http::timeout(30)->get($apiUrl, [
                'api_key' => $gateway->api_key,
                'senderid' => $gateway->sender_id,
                'message' => $message,
                'number' => $phone,
                'type' => $gateway->message_type ?? 'text'
            ]);
            
            Log::info('BulkSMSBD Response: ' . $response->body());
            
            if ($response->successful()) {
                $data = $response->json();
                
                // Check for various success indicators
                if (
                    (isset($data['status_code']) && $data['status_code'] == 200) ||
                    (isset($data['response_code']) && $data['response_code'] == 202) ||
                    (isset($data['success']) && $data['success'] == true) ||
                    (isset($data['status']) && strtolower($data['status']) == 'success')
                ) {
                    Log::info("SMS sent successfully to {$phone}");
                    return true;
                }
                
                Log::error('BulkSMSBD API error: ' . json_encode($data));
                return false;
            }
            
            Log::error("BulkSMSBD HTTP error: {$response->status()} - {$response->body()}");
            return false;
            
        } catch (\Exception $e) {
            Log::error('BulkSMSBD sending error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Send via Pushbullet gateway with specific gateway instance (Actual SMS)
     */
    protected function sendViaPushbulletWithGateway($phone, $message, $gateway)
    {
        try {
            // Clean phone number (remove spaces, dashes, etc.)
            $cleanPhone = preg_replace('/[^0-9+]/', '', $phone);
            
            Log::info('Pushbullet SMS Request', [
                'phone' => $cleanPhone,
                'device_iden' => $gateway->device_id,
                'message_length' => strlen($message)
            ]);
            
            // Use /v2/texts endpoint to send actual SMS
            $response = Http::withHeaders([
                'Access-Token' => $gateway->api_key,
                'Content-Type' => 'application/json'
            ])->post('https://api.pushbullet.com/v2/texts', [
                'data' => [
                    'target_device_iden' => $gateway->device_id,
                    'addresses' => [$cleanPhone],
                    'message' => $message
                ]
            ]);
            
            Log::info('Pushbullet Response: ' . $response->body());
            
            if ($response->successful()) {
                Log::info("SMS sent via Pushbullet to {$cleanPhone} through device {$gateway->device_name}");
                return true;
            }
            
            Log::error('Pushbullet API error: ' . $response->body());
            return false;
            
        } catch (\Exception $e) {
            Log::error('Pushbullet sending error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get active gateway
     */
    public function getGateway()
    {
        return $this->gateway;
    }
    
    /**
     * Check if gateway is configured
     */
    public function isConfigured()
    {
        return !is_null($this->gateway) && !empty($this->gateway->api_key);
    }
}

