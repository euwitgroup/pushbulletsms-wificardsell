<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use App\Models\Setting;

class GuestRupantorPayService
{
    protected $apiKey;
    protected $baseUrl = 'https://payment.rupantorpay.com/api';

    public function __construct()
    {
        $this->apiKey = Setting::get('rupantorpay_api_key');
    }

    /**
     * Create payment checkout for guest WiFi card purchase
     */
    public function createPayment($amount, $metadata = [])
    {
        if (!$this->apiKey) {
            throw new \Exception('RupantorPay API key not configured');
        }

        // Include transaction_id in URLs as query parameter for easier retrieval
        $transactionId = $metadata['transaction_id'] ?? null;
        $successUrl = route('wifi-cards.payment.success');
        $cancelUrl = route('wifi-cards.payment.cancel');
        
        if ($transactionId) {
            $successUrl .= '?transaction_id=' . $transactionId;
            $cancelUrl .= '?transaction_id=' . $transactionId;
        }

        $payload = [
            'success_url' => $successUrl,
            'cancel_url' => $cancelUrl,
            'webhook_url' => route('wifi-cards.payment.webhook'),
            'metadata' => $metadata,
            'amount' => (string) $amount
        ];

        try {
            $response = Http::withHeaders([
                'X-API-KEY' => $this->apiKey,
                'Content-Type' => 'application/json',
                'X-CLIENT' => request()->getHost()
            ])->post($this->baseUrl . '/payment/checkout', $payload);

            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $response->json()
                ];
            }

            return [
                'success' => false,
                'error' => $response->json()['message'] ?? 'Payment creation failed'
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Verify payment
     */
    public function verifyPayment($transactionId)
    {
        try {
            $response = Http::withHeaders([
                'X-API-KEY' => $this->apiKey,
                'Content-Type' => 'application/json',
            ])->get($this->baseUrl . '/payment/verify/' . $transactionId);

            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $response->json()
                ];
            }

            return [
                'success' => false,
                'error' => $response->json()['message'] ?? 'Payment verification failed'
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
}

