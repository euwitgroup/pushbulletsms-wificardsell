<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use App\Models\Setting;

class RupantorPayService
{
    protected $apiKey;
    protected $baseUrl = 'https://payment.rupantorpay.com/api';

    public function __construct()
    {
        $this->apiKey = Setting::get('rupantorpay_api_key');
    }

    /**
     * Create payment checkout
     */
    public function createPayment($amount, $metadata = [])
    {
        if (!$this->apiKey) {
            throw new \Exception('RupantorPay API key not configured');
        }

        $payload = [
            'success_url' => route('payment.success'),
            'cancel_url' => route('payment.cancel'),
            'webhook_url' => route('payment.webhook'),
            'metadata' => $metadata,
            'amount' => (string) $amount
        ];

        try {
            $response = Http::withHeaders([
                'X-API-KEY' => $this->apiKey,
                'Content-Type' => 'application/json',
                'X-CLIENT' => request()->getHost()
            ])->post($this->baseUrl . '/payment/checkout', $payload);

            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $response->json()
                ];
            }

            return [
                'success' => false,
                'error' => $response->json()['message'] ?? 'Payment creation failed'
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Verify payment
     */
    public function verifyPayment($transactionId)
    {
        try {
            $response = Http::withHeaders([
                'X-API-KEY' => $this->apiKey,
                'Content-Type' => 'application/json',
            ])->get($this->baseUrl . '/payment/verify/' . $transactionId);

            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $response->json()
                ];
            }

            return [
                'success' => false,
                'error' => 'Payment verification failed'
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
}
