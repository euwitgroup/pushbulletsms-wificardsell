@extends('layouts.frontend')

@section('title', 'WiFi Cards - ' . config('app.name'))

@section('content')

<!-- Hero Section -->
<section class="wifi-hero-section">
    <div class="container">
        <div class="hero-content">
            <h1 class="hero-title">
                <i class="fas fa-wifi"></i>
                WiFi Internet Cards
            </h1>
            <p class="hero-subtitle">Choose your perfect internet card from our collection. Fast, reliable, and affordable WiFi access.</p>
            
            <!-- Category Filter Buttons -->
            @if($categories->count() > 0)
            <div class="category-filters">
                <a href="{{ route('wifi-cards.index') }}" class="category-btn {{ !$selectedCategory ? 'active' : '' }}">
                    <i class="fas fa-th-large"></i>
                    All Cards
                </a>
                @foreach($categories as $category)
                <a href="{{ route('wifi-cards.index', ['category' => $category->id]) }}" class="category-btn {{ $selectedCategory == $category->id ? 'active' : '' }}">
                    <i class="fas fa-folder"></i>
                    {{ $category->name }}
                </a>
                @endforeach
            </div>
            @endif
        </div>
    </div>
</section>

<!-- Cards Display Section -->
<section class="wifi-cards-section">
    <div class="container">
        @if($cardTypes->count() > 0)
            <div class="cards-grid">
                @foreach($cardTypes as $cardType)
                    <x-wifi-card-item :cardType="$cardType" />
                @endforeach
            </div>
        @else
            <div class="empty-state">
                <i class="fas fa-wifi"></i>
                <h3>No Cards Available</h3>
                <p>{{ $selectedCategory ? 'No cards available in this category at the moment.' : 'No WiFi cards available at the moment. Please check back later.' }}</p>
                @if($selectedCategory)
                <a href="{{ route('wifi-cards.index') }}" class="btn-primary">
                    <i class="fas fa-arrow-left"></i>
                    View All Cards
                </a>
                @endif
            </div>
        @endif
    </div>
</section>

@endsection

@push('styles')
<style>
    .wifi-hero-section {
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        padding: 80px 0 60px;
        text-align: center;
        position: relative;
        overflow: hidden;
    }

    .wifi-hero-section::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="rgba(255,255,255,0.1)" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,138.7C960,139,1056,117,1152,101.3C1248,85,1344,75,1392,69.3L1440,64L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>') no-repeat bottom;
        opacity: 0.3;
    }

    .hero-content {
        position: relative;
        z-index: 1;
    }

    .hero-title {
        font-size: 3rem;
        font-weight: 700;
        color: #fff;
        margin-bottom: 1rem;
        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .hero-title i {
        margin-right: 15px;
        animation: pulse 2s ease-in-out infinite;
    }

    @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.1); }
    }

    .hero-subtitle {
        font-size: 1.25rem;
        color: rgba(255, 255, 255, 0.95);
        margin-bottom: 2.5rem;
        max-width: 600px;
        margin-left: auto;
        margin-right: auto;
    }

    .category-filters {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 12px;
        margin-top: 30px;
    }

    .category-btn {
        padding: 12px 24px;
        background: rgba(255, 255, 255, 0.2);
        color: #fff;
        border: 2px solid rgba(255, 255, 255, 0.3);
        border-radius: 50px;
        font-weight: 600;
        text-decoration: none;
        transition: all 0.3s ease;
        backdrop-filter: blur(10px);
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }

    .category-btn:hover {
        background: rgba(255, 255, 255, 0.3);
        border-color: rgba(255, 255, 255, 0.5);
        transform: translateY(-2px);
        color: #fff;
    }

    .category-btn.active {
        background: #fff;
        color: var(--primary-color);
        border-color: #fff;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }

    .wifi-cards-section {
        padding: 60px 0;
        background: #f8f9fa;
    }

    .cards-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 130px;
    }

    /* WiFi Card Box Component Styles - Matching Image Design */
    .wifi-card-box {
        background: #fff;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
        transition: all 0.3s ease;
        display: flex;
        flex-direction: row;
        height: 60px;
        border: 1px solid #e0e0e0;
    }

    .wifi-card-box:hover {
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
        transform: translateY(-2px);
    }

    .card-image-section {
        position: relative;
        width: 55%;
        flex-shrink: 0;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        border-right: 1px solid #e0e0e0;
    }

    .card-image-section img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        object-position: center;
        padding: 5px;
    }

    .no-image-placeholder {
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: rgba(255, 255, 255, 0.7);
        font-size: 2rem;
    }

    .stock-indicator {
        position: absolute;
        top: 6px;
        right: 6px;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.7rem;
        z-index: 2;
    }

    .stock-indicator.out-of-stock {
        background: #ef4444;
        color: #fff;
    }

    .card-content-section {
        flex: 1;
        padding: 0 15px 0 18px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 15px;
    }

    .card-details-info {
        flex: 1;
        display: flex;
        flex-direction: column;
        gap: 3px;
    }

    .card-category {
        font-size: 0.85rem;
        font-weight: 600;
        color: #1f2937;
        line-height: 1.2;
    }

    .card-validity {
        font-size: 0.75rem;
        font-weight: 500;
        color: #6b7280;
        line-height: 1.2;
    }

    .card-price-section {
        flex: 0 0 auto;
        margin-left: auto;
    }

    .price-amount {
        font-size: 1.1rem;
        font-weight: 700;
        color: #000;
        display: block;
        line-height: 1;
        white-space: nowrap;
    }

    .card-button-section {
        flex: 0 0 auto;
    }

    .btn-buy-now {
        padding: 5px 16px;
        background: #fbbf24;
        color: #000;
        border: none;
        border-radius: 5px;
        font-weight: 700;
        font-size: 0.8rem;
        cursor: pointer;
        transition: all 0.3s ease;
        text-decoration: none;
        display: inline-block;
        white-space: nowrap;
    }

    .btn-buy-now:hover:not(.disabled) {
        background: #f59e0b;
        transform: scale(1.05);
        color: #000;
    }

    .btn-buy-now.disabled {
        background: #9ca3af;
        color: #fff;
        cursor: not-allowed;
        opacity: 0.7;
    }

    .empty-state {
        text-align: center;
        padding: 80px 20px;
    }

    .empty-state i {
        font-size: 5rem;
        color: #d1d5db;
        margin-bottom: 20px;
    }

    .empty-state h3 {
        font-size: 1.75rem;
        color: #374151;
        margin-bottom: 10px;
    }

    .empty-state p {
        font-size: 1.1rem;
        color: #6b7280;
        margin-bottom: 30px;
        max-width: 500px;
        margin-left: auto;
        margin-right: auto;
    }

    .btn-primary {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        padding: 12px 30px;
        background: var(--primary-color);
        color: #fff;
        border-radius: 8px;
        text-decoration: none;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .btn-primary:hover {
        background: var(--secondary-color);
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        color: #fff;
    }

    /* Responsive Design */
    @media (max-width: 1024px) {
        .cards-grid {
            gap: 20px;
        }

        .wifi-card-box {
            height: 55px;
        }

        .card-content-section {
            padding: 0 12px 0 15px;
            gap: 12px;
        }

        .card-category {
            font-size: 0.8rem;
        }

        .card-validity {
            font-size: 0.7rem;
        }

        .price-amount {
            font-size: 1rem;
        }

        .btn-buy-now {
            padding: 4px 12px;
            font-size: 0.75rem;
        }
    }

    @media (max-width: 768px) {
        .hero-title {
            font-size: 2rem;
        }

        .hero-subtitle {
            font-size: 1rem;
        }

        .cards-grid {
            grid-template-columns: 1fr;
            gap: 15px;
        }

        .wifi-card-box {
            height: 60px;
        }
    }

    @media (max-width: 576px) {
        .category-btn {
            font-size: 0.85rem;
            padding: 10px 18px;
        }

        .wifi-card-box {
            height: 55px;
        }

        .card-image-section {
            width: 50%;
        }

        .card-content-section {
            padding: 0 10px;
            gap: 8px;
        }

        .card-category {
            font-size: 0.75rem;
        }

        .card-validity {
            font-size: 0.65rem;
        }

        .price-amount {
            font-size: 0.95rem;
        }

        .btn-buy-now {
            padding: 4px 10px;
            font-size: 0.7rem;
        }
    }
</style>
@endpush

@push('scripts')
<script>
    // Show success or error messages
    @if(session('success'))
        Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: '{{ session('success') }}',
            timer: 3000,
            showConfirmButton: false
        });
    @endif

    @if(session('error'))
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: '{{ session('error') }}',
        });
    @endif
</script>
@endpush

