@extends('layouts.frontend')

@section('title', 'Purchase Successful!')

@section('content')

<!-- Success Section -->
<section class="success-section">
    <div class="container">
        <div class="success-content">
            <!-- Success Icon -->
            <div class="success-icon">
                <div class="checkmark-circle">
                    <i class="fas fa-check"></i>
                </div>
            </div>

            <!-- Success Message -->
            <h1 class="success-title">Payment Successful!</h1>
            <p class="success-subtitle">Thank you for your purchase. Your WiFi card is ready to use.</p>

            <!-- Card Key Display -->
            <div class="card-key-display">
                <div class="key-header">
                    <i class="fas fa-key"></i>
                    <h3>Your WiFi Card Key</h3>
                </div>
                <div class="key-code">
                    <span id="cardKey">{{ $transaction->cardKey->key_code }}</span>
                    <button type="button" class="btn-copy" onclick="copyCardKey()" title="Copy to clipboard">
                        <i class="fas fa-copy"></i>
                    </button>
                </div>
                <p class="key-note">
                    <i class="fas fa-info-circle"></i>
                    This card key has also been sent to your phone via SMS
                </p>
            </div>

            <!-- Transaction Details -->
            <div class="transaction-details">
                <h3><i class="fas fa-receipt"></i> Transaction Details</h3>
                
                <div class="detail-grid">
                    <div class="detail-item">
                        <span class="label">Transaction ID</span>
                        <span class="value">{{ $transaction->transaction_id }}</span>
                    </div>
                    
                    <div class="detail-item">
                        <span class="label">Card Type</span>
                        <span class="value">{{ $transaction->cardType->name }}</span>
                    </div>
                    
                    <div class="detail-item">
                        <span class="label">Category</span>
                        <span class="value">{{ $transaction->cardType->cardCategory->name }}</span>
                    </div>
                    
                    <div class="detail-item">
                        <span class="label">Validity</span>
                        <span class="value">
                            {{ $transaction->cardType->validity_value }}
                            {{ $transaction->cardType->validity_type === 'hours' ? 'Hours' : 'Days' }}
                        </span>
                    </div>
                    
                    <div class="detail-item">
                        <span class="label">Amount Paid</span>
                        <span class="value amount">৳{{ number_format($transaction->amount, 2) }}</span>
                    </div>
                    
                    <div class="detail-item">
                        <span class="label">Payment Method</span>
                        <span class="value">{{ $transaction->payment_method }}</span>
                    </div>
                    
                    <div class="detail-item">
                        <span class="label">Customer Name</span>
                        <span class="value">{{ $transaction->customer_name }}</span>
                    </div>
                    
                    <div class="detail-item">
                        <span class="label">Phone Number</span>
                        <span class="value">{{ $transaction->customer_phone }}</span>
                    </div>
                    
                    <div class="detail-item">
                        <span class="label">Purchase Date</span>
                        <span class="value">{{ $transaction->purchased_at->format('d M Y, h:i A') }}</span>
                    </div>
                    
                    <div class="detail-item">
                        <span class="label">Status</span>
                        <span class="value">
                            <span class="status-badge success">
                                <i class="fas fa-check-circle"></i>
                                Completed
                            </span>
                        </span>
                    </div>
                </div>
            </div>

            <!-- How to Use -->
            <div class="how-to-use">
                <h3><i class="fas fa-question-circle"></i> How to Use Your WiFi Card</h3>
                <ol>
                    <li>
                        <i class="fas fa-wifi"></i>
                        <span>Connect to the WiFi network</span>
                    </li>
                    <li>
                        <i class="fas fa-browser"></i>
                        <span>Open your web browser</span>
                    </li>
                    <li>
                        <i class="fas fa-key"></i>
                        <span>Enter your card key when prompted</span>
                    </li>
                    <li>
                        <i class="fas fa-globe"></i>
                        <span>Start browsing the internet!</span>
                    </li>
                </ol>
            </div>

            <!-- Action Buttons -->
            <div class="action-buttons">
                <a href="{{ route('wifi-cards.index') }}" class="btn-secondary">
                    <i class="fas fa-shopping-cart"></i>
                    Buy Another Card
                </a>
                <a href="{{ route('home') }}" class="btn-primary">
                    <i class="fas fa-home"></i>
                    Go to Home
                </a>
            </div>

            <!-- Support Info -->
            <div class="support-info">
                <p>
                    <i class="fas fa-headset"></i>
                    Need help? Contact our support team at 
                    <a href="{{ route('contact') }}">Contact Us</a>
                </p>
            </div>
        </div>
    </div>
</section>

@endsection

@push('styles')
<style>
    .success-section {
        padding: 60px 0;
        background: linear-gradient(135deg, #f0fdf4 0%, #e0f2fe 100%);
        min-height: calc(100vh - 200px);
    }

    .success-content {
        max-width: 800px;
        margin: 0 auto;
    }

    .success-icon {
        text-align: center;
        margin-bottom: 30px;
    }

    .checkmark-circle {
        width: 120px;
        height: 120px;
        background: linear-gradient(135deg, #10b981, #059669);
        border-radius: 50%;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        animation: scaleIn 0.5s ease-out;
        box-shadow: 0 8px 24px rgba(16, 185, 129, 0.3);
    }

    .checkmark-circle i {
        font-size: 4rem;
        color: #fff;
    }

    @keyframes scaleIn {
        0% {
            transform: scale(0);
            opacity: 0;
        }
        50% {
            transform: scale(1.1);
        }
        100% {
            transform: scale(1);
            opacity: 1;
        }
    }

    .success-title {
        font-size: 2.5rem;
        color: #1f2937;
        text-align: center;
        margin: 20px 0 10px;
        font-weight: 700;
    }

    .success-subtitle {
        font-size: 1.1rem;
        color: #6b7280;
        text-align: center;
        margin-bottom: 40px;
    }

    .card-key-display {
        background: #fff;
        border-radius: 16px;
        padding: 30px;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
        margin-bottom: 30px;
        border: 3px solid #10b981;
    }

    .key-header {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
        margin-bottom: 20px;
    }

    .key-header i {
        font-size: 1.5rem;
        color: var(--primary-color);
    }

    .key-header h3 {
        font-size: 1.5rem;
        color: #1f2937;
        margin: 0;
    }

    .key-code {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 15px;
        padding: 20px;
        background: #f9fafb;
        border-radius: 12px;
        border: 2px dashed #d1d5db;
        margin-bottom: 15px;
    }

    .key-code span {
        font-size: 2rem;
        font-weight: 700;
        color: var(--primary-color);
        font-family: 'Courier New', monospace;
        letter-spacing: 2px;
    }

    .btn-copy {
        padding: 12px 16px;
        background: var(--primary-color);
        color: #fff;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s ease;
        font-size: 1.1rem;
    }

    .btn-copy:hover {
        background: var(--secondary-color);
        transform: scale(1.1);
    }

    .key-note {
        text-align: center;
        font-size: 0.9rem;
        color: #059669;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        margin: 0;
    }

    .key-note i {
        font-size: 1.1rem;
    }

    .transaction-details,
    .how-to-use {
        background: #fff;
        border-radius: 16px;
        padding: 30px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        margin-bottom: 30px;
    }

    .transaction-details h3,
    .how-to-use h3 {
        font-size: 1.5rem;
        color: #1f2937;
        margin: 0 0 25px 0;
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .transaction-details h3 i,
    .how-to-use h3 i {
        color: var(--primary-color);
    }

    .detail-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
    }

    .detail-item {
        display: flex;
        flex-direction: column;
        gap: 5px;
    }

    .detail-item .label {
        font-size: 0.85rem;
        color: #6b7280;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .detail-item .value {
        font-size: 1rem;
        color: #1f2937;
        font-weight: 600;
    }

    .detail-item .value.amount {
        font-size: 1.25rem;
        color: var(--primary-color);
    }

    .status-badge {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
    }

    .status-badge.success {
        background: #d1fae5;
        color: #065f46;
    }

    .how-to-use ol {
        list-style: none;
        padding: 0;
        margin: 0;
        counter-reset: step-counter;
    }

    .how-to-use li {
        display: flex;
        align-items: center;
        gap: 15px;
        padding: 15px;
        background: #f9fafb;
        border-radius: 12px;
        margin-bottom: 12px;
        counter-increment: step-counter;
        position: relative;
        padding-left: 60px;
    }

    .how-to-use li::before {
        content: counter(step-counter);
        position: absolute;
        left: 15px;
        width: 35px;
        height: 35px;
        background: var(--primary-color);
        color: #fff;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 1.1rem;
    }

    .how-to-use li i {
        color: var(--primary-color);
        font-size: 1.25rem;
    }

    .how-to-use li span {
        font-size: 1rem;
        color: #374151;
        font-weight: 500;
    }

    .action-buttons {
        display: flex;
        gap: 15px;
        justify-content: center;
        margin-bottom: 30px;
    }

    .btn-primary,
    .btn-secondary {
        padding: 14px 28px;
        border-radius: 8px;
        font-size: 1rem;
        font-weight: 600;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 10px;
        transition: all 0.3s ease;
        cursor: pointer;
    }

    .btn-primary {
        background: var(--primary-color);
        color: #fff;
        border: 2px solid var(--primary-color);
    }

    .btn-primary:hover {
        background: var(--secondary-color);
        border-color: var(--secondary-color);
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        color: #fff;
    }

    .btn-secondary {
        background: #fff;
        color: var(--primary-color);
        border: 2px solid var(--primary-color);
    }

    .btn-secondary:hover {
        background: var(--primary-color);
        color: #fff;
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
    }

    .support-info {
        text-align: center;
        padding: 20px;
        background: #f0f9ff;
        border-radius: 12px;
        border: 1px solid #bae6fd;
    }

    .support-info p {
        margin: 0;
        font-size: 0.95rem;
        color: #1e40af;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        flex-wrap: wrap;
    }

    .support-info i {
        font-size: 1.2rem;
    }

    .support-info a {
        color: var(--primary-color);
        text-decoration: none;
        font-weight: 700;
    }

    .support-info a:hover {
        text-decoration: underline;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
        .success-title {
            font-size: 2rem;
        }

        .detail-grid {
            grid-template-columns: 1fr;
        }

        .key-code span {
            font-size: 1.5rem;
        }

        .action-buttons {
            flex-direction: column;
        }

        .btn-primary,
        .btn-secondary {
            width: 100%;
            justify-content: center;
        }
    }
</style>
@endpush

@push('scripts')
<script>
    // Copy card key to clipboard
    function copyCardKey() {
        const cardKey = document.getElementById('cardKey').textContent;
        
        navigator.clipboard.writeText(cardKey).then(function() {
            Swal.fire({
                icon: 'success',
                title: 'Copied!',
                text: 'Card key copied to clipboard',
                timer: 2000,
                showConfirmButton: false
            });
        }, function(err) {
            Swal.fire({
                icon: 'error',
                title: 'Copy Failed',
                text: 'Could not copy to clipboard',
            });
        });
    }

    // Celebrate success with confetti effect
    window.addEventListener('load', function() {
        Swal.fire({
            icon: 'success',
            title: 'Purchase Successful!',
            text: 'Your WiFi card key has been sent to your phone via SMS',
            timer: 3000,
            showConfirmButton: false
        });
    });
</script>
@endpush

