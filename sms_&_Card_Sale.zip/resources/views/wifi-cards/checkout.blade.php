@extends('layouts.frontend')

@section('title', 'Checkout - ' . $cardType->name)

@section('content')

<!-- Checkout Section -->
<section class="checkout-section">
    <div class="container">
        <div class="checkout-header">
            <a href="{{ route('wifi-cards.index') }}" class="back-link">
                <i class="fas fa-arrow-left"></i>
                Back to Cards
            </a>
            <h1>Checkout</h1>
        </div>

        <div class="checkout-content">
            <!-- Order Summary -->
            <div class="order-summary">
                <h3><i class="fas fa-shopping-cart"></i> Order Summary</h3>
                
                <div class="product-info">
                    <div class="product-image">
                        @if($cardType->image)
                            <img src="{{ Storage::url($cardType->image) }}" alt="{{ $cardType->name }}">
                        @else
                            <div class="no-image">
                                <i class="fas fa-wifi"></i>
                            </div>
                        @endif
                    </div>
                    
                    <div class="product-details">
                        <span class="product-category">
                            <i class="fas fa-tag"></i>
                            {{ $cardType->cardCategory->name }}
                        </span>
                        <h4>{{ $cardType->name }}</h4>
                        @if($cardType->description)
                        <p>{{ $cardType->description }}</p>
                        @endif
                        
                        <div class="product-features">
                            <div class="feature">
                                <i class="fas fa-clock"></i>
                                <span>
                                    {{ $cardType->validity_value }} 
                                    {{ $cardType->validity_type === 'hours' ? 'Hours' : 'Days' }}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="price-breakdown">
                    <div class="price-row">
                        <span>Card Price</span>
                        <span class="amount">৳{{ number_format($cardType->price, 2) }}</span>
                    </div>
                    <div class="price-row">
                        <span>Gateway Fee ({{ $gatewayFeePercentage }}%)</span>
                        <span class="amount">৳{{ number_format($gatewayFee, 2) }}</span>
                    </div>
                    <div class="price-row total">
                        <span>Total Amount</span>
                        <span class="amount">৳{{ number_format($totalAmount, 2) }}</span>
                    </div>
                </div>

                <div class="secure-payment">
                    <i class="fas fa-lock"></i>
                    <span>Secure Payment with RupantorPay</span>
                </div>
            </div>

            <!-- Customer Details Form -->
            <div class="customer-form">
                <h3><i class="fas fa-user"></i> Customer Details</h3>
                
                <form action="{{ route('wifi-cards.process-payment', $cardType->id) }}" method="POST" id="checkoutForm">
                    @csrf
                    
                    <div class="form-group">
                        <label for="customer_name">
                            Full Name <span class="required">*</span>
                        </label>
                        <input type="text" 
                               id="customer_name" 
                               name="customer_name" 
                               class="form-control @error('customer_name') is-invalid @enderror" 
                               value="{{ old('customer_name') }}" 
                               placeholder="Enter your full name"
                               required>
                        @error('customer_name')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="form-group">
                        <label for="customer_phone">
                            Phone Number <span class="required">*</span>
                        </label>
                        <input type="tel" 
                               id="customer_phone" 
                               name="customer_phone" 
                               class="form-control @error('customer_phone') is-invalid @enderror" 
                               value="{{ old('customer_phone') }}" 
                               placeholder="e.g., 01712345678"
                               required>
                        @error('customer_phone')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                        <small class="form-text">Your WiFi card key will be sent to this number via SMS</small>
                    </div>

                    <div class="form-group">
                        <label for="customer_email">
                            Email Address (Optional)
                        </label>
                        <input type="email" 
                               id="customer_email" 
                               name="customer_email" 
                               class="form-control @error('customer_email') is-invalid @enderror" 
                               value="{{ old('customer_email') }}" 
                               placeholder="your@email.com">
                        @error('customer_email')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="terms-checkbox">
                        <input type="checkbox" id="terms" required>
                        <label for="terms">
                            I agree to the <a href="#" target="_blank">Terms & Conditions</a> and <a href="#" target="_blank">Privacy Policy</a>
                        </label>
                    </div>

                    <button type="submit" class="btn-proceed">
                        <i class="fas fa-credit-card"></i>
                        Proceed to Payment
                    </button>

                    <p class="payment-note">
                        <i class="fas fa-info-circle"></i>
                        You will be redirected to RupantorPay for secure payment processing
                    </p>
                </form>
            </div>
        </div>
    </div>
</section>

@endsection

@push('styles')
<style>
    .checkout-section {
        padding: 60px 0;
        background: #f8f9fa;
        min-height: calc(100vh - 200px);
    }

    .checkout-header {
        margin-bottom: 40px;
        text-align: center;
    }

    .back-link {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        color: var(--primary-color);
        text-decoration: none;
        font-weight: 600;
        margin-bottom: 15px;
        transition: all 0.3s ease;
    }

    .back-link:hover {
        color: var(--secondary-color);
        transform: translateX(-5px);
    }

    .checkout-header h1 {
        font-size: 2.5rem;
        color: #1f2937;
        margin: 0;
    }

    .checkout-content {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 30px;
        max-width: 1200px;
        margin: 0 auto;
    }

    .order-summary,
    .customer-form {
        background: #fff;
        border-radius: 16px;
        padding: 30px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    }

    .order-summary h3,
    .customer-form h3 {
        font-size: 1.5rem;
        color: #1f2937;
        margin: 0 0 25px 0;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .order-summary h3 i,
    .customer-form h3 i {
        color: var(--primary-color);
    }

    .product-info {
        display: flex;
        gap: 20px;
        margin-bottom: 30px;
        padding-bottom: 25px;
        border-bottom: 2px solid #e5e7eb;
    }

    .product-image {
        width: 120px;
        height: 120px;
        flex-shrink: 0;
        border-radius: 12px;
        overflow: hidden;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .product-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .product-image .no-image {
        color: rgba(255, 255, 255, 0.8);
        font-size: 2.5rem;
    }

    .product-details {
        flex: 1;
    }

    .product-category {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        font-size: 0.75rem;
        color: var(--primary-color);
        background: rgba(102, 126, 234, 0.1);
        padding: 4px 10px;
        border-radius: 12px;
        font-weight: 600;
        margin-bottom: 8px;
    }

    .product-details h4 {
        font-size: 1.25rem;
        color: #1f2937;
        margin: 8px 0;
    }

    .product-details p {
        font-size: 0.9rem;
        color: #6b7280;
        margin: 8px 0;
        line-height: 1.5;
    }

    .product-features {
        margin-top: 12px;
    }

    .product-features .feature {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 0.9rem;
        color: #4b5563;
        font-weight: 500;
    }

    .product-features .feature i {
        color: var(--primary-color);
    }

    .price-breakdown {
        margin-bottom: 20px;
    }

    .price-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 0;
        border-bottom: 1px solid #f3f4f6;
        font-size: 1rem;
    }

    .price-row.total {
        border-bottom: none;
        border-top: 2px solid #e5e7eb;
        padding-top: 15px;
        margin-top: 10px;
        font-size: 1.25rem;
        font-weight: 700;
        color: var(--primary-color);
    }

    .price-row .amount {
        font-weight: 600;
    }

    .secure-payment {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        padding: 15px;
        background: #f0fdf4;
        border: 1px solid #86efac;
        border-radius: 8px;
        color: #16a34a;
        font-weight: 600;
    }

    .secure-payment i {
        font-size: 1.2rem;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        font-weight: 600;
        color: #374151;
        margin-bottom: 8px;
        font-size: 0.95rem;
    }

    .form-group label .required {
        color: #ef4444;
    }

    .form-control {
        width: 100%;
        padding: 12px 15px;
        border: 2px solid #e5e7eb;
        border-radius: 8px;
        font-size: 1rem;
        transition: all 0.3s ease;
    }

    .form-control:focus {
        outline: none;
        border-color: var(--primary-color);
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    }

    .form-control.is-invalid {
        border-color: #ef4444;
    }

    .invalid-feedback {
        color: #ef4444;
        font-size: 0.85rem;
        margin-top: 5px;
        display: block;
    }

    .form-text {
        display: block;
        font-size: 0.85rem;
        color: #6b7280;
        margin-top: 5px;
    }

    .terms-checkbox {
        display: flex;
        align-items: start;
        gap: 10px;
        margin: 25px 0;
        padding: 15px;
        background: #f9fafb;
        border-radius: 8px;
    }

    .terms-checkbox input[type="checkbox"] {
        margin-top: 3px;
        width: 18px;
        height: 18px;
        cursor: pointer;
    }

    .terms-checkbox label {
        margin: 0;
        font-size: 0.9rem;
        color: #4b5563;
        cursor: pointer;
    }

    .terms-checkbox a {
        color: var(--primary-color);
        text-decoration: none;
        font-weight: 600;
    }

    .terms-checkbox a:hover {
        text-decoration: underline;
    }

    .btn-proceed {
        width: 100%;
        padding: 16px;
        background: var(--primary-color);
        color: #fff;
        border: none;
        border-radius: 8px;
        font-size: 1.1rem;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
    }

    .btn-proceed:hover {
        background: var(--secondary-color);
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
    }

    .payment-note {
        text-align: center;
        font-size: 0.85rem;
        color: #6b7280;
        margin-top: 15px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }

    .payment-note i {
        color: var(--primary-color);
    }

    /* Responsive Design */
    @media (max-width: 968px) {
        .checkout-content {
            grid-template-columns: 1fr;
        }

        .order-summary {
            order: 2;
        }

        .customer-form {
            order: 1;
        }
    }

    @media (max-width: 576px) {
        .checkout-header h1 {
            font-size: 2rem;
        }

        .product-info {
            flex-direction: column;
            text-align: center;
        }

        .product-image {
            width: 100%;
            height: 180px;
        }
    }
</style>
@endpush

@push('scripts')
<script>
    // Show validation errors
    @if($errors->any())
        Swal.fire({
            icon: 'error',
            title: 'Validation Error',
            html: '<ul style="text-align: left;">@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>',
        });
    @endif

    @if(session('error'))
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: '{{ session('error') }}',
        });
    @endif

    // Form submission
    document.getElementById('checkoutForm').addEventListener('submit', function(e) {
        const termsCheckbox = document.getElementById('terms');
        if (!termsCheckbox.checked) {
            e.preventDefault();
            Swal.fire({
                icon: 'warning',
                title: 'Terms & Conditions',
                text: 'Please accept the Terms & Conditions to proceed.',
            });
            return false;
        }
    });
</script>
@endpush

