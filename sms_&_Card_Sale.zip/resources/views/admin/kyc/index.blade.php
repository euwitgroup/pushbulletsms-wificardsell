@extends('admin.layouts.app')

@section('title', 'KYC Management')

@section('content')
<style>
    .kyc-card {
        transition: all 0.3s ease;
    }
    
    .kyc-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    
    .status-filter {
        cursor: pointer;
        transition: all 0.2s;
    }
    
    .status-filter:hover {
        transform: scale(1.05);
    }
    
    .document-icon {
        font-size: 2rem;
        opacity: 0.3;
    }
    
    .document-uploaded {
        color: #28a745;
        opacity: 1;
    }
</style>

<!-- Page Header -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 style="font-weight: 700; color: #1a1d2e; margin: 0;">
            <i class="fas fa-id-card me-2" style="color: #667eea;"></i>KYC Management
        </h2>
    </div>
    <div>
        <p style="color: #6c757d; font-size: 14px; margin: 0;">
            <a href="{{ route('admin.dashboard') }}" style="color: #6c757d; text-decoration: none;">Home</a> 
            <i class="fas fa-chevron-right" style="font-size: 10px; margin: 0 5px;"></i> 
            <span>KYC Management</span>
        </p>
    </div>
</div>

<!-- Stats Cards -->
<div class="row mb-4">
    <div class="col-md-3">
        <a href="{{ route('admin.kyc.index', ['status' => 'pending']) }}" class="text-decoration-none">
            <div class="card status-filter {{ $status == 'pending' ? 'border-warning border-2' : '' }}">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h3 class="mb-0">{{ $stats['pending'] }}</h3>
                            <p class="text-muted mb-0">Pending Review</p>
                        </div>
                        <div class="text-warning">
                            <i class="fas fa-clock fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
    
    <div class="col-md-3">
        <a href="{{ route('admin.kyc.index', ['status' => 'approved']) }}" class="text-decoration-none">
            <div class="card status-filter {{ $status == 'approved' ? 'border-success border-2' : '' }}">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h3 class="mb-0">{{ $stats['approved'] }}</h3>
                            <p class="text-muted mb-0">Approved</p>
                        </div>
                        <div class="text-success">
                            <i class="fas fa-check-circle fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
    
    <div class="col-md-3">
        <a href="{{ route('admin.kyc.index', ['status' => 'rejected']) }}" class="text-decoration-none">
            <div class="card status-filter {{ $status == 'rejected' ? 'border-danger border-2' : '' }}">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h3 class="mb-0">{{ $stats['rejected'] }}</h3>
                            <p class="text-muted mb-0">Rejected</p>
                        </div>
                        <div class="text-danger">
                            <i class="fas fa-times-circle fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
    
    <div class="col-md-3">
        <a href="{{ route('admin.kyc.index', ['status' => 'not_submitted']) }}" class="text-decoration-none">
            <div class="card status-filter {{ $status == 'not_submitted' ? 'border-secondary border-2' : '' }}">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h3 class="mb-0">{{ $stats['not_submitted'] }}</h3>
                            <p class="text-muted mb-0">Not Submitted</p>
                        </div>
                        <div class="text-secondary">
                            <i class="fas fa-user fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
</div>

<!-- Filter Bar -->
<div class="card mb-4">
    <div class="card-body py-3">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <strong>Filter:</strong>
                <a href="{{ route('admin.kyc.index') }}" class="btn btn-sm {{ $status == 'all' ? 'btn-primary' : 'btn-outline-secondary' }} ms-2">All</a>
                <a href="{{ route('admin.kyc.index', ['status' => 'pending']) }}" class="btn btn-sm {{ $status == 'pending' ? 'btn-warning' : 'btn-outline-warning' }} ms-1">Pending</a>
                <a href="{{ route('admin.kyc.index', ['status' => 'approved']) }}" class="btn btn-sm {{ $status == 'approved' ? 'btn-success' : 'btn-outline-success' }} ms-1">Approved</a>
                <a href="{{ route('admin.kyc.index', ['status' => 'rejected']) }}" class="btn btn-sm {{ $status == 'rejected' ? 'btn-danger' : 'btn-outline-danger' }} ms-1">Rejected</a>
                <a href="{{ route('admin.kyc.index', ['status' => 'not_submitted']) }}" class="btn btn-sm {{ $status == 'not_submitted' ? 'btn-secondary' : 'btn-outline-secondary' }} ms-1">Not Submitted</a>
            </div>
            <div>
                <span class="text-muted">Total: <strong>{{ $users->total() }}</strong></span>
            </div>
        </div>
    </div>
</div>

<!-- Users List -->
<div class="row">
    @forelse($users as $user)
    <div class="col-md-6 col-lg-4 mb-4">
        <div class="card kyc-card h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div class="d-flex align-items-center">
                        @if($user->profile_photo)
                            <img src="{{ asset('storage/' . $user->profile_photo) }}" 
                                 alt="{{ $user->name }}" 
                                 class="rounded-circle me-3" 
                                 style="width: 50px; height: 50px; object-fit: cover;">
                        @else
                            <div class="rounded-circle me-3 d-flex align-items-center justify-content-center" 
                                 style="width: 50px; height: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                                <i class="fas fa-user text-white"></i>
                            </div>
                        @endif
                        <div>
                            <h6 class="mb-0">{{ $user->name }}</h6>
                            <small class="text-muted">{{ $user->email }}</small>
                        </div>
                    </div>
                    {!! $user->kyc_status_badge !!}
                </div>

                <div class="mb-3">
                    <small class="text-muted d-block">
                        <i class="fas fa-phone me-1"></i>{{ $user->phone }}
                    </small>
                    <small class="text-muted d-block">
                        <i class="fas fa-calendar me-1"></i>Joined {{ $user->created_at->format('M d, Y') }}
                    </small>
                    @if($user->kyc_submitted_at)
                        <small class="text-muted d-block">
                            <i class="fas fa-clock me-1"></i>Submitted {{ $user->kyc_submitted_at->diffForHumans() }}
                        </small>
                    @endif
                </div>

                <!-- Documents Status -->
                <div class="mb-3">
                    <div class="d-flex justify-content-around py-2 bg-light rounded">
                        <div class="text-center" title="NID">
                            <i class="fas fa-id-card document-icon {{ $user->nid_number ? 'document-uploaded' : '' }}"></i>
                            <small class="d-block">NID</small>
                        </div>
                        <div class="text-center" title="Passport">
                            <i class="fas fa-passport document-icon {{ $user->passport_number ? 'document-uploaded' : '' }}"></i>
                            <small class="d-block">Passport</small>
                        </div>
                        <div class="text-center" title="Driving License">
                            <i class="fas fa-car document-icon {{ $user->driving_license ? 'document-uploaded' : '' }}"></i>
                            <small class="d-block">License</small>
                        </div>
                    </div>
                </div>

                <div class="text-center">
                    <a href="{{ route('admin.kyc.show', $user->id) }}" class="btn btn-sm btn-primary">
                        <i class="fas fa-eye me-1"></i>View Details
                    </a>
                </div>
            </div>
        </div>
    </div>
    @empty
    <div class="col-12">
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="fas fa-id-card fa-4x text-muted mb-3"></i>
                <p class="text-muted mb-0">No users found for this filter</p>
            </div>
        </div>
    </div>
    @endforelse
</div>

<!-- Pagination -->
@if($users->hasPages())
<div class="d-flex justify-content-center">
    {{ $users->appends(['status' => $status])->links() }}
</div>
@endif

@endsection

