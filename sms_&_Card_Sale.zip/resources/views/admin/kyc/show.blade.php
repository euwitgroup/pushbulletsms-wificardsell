@extends('admin.layouts.app')

@section('title', 'KYC Details - ' . $user->name)

@section('content')
<style>
    .document-preview {
        cursor: pointer;
        transition: all 0.3s;
        border: 2px solid #e9ecef;
        border-radius: 8px;
        padding: 10px;
    }
    
    .document-preview:hover {
        border-color: #667eea;
        transform: scale(1.02);
    }
    
    .document-preview img {
        max-width: 100%;
        border-radius: 4px;
    }
    
    .info-label {
        font-weight: 600;
        color: #6c757d;
        font-size: 0.9rem;
    }
    
    .info-value {
        font-size: 1rem;
        color: #2c3e50;
    }
    
    .timeline-item {
        position: relative;
        padding-left: 30px;
        margin-bottom: 20px;
    }
    
    .timeline-item::before {
        content: '';
        position: absolute;
        left: 7px;
        top: 25px;
        width: 2px;
        height: calc(100% - 25px);
        background: #e9ecef;
    }
    
    .timeline-item:last-child::before {
        display: none;
    }
    
    .timeline-dot {
        position: absolute;
        left: 0;
        top: 0;
        width: 16px;
        height: 16px;
        border-radius: 50%;
        background: white;
        border: 3px solid #667eea;
    }
</style>

<!-- Page Header -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 style="font-weight: 700; color: #1a1d2e; margin: 0;">
            <i class="fas fa-id-card me-2" style="color: #667eea;"></i>KYC Verification Details
        </h2>
    </div>
    <div>
        <a href="{{ route('admin.kyc.index') }}" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i>Back to List
        </a>
    </div>
</div>

<div class="row">
    <!-- User Information Column -->
    <div class="col-lg-4">
        <!-- User Profile Card -->
        <div class="card mb-4">
            <div class="card-body text-center">
                @if($user->profile_photo)
                    <img src="{{ asset('storage/' . $user->profile_photo) }}" 
                         alt="{{ $user->name }}" 
                         class="rounded-circle mb-3" 
                         style="width: 100px; height: 100px; object-fit: cover; border: 4px solid #667eea;">
                @else
                    <div class="rounded-circle mb-3 d-inline-flex align-items-center justify-content-center" 
                         style="width: 100px; height: 100px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                        <i class="fas fa-user text-white fa-3x"></i>
                    </div>
                @endif
                
                <h5 class="mb-1">{{ $user->name }}</h5>
                <p class="text-muted mb-2">{{ $user->email }}</p>
                <p class="text-muted mb-3">{{ $user->phone }}</p>
                
                {!! $user->kyc_status_badge !!}
                
                <hr>
                
                <div class="text-start mt-3">
                    <p class="mb-2"><span class="info-label">User ID:</span> <span class="info-value">#{{ $user->id }}</span></p>
                    <p class="mb-2"><span class="info-label">Gender:</span> <span class="info-value">{{ $user->gender ? ucfirst($user->gender) : 'Not specified' }}</span></p>
                    <p class="mb-2"><span class="info-label">Date of Birth:</span> <span class="info-value">{{ $user->date_of_birth ? $user->date_of_birth->format('F d, Y') : 'Not specified' }}</span></p>
                    <p class="mb-2"><span class="info-label">Balance:</span> <span class="info-value">৳{{ number_format($user->balance, 2) }}</span></p>
                    <p class="mb-0"><span class="info-label">Member Since:</span> <span class="info-value">{{ $user->created_at->format('F d, Y') }}</span></p>
                </div>
            </div>
        </div>

        <!-- Address Card -->
        <div class="card mb-4">
            <div class="card-header">
                <h6 class="mb-0"><i class="fas fa-map-marker-alt me-2"></i>Address Information</h6>
            </div>
            <div class="card-body">
                <p class="mb-2">
                    <span class="info-label">Address:</span><br>
                    <span class="info-value">{{ $user->address ?: 'Not provided' }}</span>
                </p>
                <p class="mb-2">
                    <span class="info-label">City:</span> <span class="info-value">{{ $user->city ?: 'Not provided' }}</span>
                </p>
                <p class="mb-2">
                    <span class="info-label">State:</span> <span class="info-value">{{ $user->state ?: 'Not provided' }}</span>
                </p>
                <p class="mb-2">
                    <span class="info-label">Postal Code:</span> <span class="info-value">{{ $user->postal_code ?: 'Not provided' }}</span>
                </p>
                <p class="mb-0">
                    <span class="info-label">Country:</span> <span class="info-value">{{ $user->country }}</span>
                </p>
            </div>
        </div>
    </div>

    <!-- KYC Documents Column -->
    <div class="col-lg-8">
        <!-- KYC Status Card -->
        <div class="card mb-4">
            <div class="card-header bg-{{ $user->isKycVerified() ? 'success' : ($user->isKycPending() ? 'warning' : ($user->isKycRejected() ? 'danger' : 'secondary')) }} text-white">
                <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>KYC Status</h5>
            </div>
            <div class="card-body">
                @if($user->isKycVerified())
                    <div class="alert alert-success mb-0">
                        <h6><i class="fas fa-check-circle me-2"></i>KYC Verified</h6>
                        <p class="mb-1">Verified on: {{ $user->kyc_verified_at->format('F d, Y \a\t h:i A') }}</p>
                        @if($user->kycVerifiedBy)
                            <p class="mb-1">Verified by: {{ $user->kycVerifiedBy->name }}</p>
                        @endif
                        @if($user->kyc_notes)
                            <p class="mb-0"><strong>Notes:</strong> {{ $user->kyc_notes }}</p>
                        @endif
                    </div>
                @elseif($user->isKycPending())
                    <div class="alert alert-warning mb-3">
                        <h6><i class="fas fa-clock me-2"></i>Pending Review</h6>
                        <p class="mb-0">Submitted: {{ $user->kyc_submitted_at->format('F d, Y \a\t h:i A') }} ({{ $user->kyc_submitted_at->diffForHumans() }})</p>
                    </div>
                    
                    <!-- Quick Actions -->
                    <div class="row">
                        <div class="col-md-6 mb-2">
                            <button type="button" class="btn btn-success w-100" data-bs-toggle="modal" data-bs-target="#approveModal">
                                <i class="fas fa-check-circle me-2"></i>Approve KYC
                            </button>
                        </div>
                        <div class="col-md-6 mb-2">
                            <button type="button" class="btn btn-danger w-100" data-bs-toggle="modal" data-bs-target="#rejectModal">
                                <i class="fas fa-times-circle me-2"></i>Reject KYC
                            </button>
                        </div>
                    </div>
                @elseif($user->isKycRejected())
                    <div class="alert alert-danger mb-3">
                        <h6><i class="fas fa-times-circle me-2"></i>KYC Rejected</h6>
                        @if($user->kyc_notes)
                            <p class="mb-0"><strong>Reason:</strong> {{ $user->kyc_notes }}</p>
                        @endif
                    </div>
                    
                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#resubmitModal">
                        <i class="fas fa-redo me-2"></i>Request Resubmission
                    </button>
                @else
                    <div class="alert alert-secondary mb-0">
                        <h6><i class="fas fa-info-circle me-2"></i>KYC Not Submitted</h6>
                        <p class="mb-0">User has not submitted KYC documents yet.</p>
                    </div>
                @endif
            </div>
        </div>

        <!-- National ID Documents -->
        @if($user->nid_number)
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-id-card me-2"></i>National ID (NID)</h5>
            </div>
            <div class="card-body">
                <p class="mb-3"><strong>NID Number:</strong> {{ $user->nid_number }}</p>
                
                <div class="row">
                    @if($user->nid_front)
                    <div class="col-md-6 mb-3">
                        <p class="mb-2"><strong>NID Front:</strong></p>
                        <div class="document-preview" data-bs-toggle="modal" data-bs-target="#imageModal" data-image="{{ asset('storage/' . $user->nid_front) }}" data-title="NID Front">
                            <img src="{{ asset('storage/' . $user->nid_front) }}" alt="NID Front" style="max-height: 200px; width: 100%; object-fit: contain;">
                            <p class="text-center mb-0 mt-2"><i class="fas fa-search-plus"></i> Click to enlarge</p>
                        </div>
                    </div>
                    @endif
                    
                    @if($user->nid_back)
                    <div class="col-md-6 mb-3">
                        <p class="mb-2"><strong>NID Back:</strong></p>
                        <div class="document-preview" data-bs-toggle="modal" data-bs-target="#imageModal" data-image="{{ asset('storage/' . $user->nid_back) }}" data-title="NID Back">
                            <img src="{{ asset('storage/' . $user->nid_back) }}" alt="NID Back" style="max-height: 200px; width: 100%; object-fit: contain;">
                            <p class="text-center mb-0 mt-2"><i class="fas fa-search-plus"></i> Click to enlarge</p>
                        </div>
                    </div>
                    @endif
                </div>
            </div>
        </div>
        @endif

        <!-- Passport Documents -->
        @if($user->passport_number)
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-passport me-2"></i>Passport</h5>
            </div>
            <div class="card-body">
                <p class="mb-3"><strong>Passport Number:</strong> {{ $user->passport_number }}</p>
                
                @if($user->passport_photo)
                <div class="row">
                    <div class="col-md-6">
                        <p class="mb-2"><strong>Passport Photo Page:</strong></p>
                        <div class="document-preview" data-bs-toggle="modal" data-bs-target="#imageModal" data-image="{{ asset('storage/' . $user->passport_photo) }}" data-title="Passport">
                            <img src="{{ asset('storage/' . $user->passport_photo) }}" alt="Passport" style="max-height: 200px; width: 100%; object-fit: contain;">
                            <p class="text-center mb-0 mt-2"><i class="fas fa-search-plus"></i> Click to enlarge</p>
                        </div>
                    </div>
                </div>
                @endif
            </div>
        </div>
        @endif

        <!-- Driving License -->
        @if($user->driving_license)
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-car me-2"></i>Driving License</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="document-preview" data-bs-toggle="modal" data-bs-target="#imageModal" data-image="{{ asset('storage/' . $user->driving_license) }}" data-title="Driving License">
                            <img src="{{ asset('storage/' . $user->driving_license) }}" alt="Driving License" style="max-height: 200px; width: 100%; object-fit: contain;">
                            <p class="text-center mb-0 mt-2"><i class="fas fa-search-plus"></i> Click to enlarge</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endif

        <!-- Activity Timeline -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-history me-2"></i>Activity Timeline</h5>
            </div>
            <div class="card-body">
                <div class="timeline-item">
                    <div class="timeline-dot"></div>
                    <p class="mb-1"><strong>Account Created</strong></p>
                    <small class="text-muted">{{ $user->created_at->format('F d, Y \a\t h:i A') }}</small>
                </div>
                
                @if($user->kyc_submitted_at)
                <div class="timeline-item">
                    <div class="timeline-dot" style="border-color: #ffc107;"></div>
                    <p class="mb-1"><strong>KYC Documents Submitted</strong></p>
                    <small class="text-muted">{{ $user->kyc_submitted_at->format('F d, Y \a\t h:i A') }}</small>
                </div>
                @endif
                
                @if($user->kyc_verified_at)
                <div class="timeline-item">
                    <div class="timeline-dot" style="border-color: {{ $user->isKycVerified() ? '#28a745' : '#dc3545' }};"></div>
                    <p class="mb-1"><strong>KYC {{ $user->isKycVerified() ? 'Approved' : 'Rejected' }}</strong></p>
                    <small class="text-muted">{{ $user->kyc_verified_at->format('F d, Y \a\t h:i A') }}</small>
                    @if($user->kycVerifiedBy)
                        <small class="text-muted d-block">By: {{ $user->kycVerifiedBy->name }}</small>
                    @endif
                </div>
                @endif
            </div>
        </div>
    </div>
</div>

<!-- Approve Modal -->
<div class="modal fade" id="approveModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('admin.kyc.approve', $user->id) }}" method="POST">
                @csrf
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title"><i class="fas fa-check-circle me-2"></i>Approve KYC</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to approve KYC for <strong>{{ $user->name }}</strong>?</p>
                    
                    <div class="mb-3">
                        <label class="form-label">Notes (Optional)</label>
                        <textarea class="form-control" name="notes" rows="3" placeholder="Add any notes..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success"><i class="fas fa-check me-2"></i>Approve</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Reject Modal -->
<div class="modal fade" id="rejectModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('admin.kyc.reject', $user->id) }}" method="POST">
                @csrf
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title"><i class="fas fa-times-circle me-2"></i>Reject KYC</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Please provide a reason for rejecting KYC for <strong>{{ $user->name }}</strong>:</p>
                    
                    <div class="mb-3">
                        <label class="form-label">Rejection Reason *</label>
                        <textarea class="form-control" name="reason" rows="4" required placeholder="E.g., Documents are not clear, information mismatch, etc."></textarea>
                    </div>
                    
                    <div class="alert alert-warning">
                        <small><i class="fas fa-info-circle me-1"></i>User will be notified via SMS and notification about the rejection.</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger"><i class="fas fa-times me-2"></i>Reject</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Request Resubmission Modal -->
<div class="modal fade" id="resubmitModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('admin.kyc.resubmit', $user->id) }}" method="POST">
                @csrf
                <div class="modal-header bg-warning">
                    <h5 class="modal-title"><i class="fas fa-redo me-2"></i>Request KYC Resubmission</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Request <strong>{{ $user->name }}</strong> to resubmit KYC documents:</p>
                    
                    <div class="mb-3">
                        <label class="form-label">Message to User *</label>
                        <textarea class="form-control" name="message" rows="4" required placeholder="E.g., Please resubmit with clearer images..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning"><i class="fas fa-redo me-2"></i>Request Resubmission</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Image Preview Modal -->
<div class="modal fade" id="imageModal" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="imageModalTitle">Document Preview</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <img id="imageModalImg" src="" alt="Document" style="max-width: 100%; height: auto;">
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
// Image preview modal
document.querySelectorAll('.document-preview').forEach(preview => {
    preview.addEventListener('click', function() {
        const imageSrc = this.getAttribute('data-image');
        const imageTitle = this.getAttribute('data-title');
        document.getElementById('imageModalImg').src = imageSrc;
        document.getElementById('imageModalTitle').textContent = imageTitle;
    });
});
</script>
@endpush

@endsection

