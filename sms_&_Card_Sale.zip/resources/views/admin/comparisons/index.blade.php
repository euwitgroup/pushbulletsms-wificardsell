@extends('admin.layouts.app')

@section('title', 'Comparison Features Management')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .breadcrumb-nav a:hover {
        color: #3498db;
    }
    
    .table-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .btn-add-new {
        background: #26de81;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s ease;
    }
    
    .btn-add-new:hover {
        background: #20bf6b;
        transform: translateY(-1px);
    }
    
    .table-filters {
        display: flex;
        gap: 10px;
    }
    
    .btn-icon {
        background: #3498db;
        color: white;
        border: none;
        padding: 6px 10px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
    }
    
    .btn-icon.red {
        background: #ee5a6f;
    }
    
    .comparisons-table-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .comparisons-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .comparisons-table thead th {
        background: #f8f9fa;
        padding: 12px 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: #7f8c8d;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .comparisons-table tbody td {
        padding: 14px 16px;
        font-size: 13px;
        color: #2c3e50;
        border-bottom: 1px solid #f1f2f6;
        vertical-align: middle;
    }
    
    .comparisons-table tbody tr:hover {
        background: #fafbfc;
    }

    .check-icon {
        font-size: 1.3rem;
    }

    .check-yes {
        color: #26de81;
    }

    .check-no {
        color: #ee5a6f;
    }

    .badge-order {
        background: #8854d0;
        color: white;
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 500;
        display: inline-block;
    }
    
    .status-toggle {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 22px;
    }
    
    .status-toggle input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .toggle-slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .3s;
        border-radius: 24px;
    }
    
    .toggle-slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: .3s;
        border-radius: 50%;
    }
    
    input:checked + .toggle-slider {
        background-color: #26de81;
    }
    
    input:checked + .toggle-slider:before {
        transform: translateX(18px);
    }
    
    .action-buttons {
        display: flex;
        gap: 6px;
    }
    
    .btn-action {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 12px;
    }
    
    .btn-action:hover {
        transform: scale(1.1);
    }
    
    .btn-action.edit {
        background: #ffeaa7;
        color: #fdcb6e;
    }
    
    .btn-action.delete {
        background: #ffcccc;
        color: #ee5a6f;
    }
    
    .pagination-wrapper {
        padding: 15px;
        display: flex;
        justify-content: flex-end;
    }

    .empty-state {
        text-align: center;
        padding: 60px 20px;
    }

    .empty-state i {
        font-size: 64px;
        color: #dcdde1;
        margin-bottom: 20px;
    }

    .empty-state h4 {
        color: #7f8c8d;
        font-size: 18px;
        margin-bottom: 10px;
    }

    .empty-state p {
        color: #95a5a6;
        font-size: 14px;
    }
</style>

<!-- Breadcrumb -->
<div class="page-breadcrumb">
    <h1 class="page-title">⚖️ Comparison Features</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > <span>Comparisons</span>
    </div>
</div>

<!-- Table Controls -->
<div class="table-controls">
    <button onclick="createComparison()" class="btn-add-new">
        <i class="fas fa-plus"></i> Add New Feature
    </button>
    
    <div class="table-filters">
        <div class="search-box">
            <button class="btn-icon"><i class="fas fa-filter"></i></button>
            <button class="btn-icon red"><i class="fas fa-file-pdf"></i></button>
        </div>
    </div>
</div>

<!-- Comparisons Table -->
<div class="comparisons-table-card">
    <table class="comparisons-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Order</th>
                <th>Feature Name</th>
                <th class="text-center">We Have</th>
                <th class="text-center">Competitor</th>
                <th>Status</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
            @forelse($comparisons as $index => $comparison)
            <tr>
                <td>{{ $comparisons->firstItem() + $index }}</td>
                <td>
                    <span class="badge-order">#{{ $comparison->order }}</span>
                </td>
                <td>
                    <strong>{{ $comparison->feature_name }}</strong>
                </td>
                <td class="text-center">
                    @if($comparison->we_have)
                        <i class="fas fa-check-circle check-icon check-yes"></i>
                    @else
                        <i class="fas fa-times-circle check-icon check-no"></i>
                    @endif
                </td>
                <td class="text-center">
                    @if($comparison->competitor_have)
                        <i class="fas fa-check-circle check-icon check-yes"></i>
                    @else
                        <i class="fas fa-times-circle check-icon check-no"></i>
                    @endif
                </td>
                <td>
                    <label class="status-toggle">
                        <input type="checkbox" {{ $comparison->is_active ? 'checked' : '' }} 
                               onchange="confirmStatusToggle(this, {{ $comparison->id }}, {{ $comparison->is_active ? 'true' : 'false' }})">
                        <span class="toggle-slider"></span>
                    </label>
                </td>
                <td>
                    <div class="action-buttons">
                        <button onclick="editComparison({{ $comparison->id }})" class="btn-action edit" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button type="button" class="btn-action delete" title="Delete" onclick="confirmDelete({{ $comparison->id }})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="7">
                    <div class="empty-state">
                        <i class="fas fa-balance-scale"></i>
                        <h4>No Comparison Features Found</h4>
                        <p>Add your first feature to get started!</p>
                    </div>
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
    
    <!-- Pagination -->
    @if($comparisons->hasPages())
    <div class="pagination-wrapper">
        {{ $comparisons->links() }}
    </div>
    @endif
</div>

@push('scripts')
<script>
// Status Toggle Confirmation
function confirmStatusToggle(checkbox, comparisonId, currentStatus) {
    const newStatus = !currentStatus;
    const statusText = newStatus ? 'activate' : 'deactivate';
    
    Swal.fire({
        title: 'Change Feature Status?',
        html: `Are you sure you want to <strong>${statusText}</strong> this feature?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: newStatus ? '#26de81' : '#ee5a6f',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: `Yes, ${statusText}!`,
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            showLoading('Updating status...');
            
            fetch(`/admin/comparisons/${comparisonId}/toggle-status`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: data.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        window.location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: data.message
                    });
                    checkbox.checked = currentStatus;
                }
            })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'An error occurred. Please try again.'
                });
                checkbox.checked = currentStatus;
            });
        } else {
            checkbox.checked = currentStatus;
        }
    });
}

// Delete Confirmation
function confirmDelete(comparisonId) {
    Swal.fire({
        title: 'Delete Feature?',
        text: 'This action cannot be undone!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ee5a6f',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: '<i class="fas fa-trash me-2"></i>Yes, delete it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            showLoading('Deleting feature...');
            
            fetch(`/admin/comparisons/${comparisonId}`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Deleted!',
                        text: data.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        window.location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: data.message
                    });
                }
            })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'An error occurred. Please try again.'
                });
            });
        }
    });
}

function showLoading(message) {
    Swal.fire({
        title: message,
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
}

// Create Comparison Feature
function createComparison() {
    Swal.fire({
        title: 'Add New Comparison Feature',
        html: `
            <form id="createComparisonForm">
                <div class="mb-3 text-start">
                    <label class="form-label">Feature Name *</label>
                    <input type="text" class="form-control" id="createFeatureName" name="feature_name" required placeholder="e.g., Bulk SMS Support">
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Order</label>
                    <input type="number" class="form-control" id="createOrder" name="order" value="0" min="0">
                </div>
                <div class="mb-3 text-start">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="createWeHave" name="we_have" value="1" checked>
                        <label class="form-check-label" for="createWeHave">
                            <strong>We Have This Feature</strong>
                        </label>
                    </div>
                </div>
                <div class="mb-3 text-start">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="createCompetitorHave" name="competitor_have" value="1">
                        <label class="form-check-label" for="createCompetitorHave">
                            <strong>Competitor Has This Feature</strong>
                        </label>
                    </div>
                </div>
                <div class="mb-3 text-start">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="createActive" name="is_active" value="1" checked>
                        <label class="form-check-label" for="createActive">
                            Active
                        </label>
                    </div>
                </div>
            </form>
        `,
        width: '600px',
        showCancelButton: true,
        confirmButtonText: 'Add Feature',
        cancelButtonText: 'Cancel',
        preConfirm: () => {
            const form = document.getElementById('createComparisonForm');
            const formData = new FormData(form);

            // Handle checkboxes
            const weHave = document.getElementById('createWeHave').checked;
            const competitorHave = document.getElementById('createCompetitorHave').checked;
            const isActive = document.getElementById('createActive').checked;
            
            formData.set('we_have', weHave ? '1' : '0');
            formData.set('competitor_have', competitorHave ? '1' : '0');
            formData.set('is_active', isActive ? '1' : '0');

            if (!formData.get('feature_name')) {
                Swal.showValidationMessage('Feature name is required');
                return false;
            }

            return formData;
        }
    }).then((result) => {
        if (result.isConfirmed) {
            const formData = result.value;

            Swal.fire({
                title: 'Creating...',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            fetch('{{ route('admin.comparisons.store') }}', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: data.message,
                        timer: 1500
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: data.message
                    });
                }
            })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'An error occurred. Please try again.'
                });
            });
        }
    });
}

// Edit Comparison Feature
function editComparison(id) {
    Swal.fire({
        title: 'Loading...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    fetch(`/admin/comparisons/${id}/edit`)
        .then(response => response.json())
        .then(comparison => {
            Swal.fire({
                title: 'Edit Comparison Feature',
                html: `
                    <form id="editComparisonForm">
                        <div class="mb-3 text-start">
                            <label class="form-label">Feature Name *</label>
                            <input type="text" class="form-control" id="editFeatureName" name="feature_name" value="${comparison.feature_name}" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Order</label>
                            <input type="number" class="form-control" id="editOrder" name="order" value="${comparison.order}" min="0">
                        </div>
                        <div class="mb-3 text-start">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="editWeHave" name="we_have" value="1" ${comparison.we_have ? 'checked' : ''}>
                                <label class="form-check-label" for="editWeHave">
                                    <strong>We Have This Feature</strong>
                                </label>
                            </div>
                        </div>
                        <div class="mb-3 text-start">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="editCompetitorHave" name="competitor_have" value="1" ${comparison.competitor_have ? 'checked' : ''}>
                                <label class="form-check-label" for="editCompetitorHave">
                                    <strong>Competitor Has This Feature</strong>
                                </label>
                            </div>
                        </div>
                        <div class="mb-3 text-start">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="editActive" name="is_active" value="1" ${comparison.is_active ? 'checked' : ''}>
                                <label class="form-check-label" for="editActive">
                                    Active
                                </label>
                            </div>
                        </div>
                    </form>
                `,
                width: '600px',
                showCancelButton: true,
                confirmButtonText: 'Update Feature',
                cancelButtonText: 'Cancel',
                preConfirm: () => {
                    const form = document.getElementById('editComparisonForm');
                    const formData = new FormData(form);
                    formData.append('_method', 'PUT');

                    // Handle checkboxes
                    const weHave = document.getElementById('editWeHave').checked;
                    const competitorHave = document.getElementById('editCompetitorHave').checked;
                    const isActive = document.getElementById('editActive').checked;
                    
                    formData.set('we_have', weHave ? '1' : '0');
                    formData.set('competitor_have', competitorHave ? '1' : '0');
                    formData.set('is_active', isActive ? '1' : '0');

                    if (!formData.get('feature_name')) {
                        Swal.showValidationMessage('Feature name is required');
                        return false;
                    }

                    return formData;
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    const formData = result.value;

                    Swal.fire({
                        title: 'Updating...',
                        allowOutsideClick: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });

                    fetch(`/admin/comparisons/${id}`, {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success!',
                                text: data.message,
                                timer: 1500
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error!',
                                text: data.message
                            });
                        }
                    })
                    .catch(error => {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error!',
                            text: 'An error occurred. Please try again.'
                        });
                    });
                }
            });
        })
        .catch(error => {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Failed to load feature data'
            });
        });
}

</script>
@endpush

@endsection

