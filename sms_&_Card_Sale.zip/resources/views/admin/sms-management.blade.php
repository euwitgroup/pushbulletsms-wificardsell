@extends('admin.layouts.app')

@section('title', 'SMS Management')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .breadcrumb-nav a:hover {
        color: #3498db;
    }
    
    .table-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .info-note {
        background: #e8f4f8;
        color: #2980b9;
        padding: 8px 16px;
        border-radius: 4px;
        font-size: 12px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }
    
    .table-filters {
        display: flex;
        gap: 10px;
    }
    
    .btn-icon {
        background: #3498db;
        color: white;
        border: none;
        padding: 6px 10px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
    }
    
    .btn-icon.green {
        background: #26de81;
    }
    
    .btn-icon.red {
        background: #ee5a6f;
    }
    
    .sms-table-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .sms-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .sms-table thead th {
        background: #f8f9fa;
        padding: 12px 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: #7f8c8d;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .sms-table tbody td {
        padding: 14px 16px;
        font-size: 13px;
        color: #2c3e50;
        border-bottom: 1px solid #f1f2f6;
        vertical-align: middle;
    }
    
    .sms-table tbody tr:hover {
        background: #fafbfc;
    }
    
    .gateway-icon {
        width: 40px;
        height: 40px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
        color: #fff;
    }
    
    .gateway-name {
        font-weight: 500;
        color: #2c3e50;
        margin-bottom: 2px;
        font-size: 13px;
    }
    
    .gateway-description {
        font-size: 11px;
        color: #7f8c8d;
    }
    
    .status-badge {
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 11px;
        font-weight: 500;
        display: inline-block;
    }
    
    .status-active {
        background: #d4edda;
        color: #155724;
    }
    
    .status-inactive {
        background: #f8d7da;
        color: #721c24;
    }
    
    .cost-badge {
        background: #8854d0;
        color: white;
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 13px;
        font-weight: 600;
        display: inline-block;
    }
    
    .action-buttons {
        display: flex;
        gap: 6px;
    }
    
    .btn-action {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 12px;
    }
    
    .btn-action:hover {
        transform: scale(1.1);
    }
    
    .btn-action.cost {
        background: #d4f1f4;
        color: #05c3dd;
    }
    
    .btn-action.configure {
        background: #ffeaa7;
        color: #fdcb6e;
    }
</style>

<!-- Breadcrumb -->
<div class="page-breadcrumb">
    <h1 class="page-title">SMS Management</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > <span>SMS Management</span>
    </div>
</div>

<!-- Table Controls -->
<div class="table-controls">
    <div class="info-note">
        <i class="fas fa-info-circle"></i>
        <span>Set different SMS costs for each gateway. Cost will be charged based on active gateway.</span>
    </div>
    
    <div class="table-filters">
        <button class="btn-icon green" onclick="location.reload()">
            <i class="fas fa-sync-alt"></i>
        </button>
        <a href="{{ route('admin.sms-gateway.index') }}" class="btn-icon">
            <i class="fas fa-cog"></i>
        </a>
    </div>
</div>

<!-- SMS Gateways Table -->
<div class="sms-table-card">
    <table class="sms-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Gateway</th>
                <th>Description</th>
                <th>Status</th>
                <th>Cost per SMS</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
            @forelse($gateways as $index => $gateway)
            <tr>
                <td>
                    <div class="gateway-icon" style="background: {{ $gateway->gateway_name == 'bulksmsbd' ? 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)' : 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)' }}">
                        <i class="fas fa-{{ $gateway->gateway_name == 'bulksmsbd' ? 'sms' : 'mobile-alt' }}"></i>
                    </div>
                </td>
                <td>
                    <div class="gateway-name">
                        {{ $gateway->gateway_name == 'bulksmsbd' ? 'BulkSMSBD.com' : 'Pushbullet' }}
                    </div>
                    <div class="gateway-description">
                        {{ $gateway->gateway_name }}
                    </div>
                </td>
                <td>
                    <span style="font-size: 12px; color: #7f8c8d;">
                        {{ $gateway->gateway_name == 'bulksmsbd' ? 'Professional SMS Gateway Service' : 'Device-based SMS via Android' }}
                    </span>
                </td>
                <td>
                    <span class="status-badge {{ $gateway->is_active ? 'status-active' : 'status-inactive' }}">
                        {{ $gateway->is_active ? 'Active' : 'Inactive' }}
                    </span>
                </td>
                <td>
                    <span class="cost-badge">৳{{ number_format($gateway->cost_per_sms, 2) }}</span>
                </td>
                <td>
                    <div class="action-buttons">
                        <button type="button" 
                                class="btn-action cost" 
                                title="Cost Settings"
                                onclick="updateCostSettings('{{ $gateway->id }}', '{{ $gateway->gateway_name }}', '{{ $gateway->cost_per_sms }}')">
                            <i class="fas fa-dollar-sign"></i>
                        </button>
                        <a href="{{ route('admin.sms-gateway.index') }}" 
                           class="btn-action configure" 
                           title="Configure Gateway">
                            <i class="fas fa-cog"></i>
                        </a>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="6" class="text-center py-5">
                    <p class="text-muted">No SMS gateways found</p>
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>

@push('scripts')
<script>
function updateCostSettings(gatewayId, gatewayName, currentCost) {
    const gatewayDisplayName = gatewayName === 'bulksmsbd' ? 'BulkSMSBD.com' : 'Pushbullet';
    
    Swal.fire({
        title: '<strong>SMS Cost Settings</strong>',
        html: `
            <div style="text-align: left; padding: 20px;">
                <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                    <i class="fas fa-sms me-2"></i><strong>${gatewayDisplayName}</strong>
                </div>
                <label style="display: block; margin-bottom: 8px; font-weight: 600; color: #495057;">
                    <i class="fas fa-money-bill-wave me-2" style="color: #667eea;"></i>Cost Per SMS (৳)
                </label>
                <input type="number" id="sms-cost-input" class="swal2-input" value="${currentCost}" step="0.01" min="0" placeholder="1.00" style="margin: 0; width: 100%; font-size: 18px; font-weight: 600; text-align: center;">
                <small style="color: #6c757d; display: block; margin-top: 10px;">
                    <i class="fas fa-info-circle me-1"></i>This cost will be charged to users when they send SMS via this gateway
                </small>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: '<i class="fas fa-save me-2"></i>Save Settings',
        cancelButtonText: '<i class="fas fa-times me-2"></i>Cancel',
        confirmButtonColor: '#26de81',
        cancelButtonColor: '#7f8c8d',
        width: '500px',
        customClass: {
            confirmButton: 'btn-lg',
            cancelButton: 'btn-lg'
        },
        preConfirm: () => {
            const cost = document.getElementById('sms-cost-input').value;
            
            if (!cost || cost < 0) {
                Swal.showValidationMessage('Please enter a valid cost amount');
                return false;
            }
            
            return { cost: cost };
        }
    }).then((result) => {
        if (result.isConfirmed) {
            // Show loading
            showLoading('Updating SMS cost settings...');
            
            // Send AJAX request
            fetch(`/admin/sms-management/${gatewayId}/update-cost`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    cost_per_sms: result.value.cost
                })
            })
            .then(response => response.json())
            .then(data => {
                closeLoading();
                
                if (data.success) {
                    // Show success toast
                    showToast('success', data.message);
                    
                    // Update the cost badge in the table without reloading
                    setTimeout(() => {
                        location.reload();
                    }, 1500);
                } else {
                    showError(data.message || 'Failed to update cost settings');
                }
            })
            .catch(error => {
                closeLoading();
                showError('An error occurred while updating the cost settings');
                console.error('Error:', error);
            });
        }
    });
}
</script>
@endpush

@endsection

