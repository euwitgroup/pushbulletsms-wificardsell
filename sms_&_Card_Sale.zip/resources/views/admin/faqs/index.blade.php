@extends('admin.layouts.app')

@section('title', 'FAQs')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .breadcrumb-nav a:hover {
        color: #3498db;
    }
    
    .table-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .btn-add-new {
        background: #26de81;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s ease;
    }
    
    .btn-add-new:hover {
        background: #20bf6b;
        transform: translateY(-1px);
    }
    
    .table-filters {
        display: flex;
        gap: 10px;
    }
    
    .btn-icon {
        background: #3498db;
        color: white;
        border: none;
        padding: 6px 10px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
    }
    
    .btn-icon.red {
        background: #ee5a6f;
    }
    
    .faqs-table-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .faqs-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .faqs-table thead th {
        background: #f8f9fa;
        padding: 12px 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: #7f8c8d;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .faqs-table tbody td {
        padding: 14px 16px;
        font-size: 13px;
        color: #2c3e50;
        border-bottom: 1px solid #f1f2f6;
        vertical-align: middle;
    }
    
    .faqs-table tbody tr:hover {
        background: #fafbfc;
    }
    
    .badge-order {
        background: #8854d0;
        color: white;
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 500;
        display: inline-block;
    }
    
    .status-toggle {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 22px;
    }
    
    .status-toggle input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .toggle-slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .3s;
        border-radius: 24px;
    }
    
    .toggle-slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: .3s;
        border-radius: 50%;
    }
    
    input:checked + .toggle-slider {
        background-color: #26de81;
    }
    
    input:checked + .toggle-slider:before {
        transform: translateX(18px);
    }
    
    .action-buttons {
        display: flex;
        gap: 6px;
    }
    
    .btn-action {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 12px;
    }
    
    .btn-action:hover {
        transform: scale(1.1);
    }
    
    .btn-action.edit {
        background: #ffeaa7;
        color: #fdcb6e;
    }
    
    .btn-action.delete {
        background: #ffcccc;
        color: #ee5a6f;
    }
    
    .pagination-wrapper {
        padding: 15px;
        display: flex;
        justify-content: flex-end;
    }

    .empty-state {
        text-align: center;
        padding: 60px 20px;
    }

    .empty-state i {
        font-size: 64px;
        color: #dcdde1;
        margin-bottom: 20px;
    }

    .empty-state h4 {
        color: #7f8c8d;
        font-size: 18px;
        margin-bottom: 10px;
    }

    .empty-state p {
        color: #95a5a6;
        font-size: 14px;
    }
</style>

<!-- Breadcrumb -->
<div class="page-breadcrumb">
    <h1 class="page-title">FAQs</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > <span>FAQs</span>
    </div>
</div>

<!-- Table Controls -->
<div class="table-controls">
    <button onclick="openCreateModal()" class="btn-add-new">
        <i class="fas fa-plus"></i> Add New FAQ
    </button>
    
    <div class="table-filters">
        <button class="btn-icon"><i class="fas fa-filter"></i></button>
        <button class="btn-icon red"><i class="fas fa-file-pdf"></i></button>
    </div>
</div>

<!-- FAQs Table -->
<div class="faqs-table-card">
    <table class="faqs-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Question</th>
                <th>Answer</th>
                <th>Order</th>
                <th>Status</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
            @forelse($faqs as $index => $faq)
            <tr>
                <td>{{ $faqs->firstItem() + $index }}</td>
                <td><strong>{{ $faq->question }}</strong></td>
                <td>{{ Str::limit($faq->answer, 80) }}</td>
                <td>
                    <span class="badge-order">#{{ $faq->order }}</span>
                </td>
                <td>
                    <label class="status-toggle">
                        <input type="checkbox" {{ $faq->is_active ? 'checked' : '' }} 
                               onchange="confirmStatusToggle(this, '{{ route('admin.faqs.toggle-status', $faq->id) }}', {{ $faq->is_active ? 'true' : 'false' }})">
                        <span class="toggle-slider"></span>
                    </label>
                </td>
                <td>
                    <div class="action-buttons">
                        <button onclick="openEditModal({{ $faq->id }})" class="btn-action edit" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        <form action="{{ route('admin.faqs.destroy', $faq->id) }}" 
                              method="POST" 
                              class="d-inline delete-form"
                              id="delete-form-{{ $faq->id }}">
                            @csrf
                            @method('DELETE')
                            <button type="button" 
                                    class="btn-action delete" 
                                    title="Delete"
                                    onclick="confirmDelete('{{ $faq->id }}')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="6">
                    <div class="empty-state">
                        <i class="fas fa-question-circle"></i>
                        <h4>No FAQs Found</h4>
                        <p>Create your first FAQ to get started!</p>
                    </div>
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
    
    <!-- Pagination -->
    @if($faqs->hasPages())
    <div class="pagination-wrapper">
        {{ $faqs->links() }}
    </div>
    @endif
</div>

@push('scripts')
<script>
// Create Modal
function openCreateModal() {
    Swal.fire({
        title: '<i class="fas fa-question-circle text-primary me-2"></i>Add New FAQ',
        html: `
            <form id="createFaqForm">
                <div class="mb-3 text-start">
                    <label class="form-label">Question *</label>
                    <input type="text" class="form-control" name="question" placeholder="Enter question" required>
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Answer *</label>
                    <textarea class="form-control" name="answer" rows="4" placeholder="Enter answer" required></textarea>
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Display Order</label>
                    <input type="number" class="form-control" name="order" value="0" min="0">
                    <small class="text-muted">Lower numbers appear first</small>
                </div>
                <div class="mb-3 text-start">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="is_active" checked id="createActive">
                        <label class="form-check-label" for="createActive">Active</label>
                    </div>
                </div>
            </form>
        `,
        width: '600px',
        showCancelButton: true,
        confirmButtonText: '<i class="fas fa-save me-2"></i>Create FAQ',
        cancelButtonText: '<i class="fas fa-times me-2"></i>Cancel',
        confirmButtonColor: '#26de81',
        cancelButtonColor: '#7f8c8d',
        preConfirm: () => {
            const form = document.getElementById('createFaqForm');
            const formData = new FormData(form);
            
            const isActive = document.getElementById('createActive').checked;
            formData.set('is_active', isActive ? '1' : '0');
            
            const data = {};
            formData.forEach((value, key) => data[key] = value);
            
            return data;
        }
    }).then((result) => {
        if (result.isConfirmed) {
            submitCreateForm(result.value);
        }
    });
}

// Submit Create Form
function submitCreateForm(data) {
    Swal.fire({
        title: 'Creating FAQ...',
        html: 'Please wait',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    fetch('{{ route('admin.faqs.store') }}', {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: data.message,
                showConfirmButton: false,
                timer: 1500
            }).then(() => {
                window.location.reload();
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: data.message || 'Something went wrong'
            });
        }
    })
    .catch(error => {
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: 'Failed to create FAQ'
        });
    });
}

// Edit Modal
function openEditModal(faqId) {
    Swal.fire({
        title: 'Loading...',
        text: 'Please wait',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    fetch(`/admin/faqs/${faqId}/edit`)
        .then(response => response.json())
        .then(faq => {
            Swal.fire({
                title: '<i class="fas fa-edit text-warning me-2"></i>Edit FAQ',
                html: `
                    <form id="editFaqForm">
                        <div class="mb-3 text-start">
                            <label class="form-label">Question *</label>
                            <input type="text" class="form-control" name="question" value="${faq.question}" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Answer *</label>
                            <textarea class="form-control" name="answer" rows="4" required>${faq.answer}</textarea>
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Display Order</label>
                            <input type="number" class="form-control" name="order" value="${faq.order}" min="0">
                        </div>
                        <div class="mb-3 text-start">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="is_active" ${faq.is_active ? 'checked' : ''} id="editActive">
                                <label class="form-check-label" for="editActive">Active</label>
                            </div>
                        </div>
                    </form>
                `,
                width: '600px',
                showCancelButton: true,
                confirmButtonText: '<i class="fas fa-save me-2"></i>Update FAQ',
                cancelButtonText: '<i class="fas fa-times me-2"></i>Cancel',
                confirmButtonColor: '#fdcb6e',
                cancelButtonColor: '#7f8c8d',
                preConfirm: () => {
                    const form = document.getElementById('editFaqForm');
                    const formData = new FormData(form);
                    
                    const isActive = document.getElementById('editActive').checked;
                    formData.set('is_active', isActive ? '1' : '0');
                    
                    const data = {};
                    formData.forEach((value, key) => data[key] = value);
                    
                    return data;
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    submitEditForm(faqId, result.value);
                }
            });
        })
        .catch(error => {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Failed to load FAQ data'
            });
        });
}

// Submit Edit Form
function submitEditForm(faqId, data) {
    data._method = 'PUT';
    
    Swal.fire({
        title: 'Updating FAQ...',
        html: 'Please wait',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    fetch(`/admin/faqs/${faqId}`, {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: data.message,
                showConfirmButton: false,
                timer: 1500
            }).then(() => {
                window.location.reload();
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: data.message || 'Something went wrong'
            });
        }
    })
    .catch(error => {
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: 'Failed to update FAQ'
        });
    });
}

// Status Toggle
function confirmStatusToggle(checkbox, url, currentStatus) {
    const newStatus = !currentStatus;
    const statusText = newStatus ? 'activate' : 'deactivate';
    
    Swal.fire({
        title: 'Change FAQ Status?',
        html: `Are you sure you want to <strong>${statusText}</strong> this FAQ?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: newStatus ? '#26de81' : '#ee5a6f',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: `Yes, ${statusText}!`,
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            showLoading('Updating status...');
            window.location.href = url;
        } else {
            checkbox.checked = currentStatus;
        }
    });
}

// Delete Confirmation
function confirmDelete(faqId) {
    Swal.fire({
        title: 'Delete FAQ?',
        text: 'This action cannot be undone!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ee5a6f',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: '<i class="fas fa-trash me-2"></i>Yes, delete it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('delete-form-' + faqId).submit();
        }
    });
}

function showLoading(message) {
    Swal.fire({
        title: message,
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
}
</script>
@endpush

@endsection

