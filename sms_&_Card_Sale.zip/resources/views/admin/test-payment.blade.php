@extends('admin.layouts.app')

@section('title', 'Test Payment Gateway')

@section('content')
<style>
    .test-card {
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        padding: 32px;
        max-width: 600px;
        margin: 0 auto;
    }
    
    .test-header {
        text-align: center;
        margin-bottom: 32px;
    }
    
    .test-icon {
        width: 80px;
        height: 80px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 40px;
        margin: 0 auto 16px;
    }
    
    .amount-input {
        border-radius: 8px;
        border: 2px solid #e5e7eb;
        padding: 16px 20px;
        font-size: 24px;
        font-weight: 600;
        text-align: center;
        width: 100%;
        margin-bottom: 24px;
    }
    
    .amount-input:focus {
        border-color: #667eea;
        outline: none;
    }
    
    .quick-amounts {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 12px;
        margin-bottom: 24px;
    }
    
    .quick-amount-btn {
        padding: 12px;
        border: 2px solid #e5e7eb;
        border-radius: 8px;
        background: white;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s;
    }
    
    .quick-amount-btn:hover {
        border-color: #667eea;
        background: #f3f4f6;
    }
    
    .pay-btn {
        width: 100%;
        padding: 16px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 18px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
    }
    
    .pay-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
    }
    
    .gateway-info {
        background: #f9fafb;
        border-radius: 8px;
        padding: 16px;
        margin-top: 24px;
    }
    
    .info-row {
        display: flex;
        justify-content: space-between;
        padding: 8px 0;
        border-bottom: 1px solid #e5e7eb;
    }
    
    .info-row:last-child {
        border-bottom: none;
    }
</style>

<!-- Page Header -->
<div class="mb-4">
    <h4 style="font-weight: 600; color: #1f2937; margin: 0;">Test Payment Gateway</h4>
    <p style="color: #6b7280; font-size: 14px; margin-top: 4px;">Test your RupantorPay integration with a small payment</p>
</div>

<!-- Messages -->
@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

@if(session('error'))
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-circle me-2"></i>{{ session('error') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

@if(!$isActive)
<div class="alert alert-warning alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-triangle me-2"></i>
    <strong>Warning!</strong> RupantorPay gateway is currently inactive. Please activate it from the 
    <a href="{{ route('admin.payment-methods') }}" style="text-decoration: underline;">Payment Methods</a> page.
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

<!-- Test Payment Card -->
<div class="test-card">
    <div class="test-header">
        <div class="test-icon">💳</div>
        <h3 style="margin: 0; font-weight: 600; color: #1f2937;">Test Payment</h3>
        <p style="color: #6b7280; margin-top: 8px;">Enter an amount to test the payment gateway</p>
    </div>
    
    <form action="{{ route('admin.test-payment.initiate') }}" method="POST">
        @csrf
        
        <input type="number" 
               name="amount" 
               id="amount" 
               class="amount-input" 
               value="10" 
               min="1" 
               step="1"
               placeholder="Enter amount"
               oninput="calculateCharge()">
        
        <div class="quick-amounts">
            <button type="button" class="quick-amount-btn" onclick="setAmount(10)">৳10</button>
            <button type="button" class="quick-amount-btn" onclick="setAmount(50)">৳50</button>
            <button type="button" class="quick-amount-btn" onclick="setAmount(100)">৳100</button>
            <button type="button" class="quick-amount-btn" onclick="setAmount(500)">৳500</button>
        </div>
        
        <!-- Payment Breakdown -->
        <div class="gateway-info" style="margin-bottom: 24px;">
            <h6 style="font-weight: 600; color: #1f2937; margin-bottom: 12px;">Payment Breakdown</h6>
            <div class="info-row">
                <span style="color: #6b7280; font-size: 14px;">Base Amount</span>
                <span style="font-weight: 500; color: #1f2937; font-size: 14px;" id="base-amount">৳10.00</span>
            </div>
            <div class="info-row">
                <span style="color: #6b7280; font-size: 14px;">Payment Charge ({{ $paymentCharge }}%)</span>
                <span style="font-weight: 500; color: #1f2937; font-size: 14px;" id="charge-amount">৳0.00</span>
            </div>
            <div class="info-row" style="border-top: 2px solid #e5e7eb; padding-top: 12px; margin-top: 8px;">
                <span style="color: #1f2937; font-weight: 600; font-size: 16px;">Total Amount</span>
                <span style="font-weight: 700; color: #667eea; font-size: 18px;" id="total-amount">৳10.00</span>
            </div>
        </div>
        
        <button type="submit" class="pay-btn" id="pay-btn">
            <i class="fas fa-credit-card me-2"></i>Pay <span id="pay-btn-amount">৳10.00</span>
        </button>
    </form>
    
    <!-- Gateway Info -->
    <div class="gateway-info">
        <h6 style="font-weight: 600; color: #1f2937; margin-bottom: 12px;">Gateway Information</h6>
        <div class="info-row">
            <span style="color: #6b7280; font-size: 14px;">Gateway</span>
            <span style="font-weight: 500; color: #1f2937; font-size: 14px;">RupantorPay</span>
        </div>
        <div class="info-row">
            <span style="color: #6b7280; font-size: 14px;">Mode</span>
            <span style="font-weight: 500; color: #1f2937; font-size: 14px;">
                @if(App\Models\Setting::get('rupantorpay_sandbox') == '1')
                    <span style="background: #fef3c7; color: #92400e; padding: 4px 8px; border-radius: 4px; font-size: 12px;">
                        <i class="fas fa-flask me-1"></i>Sandbox
                    </span>
                @else
                    <span style="background: #d1fae5; color: #065f46; padding: 4px 8px; border-radius: 4px; font-size: 12px;">
                        <i class="fas fa-check me-1"></i>Live
                    </span>
                @endif
            </span>
        </div>
        <div class="info-row">
            <span style="color: #6b7280; font-size: 14px;">Status</span>
            <span style="font-weight: 500; color: #1f2937; font-size: 14px;">
                @if(App\Models\Setting::get('rupantorpay_active') == '1')
                    <span style="color: #10b981;">
                        <i class="fas fa-check-circle me-1"></i>Active
                    </span>
                @else
                    <span style="color: #ef4444;">
                        <i class="fas fa-times-circle me-1"></i>Inactive
                    </span>
                @endif
            </span>
        </div>
    </div>
</div>

<script>
const paymentChargePercent = {{ $paymentCharge }};
const minimumPayment = {{ $minimumPayment }};

function setAmount(amount) {
    document.getElementById('amount').value = amount;
    calculateCharge();
}

function calculateCharge() {
    const baseAmount = parseFloat(document.getElementById('amount').value) || 0;
    
    // Calculate charge
    const chargeAmount = (baseAmount * paymentChargePercent) / 100;
    const totalAmount = baseAmount + chargeAmount;
    
    // Update display
    document.getElementById('base-amount').textContent = '৳' + baseAmount.toFixed(2);
    document.getElementById('charge-amount').textContent = '৳' + chargeAmount.toFixed(2);
    document.getElementById('total-amount').textContent = '৳' + totalAmount.toFixed(2);
    document.getElementById('pay-btn-amount').textContent = '৳' + totalAmount.toFixed(2);
    
    // Check minimum payment and disable button if below minimum
    const payBtn = document.getElementById('pay-btn');
    if (baseAmount < minimumPayment) {
        payBtn.disabled = true;
        payBtn.style.opacity = '0.5';
        payBtn.style.cursor = 'not-allowed';
        payBtn.innerHTML = '<i class="fas fa-exclamation-triangle me-2"></i>Minimum ৳' + minimumPayment;
    } else {
        payBtn.disabled = false;
        payBtn.style.opacity = '1';
        payBtn.style.cursor = 'pointer';
        payBtn.innerHTML = '<i class="fas fa-credit-card me-2"></i>Pay ৳' + totalAmount.toFixed(2);
    }
}

// Calculate on page load
document.addEventListener('DOMContentLoaded', function() {
    calculateCharge();
});
</script>
@endsection
