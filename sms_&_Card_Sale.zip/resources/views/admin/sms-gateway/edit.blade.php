@extends('admin.layouts.app')

@section('title', 'Edit SMS Gateway')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .breadcrumb-nav a:hover {
        color: #3498db;
    }
    
    .gateway-card {
        background: white;
        border-radius: 8px;
        padding: 24px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        margin-bottom: 20px;
    }
    
    .card-section-title {
        font-size: 14px;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .form-group {
        margin-bottom: 20px;
    }
    
    .form-label {
        font-size: 13px;
        color: #7f8c8d;
        margin-bottom: 6px;
        font-weight: 500;
        display: block;
    }
    
    .form-control {
        width: 100%;
        border-radius: 6px;
        border: 1px solid #dcdde1;
        padding: 8px 12px;
        font-size: 13px;
        transition: all 0.2s ease;
    }
    
    .form-control:focus {
        border-color: #26de81;
        outline: none;
        box-shadow: 0 0 0 2px rgba(38, 222, 129, 0.1);
    }
    
    .badge-required {
        background: #ee5a6f;
        color: white;
        padding: 2px 6px;
        border-radius: 3px;
        font-size: 10px;
        font-weight: 600;
    }
    
    .btn-save {
        background: #26de81;
        color: white;
        border: none;
        padding: 10px 24px;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .btn-save:hover {
        background: #20bf6b;
        transform: translateY(-1px);
    }
    
    .btn-back {
        background: #7f8c8d;
        color: white;
        border: none;
        padding: 10px 24px;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;
        margin-left: 10px;
        text-decoration: none;
        display: inline-block;
    }
    
    .btn-back:hover {
        background: #636e72;
        color: white;
    }
    
    .gateway-header {
        background: linear-gradient(135deg, {{ $gateway->gateway_name == 'bulksmsbd' ? '#f093fb 0%, #f5576c 100%' : '#4facfe 0%, #00f2fe 100%' }});
        color: white;
        padding: 20px;
        border-radius: 8px;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        gap: 15px;
    }
    
    .gateway-header-icon {
        width: 60px;
        height: 60px;
        background: rgba(255,255,255,0.2);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 28px;
    }
    
    .gateway-header-text h2 {
        margin: 0;
        font-size: 20px;
        font-weight: 700;
    }
    
    .gateway-header-text p {
        margin: 5px 0 0 0;
        font-size: 13px;
        opacity: 0.9;
    }
    
    .input-group {
        display: flex;
        gap: 8px;
    }
    
    .btn-regenerate {
        background: #3498db;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;
        white-space: nowrap;
    }
    
    .btn-regenerate:hover {
        background: #2980b9;
    }
</style>

<!-- Breadcrumb -->
<div class="page-breadcrumb">
    <h1 class="page-title">Edit SMS Gateway</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > 
        <a href="{{ route('admin.sms-gateway.index') }}">SMS Gateway</a> > 
        <span>Edit</span>
    </div>
</div>

<!-- Gateway Header -->
<div class="gateway-header">
    <div class="gateway-header-icon">
        <i class="fas fa-{{ $gateway->gateway_name == 'bulksmsbd' ? 'sms' : 'mobile-alt' }}"></i>
    </div>
    <div class="gateway-header-text">
        <h2>{{ $gateway->gateway_name == 'bulksmsbd' ? 'BulkSMSBD.com' : 'Pushbullet' }}</h2>
        <p>{{ $gateway->gateway_name == 'bulksmsbd' ? 'Professional SMS Gateway Service' : 'Device-based SMS Gateway via Android' }}</p>
    </div>
</div>

<!-- BulkSMSBD Gateway Form -->
@if($gateway->gateway_name == 'bulksmsbd')
<div class="gateway-card">
    <h6 class="card-section-title">API Settings</h6>
    
    <form action="{{ route('admin.sms-gateway.update', $gateway->id) }}" method="POST">
        @csrf
        @method('PUT')
        
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">API Key <span class="badge-required">Required</span></label>
                    <input type="text" 
                           class="form-control @error('api_key') is-invalid @enderror" 
                           name="api_key" 
                           value="{{ old('api_key', $gateway->api_key) }}" 
                           placeholder="Enter your BulkSMSBD API key">
                    <small class="text-muted">Your unique API authentication key from BulkSMSBD</small>
                    @error('api_key')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">Sender ID <span class="badge-required">Required</span></label>
                    <input type="text" 
                           class="form-control @error('sender_id') is-invalid @enderror" 
                           name="sender_id" 
                           value="{{ old('sender_id', $gateway->sender_id) }}" 
                           placeholder="Enter approved sender ID">
                    <small class="text-muted">Your approved sender ID (e.g., 8809617624080)</small>
                    @error('sender_id')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">API URL</label>
                    <input type="text" class="form-control" value="{{ $gateway->api_url }}" readonly>
                    <small class="text-muted">API endpoint (read-only)</small>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">Message Type</label>
                    <select class="form-control @error('message_type') is-invalid @enderror" name="message_type">
                        <option value="text" {{ old('message_type', $gateway->message_type) == 'text' ? 'selected' : '' }}>Text</option>
                        <option value="unicode" {{ old('message_type', $gateway->message_type) == 'unicode' ? 'selected' : '' }}>Unicode (Bangla)</option>
                    </select>
                    <small class="text-muted">Select message encoding type</small>
                    @error('message_type')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>
        </div>
        
        <div class="d-flex">
            <button type="submit" class="btn-save">
                <i class="fas fa-save me-2"></i>Save Settings
            </button>
            <a href="{{ route('admin.sms-gateway.index') }}" class="btn-back">
                <i class="fas fa-arrow-left me-2"></i>Back to List
            </a>
        </div>
    </form>
</div>

<!-- Pushbullet Gateway Form -->
@elseif($gateway->gateway_name == 'pushbullet')
<div class="gateway-card">
    <h6 class="card-section-title">Pushbullet Configuration</h6>
    
    <form action="{{ route('admin.sms-gateway.update', $gateway->id) }}" method="POST">
        @csrf
        @method('PUT')
        
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label class="form-label">Access Token <span class="badge-required">Required</span></label>
                    <div class="input-group">
                        <input type="text" 
                               class="form-control @error('api_key') is-invalid @enderror" 
                               name="api_key" 
                               id="pushbullet-token"
                               value="{{ old('api_key', $gateway->api_key) }}" 
                               placeholder="Enter your Pushbullet API token">
                        <button type="button" class="btn-regenerate" onclick="applyPushbulletToken()" style="background: #26de81;">
                            <i class="fas fa-check me-1"></i>Apply
                        </button>
                    </div>
                    <small class="text-muted">Get from <a href="https://www.pushbullet.com/#settings/account" target="_blank">Pushbullet Settings</a></small>
                    @error('api_key')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">Device Name</label>
                    <div class="input-group">
                        <select class="form-control @error('device_name') is-invalid @enderror" name="device_name" id="device-select" {{ $gateway->api_key ? '' : 'disabled' }}>
                            <option value="">Select a device...</option>
                            @if($gateway->device_name)
                                <option value="{{ $gateway->device_name }}" selected>{{ $gateway->device_name }}</option>
                            @endif
                        </select>
                        <input type="hidden" name="device_id" id="device-id" value="{{ $gateway->device_id }}">
                        <button type="button" class="btn-regenerate" onclick="checkDevices()" id="check-device-btn" {{ $gateway->api_key ? '' : 'disabled' }}>
                            <i class="fas fa-mobile-alt me-1"></i>Check Device
                        </button>
                    </div>
                    <small class="text-muted">Select Android device after applying API key</small>
                    @error('device_name')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">API URL</label>
                    <input type="text" class="form-control" value="{{ $gateway->api_url }}" readonly>
                    <small class="text-muted">API endpoint (read-only)</small>
                </div>
            </div>
        </div>
        
        <div class="d-flex">
            <button type="submit" class="btn-save">
                <i class="fas fa-save me-2"></i>Save Settings
            </button>
            <a href="{{ route('admin.sms-gateway.index') }}" class="btn-back">
                <i class="fas fa-arrow-left me-2"></i>Back to List
            </a>
        </div>
    </form>
</div>

@push('scripts')
<script>
function applyPushbulletToken() {
    const token = document.getElementById('pushbullet-token').value;
    
    if (!token) {
        showWarning('Please enter an API token first');
        return;
    }
    
    document.getElementById('check-device-btn').disabled = false;
    document.getElementById('device-select').disabled = false;
    
    showToast('success', 'Token applied! You can now check for devices.');
}

function checkDevices() {
    const token = document.getElementById('pushbullet-token').value;
    
    if (!token) {
        showWarning('Please enter and apply an API token first');
        return;
    }
    
    showLoading('Fetching devices...');
    
    fetch('/admin/sms-gateway/pushbullet/devices?api_key=' + encodeURIComponent(token), {
        method: 'GET',
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Accept': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        closeLoading();
        
        if (data.success && data.devices.length > 0) {
            const deviceSelect = document.getElementById('device-select');
            const deviceIdInput = document.getElementById('device-id');
            
            // Clear existing options
            deviceSelect.innerHTML = '<option value="">Select a device...</option>';
            
            // Add devices
            data.devices.forEach(device => {
                const option = document.createElement('option');
                option.value = device.name;
                option.textContent = device.name + (device.manufacturer ? ` (${device.manufacturer} ${device.model})` : '');
                option.dataset.deviceId = device.id;
                deviceSelect.appendChild(option);
            });
            
            // Handle device selection
            deviceSelect.onchange = function() {
                const selectedOption = this.options[this.selectedIndex];
                if (selectedOption.dataset.deviceId) {
                    deviceIdInput.value = selectedOption.dataset.deviceId;
                }
            };
            
            showToast('success', `Found ${data.devices.length} device(s)! Please select a device.`);
        } else {
            showWarning('No devices found. Please ensure you have devices connected to Pushbullet.');
        }
    })
    .catch(error => {
        closeLoading();
        showError('Error fetching devices: ' + error.message);
    });
}
</script>
@endpush
@endif

@endsection

