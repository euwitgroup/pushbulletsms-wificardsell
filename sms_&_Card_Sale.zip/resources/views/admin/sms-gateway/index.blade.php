@extends('admin.layouts.app')

@section('title', 'SMS Gateway Settings')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .breadcrumb-nav a:hover {
        color: #3498db;
    }
    
    .table-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .info-note {
        background: #e8f4f8;
        color: #2980b9;
        padding: 8px 16px;
        border-radius: 4px;
        font-size: 12px;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }
    
    .table-filters {
        display: flex;
        gap: 10px;
    }
    
    .btn-icon {
        background: #3498db;
        color: white;
        border: none;
        padding: 6px 10px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
    }
    
    .btn-icon.green {
        background: #26de81;
    }
    
    .gateway-table-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .gateway-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .gateway-table thead th {
        background: #f8f9fa;
        padding: 12px 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: #7f8c8d;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .gateway-table tbody td {
        padding: 14px 16px;
        font-size: 13px;
        color: #2c3e50;
        border-bottom: 1px solid #f1f2f6;
        vertical-align: middle;
    }
    
    .gateway-table tbody tr:hover {
        background: #fafbfc;
    }
    
    .gateway-icon {
        width: 40px;
        height: 40px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
        color: #fff;
    }
    
    .gateway-name {
        font-weight: 500;
        color: #2c3e50;
        margin-bottom: 2px;
        font-size: 13px;
    }
    
    .gateway-description {
        font-size: 11px;
        color: #7f8c8d;
    }
    
    .status-badge {
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 11px;
        font-weight: 500;
        display: inline-block;
    }
    
    .status-active {
        background: #d4edda;
        color: #155724;
    }
    
    .status-inactive {
        background: #f8d7da;
        color: #721c24;
    }
    
    .status-toggle {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 22px;
    }
    
    .status-toggle input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .toggle-slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .3s;
        border-radius: 24px;
    }
    
    .toggle-slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: .3s;
        border-radius: 50%;
    }
    
    input:checked + .toggle-slider {
        background-color: #26de81;
    }
    
    input:checked + .toggle-slider:before {
        transform: translateX(18px);
    }
    
    .action-buttons {
        display: flex;
        gap: 6px;
    }
    
    .btn-action {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 12px;
    }
    
    .btn-action:hover {
        transform: scale(1.1);
    }
    
    .btn-action.edit {
        background: #ffeaa7;
        color: #fdcb6e;
    }
    
    .btn-action.test {
        background: #d4f1f4;
        color: #05c3dd;
    }
</style>

<!-- Breadcrumb -->
<div class="page-breadcrumb">
    <h1 class="page-title">SMS Gateway Settings</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > <span>SMS Gateway</span>
    </div>
</div>

<!-- Table Controls -->
<div class="table-controls">
    <div class="info-note">
        <i class="fas fa-info-circle"></i>
        <span>Configure SMS gateways to send messages. Toggle to activate/deactivate gateways.</span>
    </div>
    
    <div class="table-filters">
        <button class="btn-icon green" onclick="location.reload()">
            <i class="fas fa-sync-alt"></i>
        </button>
        <a href="{{ route('admin.sms-management') }}" class="btn-icon">
            <i class="fas fa-dollar-sign"></i>
        </a>
    </div>
</div>

<!-- SMS Gateway Table -->
<div class="gateway-table-card">
    <table class="gateway-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Gateway Name</th>
                <th>API Configuration</th>
                <th>Type</th>
                <th>Status</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
            @forelse($gateways as $index => $gateway)
            <tr>
                <td>
                    <div class="gateway-icon" style="background: {{ $gateway->gateway_name == 'bulksmsbd' ? 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)' : 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)' }}">
                        <i class="fas fa-{{ $gateway->gateway_name == 'bulksmsbd' ? 'sms' : 'mobile-alt' }}"></i>
                    </div>
                </td>
                <td>
                    <div class="gateway-name">
                        {{ $gateway->gateway_name == 'bulksmsbd' ? 'BulkSMSBD.com' : 'Pushbullet' }}
                    </div>
                    <div class="gateway-description">
                        {{ $gateway->gateway_name }}
                    </div>
                </td>
                <td>
                    @if($gateway->api_key)
                        <span style="font-size: 11px; color: #26de81;">
                            <i class="fas fa-check-circle"></i> Configured
                        </span>
                    @else
                        <span style="font-size: 11px; color: #ee5a6f;">
                            <i class="fas fa-times-circle"></i> Not Configured
                        </span>
                    @endif
                </td>
                <td>
                    <span style="font-size: 12px; color: #7f8c8d;">
                        {{ $gateway->gateway_name == 'bulksmsbd' ? 'Professional' : 'Device-based' }}
                    </span>
                </td>
                <td>
                    <label class="status-toggle">
                        <input type="checkbox" {{ $gateway->is_active ? 'checked' : '' }} 
                               onchange="confirmStatusToggle(this, '{{ route('admin.sms-gateway.toggle-status', $gateway->id) }}', '{{ $gateway->gateway_name }}', {{ $gateway->is_active ? 'true' : 'false' }})">
                        <span class="toggle-slider"></span>
                    </label>
                </td>
                <td>
                    <div class="action-buttons">
                        <a href="{{ route('admin.sms-gateway.edit', $gateway->id) }}" 
                           class="btn-action edit" 
                           title="Edit Gateway">
                            <i class="fas fa-edit"></i>
                        </a>
                        <a href="{{ route('admin.sms-gateway.test', $gateway->id) }}" 
                           class="btn-action test" 
                           title="Test Gateway">
                            <i class="fas fa-vial"></i>
                        </a>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="6" class="text-center py-5">
                    <p class="text-muted">No SMS gateways found</p>
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>

@push('scripts')
<script>
function confirmStatusToggle(checkbox, url, gatewayName, currentStatus) {
    const newStatus = !currentStatus;
    const statusText = newStatus ? 'activate' : 'deactivate';
    
    Swal.fire({
        title: 'Change Gateway Status?',
        html: `Are you sure you want to <strong>${statusText}</strong> ${gatewayName}?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: newStatus ? '#26de81' : '#ee5a6f',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: `Yes, ${statusText}!`,
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            showLoading('Updating status...');
            
            fetch(url, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                closeLoading();
                if (data.success) {
                    showToast('success', data.message);
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showError(data.message || 'Failed to update status');
                    checkbox.checked = currentStatus;
                }
            })
            .catch(error => {
                closeLoading();
                showError('An error occurred');
                checkbox.checked = currentStatus;
            });
        } else {
            // Revert checkbox
            checkbox.checked = currentStatus;
        }
    });
}
</script>
@endpush

@endsection

