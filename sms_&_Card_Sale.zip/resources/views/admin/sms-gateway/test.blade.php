@extends('admin.layouts.app')

@section('title', 'Test SMS Gateway')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .breadcrumb-nav a:hover {
        color: #3498db;
    }
    
    .gateway-card {
        background: white;
        border-radius: 8px;
        padding: 24px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        margin-bottom: 20px;
    }
    
    .card-section-title {
        font-size: 14px;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .form-group {
        margin-bottom: 20px;
    }
    
    .form-label {
        font-size: 13px;
        color: #7f8c8d;
        margin-bottom: 6px;
        font-weight: 500;
        display: block;
    }
    
    .form-control {
        width: 100%;
        border-radius: 6px;
        border: 1px solid #dcdde1;
        padding: 8px 12px;
        font-size: 13px;
        transition: all 0.2s ease;
    }
    
    .form-control:focus {
        border-color: #26de81;
        outline: none;
        box-shadow: 0 0 0 2px rgba(38, 222, 129, 0.1);
    }
    
    .badge-required {
        background: #ee5a6f;
        color: white;
        padding: 2px 6px;
        border-radius: 3px;
        font-size: 10px;
        font-weight: 600;
    }
    
    .btn-test {
        background: #8854d0;
        color: white;
        border: none;
        padding: 10px 24px;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .btn-test:hover {
        background: #6c3fb5;
    }
    
    .btn-back {
        background: #7f8c8d;
        color: white;
        border: none;
        padding: 10px 24px;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;
        margin-left: 10px;
        text-decoration: none;
        display: inline-block;
    }
    
    .btn-back:hover {
        background: #636e72;
        color: white;
    }
    
    .gateway-header {
        background: linear-gradient(135deg, {{ $gateway->gateway_name == 'bulksmsbd' ? '#f093fb 0%, #f5576c 100%' : '#4facfe 0%, #00f2fe 100%' }});
        color: white;
        padding: 20px;
        border-radius: 8px;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        gap: 15px;
    }
    
    .gateway-header-icon {
        width: 60px;
        height: 60px;
        background: rgba(255,255,255,0.2);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 28px;
    }
    
    .gateway-header-text h2 {
        margin: 0;
        font-size: 20px;
        font-weight: 700;
    }
    
    .gateway-header-text p {
        margin: 5px 0 0 0;
        font-size: 13px;
        opacity: 0.9;
    }
    
    .alert-warning-custom {
        background: #fff3cd;
        border-left: 4px solid #ffc107;
        padding: 15px;
        border-radius: 6px;
        margin-bottom: 20px;
    }
    
    .alert-info-custom {
        background: #d1ecf1;
        border-left: 4px solid #3498db;
        padding: 15px;
        border-radius: 6px;
        margin-top: 20px;
    }
</style>

<!-- Breadcrumb -->
<div class="page-breadcrumb">
    <h1 class="page-title">Test SMS Gateway</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > 
        <a href="{{ route('admin.sms-gateway.index') }}">SMS Gateway</a> > 
        <span>Test</span>
    </div>
</div>

<!-- Gateway Header -->
<div class="gateway-header">
    <div class="gateway-header-icon">
        <i class="fas fa-{{ $gateway->gateway_name == 'bulksmsbd' ? 'sms' : 'mobile-alt' }}"></i>
    </div>
    <div class="gateway-header-text">
        <h2>{{ $gateway->gateway_name == 'bulksmsbd' ? 'BulkSMSBD.com' : 'Pushbullet' }}</h2>
        <p>Test SMS Gateway - Send test message to verify configuration</p>
    </div>
</div>

<!-- Configuration Status -->
@if(!$gateway->api_key)
<div class="alert-warning-custom">
    <i class="fas fa-exclamation-triangle me-2"></i>
    <strong>Gateway Not Configured:</strong> Please configure the gateway settings before testing.
    <a href="{{ route('admin.sms-gateway.edit', $gateway->id) }}" style="margin-left: 10px;">Configure Now</a>
</div>
@endif

<!-- Test SMS Form -->
<div class="gateway-card">
    <h6 class="card-section-title">Send Test SMS</h6>
    
    <form id="test-sms-form">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">Phone Number <span class="badge-required">Required</span></label>
                    <input type="text" 
                           class="form-control" 
                           id="test-number" 
                           placeholder="{{ $gateway->gateway_name == 'bulksmsbd' ? '88017XXXXXXXX' : '+8801XXXXXXXXX' }}"
                           {{ $gateway->api_key ? '' : 'disabled' }}>
                    <small class="text-muted">
                        {{ $gateway->gateway_name == 'bulksmsbd' ? 'Enter phone number with country code (e.g., 88017XXXXXXXX)' : 'Enter phone number with + and country code (e.g., +8801XXXXXXXXX)' }}
                    </small>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">Test Message <span class="badge-required">Required</span></label>
                    <textarea class="form-control" 
                              id="test-message" 
                              rows="3" 
                              placeholder="Enter test message"
                              {{ $gateway->api_key ? '' : 'disabled' }}>This is a test SMS from {{ $gateway->gateway_name == 'bulksmsbd' ? 'BulkSMSBD' : 'Pushbullet' }} gateway.</textarea>
                    <small class="text-muted">Maximum 1000 characters</small>
                </div>
            </div>
            
            <div class="col-md-12">
                <button type="button" 
                        class="btn-test" 
                        onclick="sendTestSMS()"
                        {{ $gateway->api_key ? '' : 'disabled' }}>
                    <i class="fas fa-paper-plane me-2"></i>Send Test SMS
                </button>
                <a href="{{ route('admin.sms-gateway.index') }}" class="btn-back">
                    <i class="fas fa-arrow-left me-2"></i>Back to List
                </a>
            </div>
        </div>
    </form>
    
    <div class="alert-info-custom">
        <i class="fas fa-info-circle me-2"></i>
        <strong>Note:</strong> 
        @if($gateway->gateway_name == 'bulksmsbd')
            Ensure your BulkSMSBD account has sufficient balance and the API key is valid. Test SMS will be deducted from your BulkSMSBD balance.
        @else
            Ensure your Android device is connected to Pushbullet and SMS permission is enabled. The device must be online to send SMS.
        @endif
    </div>
</div>

@push('scripts')
<script>
function sendTestSMS() {
    const number = document.getElementById('test-number').value;
    const message = document.getElementById('test-message').value;
    
    if (!number || !message) {
        showWarning('Please enter phone number and message');
        return;
    }
    
    // Confirm before sending
    Swal.fire({
        title: 'Send Test SMS?',
        html: `
            <div style="text-align: left; font-size: 13px;">
                <strong>Number:</strong> ${number}<br>
                <strong>Message:</strong> ${message}<br>
                <strong>Gateway:</strong> {{ $gateway->gateway_name == 'bulksmsbd' ? 'BulkSMSBD.com' : 'Pushbullet' }}
            </div>
        `,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#8854d0',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: '<i class="fas fa-paper-plane me-2"></i>Send Now',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            showLoading('Sending test SMS...');
            
            fetch('{{ route('admin.sms-gateway.test-send', $gateway->id) }}', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ 
                    phone: number, 
                    message: message 
                })
            })
            .then(response => response.json())
            .then(data => {
                closeLoading();
                
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'SMS Sent Successfully!',
                        html: `
                            <div style="text-align: left; font-size: 13px; background: #f8f9fa; padding: 15px; border-radius: 6px;">
                                ${data.code ? `<strong>Response Code:</strong> <span style="color: #26de81; font-weight: bold;">${data.code}</span><br>` : ''}
                                <strong>Status:</strong> ${data.message}<br>
                                <strong>Gateway:</strong> ${data.gateway}<br>
                                <strong>Number:</strong> ${number}
                            </div>
                        `,
                        confirmButtonColor: '#26de81'
                    });
                    
                    // Clear form
                    document.getElementById('test-number').value = '';
                    document.getElementById('test-message').value = 'This is a test SMS from {{ $gateway->gateway_name == 'bulksmsbd' ? 'BulkSMSBD' : 'Pushbullet' }} gateway.';
                } else {
                    showError(data.message || 'Failed to send SMS');
                }
            })
            .catch(error => {
                closeLoading();
                showError('Error: ' + error.message);
            });
        }
    });
}
</script>
@endpush

@endsection

