@extends('admin.layouts.app')

@section('title', 'SMS Packages')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .table-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .btn-add-new {
        background: #26de81;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s ease;
        text-decoration: none;
    }
    
    .btn-add-new:hover {
        background: #20bf6b;
        transform: translateY(-1px);
        color: white;
    }
    
    .packages-table-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .packages-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .packages-table thead th {
        background: #f8f9fa;
        padding: 12px 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: #7f8c8d;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .packages-table tbody td {
        padding: 14px 16px;
        font-size: 13px;
        color: #2c3e50;
        border-bottom: 1px solid #f1f2f6;
        vertical-align: middle;
    }
    
    .packages-table tbody tr:hover {
        background: #fafbfc;
    }
    
    .badge-price {
        background: #26de81;
        color: white;
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 500;
        display: inline-block;
    }
    
    .badge-sms {
        background: #3498db;
        color: white;
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 500;
        display: inline-block;
    }
    
    .badge-featured {
        background: #8854d0;
        color: white;
        padding: 3px 8px;
        border-radius: 3px;
        font-size: 10px;
        font-weight: 500;
        display: inline-block;
        margin-left: 6px;
    }
    
    .status-toggle {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 22px;
    }
    
    .status-toggle input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .toggle-slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .3s;
        border-radius: 24px;
    }
    
    .toggle-slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: .3s;
        border-radius: 50%;
    }
    
    input:checked + .toggle-slider {
        background-color: #26de81;
    }
    
    input:checked + .toggle-slider:before {
        transform: translateX(18px);
    }
    
    .action-buttons {
        display: flex;
        gap: 6px;
    }
    
    .btn-action {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 12px;
    }
    
    .btn-action:hover {
        transform: scale(1.1);
    }
    
    .btn-action.edit {
        background: #ffeaa7;
        color: #fdcb6e;
    }
    
    .btn-action.delete {
        background: #ffcccc;
        color: #ee5a6f;
    }
</style>

<!-- Breadcrumb -->
<div class="page-breadcrumb">
    <h1 class="page-title">SMS Packages</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > <span>SMS Packages</span>
    </div>
</div>

<!-- Table Controls -->
<div class="table-controls">
    <a href="{{ route('admin.packages.create') }}" class="btn-add-new">
        <i class="fas fa-plus"></i> Add New Package
    </a>
</div>

<!-- Packages Table -->
<div class="packages-table-card">
    <table class="packages-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Package Name</th>
                <th>Gateway</th>
                <th>SMS Count</th>
                <th>Price</th>
                <th>Per SMS Rate</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse($packages as $package)
            <tr>
                <td><strong>#{{ $package->id }}</strong></td>
                <td>
                    {{ $package->name }}
                    @if($package->is_featured)
                    <span class="badge-featured"><i class="fas fa-star"></i> Featured</span>
                    @endif
                </td>
                <td>
                    @if($package->smsGateway)
                        <span class="badge" style="background: #667eea; color: white; padding: 4px 10px; border-radius: 4px; font-size: 11px;">
                            <i class="fas fa-server me-1"></i>{{ $package->smsGateway->gateway_name }}
                        </span>
                    @else
                        <span class="text-muted"><i>Not Set</i></span>
                    @endif
                </td>
                <td><span class="badge-sms">{{ number_format($package->sms_count) }} SMS</span></td>
                <td><span class="badge-price">৳{{ number_format($package->price, 2) }}</span></td>
                <td>৳{{ number_format($package->price / $package->sms_count, 2) }}/SMS</td>
                <td>
                    <form action="{{ route('admin.packages.toggle-status', $package->id) }}" method="POST" id="toggle-form-{{ $package->id }}" style="display: inline;">
                        @csrf
                    </form>
                    <label class="status-toggle">
                        <input type="checkbox" {{ $package->status ? 'checked' : '' }} 
                               onchange="confirmStatusToggle(this, document.getElementById('toggle-form-{{ $package->id }}'), '{{ $package->name }}', {{ $package->status ? 'true' : 'false' }})">
                        <span class="toggle-slider"></span>
                    </label>
                </td>
                <td>
                    <div class="action-buttons">
                        <a href="{{ route('admin.packages.edit', $package->id) }}" class="btn-action edit" title="Edit">
                            <i class="fas fa-edit"></i>
                        </a>
                        <form action="{{ route('admin.packages.destroy', $package->id) }}" 
                              method="POST" 
                              class="d-inline delete-form"
                              id="delete-form-{{ $package->id }}">
                            @csrf
                            @method('DELETE')
                            <button type="button" 
                                    class="btn-action delete" 
                                    title="Delete"
                                    onclick="confirmDelete('Delete Package', 'Are you sure you want to delete {{ $package->name }}?', document.getElementById('delete-form-{{ $package->id }}'))">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="8" class="text-center py-5">
                    <i class="fas fa-box-open fa-3x text-muted mb-3" style="display: block; margin-bottom: 15px;"></i>
                    <p class="text-muted mb-3">No SMS packages found</p>
                    <a href="{{ route('admin.packages.create') }}" class="btn-add-new">Create First Package</a>
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>

@push('scripts')
<script>
function confirmStatusToggle(checkbox, form, packageName, currentStatus) {
    const newStatus = !currentStatus;
    const statusText = newStatus ? 'activate' : 'deactivate';
    
    Swal.fire({
        title: 'Change Package Status?',
        html: `Are you sure you want to <strong>${statusText}</strong> ${packageName}?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: newStatus ? '#26de81' : '#ee5a6f',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: `Yes, ${statusText}!`,
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            showLoading('Updating status...');
            form.submit();
        } else {
            checkbox.checked = currentStatus;
        }
    });
}
</script>
@endpush

@endsection
