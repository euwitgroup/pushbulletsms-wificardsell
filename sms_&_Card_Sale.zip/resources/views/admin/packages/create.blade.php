@extends('admin.layouts.app')

@section('title', 'Create SMS Package')

@section('content')
<style>
    .form-card {
        background: #fff;
        border-radius: 5px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.08);
        overflow: hidden;
    }
    
    .form-card-header {
        background: linear-gradient(135deg, #26de81 0%, #20bf6b 100%);
        padding: 12px 16px;
        color: white;
    }
    
    .form-card-header h4 {
        font-size: 0.95rem;
        font-weight: 600;
        margin: 0;
    }
    
    .form-card-header p {
        font-size: 0.75rem;
        margin: 0;
    }
    
    .form-card-body {
        padding: 16px;
    }
    
    .form-label-custom {
        font-weight: 600;
        color: #2c3e50;
        font-size: 0.8rem;
        margin-bottom: 4px;
    }
    
    .form-control-custom {
        border-radius: 5px;
        border: 1px solid #dcdde1;
        padding: 6px 10px;
        font-size: 0.8rem;
        transition: all 0.2s ease;
        height: auto;
    }
    
    .form-control-custom:focus {
        border-color: #26de81;
        box-shadow: 0 0 0 2px rgba(38, 222, 129, 0.1);
        outline: none;
    }
    
    .btn-submit {
        background: linear-gradient(135deg, #26de81 0%, #20bf6b 100%);
        color: white;
        padding: 6px 16px;
        border-radius: 5px;
        border: none;
        font-weight: 600;
        font-size: 0.8rem;
        transition: all 0.2s ease;
    }
    
    .btn-submit:hover {
        opacity: 0.9;
    }
    
    .btn-cancel {
        background: #f8f9fa;
        color: #495057;
        padding: 6px 16px;
        border-radius: 5px;
        border: 1px solid #dcdde1;
        font-weight: 600;
        font-size: 0.8rem;
        transition: all 0.2s ease;
        text-decoration: none;
    }
    
    .btn-cancel:hover {
        background: #e9ecef;
    }

    .gateway-info-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 5px;
        padding: 10px 12px;
        color: white;
        margin-bottom: 12px;
        display: none;
        font-size: 0.8rem;
    }

    .gateway-info-card.active {
        display: block;
    }
    
    .gateway-info-card h6 {
        font-size: 0.8rem;
        margin-bottom: 2px;
    }
    
    .gateway-info-card p {
        font-size: 0.7rem;
    }

    .form-fields-container {
        display: none;
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .form-fields-container.active {
        display: block;
        opacity: 1;
    }
    
    .alert {
        padding: 8px 12px;
        font-size: 0.75rem;
        border-radius: 5px;
    }
    
    textarea.form-control-custom {
        min-height: 60px;
    }
    
    .breadcrumb {
        background: transparent;
        padding: 0;
        margin-bottom: 12px;
        font-size: 0.8rem;
    }
    
    .breadcrumb-item + .breadcrumb-item::before {
        font-size: 0.75rem;
    }
    
    small.text-muted {
        font-size: 0.7rem;
    }
    
    .invalid-feedback {
        font-size: 0.7rem;
    }
</style>

<!-- Breadcrumb -->
<nav aria-label="breadcrumb" class="mb-2">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
        <li class="breadcrumb-item"><a href="{{ route('admin.packages.index') }}">SMS Packages</a></li>
        <li class="breadcrumb-item active">Create Package</li>
    </ol>
</nav>

<div class="row">
    <div class="col-lg-10 mx-auto">
        <div class="form-card">
            <div class="form-card-header">
                <h4><i class="fas fa-plus-circle me-1"></i>Create New SMS Package</h4>
                <p>Set up a new package with selected gateway pricing</p>
            </div>
            
            <div class="form-card-body">
                <form action="{{ route('admin.packages.store') }}" method="POST" id="packageForm">
                @csrf
                    
                    <div class="row">
                        <!-- Step 1: Gateway Selection -->
                        <div class="col-12 mb-2">
                            <label class="form-label-custom">
                                <i class="fas fa-server me-1 text-primary"></i>Step 1: Select SMS Gateway
                                <span class="text-danger">*</span>
                            </label>
                            <select name="sms_gateway_id" 
                                    id="gatewaySelect" 
                                    class="form-control form-control-custom @error('sms_gateway_id') is-invalid @enderror" 
                                    required>
                                <option value="">-- Select SMS Gateway First --</option>
                                @foreach($gateways as $gateway)
                                    <option value="{{ $gateway->id }}" 
                                            data-cost="{{ $gateway->cost_per_sms }}"
                                            data-name="{{ $gateway->gateway_name }}"
                                            {{ old('sms_gateway_id') == $gateway->id ? 'selected' : '' }}>
                                        {{ $gateway->gateway_name }} 
                                        (৳{{ number_format($gateway->cost_per_sms, 2) }} per SMS)
                                        - {{ $gateway->is_active ? 'Active' : 'Inactive' }}
                                    </option>
                                @endforeach
                            </select>
                            <small class="text-muted">Different gateways have different SMS costs</small>
                            @error('sms_gateway_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <!-- Gateway Info Card -->
                        <div class="col-12">
                            <div class="gateway-info-card" id="gatewayInfoCard">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6>Selected Gateway: <span id="selectedGatewayName"></span></h6>
                                        <p class="mb-0">Cost per SMS: ৳<span id="selectedGatewayCost">0.00</span></p>
                                    </div>
                                    <i class="fas fa-check-circle fa-lg"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Step 2: Package Details (Hidden until gateway selected) -->
                    <div class="form-fields-container" id="packageFields">
                        <div class="alert alert-info mb-2">
                            <i class="fas fa-info-circle me-1"></i>
                            <strong>Step 2:</strong> Enter package details based on selected gateway
                        </div>
                
                <div class="row">
                    <!-- Package Name -->
                            <div class="col-md-12 mb-2">
                                <label class="form-label-custom">
                                    <i class="fas fa-tag me-1 text-primary"></i>Package Name
                                    <span class="text-danger">*</span>
                                </label>
                        <input type="text" 
                               name="name" 
                                       id="packageName"
                                       class="form-control form-control-custom @error('name') is-invalid @enderror" 
                               value="{{ old('name') }}"
                               placeholder="e.g., Starter Package"
                               required>
                        @error('name')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <!-- Description -->
                            <div class="col-md-12 mb-2">
                                <label class="form-label-custom">
                                    <i class="fas fa-align-left me-1 text-success"></i>Description
                                </label>
                        <textarea name="description" 
                                          class="form-control form-control-custom @error('description') is-invalid @enderror" 
                                          rows="2"
                                  placeholder="Describe the package">{{ old('description') }}</textarea>
                        @error('description')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <!-- SMS Count -->
                            <div class="col-md-6 mb-2">
                                <label class="form-label-custom">
                                    <i class="fas fa-sms me-1 text-info"></i>SMS Count
                                    <span class="text-danger">*</span>
                                </label>
                        <input type="number" 
                               name="sms_count" 
                                       id="smsCount"
                                       class="form-control form-control-custom @error('sms_count') is-invalid @enderror" 
                               value="{{ old('sms_count') }}"
                               placeholder="e.g., 1000"
                               min="1"
                               required>
                        <small class="text-muted">Number of SMS credits in this package</small>
                        @error('sms_count')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                            <!-- Price (Can be adjusted) -->
                            <div class="col-md-6 mb-2">
                                <label class="form-label-custom">
                                    <i class="fas fa-dollar-sign me-1 text-warning"></i>Final Package Price (৳)
                                    <span class="text-danger">*</span>
                                </label>
                        <input type="number" 
                               name="price" 
                                       id="packagePrice"
                                       class="form-control form-control-custom @error('price') is-invalid @enderror" 
                               value="{{ old('price') }}"
                                       placeholder="Auto-calculated"
                               step="0.01"
                               min="0.01"
                               required>
                                <small class="text-muted">Auto-calculated: <span id="calculatedPrice">0.00</span> (SMS × Gateway Cost)</small>
                        @error('price')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <!-- Is Featured -->
                            <div class="col-md-6 mb-2">
                                <label class="form-label-custom">
                                    <i class="fas fa-star me-1 text-danger"></i>Featured Package
                                </label>
                                <select name="is_featured" class="form-control form-control-custom @error('is_featured') is-invalid @enderror">
                            <option value="0" {{ old('is_featured', '0') == '0' ? 'selected' : '' }}>No</option>
                            <option value="1" {{ old('is_featured') == '1' ? 'selected' : '' }}>Yes</option>
                        </select>
                        <small class="text-muted">Mark as most popular package</small>
                        @error('is_featured')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <!-- Status -->
                            <div class="col-md-6 mb-2">
                                <label class="form-label-custom">
                                    <i class="fas fa-toggle-on me-1 text-success"></i>Status
                                    <span class="text-danger">*</span>
                                </label>
                                <select name="status" class="form-control form-control-custom @error('status') is-invalid @enderror" required>
                            <option value="1" {{ old('status', '1') == '1' ? 'selected' : '' }}>Active</option>
                            <option value="0" {{ old('status') == '0' ? 'selected' : '' }}>Inactive</option>
                        </select>
                        <small class="text-muted">Only active packages are visible to users</small>
                        @error('status')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                            </div>
                    </div>
                </div>
                
                <!-- Action Buttons -->
                    <div class="d-flex gap-2 justify-content-end pt-2 mt-2 border-top">
                        <a href="{{ route('admin.packages.index') }}" class="btn btn-cancel">
                            <i class="fas fa-times me-1"></i>Cancel
                    </a>
                        <button type="submit" class="btn btn-submit" id="submitBtn" disabled>
                            <i class="fas fa-save me-1"></i>Create Package
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const gatewaySelect = document.getElementById('gatewaySelect');
    const gatewayInfoCard = document.getElementById('gatewayInfoCard');
    const packageFields = document.getElementById('packageFields');
    const submitBtn = document.getElementById('submitBtn');
    const smsCount = document.getElementById('smsCount');
    const packagePrice = document.getElementById('packagePrice');
    
    let currentCostPerSms = 0;

    // Initialize if gateway is already selected (e.g., after validation error)
    if (gatewaySelect.value) {
        handleGatewayChange();
    }

    // Gateway selection change
    gatewaySelect.addEventListener('change', handleGatewayChange);

    function handleGatewayChange() {
        const selectedOption = gatewaySelect.options[gatewaySelect.selectedIndex];
        
        if (selectedOption.value) {
            const cost = parseFloat(selectedOption.dataset.cost);
            const name = selectedOption.dataset.name;
            
            currentCostPerSms = cost;
            
            // Show gateway info
            document.getElementById('selectedGatewayName').textContent = name;
            document.getElementById('selectedGatewayCost').textContent = cost.toFixed(2);
            gatewayInfoCard.classList.add('active');
            
            // Show package fields
            packageFields.classList.add('active');
            submitBtn.disabled = false;
            
            // Calculate price if SMS count is set
            calculatePrice();
            
            // Scroll to package fields smoothly
            setTimeout(() => {
                packageFields.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }, 300);
        } else {
            // Hide everything if no gateway selected
            gatewayInfoCard.classList.remove('active');
            packageFields.classList.remove('active');
            submitBtn.disabled = true;
        }
    }

    // SMS Count change
    smsCount.addEventListener('input', calculatePrice);

    function calculatePrice() {
        const count = parseInt(smsCount.value) || 0;
        const calculated = count * currentCostPerSms;
        
        // Update display
        document.getElementById('calculatedPrice').textContent = '৳' + calculated.toFixed(2);
        
        // Update price input
        packagePrice.value = calculated.toFixed(2);
    }

    // Allow manual price adjustment with warning
    packagePrice.addEventListener('focus', function() {
        if (this.value) {
            const calculated = (parseInt(smsCount.value) || 0) * currentCostPerSms;
            const current = parseFloat(this.value);
            
            if (Math.abs(calculated - current) > 0.01) {
                Swal.fire({
                    icon: 'info',
                    title: 'Custom Pricing',
                    text: 'You are about to modify the auto-calculated price. Make sure this is intentional.',
                    confirmButtonColor: '#26de81',
                    confirmButtonText: 'OK, I understand'
                });
            }
        }
    });
});
</script>
@endsection
