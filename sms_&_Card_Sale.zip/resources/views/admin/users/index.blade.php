@extends('admin.layouts.app')

@section('title', 'Manage Users')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .breadcrumb-nav a:hover {
        color: #3498db;
    }
    
    .table-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .btn-add-new {
        background: #26de81;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s ease;
    }
    
    .btn-add-new:hover {
        background: #20bf6b;
        transform: translateY(-1px);
    }
    
    .table-filters {
        display: flex;
        gap: 10px;
    }
    
    .filter-select {
        padding: 6px 12px;
        border: 1px solid #dcdde1;
        border-radius: 4px;
        font-size: 12px;
        color: #7f8c8d;
        background: white;
        min-width: 130px;
    }
    
    .search-box {
        position: relative;
        display: flex;
        gap: 6px;
    }
    
    .search-input {
        padding: 6px 35px 6px 12px;
        border: 1px solid #dcdde1;
        border-radius: 4px;
        font-size: 12px;
        width: 220px;
    }
    
    .search-btn {
        position: absolute;
        right: 45px;
        top: 50%;
        transform: translateY(-50%);
        background: #3498db;
        color: white;
        border: none;
        padding: 5px 10px;
        border-radius: 3px;
        cursor: pointer;
        font-size: 12px;
    }
    
    .btn-icon {
        background: #3498db;
        color: white;
        border: none;
        padding: 6px 10px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
    }
    
    .btn-icon.red {
        background: #ee5a6f;
    }
    
    .users-table-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .users-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .users-table thead th {
        background: #f8f9fa;
        padding: 12px 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: #7f8c8d;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .users-table tbody td {
        padding: 14px 16px;
        font-size: 13px;
        color: #2c3e50;
        border-bottom: 1px solid #f1f2f6;
        vertical-align: middle;
    }
    
    .users-table tbody tr:hover {
        background: #fafbfc;
    }
    
    .user-avatar {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        background: #ecf0f1;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 11px;
        font-weight: 600;
        color: #7f8c8d;
        margin-right: 10px;
    }
    
    .user-name {
        font-weight: 500;
        color: #2c3e50;
        margin-bottom: 2px;
        font-size: 13px;
    }
    
    .user-email {
        font-size: 12px;
        color: #2c3e50;
        margin: 0;
    }
    
    .user-phone {
        font-size: 12px;
        color: #3498db;
        display: block;
        margin-top: 2px;
    }
    
    .badge-balance {
        background: #8854d0;
        color: white;
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 500;
        display: inline-block;
    }
    
    .badge-system {
        background: #26de81;
        color: white;
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 500;
        display: inline-block;
    }
    
    .status-toggle {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 22px;
    }
    
    .status-toggle input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .toggle-slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .3s;
        border-radius: 24px;
    }
    
    .toggle-slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: .3s;
        border-radius: 50%;
    }
    
    input:checked + .toggle-slider {
        background-color: #8854d0;
    }
    
    input:checked + .toggle-slider:before {
        transform: translateX(18px);
    }
    
    .action-buttons {
        display: flex;
        gap: 6px;
    }
    
    .btn-action {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 12px;
    }
    
    .btn-action:hover {
        transform: scale(1.1);
    }
    
    .btn-action.view {
        background: #d4f1f4;
        color: #05c3dd;
    }
    
    .btn-action.edit {
        background: #ffeaa7;
        color: #fdcb6e;
    }
    
    .btn-action.delete {
        background: #ffcccc;
        color: #ee5a6f;
    }
    
    .pagination-wrapper {
        padding: 15px;
        display: flex;
        justify-content: flex-end;
    }
</style>

<!-- Breadcrumb -->
<div class="page-breadcrumb">
    <h1 class="page-title">Manage Users</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > <span>Users</span>
    </div>
</div>

<!-- Table Controls -->
<div class="table-controls">
    <a href="{{ route('admin.users.create') }}" class="btn-add-new">
        <i class="fas fa-plus"></i> Add New
    </a>
    
    <div class="table-filters">
        <div class="search-box">
            <input type="text" 
                   class="search-input" 
                   placeholder="Search by Name,email,ph...."
                   name="search"
                   value="{{ request('search') }}">
            <button class="search-btn"><i class="fas fa-search"></i></button>
            <button class="btn-icon"><i class="fas fa-filter"></i></button>
            <button class="btn-icon red"><i class="fas fa-file-pdf"></i></button>
        </div>
    </div>
</div>

<!-- Users Table -->
<div class="users-table-card">
    <table class="users-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email - Phone</th>
                <th>Country</th>
                <th>Balance</th>
                <th>Created By</th>
                <th>Status</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
            @forelse($users as $index => $user)
            <tr>
                <td>{{ $users->firstItem() + $index }}</td>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="user-avatar">
                            {{ strtoupper(substr($user->name, 0, 2)) }}
                        </div>
                        <span class="user-name">{{ $user->name }}</span>
                    </div>
                </td>
                <td>
                    <div class="user-email">{{ $user->email }}</div>
                    <span class="user-phone">{{ $user->phone ?? 'N/A' }}</span>
                </td>
                <td>{{ $user->country ?? 'Bangladesh' }}</td>
                <td>
                    <span class="badge-balance">৳{{ number_format($user->balance, 2) }}</span>
                </td>
                <td>
                    <span class="badge-system">System</span>
                </td>
                <td>
                    <label class="status-toggle">
                        <input type="checkbox" {{ $user->status ? 'checked' : '' }} 
                               onchange="confirmStatusToggle(this, '{{ route('admin.users.toggle-status', $user->id) }}', '{{ $user->name }}', {{ $user->status ? 'true' : 'false' }})">
                        <span class="toggle-slider"></span>
                    </label>
                </td>
                <td>
                    <div class="action-buttons">
                        <a href="{{ route('admin.users.show', $user->id) }}" class="btn-action view" title="View">
                            <i class="fas fa-eye"></i>
                        </a>
                        <a href="{{ route('admin.users.edit', $user->id) }}" class="btn-action edit" title="Edit">
                            <i class="fas fa-edit"></i>
                        </a>
                        @if($user->id != auth()->id())
                        <form action="{{ route('admin.users.destroy', $user->id) }}" 
                              method="POST" 
                              class="d-inline delete-form"
                              id="delete-form-{{ $user->id }}">
                            @csrf
                            @method('DELETE')
                            <button type="button" 
                                    class="btn-action delete" 
                                    title="Delete"
                                    onclick="confirmDelete('Delete User', 'Are you sure you want to delete {{ $user->name }}?', document.getElementById('delete-form-{{ $user->id }}'))">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                        @endif
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="8" class="text-center py-5">
                    <p class="text-muted">No users found</p>
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
    
    <!-- Pagination -->
    @if($users->hasPages())
    <div class="pagination-wrapper">
        {{ $users->links() }}
    </div>
    @endif
</div>

@push('scripts')
<script>
function confirmStatusToggle(checkbox, url, userName, currentStatus) {
    const newStatus = !currentStatus;
    const statusText = newStatus ? 'activate' : 'deactivate';
    
    Swal.fire({
        title: 'Change User Status?',
        html: `Are you sure you want to <strong>${statusText}</strong> ${userName}?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: newStatus ? '#26de81' : '#ee5a6f',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: `Yes, ${statusText}!`,
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            showLoading('Updating status...');
            window.location.href = url;
        } else {
            // Revert checkbox
            checkbox.checked = currentStatus;
        }
    });
}
</script>
@endpush

@endsection
