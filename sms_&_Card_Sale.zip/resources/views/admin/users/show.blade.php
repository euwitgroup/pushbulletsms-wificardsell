@extends('admin.layouts.app')

@section('title', 'Show Users')

@section('content')
<style>
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .user-info-card {
        background: white;
        border-radius: 8px;
        padding: 24px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .user-avatar-large {
        width: 120px;
        height: 120px;
        border-radius: 50%;
        background: #ecf0f1;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 32px;
        font-weight: 700;
        color: #7f8c8d;
        margin: 0 auto 20px;
    }
    
    .user-name-display {
        text-align: center;
        font-size: 16px;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 8px;
    }
    
    .user-email-display {
        text-align: center;
        font-size: 13px;
        color: #7f8c8d;
        margin-bottom: 20px;
    }
    
    .balance-display {
        text-align: center;
        margin-bottom: 20px;
    }
    
    .balance-label {
        font-size: 12px;
        color: #7f8c8d;
        margin-bottom: 5px;
    }
    
    .balance-amount {
        font-size: 24px;
        font-weight: 700;
        color: #8854d0;
        background: #8854d0;
        color: white;
        padding: 8px 16px;
        border-radius: 6px;
        display: inline-block;
    }
    
    .user-detail-row {
        display: flex;
        padding: 10px 0;
        border-bottom: 1px solid #f1f3f5;
        font-size: 13px;
    }
    
    .user-detail-row:last-child {
        border-bottom: none;
    }
    
    .detail-label {
        color: #7f8c8d;
        min-width: 100px;
    }
    
    .detail-value {
        color: #2c3e50;
        font-weight: 500;
    }
    
    .btn-update-profile {
        width: 100%;
        padding: 10px;
        background: #8854d0;
        color: white;
        border: none;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }
    
    .subscription-box {
        background: #8854d0;
        color: white;
        padding: 20px;
        border-radius: 8px;
        text-align: center;
        margin-bottom: 15px;
    }
    
    .subscription-title {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 15px;
    }
    
    .btn-update-subscription {
        width: 100%;
        padding: 10px;
        background: rgba(255,255,255,0.2);
        color: white;
        border: none;
        border-radius: 6px;
        font-size: 13px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }
    
    .stat-card {
        background: white;
        border-radius: 8px;
        padding: 20px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        margin-bottom: 20px;
    }
    
    .stat-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
    }
    
    .stat-title {
        font-size: 14px;
        color: #7f8c8d;
        margin: 0;
    }
    
    .stat-icon {
        width: 45px;
        height: 45px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        color: white;
    }
    
    .stat-value {
        font-size: 28px;
        font-weight: 700;
        color: #2c3e50;
        margin-bottom: 10px;
    }
    
    .stat-link {
        color: #3498db;
        font-size: 12px;
        text-decoration: none;
    }
    
    .chart-card {
        background: white;
        border-radius: 8px;
        padding: 20px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        margin-bottom: 20px;
    }
    
    .chart-title {
        font-size: 16px;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 20px;
    }
    
    .action-buttons-bottom {
        display: flex;
        gap: 15px;
        margin-top: 20px;
    }
    
    .btn-deposit {
        flex: 1;
        padding: 12px;
        background: #26de81;
        color: white;
        border: none;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }
    
    .btn-withdraw {
        flex: 1;
        padding: 12px;
        background: #ee5a6f;
        color: white;
        border: none;
        border-radius: 6px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
    }
</style>

<!-- Breadcrumb -->
<div class="page-breadcrumb">
    <h1 class="page-title">Show Users</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > 
        <a href="{{ route('admin.users.index') }}">Users</a> > 
        <span>Show</span>
    </div>
</div>

<div class="row">
    <!-- Left Sidebar - User Info -->
    <div class="col-lg-3">
        <div class="user-info-card">
            <h6 style="font-size: 14px; font-weight: 600; color: #2c3e50; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 1px solid #ecf0f1;">User Information</h6>
            
            <div class="user-avatar-large">
                {{ strtoupper(substr($user->name, 0, 2)) }}
            </div>
            
            <div class="user-name-display">{{ $user->name }}</div>
            <div class="user-email-display">{{ $user->email }}</div>
            
            <div class="balance-display">
                <div class="balance-label">Balance :</div>
                <div class="balance-amount">৳{{ number_format($user->balance, 2) }}</div>
            </div>
            
            <div style="margin: 20px 0;">
                <div class="user-detail-row">
                    <div class="detail-label">Name :</div>
                    <div class="detail-value">{{ $user->name }}</div>
                </div>
                <div class="user-detail-row">
                    <div class="detail-label">Username :</div>
                    <div class="detail-value">--</div>
                </div>
                <div class="user-detail-row">
                    <div class="detail-label">Phone :</div>
                    <div class="detail-value">{{ $user->phone ?? '--' }}</div>
                </div>
                <div class="user-detail-row">
                    <div class="detail-label">Email :</div>
                    <div class="detail-value" style="word-break: break-all;">{{ $user->email }}</div>
                </div>
                <div class="user-detail-row">
                    <div class="detail-label">Country :</div>
                    <div class="detail-value">{{ $user->country ?? 'Bangladesh' }}</div>
                </div>
            </div>
            
            <a href="{{ route('admin.users.edit', $user->id) }}" class="btn-update-profile">
                <i class="fas fa-user"></i> Update Profile
            </a>
            
            <div class="subscription-box">
                <div class="subscription-title">SMS Balance</div>
                <div style="font-size: 24px; font-weight: 700; margin-bottom: 15px;">৳{{ number_format($user->balance, 2) }}</div>
                <a href="{{ route('admin.users.edit', $user->id) }}" class="btn-update-subscription">
                    <i class="fas fa-wallet"></i> Manage Balance
                </a>
            </div>
        </div>
    </div>
    
    <!-- Right Content - Stats -->
    <div class="col-lg-9">
        <div class="row">
            <!-- Total SMS Sent -->
            <div class="col-lg-4 col-md-6">
                <div class="stat-card">
                    <div class="stat-header">
                        <h6 class="stat-title">Total SMS Sent</h6>
                        <div class="stat-icon" style="background: #8854d0;">
                            <i class="fas fa-sms"></i>
                        </div>
                    </div>
                    <div class="stat-value">{{ $user->smsHistory()->where('status', 'sent')->count() }}</div>
                    <a href="#" class="stat-link">View All</a>
                </div>
            </div>
            
            <!-- SMS Failed -->
            <div class="col-lg-4 col-md-6">
                <div class="stat-card">
                    <div class="stat-header">
                        <h6 class="stat-title">SMS Failed</h6>
                        <div class="stat-icon" style="background: #ee5a6f;">
                            <i class="fas fa-times-circle"></i>
                        </div>
                    </div>
                    <div class="stat-value">{{ $user->smsHistory()->where('status', 'failed')->count() }}</div>
                    <a href="#" class="stat-link">View All</a>
                </div>
            </div>
            
            <!-- Balance Deposits -->
            <div class="col-lg-4 col-md-6">
                <div class="stat-card">
                    <div class="stat-header">
                        <h6 class="stat-title">Deposit Logs</h6>
                        <div class="stat-icon" style="background: #26de81;">
                            <i class="fas fa-arrow-down"></i>
                        </div>
                    </div>
                    <div class="stat-value">{{ $user->transactions()->where('type', 'credit')->count() }}</div>
                    <a href="#" class="stat-link">View All</a>
                </div>
            </div>
            
            <!-- SMS Pending -->
            <div class="col-lg-4 col-md-6">
                <div class="stat-card">
                    <div class="stat-header">
                        <h6 class="stat-title">SMS Pending</h6>
                        <div class="stat-icon" style="background: #ffc107;">
                            <i class="fas fa-clock"></i>
                        </div>
                    </div>
                    <div class="stat-value">{{ $user->smsHistory()->where('status', 'pending')->count() }}</div>
                    <a href="#" class="stat-link">View All</a>
                </div>
            </div>
            
            <!-- Total SMS -->
            <div class="col-lg-4 col-md-6">
                <div class="stat-card">
                    <div class="stat-header">
                        <h6 class="stat-title">Total SMS</h6>
                        <div class="stat-icon" style="background: #3498db;">
                            <i class="fas fa-envelope"></i>
                        </div>
                    </div>
                    <div class="stat-value">{{ $user->smsHistory()->count() }}</div>
                    <a href="#" class="stat-link">View All</a>
                </div>
            </div>
            
            <!-- Total Transactions -->
            <div class="col-lg-4 col-md-6">
                <div class="stat-card">
                    <div class="stat-header">
                        <h6 class="stat-title">Total Transactions</h6>
                        <div class="stat-icon" style="background: #fa8c79;">
                            <i class="fas fa-exchange-alt"></i>
                        </div>
                    </div>
                    <div class="stat-value">{{ $user->transactions()->count() }}</div>
                    <a href="#" class="stat-link">View All</a>
                </div>
            </div>
        </div>
        
        <!-- Chart -->
        <div class="chart-card">
            <h6 class="chart-title">SMS Activity Statistics (Current Year)</h6>
            <canvas id="userStatsChart" height="80"></canvas>
        </div>
        
        <!-- Action Buttons -->
        <div class="action-buttons-bottom">
            <form action="{{ route('admin.users.add-balance', $user->id) }}" method="POST" id="add-balance-form" style="flex: 1;">
                @csrf
                <input type="hidden" name="amount" id="balance-amount">
                <button type="button" class="btn-deposit" onclick="openBalanceDialog()">
                    <i class="fas fa-plus-circle"></i> Add Balance
                </button>
            </form>
            <a href="{{ route('admin.transactions') }}" class="btn-withdraw" style="text-decoration: none;">
                <i class="fas fa-history"></i> View Transactions
            </a>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
// SMS Activity Chart
const ctx = document.getElementById('userStatsChart');
if (ctx) {
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['January', 'February', 'March', 'April'],
            datasets: [{
                label: 'Sent SMS',
                data: [0.5, 1.5, 1, 2],
                borderColor: '#26de81',
                backgroundColor: 'rgba(38, 222, 129, 0.1)',
                tension: 0.4
            }, {
                label: 'Failed SMS',
                data: [0.2, 0.3, 0.2, 0.4],
                borderColor: '#ee5a6f',
                backgroundColor: 'rgba(238, 90, 111, 0.1)',
                tension: 0.4
            }, {
                label: 'Pending SMS',
                data: [0.3, 0.2, 0.4, 0.3],
                borderColor: '#ffc107',
                backgroundColor: 'rgba(255, 193, 7, 0.1)',
                tension: 0.4
            }, {
                label: 'Total Revenue',
                data: [1.2, 0.8, 1.3, 1.1],
                borderColor: '#8854d0',
                backgroundColor: 'rgba(136, 84, 208, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Add Balance Dialog
function openBalanceDialog() {
    Swal.fire({
        title: 'Add Balance to {{ $user->name }}',
        html: `
            <div style="text-align: left; margin-bottom: 15px;">
                <label style="display: block; margin-bottom: 5px; font-weight: 500;">Amount (৳)</label>
                <input type="number" id="swal-amount" class="swal2-input" placeholder="Enter amount" min="0.01" step="0.01" style="width: 100%; margin: 0;">
            </div>
            <div style="text-align: left;">
                <label style="display: block; margin-bottom: 5px; font-weight: 500;">Description (Optional)</label>
                <textarea id="swal-description" class="swal2-textarea" placeholder="Enter description" style="width: 100%; margin: 0;"></textarea>
            </div>
        `,
        showCancelButton: true,
        confirmButtonColor: '#26de81',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: '<i class="fas fa-check me-2"></i>Add Balance',
        cancelButtonText: 'Cancel',
        preConfirm: () => {
            const amount = document.getElementById('swal-amount').value;
            const description = document.getElementById('swal-description').value;
            
            if (!amount || amount <= 0) {
                Swal.showValidationMessage('Please enter a valid amount');
                return false;
            }
            
            return { amount, description };
        }
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('balance-amount').value = result.value.amount;
            
            // Add description if provided
            if (result.value.description) {
                const descInput = document.createElement('input');
                descInput.type = 'hidden';
                descInput.name = 'description';
                descInput.value = result.value.description;
                document.getElementById('add-balance-form').appendChild(descInput);
            }
            
            // Show loading
            Swal.fire({
                title: 'Processing...',
                html: 'Adding balance to user account',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });
            
            // Submit form
            document.getElementById('add-balance-form').submit();
        }
    });
}
</script>
@endpush
