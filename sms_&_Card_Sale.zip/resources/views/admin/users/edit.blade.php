@extends('admin.layouts.app')

@section('title', 'Edit User')

@section('content')
<style>
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .form-card {
        background: white;
        border-radius: 8px;
        padding: 24px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .form-section-title {
        font-size: 14px;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .form-label {
        font-size: 13px;
        color: #7f8c8d;
        margin-bottom: 6px;
        font-weight: 500;
    }
    
    .form-control {
        border-radius: 6px;
        border: 1px solid #dcdde1;
        padding: 8px 12px;
        font-size: 13px;
        transition: all 0.2s ease;
    }
    
    .form-control:focus {
        border-color: #3498db;
        box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.1);
    }
    
    .btn-submit {
        background: #3498db;
        color: white;
        padding: 10px 24px;
        border-radius: 6px;
        border: none;
        font-weight: 500;
        font-size: 14px;
        transition: all 0.2s ease;
    }
    
    .btn-submit:hover {
        background: #2980b9;
        transform: translateY(-1px);
    }
    
    .btn-cancel {
        background: #f8f9fa;
        color: #7f8c8d;
        padding: 10px 24px;
        border-radius: 6px;
        border: 1px solid #dcdde1;
        font-weight: 500;
        font-size: 14px;
        transition: all 0.2s ease;
        text-decoration: none;
    }
    
    .btn-cancel:hover {
        background: #e9ecef;
    }
</style>

<!-- Breadcrumb -->
<div class="page-breadcrumb">
    <h1 class="page-title">Edit User</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > 
        <a href="{{ route('admin.users.index') }}">Users</a> > 
        <span>Edit</span>
    </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="form-card">
            <h6 class="form-section-title">Update User: {{ $user->name }}</h6>
            <form action="{{ route('admin.users.update', $user->id) }}" method="POST">
                @csrf
                @method('PUT')
                
                <div class="row">
                    <!-- Name -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Full Name</label>
                        <input type="text" 
                               name="name" 
                               class="form-control @error('name') is-invalid @enderror" 
                               value="{{ old('name', $user->name) }}"
                               placeholder="Enter full name"
                               required>
                        @error('name')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <!-- Email -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Email Address</label>
                        <input type="email" 
                               name="email" 
                               class="form-control @error('email') is-invalid @enderror" 
                               value="{{ old('email', $user->email) }}"
                               placeholder="user@example.com"
                               required>
                        @error('email')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <!-- Password -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">New Password</label>
                        <input type="password" 
                               name="password" 
                               class="form-control @error('password') is-invalid @enderror" 
                               placeholder="Leave blank to keep current">
                        <small class="text-muted">Only fill if you want to change password</small>
                        @error('password')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <!-- Confirm Password -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Confirm New Password</label>
                        <input type="password" 
                               name="password_confirmation" 
                               class="form-control" 
                               placeholder="Confirm new password">
                    </div>
                    
                    <!-- Role -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Role</label>
                        <select name="role" class="form-control @error('role') is-invalid @enderror" required>
                            <option value="user" {{ old('role', $user->role) == 'user' ? 'selected' : '' }}>User</option>
                            <option value="admin" {{ old('role', $user->role) == 'admin' ? 'selected' : '' }}>Admin</option>
                        </select>
                        @error('role')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <!-- Status -->
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-control @error('status') is-invalid @enderror" required>
                            <option value="1" {{ old('status', $user->status) == '1' ? 'selected' : '' }}>Active</option>
                            <option value="0" {{ old('status', $user->status) == '0' ? 'selected' : '' }}>Inactive</option>
                        </select>
                        @error('status')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <!-- Balance -->
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Current Balance (৳)</label>
                        <input type="number" 
                               name="balance" 
                               class="form-control @error('balance') is-invalid @enderror" 
                               value="{{ old('balance', $user->balance) }}"
                               step="0.01"
                               min="0"
                               placeholder="0.00">
                        <small class="text-muted">Update user balance</small>
                        @error('balance')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <!-- Action Buttons -->
                <div class="d-flex gap-2 justify-content-end pt-3 mt-3 border-top">
                    <a href="{{ route('admin.users.index') }}" class="btn-cancel">
                        <i class="fas fa-times me-2"></i>Cancel
                    </a>
                    <button type="submit" class="btn-submit">
                        <i class="fas fa-check me-2"></i>Update User
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
