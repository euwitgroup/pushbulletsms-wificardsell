@extends('admin.layouts.app')

@section('title', 'Invoices')

@section('content')
<!-- Page Header -->
<div class="mb-4">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h2><i class="fas fa-file-invoice me-2"></i>Invoices</h2>
            <p class="text-muted">Manage all payment invoices</p>
        </div>
        <div class="d-flex gap-2">
            <a href="{{ route('admin.invoices.export', ['format' => 'excel']) }}" class="btn btn-success">
                <i class="fas fa-file-excel me-1"></i>Export Excel
            </a>
            <a href="{{ route('admin.invoices.export', ['format' => 'pdf']) }}" class="btn btn-danger">
                <i class="fas fa-file-pdf me-1"></i>Export PDF
            </a>
        </div>
    </div>
</div>

<!-- Filters -->
<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="{{ route('admin.invoices') }}">
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-control" onchange="this.form.submit()">
                        <option value="">All Status</option>
                        <option value="paid" {{ request('status') == 'paid' ? 'selected' : '' }}>Paid</option>
                        <option value="unpaid" {{ request('status') == 'unpaid' ? 'selected' : '' }}>Unpaid</option>
                        <option value="cancelled" {{ request('status') == 'cancelled' ? 'selected' : '' }}>Cancelled</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Date From</label>
                    <input type="date" name="date_from" class="form-control" value="{{ request('date_from') }}" onchange="this.form.submit()">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Date To</label>
                    <input type="date" name="date_to" class="form-control" value="{{ request('date_to') }}" onchange="this.form.submit()">
                </div>
                <div class="col-md-3">
                    <label class="form-label">User</label>
                    <input type="text" name="user" class="form-control" value="{{ request('user') }}" placeholder="Search by name or email" onchange="this.form.submit()">
                </div>
            </div>
            @if(request()->hasAny(['status', 'date_from', 'date_to', 'user']))
            <div class="mt-3">
                <a href="{{ route('admin.invoices') }}" class="btn btn-sm btn-outline-secondary">
                    <i class="fas fa-times me-1"></i>Clear Filters
                </a>
            </div>
            @endif
        </form>
    </div>
</div>

<!-- Invoices Table -->
<div class="card">
    <div class="card-header bg-white">
        <h5 class="mb-0"><i class="fas fa-list me-2"></i>All Invoices</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Invoice #</th>
                        <th>User</th>
                        <th>Package</th>
                        <th>Amount</th>
                        <th>Payment Method</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($invoices as $invoice)
                    <tr>
                        <td><strong>#INV-{{ str_pad($invoice->id, 6, '0', STR_PAD_LEFT) }}</strong></td>
                        <td>
                            <strong>{{ $invoice->user->name ?? 'N/A' }}</strong><br>
                            <small class="text-muted">{{ $invoice->user->email ?? '' }}</small>
                        </td>
                        <td>
                            {{ $invoice->package_name ?? 'N/A' }}<br>
                            <small class="text-muted">{{ $invoice->sms_count ?? 0 }} SMS</small>
                        </td>
                        <td class="fw-bold">৳{{ number_format($invoice->amount, 2) }}</td>
                        <td>
                            <span class="badge bg-info">
                                {{ ucfirst($invoice->payment_method ?? 'N/A') }}
                            </span>
                        </td>
                        <td>
                            <span class="badge bg-{{ $invoice->status == 'paid' ? 'success' : ($invoice->status == 'cancelled' ? 'danger' : 'warning') }}">
                                {{ ucfirst($invoice->status) }}
                            </span>
                        </td>
                        <td>
                            {{ $invoice->created_at->format('M d, Y') }}<br>
                            <small class="text-muted">{{ $invoice->created_at->format('h:i A') }}</small>
                        </td>
                        <td>
                            <div class="btn-group">
                                <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#invoiceModal{{ $invoice->id }}" title="View Invoice">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <a href="{{ route('admin.invoices.download', $invoice->id) }}" class="btn btn-sm btn-success" title="Download PDF">
                                    <i class="fas fa-download"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="8" class="text-center py-5">
                            <i class="fas fa-inbox fa-3x text-muted mb-3 d-block"></i>
                            <p class="text-muted">No invoices found</p>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if($invoices->hasPages())
        <div class="mt-3">
            {{ $invoices->links() }}
        </div>
        @endif
    </div>
</div>

<!-- Invoice Detail Modals -->
@foreach($invoices as $invoice)
<div class="modal fade" id="invoiceModal{{ $invoice->id }}" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">
                    <i class="fas fa-file-invoice me-2"></i>Invoice #INV-{{ str_pad($invoice->id, 6, '0', STR_PAD_LEFT) }}
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <!-- Invoice Header -->
                <div class="row mb-4">
                    <div class="col-6">
                        <h6 class="text-muted">FROM</h6>
                        <strong>{{ config('app.name') }}</strong><br>
                        <small class="text-muted">{{ $settings['site_email'] ?? 'admin@example.com' }}</small>
                    </div>
                    <div class="col-6 text-end">
                        <h6 class="text-muted">TO</h6>
                        <strong>{{ $invoice->user->name ?? 'N/A' }}</strong><br>
                        <small class="text-muted">{{ $invoice->user->email ?? '' }}</small>
                    </div>
                </div>

                <!-- Invoice Details -->
                <div class="row mb-4">
                    <div class="col-6">
                        <label class="text-muted small">Invoice Number</label>
                        <div class="fw-bold">#INV-{{ str_pad($invoice->id, 6, '0', STR_PAD_LEFT) }}</div>
                    </div>
                    <div class="col-6">
                        <label class="text-muted small">Invoice Date</label>
                        <div class="fw-bold">{{ $invoice->created_at->format('F d, Y') }}</div>
                    </div>
                </div>

                <!-- Items -->
                <table class="table table-bordered">
                    <thead class="table-light">
                        <tr>
                            <th>Description</th>
                            <th class="text-end">Quantity</th>
                            <th class="text-end">Rate</th>
                            <th class="text-end">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <strong>{{ $invoice->package_name ?? 'SMS Package' }}</strong><br>
                                <small class="text-muted">SMS Credits</small>
                            </td>
                            <td class="text-end">{{ $invoice->sms_count ?? 0 }}</td>
                            <td class="text-end">৳{{ number_format($invoice->amount / max($invoice->sms_count, 1), 2) }}</td>
                            <td class="text-end fw-bold">৳{{ number_format($invoice->amount, 2) }}</td>
                        </tr>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="3" class="text-end">Total</th>
                            <th class="text-end">৳{{ number_format($invoice->amount, 2) }}</th>
                        </tr>
                    </tfoot>
                </table>

                <!-- Payment Info -->
                <div class="row">
                    <div class="col-6">
                        <label class="text-muted small">Payment Method</label>
                        <div class="fw-bold">{{ ucfirst($invoice->payment_method ?? 'N/A') }}</div>
                    </div>
                    <div class="col-6">
                        <label class="text-muted small">Status</label>
                        <div>
                            <span class="badge bg-{{ $invoice->status == 'paid' ? 'success' : ($invoice->status == 'cancelled' ? 'danger' : 'warning') }} fs-6">
                                {{ ucfirst($invoice->status) }}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <a href="{{ route('admin.invoices.download', $invoice->id) }}" class="btn btn-success">
                    <i class="fas fa-download me-1"></i>Download PDF
                </a>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="fas fa-times me-1"></i>Close
                </button>
            </div>
        </div>
    </div>
</div>
@endforeach

@endsection
