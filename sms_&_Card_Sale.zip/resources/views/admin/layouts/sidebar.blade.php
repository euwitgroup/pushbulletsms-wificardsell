<style>
    .sidebar {
        position: fixed;
        top: 0;
        left: 0;
        width: 260px;
        height: 100vh;
        background: #3f4d67;
        color: #fff;
        overflow-y: auto;
        z-index: 1000;
        transition: all 0.3s ease;
    }
    
    .sidebar::-webkit-scrollbar {
        width: 6px;
    }
    
    .sidebar::-webkit-scrollbar-track {
        background: rgba(255,255,255,0.05);
    }
    
    .sidebar::-webkit-scrollbar-thumb {
        background: rgba(255,255,255,0.2);
        border-radius: 3px;
    }
    
    .sidebar-brand {
        padding: 20px 24px;
        display: flex;
        align-items: center;
        gap: 10px;
        border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    
    .sidebar-brand-icon {
        width: 32px;
        height: 32px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        color: #fff;
    }
    
    .sidebar-brand-text {
        font-size: 18px;
        font-weight: 700;
        color: #fff;
    }
    
    .sidebar-menu {
        padding: 20px 0;
    }
    
    .menu-section-title {
        padding: 8px 24px;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        color: rgba(255,255,255,0.4);
        letter-spacing: 0.5px;
        margin-top: 12px;
    }
    
    .menu-section-title:first-child {
        margin-top: 0;
    }
    
    .menu-item {
        position: relative;
    }
    
    .menu-link {
        display: flex;
        align-items: center;
        padding: 10px 24px;
        color: rgba(255,255,255,0.7);
        text-decoration: none;
        transition: all 0.2s ease;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
    }
    
    .menu-link:hover {
        color: #fff;
        background: rgba(255,255,255,0.05);
    }
    
    .menu-link.active {
        color: #fff;
        background: rgba(103, 126, 234, 0.15);
        border-left: 3px solid #667eea;
    }
    
    .menu-link i {
        width: 20px;
        font-size: 16px;
        margin-right: 12px;
        opacity: 0.8;
    }
    
    .menu-link.active i {
        opacity: 1;
    }
    
    .menu-text {
        flex: 1;
    }
    
    .menu-badge {
        font-size: 9px;
        font-weight: 700;
        padding: 3px 8px;
        border-radius: 10px;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }
    
    .badge-new {
        background: #e74c3c;
        color: #fff;
    }
    
    .badge-pro {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: #fff;
    }
    
    .menu-arrow {
        font-size: 12px;
        transition: transform 0.2s ease;
        opacity: 0.6;
    }
    
    .menu-link.has-submenu.open .menu-arrow {
        transform: rotate(90deg);
    }
    
    .submenu {
        display: none;
        padding-left: 0;
        margin: 0;
        list-style: none;
        background: rgba(0,0,0,0.1);
    }
    
    .submenu.show {
        display: block;
    }
    
    .submenu .menu-link {
        padding-left: 56px;
        font-size: 13px;
    }
    
    /* Sidebar Toggle */
    .sidebar-toggle {
        position: absolute;
        top: 20px;
        right: -15px;
        width: 30px;
        height: 30px;
        background: #fff;
        border: 1px solid #e0e0e0;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    
    .sidebar-toggle i {
        font-size: 12px;
        color: #3f4d67;
    }
</style>

@php
    use App\Models\Setting;
    $siteName = Setting::get('site_name', 'SMS & Card Sale');
    $siteLogo = Setting::get('site_logo', '');
    $logoWidth = Setting::get('logo_width', '150');
@endphp

<div class="sidebar">
    <!-- Brand -->
    <div class="sidebar-brand">
        @if($siteLogo)
            <img src="{{ asset('storage/' . $siteLogo) }}" 
                 alt="{{ $siteName }}" 
                 style="max-width: {{ $logoWidth }}px; height: auto; max-height: 40px;">
        @else
            <div class="sidebar-brand-icon">
                <i class="fas fa-bolt"></i>
            </div>
            <span class="sidebar-brand-text">{{ Str::limit($siteName, 15) }}</span>
        @endif
        <div class="sidebar-toggle">
            <i class="fas fa-chevron-left"></i>
        </div>
    </div>
    
    <!-- Menu -->
    <div class="sidebar-menu">
        <!-- Main Section -->
        <div class="menu-section-title">Main</div>
        
        <div class="menu-item">
            <a href="{{ route('admin.dashboard') }}" class="menu-link {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
                <i class="fas fa-home"></i>
                <span class="menu-text">Dashboard</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="#" class="menu-link">
                <i class="fas fa-chart-line"></i>
                <span class="menu-text">Analytics</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="#" class="menu-link">
                <i class="fas fa-chart-bar"></i>
                <span class="menu-text">Reports</span>
            </a>
        </div>
        
        <!-- User Management Section -->
        <div class="menu-section-title">User Management</div>
        
        <div class="menu-item">
            <a href="{{ route('admin.users.index') }}" class="menu-link {{ request()->routeIs('admin.users.*') ? 'active' : '' }}">
                <i class="fas fa-users"></i>
                <span class="menu-text">All Users</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.users.create') }}" class="menu-link {{ request()->routeIs('admin.users.create') ? 'active' : '' }}">
                <i class="fas fa-user-plus"></i>
                <span class="menu-text">Add New User</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.kyc.index') }}" class="menu-link {{ request()->routeIs('admin.kyc.*') ? 'active' : '' }}">
                <i class="fas fa-id-card"></i>
                <span class="menu-text">KYC Management</span>
                @php
                    $pendingKyc = \App\Models\User::where('role', 'user')->where('kyc_status', 'pending')->count();
                @endphp
                @if($pendingKyc > 0)
                    <span class="badge bg-warning text-dark ms-auto">{{ $pendingKyc }}</span>
                @endif
            </a>
        </div>

        <!-- Content Menu Section -->
        <div class="menu-section-title">Content Menu</div>
        
        <div class="menu-item">
            <a href="{{ route('admin.hero-sliders.index') }}" class="menu-link {{ request()->routeIs('admin.hero-sliders.*') ? 'active' : '' }}">
                <i class="fas fa-images"></i>
                <span class="menu-text">Hero Sliders</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.why-choose-us.index') }}" class="menu-link {{ request()->routeIs('admin.why-choose-us.*') ? 'active' : '' }}">
                <i class="fas fa-star"></i>
                <span class="menu-text">Why Choose Us</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.faqs.index') }}" class="menu-link {{ request()->routeIs('admin.faqs.*') ? 'active' : '' }}">
                <i class="fas fa-question-circle"></i>
                <span class="menu-text">FAQs</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.blogs.index') }}" class="menu-link {{ request()->routeIs('admin.blogs.*') ? 'active' : '' }}">
                <i class="fas fa-blog"></i>
                <span class="menu-text">Blogs</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.comparisons.index') }}" class="menu-link {{ request()->routeIs('admin.comparisons.*') ? 'active' : '' }}">
                <i class="fas fa-balance-scale"></i>
                <span class="menu-text">Comparisons</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.sms-prices.index') }}" class="menu-link {{ request()->routeIs('admin.sms-prices.*') ? 'active' : '' }}">
                <i class="fas fa-dollar-sign"></i>
                <span class="menu-text">SMS Pricing</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.contact-info.index') }}" class="menu-link {{ request()->routeIs('admin.contact-info.*') ? 'active' : '' }}">
                <i class="fas fa-address-book"></i>
                <span class="menu-text">Contact Information</span>
            </a>
        </div>
        
        <!-- SMS Management Section -->
        <div class="menu-section-title">SMS Management</div>
        
        <div class="menu-item">
            <a href="{{ route('admin.packages.index') }}" class="menu-link {{ request()->routeIs('admin.packages.*') ? 'active' : '' }}">
                <i class="fas fa-box"></i>
                <span class="menu-text">SMS Packages</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.sms-history') }}" class="menu-link {{ request()->routeIs('admin.sms-history') ? 'active' : '' }}">
                <i class="fas fa-history"></i>
                <span class="menu-text">SMS History</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.sms-management') }}" class="menu-link {{ request()->routeIs('admin.sms-management') ? 'active' : '' }}">
                <i class="fas fa-dollar-sign"></i>
                <span class="menu-text">SMS Management</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.sms-templates.index') }}" class="menu-link {{ request()->routeIs('admin.sms-templates.*') ? 'active' : '' }}">
                <i class="fas fa-sms"></i>
                <span class="menu-text">SMS Templates</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.sms-gateway.index') }}" class="menu-link {{ request()->routeIs('admin.sms-gateway.*') ? 'active' : '' }}">
                <i class="fas fa-phone-alt"></i>
                <span class="menu-text">SMS Gateway</span>
            </a>
        </div>
        
        <!-- WiFi Card Section -->
        <div class="menu-section-title">WiFi Card</div>
        
        <div class="menu-item">
            <a href="{{ route('admin.wifi-cards.index') }}" class="menu-link {{ request()->routeIs('admin.wifi-cards.*') ? 'active' : '' }}">
                <i class="fas fa-wifi"></i>
                <span class="menu-text">WiFi Cards</span>
                <span class="menu-badge badge-new">NEW</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.card-categories.index') }}" class="menu-link {{ request()->routeIs('admin.card-categories.*') ? 'active' : '' }}">
                <i class="fas fa-th-large"></i>
                <span class="menu-text">Card Category</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.card-types.index') }}" class="menu-link {{ request()->routeIs('admin.card-types.*') ? 'active' : '' }}">
                <i class="fas fa-tags"></i>
                <span class="menu-text">Card Type</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.card-keys.index') }}" class="menu-link {{ request()->routeIs('admin.card-keys.*') ? 'active' : '' }}">
                <i class="fas fa-key"></i>
                <span class="menu-text">Service Card Keys</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.card-inventory.index') }}" class="menu-link {{ request()->routeIs('admin.card-inventory.*') ? 'active' : '' }}">
                <i class="fas fa-warehouse"></i>
                <span class="menu-text">Inventory</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.card-history.index') }}" class="menu-link {{ request()->routeIs('admin.card-history.*') ? 'active' : '' }}">
                <i class="fas fa-history"></i>
                <span class="menu-text">Card History</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.card-transactions.index') }}" class="menu-link {{ request()->routeIs('admin.card-transactions.*') ? 'active' : '' }}">
                <i class="fas fa-receipt"></i>
                <span class="menu-text">Transaction</span>
            </a>
        </div>
        
        <!-- Financial Section -->
        <div class="menu-section-title">Financial</div>
        
        <div class="menu-item">
            <a href="{{ route('admin.transactions') }}" class="menu-link {{ request()->routeIs('admin.transactions') ? 'active' : '' }}">
                <i class="fas fa-exchange-alt"></i>
                <span class="menu-text">Transactions</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.payment-methods') }}" class="menu-link {{ request()->routeIs('admin.payment-methods') || request()->routeIs('admin.payment-gateway*') ? 'active' : '' }}">
                <i class="fas fa-wallet"></i>
                <span class="menu-text">Payment Gateway</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.invoices') }}" class="menu-link {{ request()->routeIs('admin.invoices*') ? 'active' : '' }}">
                <i class="fas fa-file-invoice-dollar"></i>
                <span class="menu-text">Invoices</span>
            </a>
        </div>
        
        <!-- System Section -->
        <div class="menu-section-title">System</div>
        
        <div class="menu-item">
            <a href="{{ route('admin.settings') }}" class="menu-link {{ request()->routeIs('admin.settings') ? 'active' : '' }}">
                <i class="fas fa-cog"></i>
                <span class="menu-text">Settings</span>
            </a>
        </div>
        
        <div class="menu-item">
            <a href="{{ route('admin.notifications.index') }}" class="menu-link {{ request()->routeIs('admin.notifications.*') ? 'active' : '' }}">
                <i class="fas fa-bell"></i>
                <span class="menu-text">Notifications</span>
                @php
                    $adminUnreadCount = \App\Models\Notification::forAdmin()->unread()->count();
                @endphp
                @if($adminUnreadCount > 0)
                    <span class="menu-badge badge-new">{{ $adminUnreadCount }}</span>
                @endif
            </a>
        </div>
    </div>
</div>

<script>
function toggleSubmenu(element, event) {
    event.preventDefault();
    const menuItem = element.parentElement;
    const submenu = menuItem.querySelector('.submenu');
    
    // Toggle open class
    element.classList.toggle('open');
    
    // Toggle submenu visibility
    if (submenu) {
        submenu.classList.toggle('show');
    }
}
</script>
