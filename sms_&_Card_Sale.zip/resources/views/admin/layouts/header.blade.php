<style>
    .admin-header {
        height: 70px;
        background: #fff;
        border-bottom: 1px solid #e9ecef;
        padding: 0 30px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        position: sticky;
        top: 0;
        z-index: 999;
    }
    
    .header-search {
        flex: 1;
        max-width: 600px;
        margin: 0 30px;
    }
    
    .search-input-wrapper {
        position: relative;
    }
    
    .search-input {
        width: 100%;
        height: 40px;
        border: 1px solid #e0e0e0;
        border-radius: 20px;
        padding: 0 45px 0 45px;
        font-size: 14px;
        color: #495057;
        background: #f8f9fa;
        transition: all 0.2s ease;
    }
    
    .search-input:focus {
        outline: none;
        border-color: #667eea;
        background: #fff;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    }
    
    .search-input::placeholder {
        color: #adb5bd;
    }
    
    .search-icon {
        position: absolute;
        left: 16px;
        top: 50%;
        transform: translateY(-50%);
        color: #adb5bd;
        font-size: 14px;
    }
    
    .search-clear {
        position: absolute;
        right: 16px;
        top: 50%;
        transform: translateY(-50%);
        color: #adb5bd;
        font-size: 14px;
        cursor: pointer;
        display: none;
    }
    
    .search-input:not(:placeholder-shown) ~ .search-clear {
        display: block;
    }
    
    .header-actions {
        display: flex;
        align-items: center;
        gap: 20px;
    }
    
    .header-action-item {
        position: relative;
        cursor: pointer;
    }
    
    .action-icon {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #495057;
        font-size: 18px;
        transition: all 0.2s ease;
        position: relative;
    }
    
    .action-icon:hover {
        background: #f8f9fa;
        color: #667eea;
    }
    
    .action-badge {
        position: absolute;
        top: 8px;
        right: 8px;
        width: 8px;
        height: 8px;
        background: #e74c3c;
        border: 2px solid #fff;
        border-radius: 50%;
    }
    
    .action-badge.has-count {
        width: auto;
        height: auto;
        min-width: 18px;
        padding: 2px 5px;
        font-size: 10px;
        font-weight: 700;
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 10px;
    }
    
    .badge-danger {
        background: #e74c3c;
    }
    
    .badge-success {
        background: #27ae60;
    }
    
    .user-profile {
        display: flex;
        align-items: center;
        gap: 12px;
        cursor: pointer;
        padding: 6px 12px;
        border-radius: 20px;
        transition: all 0.2s ease;
    }
    
    .user-profile:hover {
        background: #f8f9fa;
    }
    
    .user-avatar {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid #e0e0e0;
    }
    
    .user-info {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
    }
    
    .user-name {
        font-size: 14px;
        font-weight: 600;
        color: #212529;
        line-height: 1.2;
    }
    
    .user-role {
        font-size: 11px;
        color: #6c757d;
        line-height: 1.2;
    }
    
    .user-dropdown-arrow {
        font-size: 12px;
        color: #6c757d;
        margin-left: 4px;
    }
    
    /* Dropdown */
    .dropdown-menu {
        border: 1px solid #e0e0e0;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        padding: 8px;
        min-width: 200px;
    }
    
    .dropdown-item {
        padding: 10px 16px;
        border-radius: 8px;
        font-size: 14px;
        color: #495057;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .dropdown-item:hover {
        background: #f8f9fa;
        color: #667eea;
    }
    
    .dropdown-item i {
        width: 18px;
        font-size: 16px;
    }
    
    .dropdown-divider {
        margin: 8px 0;
        border-color: #e9ecef;
    }
    
    /* Mobile Toggle */
    .mobile-toggle {
        display: none;
        width: 40px;
        height: 40px;
        border-radius: 8px;
        background: #f8f9fa;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        color: #495057;
    }
    
    @media (max-width: 992px) {
        .mobile-toggle {
            display: flex;
        }
        
        .header-search {
            max-width: 400px;
            margin: 0 15px;
        }
        
        .user-info {
            display: none;
        }
    }
    
    @media (max-width: 768px) {
        .header-search {
            display: none;
        }
    }
</style>

<div class="admin-header">
    <!-- Mobile Toggle -->
    <div class="mobile-toggle">
        <i class="fas fa-bars"></i>
    </div>
    
    <!-- Search -->
    <div class="header-search">
        <div class="search-input-wrapper">
            <i class="fas fa-search search-icon"></i>
            <input type="text" class="search-input" placeholder="Search or enter hotkey name">
            <i class="fas fa-times search-clear"></i>
        </div>
    </div>
    
    <!-- Actions -->
    <div class="header-actions">
        <!-- Notifications -->
        <div class="header-action-item dropdown">
            <div class="action-icon" data-bs-toggle="dropdown" id="notification-bell">
                <i class="far fa-bell"></i>
                @php
                    $adminNotifications = \App\Models\Notification::forAdmin()->unread()->count();
                @endphp
                @if($adminNotifications > 0)
                    <span class="action-badge has-count badge-danger">{{ $adminNotifications }}</span>
                @endif
            </div>
            <ul class="dropdown-menu dropdown-menu-end" style="width: 350px; max-height: 400px; overflow-y: auto;">
                <li><h6 class="dropdown-header d-flex justify-content-between align-items-center">
                    <span>Notifications</span>
                    @if($adminNotifications > 0)
                        <span class="badge bg-danger">{{ $adminNotifications }}</span>
                    @endif
                </h6></li>
                
                @php
                    $recentNotifications = \App\Models\Notification::forAdmin()->latest()->limit(5)->get();
                @endphp
                
                @forelse($recentNotifications as $notification)
                    <li>
                        <a class="dropdown-item {{ !$notification->is_read ? 'bg-light' : '' }}" 
                           href="{{ $notification->link ? $notification->link : route('admin.notifications.index') }}"
                           onclick="markNotificationAsRead({{ $notification->id }})">
                            <div class="d-flex">
                                <div class="me-2">
                                    <i class="fas {{ $notification->icon ?? 'fa-bell' }} text-{{ $notification->color }}"></i>
                                </div>
                                <div class="flex-grow-1">
                                    <div class="fw-bold">{{ $notification->title }}</div>
                                    <small class="text-muted">{{ Str::limit($notification->message, 50) }}</small>
                                    <div class="text-muted" style="font-size: 11px;">{{ $notification->getTimeAgo() }}</div>
                                </div>
                            </div>
                        </a>
                    </li>
                @empty
                    <li><a class="dropdown-item text-center text-muted" href="#">No notifications</a></li>
                @endforelse
                
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-center" href="{{ route('admin.notifications.index') }}">
                    <strong>View all notifications</strong>
                </a></li>
            </ul>
        </div>
        
        <script>
        function markNotificationAsRead(id) {
            fetch(`/admin/notifications/${id}/read`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                }
            });
        }
        
        // Auto-refresh notification count every 30 seconds
        setInterval(function() {
            fetch('/admin/notifications/unread-count')
                .then(response => response.json())
                .then(data => {
                    const badge = document.querySelector('#notification-bell .action-badge');
                    if (data.count > 0) {
                        if (badge) {
                            badge.textContent = data.count;
                        } else {
                            const bell = document.getElementById('notification-bell');
                            bell.innerHTML += '<span class="action-badge has-count badge-danger">' + data.count + '</span>';
                        }
                    } else {
                        if (badge) {
                            badge.remove();
                        }
                    }
                });
        }, 30000);
        </script>
        
        <!-- Messages -->
        <div class="header-action-item dropdown">
            <div class="action-icon" data-bs-toggle="dropdown">
                <i class="far fa-comment-dots"></i>
                <span class="action-badge has-count badge-success">5</span>
            </div>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><h6 class="dropdown-header">Messages</h6></li>
                <li><a class="dropdown-item" href="#">
                    <i class="fas fa-user"></i> John sent a message
                </a></li>
                <li><a class="dropdown-item" href="#">
                    <i class="fas fa-user"></i> Sarah replied
                </a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-center" href="#">View all messages</a></li>
            </ul>
        </div>
        
        <!-- User Profile -->
        <div class="dropdown">
            <div class="user-profile" data-bs-toggle="dropdown">
                @auth
                    <img src="https://ui-avatars.com/api/?name={{ urlencode(auth()->user()->name) }}&background=667eea&color=fff" 
                         alt="{{ auth()->user()->name }}" 
                         class="user-avatar">
                    <div class="user-info">
                        <span class="user-name">{{ auth()->user()->name }}</span>
                        <span class="user-role">{{ ucfirst(auth()->user()->role) }}</span>
                    </div>
                    <i class="fas fa-chevron-down user-dropdown-arrow"></i>
                @else
                    <img src="https://ui-avatars.com/api/?name=User&background=667eea&color=fff" 
                         alt="User" 
                         class="user-avatar">
                    <div class="user-info">
                        <span class="user-name">Guest</span>
                        <span class="user-role">Visitor</span>
                    </div>
                    <i class="fas fa-chevron-down user-dropdown-arrow"></i>
                @endauth
            </div>
            <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="#">
                    <i class="fas fa-user"></i> My Profile
                </a></li>
                <li><a class="dropdown-item" href="#">
                    <i class="fas fa-cog"></i> Settings
                </a></li>
                <li><a class="dropdown-item" href="#">
                    <i class="fas fa-question-circle"></i> Help
                </a></li>
                <li><hr class="dropdown-divider"></li>
                <li>
                    <form action="{{ route('logout') }}" method="POST">
                        @csrf
                        <button type="submit" class="dropdown-item">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </button>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</div>
