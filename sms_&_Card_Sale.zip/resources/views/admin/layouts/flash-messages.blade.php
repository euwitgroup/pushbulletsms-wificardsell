<script>
// Custom SweetAlert2 Configuration
const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
});

// Flash Messages from Laravel Session
@if(session('success'))
    Toast.fire({
        icon: 'success',
        title: '{{ session('success') }}'
    });
@endif

@if(session('error'))
    Toast.fire({
        icon: 'error',
        title: '{{ session('error') }}'
    });
@endif

@if(session('warning'))
    Toast.fire({
        icon: 'warning',
        title: '{{ session('warning') }}'
    });
@endif

@if(session('info'))
    Toast.fire({
        icon: 'info',
        title: '{{ session('info') }}'
    });
@endif

// Global SweetAlert Functions
function showSuccess(message) {
    Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: message,
        confirmButtonColor: '#26de81',
        confirmButtonText: 'OK'
    });
}

function showError(message) {
    Swal.fire({
        icon: 'error',
        title: 'Error!',
        text: message,
        confirmButtonColor: '#ee5a6f',
        confirmButtonText: 'OK'
    });
}

function showWarning(message) {
    Swal.fire({
        icon: 'warning',
        title: 'Warning!',
        text: message,
        confirmButtonColor: '#ffc107',
        confirmButtonText: 'OK'
    });
}

function showInfo(message) {
    Swal.fire({
        icon: 'info',
        title: 'Information',
        text: message,
        confirmButtonColor: '#3498db',
        confirmButtonText: 'OK'
    });
}

function showQuestion(message, callback) {
    Swal.fire({
        icon: 'question',
        title: 'Question',
        text: message,
        showCancelButton: true,
        confirmButtonColor: '#3498db',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: 'Yes',
        cancelButtonText: 'No'
    }).then((result) => {
        if (result.isConfirmed && callback) {
            callback();
        }
    });
}

function confirmDelete(title, text, form) {
    Swal.fire({
        title: title || 'Are you sure?',
        text: text || "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ee5a6f',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            if (form) {
                form.submit();
            }
        }
    });
}

function showToast(icon, message) {
    Toast.fire({
        icon: icon,
        title: message
    });
}

function showTimerAlert(message, timer = 2000) {
    Swal.fire({
        title: message,
        timer: timer,
        timerProgressBar: true,
        showConfirmButton: false,
        icon: 'success'
    });
}

function showInputDialog(title, inputPlaceholder, callback) {
    Swal.fire({
        title: title,
        input: 'text',
        inputPlaceholder: inputPlaceholder,
        showCancelButton: true,
        confirmButtonColor: '#26de81',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: 'Submit',
        cancelButtonText: 'Cancel',
        inputValidator: (value) => {
            if (!value) {
                return 'You need to write something!'
            }
        }
    }).then((result) => {
        if (result.isConfirmed && callback) {
            callback(result.value);
        }
    });
}

function showNumberInput(title, inputPlaceholder, callback) {
    Swal.fire({
        title: title,
        input: 'number',
        inputPlaceholder: inputPlaceholder,
        showCancelButton: true,
        confirmButtonColor: '#26de81',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: 'Submit',
        cancelButtonText: 'Cancel',
        inputValidator: (value) => {
            if (!value || value <= 0) {
                return 'Please enter a valid amount!'
            }
        }
    }).then((result) => {
        if (result.isConfirmed && callback) {
            callback(result.value);
        }
    });
}

// Auto-dismiss loading
function showLoading(message = 'Processing...') {
    Swal.fire({
        title: message,
        allowOutsideClick: false,
        allowEscapeKey: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
}

function closeLoading() {
    Swal.close();
}
</script>
