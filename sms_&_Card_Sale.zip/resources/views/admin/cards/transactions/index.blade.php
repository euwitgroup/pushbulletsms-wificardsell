@extends('admin.layouts.app')

@section('title', 'Card Transactions')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .breadcrumb-nav a:hover {
        color: #3498db;
    }
    
    .summary-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .summary-card {
        background: white;
        border-radius: 8px;
        padding: 20px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        text-align: center;
    }
    
    .summary-icon {
        width: 50px;
        height: 50px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 22px;
        color: white;
        margin: 0 auto 15px;
    }
    
    .summary-icon.total {
        background: linear-gradient(135deg, #667eea, #764ba2);
    }
    
    .summary-icon.completed {
        background: linear-gradient(135deg, #43e97b, #38f9d7);
    }
    
    .summary-icon.pending {
        background: linear-gradient(135deg, #fa709a, #fee140);
    }
    
    .summary-icon.revenue {
        background: linear-gradient(135deg, #30cfd0, #330867);
    }
    
    .summary-value {
        font-size: 28px;
        font-weight: 700;
        color: #2c3e50;
        margin-bottom: 5px;
    }
    
    .summary-label {
        font-size: 13px;
        color: #7f8c8d;
        font-weight: 500;
    }
    
    .filter-tabs {
        display: flex;
        gap: 10px;
        margin-bottom: 20px;
    }
    
    .tab-btn {
        padding: 10px 20px;
        background: white;
        border: 2px solid #e9ecef;
        border-radius: 6px;
        font-size: 13px;
        font-weight: 600;
        color: #636e72;
        cursor: pointer;
        transition: all 0.2s ease;
        text-decoration: none;
    }
    
    .tab-btn:hover {
        border-color: #667eea;
        color: #667eea;
    }
    
    .tab-btn.active {
        background: #667eea;
        border-color: #667eea;
        color: white;
    }
    
    .transactions-table-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .transactions-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .transactions-table thead th {
        background: #f8f9fa;
        padding: 12px 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: #636e72;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: 1px solid #e9ecef;
    }
    
    .transactions-table tbody td {
        padding: 12px 16px;
        font-size: 13px;
        border-bottom: 1px solid #f1f3f5;
        vertical-align: middle;
    }
    
    .transactions-table tbody tr:hover {
        background: #f8f9fa;
    }
    
    .status-badge {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
    }
    
    .status-badge.completed {
        background: #e8f5e9;
        color: #43a047;
    }
    
    .status-badge.pending {
        background: #fff3e0;
        color: #f57c00;
    }
    
    .status-badge.failed {
        background: #ffebee;
        color: #c62828;
    }
    
    .action-buttons {
        display: flex;
        gap: 6px;
    }
    
    .btn-action {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 12px;
    }
    
    .btn-action:hover {
        transform: scale(1.1);
    }
    
    .btn-action.view {
        background: #d4f1f4;
        color: #05c3dd;
    }
    
    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: #95a5a6;
    }
    
    .empty-state i {
        font-size: 64px;
        margin-bottom: 20px;
        opacity: 0.3;
    }
    
    .empty-state h3 {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 8px;
        color: #636e72;
    }
    
    .empty-state p {
        font-size: 14px;
    }
</style>

<div class="page-breadcrumb">
    <h1 class="page-title">Card Transactions</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > 
        <a href="{{ route('admin.wifi-cards.index') }}">WiFi Cards</a> > 
        <span>Transactions</span>
    </div>
</div>

<!-- Summary Cards -->
<div class="summary-grid">
    <div class="summary-card">
        <div class="summary-icon total">
            <i class="fas fa-receipt"></i>
        </div>
        <div class="summary-value">{{ $totalTransactions }}</div>
        <div class="summary-label">Total Transactions</div>
    </div>
    
    <div class="summary-card">
        <div class="summary-icon completed">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="summary-value">{{ $completedTransactions }}</div>
        <div class="summary-label">Completed</div>
    </div>
    
    <div class="summary-card">
        <div class="summary-icon pending">
            <i class="fas fa-clock"></i>
        </div>
        <div class="summary-value">{{ $pendingTransactions }}</div>
        <div class="summary-label">Pending</div>
    </div>
    
    <div class="summary-card">
        <div class="summary-icon revenue">
            <i class="fas fa-dollar-sign"></i>
        </div>
        <div class="summary-value">৳{{ number_format($totalRevenue, 2) }}</div>
        <div class="summary-label">Total Revenue</div>
    </div>
</div>

<!-- Filter Tabs -->
<div class="filter-tabs">
    <a href="{{ route('admin.card-transactions.index') }}" class="tab-btn {{ !request('status') ? 'active' : '' }}">
        <i class="fas fa-list"></i> All
    </a>
    <a href="{{ route('admin.card-transactions.index', ['status' => 'completed']) }}" class="tab-btn {{ request('status') === 'completed' ? 'active' : '' }}">
        <i class="fas fa-check-circle"></i> Completed
    </a>
    <a href="{{ route('admin.card-transactions.index', ['status' => 'pending']) }}" class="tab-btn {{ request('status') === 'pending' ? 'active' : '' }}">
        <i class="fas fa-clock"></i> Pending
    </a>
    <a href="{{ route('admin.card-transactions.index', ['status' => 'failed']) }}" class="tab-btn {{ request('status') === 'failed' ? 'active' : '' }}">
        <i class="fas fa-times-circle"></i> Failed
    </a>
</div>

<!-- Transactions Table -->
<div class="transactions-table-card">
    @if($transactions->count() > 0)
    <div style="padding: 15px 20px; border-bottom: 1px solid #f1f3f5;">
        <span style="font-size: 14px; color: #636e72;">
            Total Records: <strong>{{ $transactions->total() }}</strong>
        </span>
    </div>
    
    <table class="transactions-table">
        <thead>
            <tr>
                <th>Transaction ID</th>
                <th>Customer</th>
                <th>Card Details</th>
                <th>Card Key</th>
                <th>Amount</th>
                <th style="width: 100px;">Status</th>
                <th style="width: 150px;">Purchase Date</th>
                <th style="width: 80px;">Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($transactions as $transaction)
            <tr>
                <td><code style="font-weight: 600;">{{ $transaction->transaction_id }}</code></td>
                <td>
                    <div style="font-size: 13px;">
                        @if($transaction->user)
                            {{-- Authenticated user --}}
                            <strong>{{ $transaction->user->name }}</strong><br>
                            <span style="color: #95a5a6;">{{ $transaction->user->phone ?? $transaction->customer_phone }}</span>
                        @else
                            {{-- Guest purchase --}}
                            <strong>{{ $transaction->customer_name }}</strong><br>
                            <span style="color: #95a5a6;">{{ $transaction->customer_phone }}</span>
                        @endif
                    </div>
                </td>
                <td>
                    <div style="font-size: 13px;">
                        <span style="color: #95a5a6;">{{ $transaction->cardType->category->name }}</span><br>
                        <strong>{{ $transaction->cardType->name }}</strong>
                    </div>
                </td>
                <td>
                    @if($transaction->cardKey)
                        <code style="font-weight: 600;">{{ $transaction->cardKey->key_code }}</code>
                    @else
                        <span style="color: #95a5a6;">-</span>
                    @endif
                </td>
                <td>
                    <strong style="color: #43a047;">৳{{ number_format($transaction->amount, 2) }}</strong>
                </td>
                <td>
                    <span class="status-badge {{ $transaction->status }}">
                        {{ ucfirst($transaction->status) }}
                    </span>
                </td>
                <td>{{ $transaction->purchased_at ? $transaction->purchased_at->format('M d, Y H:i') : '-' }}</td>
                <td>
                    <div class="action-buttons">
                        <button class="btn-action view" onclick="viewTransaction({{ $transaction->id }})" title="View Details">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    @else
    <div class="empty-state">
        <i class="fas fa-receipt"></i>
        <h3>No Transactions Yet</h3>
        <p>Card purchase transactions will appear here</p>
    </div>
    @endif
</div>

@if($transactions->hasPages())
<div style="margin-top: 20px;">
    {{ $transactions->appends(request()->query())->links() }}
</div>
@endif

@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function viewTransaction(id) {
    fetch(`/admin/card-transactions/${id}`)
        .then(response => response.json())
        .then(data => {
            Swal.fire({
                title: 'Transaction Details',
                html: `
                    <div style="text-align: left;">
                        <div style="margin-bottom: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                            <h4 style="margin: 0 0 10px 0; font-size: 14px; color: #636e72;">Transaction Information</h4>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 13px;">
                                <div>
                                    <strong>Transaction ID:</strong><br>
                                    <code>${data.transaction_id}</code>
                                </div>
                                <div>
                                    <strong>Amount:</strong><br>
                                    <span style="color: #43a047; font-weight: 600;">৳${parseFloat(data.amount).toFixed(2)}</span>
                                </div>
                                <div>
                                    <strong>Status:</strong><br>
                                    <span style="text-transform: capitalize;">${data.status}</span>
                                </div>
                                <div>
                                    <strong>Purchase Date:</strong><br>
                                    ${data.purchased_at || '-'}
                                </div>
                            </div>
                        </div>
                        
                        <div style="margin-bottom: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                            <h4 style="margin: 0 0 10px 0; font-size: 14px; color: #636e72;">Customer Information</h4>
                            <div style="font-size: 13px;">
                                <div style="margin-bottom: 8px;"><strong>Name:</strong> ${data.user.name}</div>
                                <div style="margin-bottom: 8px;"><strong>Phone:</strong> ${data.user.phone}</div>
                                <div><strong>Email:</strong> ${data.user.email || '-'}</div>
                            </div>
                        </div>
                        
                        <div style="margin-bottom: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px;">
                            <h4 style="margin: 0 0 10px 0; font-size: 14px; color: #636e72;">Card Information</h4>
                            <div style="font-size: 13px;">
                                <div style="margin-bottom: 8px;"><strong>Category:</strong> ${data.card_type.category.name}</div>
                                <div style="margin-bottom: 8px;"><strong>Card Type:</strong> ${data.card_type.name}</div>
                                <div style="margin-bottom: 8px;"><strong>Price:</strong> ৳${parseFloat(data.card_type.price).toFixed(2)}</div>
                                <div style="margin-bottom: 8px;"><strong>Validity:</strong> ${data.card_type.validity_days} days</div>
                                ${data.card_key ? `<div style="margin-top: 10px; padding: 10px; background: #fff; border-radius: 4px;"><strong>Card Key:</strong><br><code style="font-size: 14px; font-weight: 600;">${data.card_key.key_code}</code></div>` : ''}
                            </div>
                        </div>
                    </div>
                `,
                showCloseButton: true,
                showConfirmButton: false,
                width: '600px'
            });
        })
        .catch(error => {
            Swal.fire('Error!', 'Unable to fetch transaction details', 'error');
        });
}
</script>
@endpush

