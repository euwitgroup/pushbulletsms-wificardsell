@extends('admin.layouts.app')

@section('title', 'Card Categories')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .breadcrumb-nav a:hover {
        color: #3498db;
    }
    
    .table-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .btn-add-new {
        background: #26de81;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s ease;
    }
    
    .btn-add-new:hover {
        background: #20bf6b;
        transform: translateY(-1px);
    }
    
    .categories-table-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .categories-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .categories-table thead th {
        background: #f8f9fa;
        padding: 12px 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: #636e72;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: 1px solid #e9ecef;
    }
    
    .categories-table tbody td {
        padding: 12px 16px;
        font-size: 13px;
        border-bottom: 1px solid #f1f3f5;
        vertical-align: middle;
    }
    
    .categories-table tbody tr:hover {
        background: #f8f9fa;
    }
    
    .status-toggle {
        position: relative;
        display: inline-block;
        width: 44px;
        height: 24px;
    }
    
    .status-toggle input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #dfe6e9;
        transition: .3s;
        border-radius: 24px;
    }
    
    .slider:before {
        position: absolute;
        content: "";
        height: 18px;
        width: 18px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: .3s;
        border-radius: 50%;
    }
    
    input:checked + .slider {
        background-color: #26de81;
    }
    
    input:checked + .slider:before {
        transform: translateX(20px);
    }
    
    .action-buttons {
        display: flex;
        gap: 6px;
    }
    
    .btn-action {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 12px;
    }
    
    .btn-action:hover {
        transform: scale(1.1);
    }
    
    .btn-action.edit {
        background: #ffeaa7;
        color: #fdcb6e;
    }
    
    .btn-action.delete {
        background: #ffcccc;
        color: #ee5a6f;
    }
    
    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: #95a5a6;
    }
    
    .empty-state i {
        font-size: 64px;
        margin-bottom: 20px;
        opacity: 0.3;
    }
    
    .empty-state h3 {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 8px;
        color: #636e72;
    }
    
    .empty-state p {
        font-size: 14px;
        margin-bottom: 20px;
    }
    
    .swal2-container {
        z-index: 10000;
    }
</style>

<div class="page-breadcrumb">
    <h1 class="page-title">Card Categories</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > 
        <a href="{{ route('admin.wifi-cards.index') }}">WiFi Cards</a> > 
        <span>Categories</span>
    </div>
</div>

<div class="table-controls">
    <div>
        <span style="font-size: 14px; color: #636e72;">
            Total: <strong>{{ $categories->total() }}</strong> categories
        </span>
    </div>
    <button class="btn-add-new" onclick="showAddModal()">
        <i class="fas fa-plus"></i>
        Add New Category
    </button>
</div>

<div class="categories-table-card">
    @if($categories->count() > 0)
    <table class="categories-table">
        <thead>
            <tr>
                <th style="width: 60px;">Order</th>
                <th>Name</th>
                <th>Slug</th>
                <th>Description</th>
                <th style="width: 120px;">Card Types</th>
                <th style="width: 80px;">Status</th>
                <th style="width: 120px;">Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($categories as $category)
            <tr>
                <td><strong>{{ $category->order }}</strong></td>
                <td><strong>{{ $category->name }}</strong></td>
                <td><code>{{ $category->slug }}</code></td>
                <td>{{ Str::limit($category->description ?? '-', 50) }}</td>
                <td>
                    <span style="background: #e3f2fd; color: #1976d2; padding: 4px 10px; border-radius: 12px; font-size: 11px; font-weight: 600;">
                        {{ $category->card_types_count }} Types
                    </span>
                </td>
                <td>
                    <label class="status-toggle">
                        <input type="checkbox" 
                               {{ $category->is_active ? 'checked' : '' }}
                               onchange="toggleStatus({{ $category->id }})">
                        <span class="slider"></span>
                    </label>
                </td>
                <td>
                    <div class="action-buttons">
                        <button class="btn-action edit" onclick="showEditModal({{ $category->id }})" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn-action delete" onclick="deleteCategory({{ $category->id }})" title="Delete">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    @else
    <div class="empty-state">
        <i class="fas fa-th-large"></i>
        <h3>No Categories Found</h3>
        <p>Start by creating your first card category</p>
        <button class="btn-add-new" onclick="showAddModal()">
            <i class="fas fa-plus"></i>
            Add New Category
        </button>
    </div>
    @endif
</div>

@if($categories->hasPages())
<div style="margin-top: 20px;">
    {{ $categories->links() }}
</div>
@endif

@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function showAddModal() {
    Swal.fire({
        title: 'Add New Category',
        html: `
            <div style="text-align: left;">
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600; font-size: 13px;">Category Name *</label>
                    <input type="text" id="name" class="swal2-input" style="width: 100%; margin: 0;" placeholder="e.g., Carnival">
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600; font-size: 13px;">Description</label>
                    <textarea id="description" class="swal2-textarea" style="width: 100%; margin: 0; height: 80px;" placeholder="Optional description"></textarea>
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600; font-size: 13px;">Display Order</label>
                    <input type="number" id="order" class="swal2-input" style="width: 100%; margin: 0;" value="0" min="0">
                </div>
                <div style="margin-bottom: 0;">
                    <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                        <input type="checkbox" id="is_active" checked style="width: 18px; height: 18px;">
                        <span style="font-size: 13px; font-weight: 500;">Active</span>
                    </label>
                </div>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'Create Category',
        cancelButtonText: 'Cancel',
        confirmButtonColor: '#26de81',
        width: '500px',
        preConfirm: () => {
            const name = document.getElementById('name').value;
            const description = document.getElementById('description').value;
            const order = document.getElementById('order').value;
            const is_active = document.getElementById('is_active').checked;
            
            if (!name) {
                Swal.showValidationMessage('Category name is required');
                return false;
            }
            
            return { name, description, order, is_active };
        }
    }).then((result) => {
        if (result.isConfirmed) {
            submitCategory(result.value);
        }
    });
}

function showEditModal(id) {
    fetch(`/admin/card-categories/${id}/edit`)
        .then(response => response.json())
        .then(data => {
            Swal.fire({
                title: 'Edit Category',
                html: `
                    <div style="text-align: left;">
                        <div style="margin-bottom: 15px;">
                            <label style="display: block; margin-bottom: 5px; font-weight: 600; font-size: 13px;">Category Name *</label>
                            <input type="text" id="name" class="swal2-input" style="width: 100%; margin: 0;" value="${data.name}">
                        </div>
                        <div style="margin-bottom: 15px;">
                            <label style="display: block; margin-bottom: 5px; font-weight: 600; font-size: 13px;">Description</label>
                            <textarea id="description" class="swal2-textarea" style="width: 100%; margin: 0; height: 80px;">${data.description || ''}</textarea>
                        </div>
                        <div style="margin-bottom: 15px;">
                            <label style="display: block; margin-bottom: 5px; font-weight: 600; font-size: 13px;">Display Order</label>
                            <input type="number" id="order" class="swal2-input" style="width: 100%; margin: 0;" value="${data.order}" min="0">
                        </div>
                        <div style="margin-bottom: 0;">
                            <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                                <input type="checkbox" id="is_active" ${data.is_active ? 'checked' : ''} style="width: 18px; height: 18px;">
                                <span style="font-size: 13px; font-weight: 500;">Active</span>
                            </label>
                        </div>
                    </div>
                `,
                showCancelButton: true,
                confirmButtonText: 'Update Category',
                cancelButtonText: 'Cancel',
                confirmButtonColor: '#3498db',
                width: '500px',
                preConfirm: () => {
                    const name = document.getElementById('name').value;
                    const description = document.getElementById('description').value;
                    const order = document.getElementById('order').value;
                    const is_active = document.getElementById('is_active').checked;
                    
                    if (!name) {
                        Swal.showValidationMessage('Category name is required');
                        return false;
                    }
                    
                    return { name, description, order, is_active };
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    updateCategory(id, result.value);
                }
            });
        });
}

function submitCategory(data) {
    fetch('{{ route("admin.card-categories.store") }}', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                toast: true,
                position: 'top-end',
                icon: 'success',
                title: data.message,
                showConfirmButton: false,
                timer: 3000
            });
            setTimeout(() => location.reload(), 1000);
        } else {
            Swal.fire('Error!', data.message, 'error');
        }
    })
    .catch(error => {
        Swal.fire('Error!', 'Something went wrong', 'error');
    });
}

function updateCategory(id, data) {
    fetch(`/admin/card-categories/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                toast: true,
                position: 'top-end',
                icon: 'success',
                title: data.message,
                showConfirmButton: false,
                timer: 3000
            });
            setTimeout(() => location.reload(), 1000);
        } else {
            Swal.fire('Error!', data.message, 'error');
        }
    })
    .catch(error => {
        Swal.fire('Error!', 'Something went wrong', 'error');
    });
}

function deleteCategory(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "This will also delete all card types under this category!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#c62828',
        cancelButtonColor: '#95a5a6',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch(`/admin/card-categories/${id}`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        toast: true,
                        position: 'top-end',
                        icon: 'success',
                        title: data.message,
                        showConfirmButton: false,
                        timer: 3000
                    });
                    setTimeout(() => location.reload(), 1000);
                } else {
                    Swal.fire('Error!', data.message, 'error');
                }
            });
        }
    });
}

function toggleStatus(id) {
    fetch(`/admin/card-categories/${id}/toggle-status`, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                toast: true,
                position: 'top-end',
                icon: 'success',
                title: data.message,
                showConfirmButton: false,
                timer: 2000
            });
        }
    });
}
</script>
@endpush

