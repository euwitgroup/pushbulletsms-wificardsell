@extends('admin.layouts.app')

@section('title', 'Card History')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .breadcrumb-nav a:hover {
        color: #3498db;
    }
    
    .filter-tabs {
        display: flex;
        gap: 10px;
        margin-bottom: 20px;
    }
    
    .tab-btn {
        padding: 10px 20px;
        background: white;
        border: 2px solid #e9ecef;
        border-radius: 6px;
        font-size: 13px;
        font-weight: 600;
        color: #636e72;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .tab-btn:hover {
        border-color: #667eea;
        color: #667eea;
    }
    
    .tab-btn.active {
        background: #667eea;
        border-color: #667eea;
        color: white;
    }
    
    .history-table-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .history-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .history-table thead th {
        background: #f8f9fa;
        padding: 12px 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: #636e72;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: 1px solid #e9ecef;
    }
    
    .history-table tbody td {
        padding: 12px 16px;
        font-size: 13px;
        border-bottom: 1px solid #f1f3f5;
        vertical-align: middle;
    }
    
    .history-table tbody tr:hover {
        background: #f8f9fa;
    }
    
    .status-badge {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
    }
    
    .status-badge.available {
        background: #e8f5e9;
        color: #43a047;
    }
    
    .status-badge.sold {
        background: #e3f2fd;
        color: #1976d2;
    }
    
    .status-badge.expired {
        background: #ffebee;
        color: #c62828;
    }
    
    .event-badge {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
    }
    
    .event-badge.added {
        background: #e8f5e9;
        color: #43a047;
    }
    
    .event-badge.purchased {
        background: #e3f2fd;
        color: #1976d2;
    }
    
    .event-badge.removed {
        background: #ffebee;
        color: #c62828;
    }
    
    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: #95a5a6;
    }
    
    .empty-state i {
        font-size: 64px;
        margin-bottom: 20px;
        opacity: 0.3;
    }
    
    .empty-state h3 {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 8px;
        color: #636e72;
    }
    
    .empty-state p {
        font-size: 14px;
    }
</style>

<div class="page-breadcrumb">
    <h1 class="page-title">Card History</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > 
        <a href="{{ route('admin.wifi-cards.index') }}">WiFi Cards</a> > 
        <span>History</span>
    </div>
</div>

<!-- Filter Tabs -->
<div class="filter-tabs">
    <a href="{{ route('admin.card-history.index') }}" class="tab-btn {{ !request('status') ? 'active' : '' }}">
        <i class="fas fa-list"></i> All
    </a>
    <a href="{{ route('admin.card-history.index', ['status' => 'available']) }}" class="tab-btn {{ request('status') === 'available' ? 'active' : '' }}">
        <i class="fas fa-check-circle"></i> Available
    </a>
    <a href="{{ route('admin.card-history.index', ['status' => 'sold']) }}" class="tab-btn {{ request('status') === 'sold' ? 'active' : '' }}">
        <i class="fas fa-shopping-cart"></i> Sold
    </a>
    <a href="{{ route('admin.card-history.index', ['status' => 'expired']) }}" class="tab-btn {{ request('status') === 'expired' ? 'active' : '' }}">
        <i class="fas fa-times-circle"></i> Expired
    </a>
</div>

<!-- History Table -->
<div class="history-table-card">
    @if($cardKeys->count() > 0)
    <div style="padding: 15px 20px; border-bottom: 1px solid #f1f3f5;">
        <span style="font-size: 14px; color: #636e72;">
            Total Records: <strong>{{ $cardKeys->total() }}</strong>
        </span>
    </div>
    
    <table class="history-table">
        <thead>
            <tr>
                <th>Key Code</th>
                <th>Category</th>
                <th>Card Type</th>
                <th>Price</th>
                <th style="width: 100px;">Status</th>
                <th style="width: 150px;">Added Date</th>
                <th style="width: 150px;">Sold Date</th>
                <th>Buyer Info</th>
            </tr>
        </thead>
        <tbody>
            @foreach($cardKeys as $key)
            <tr>
                <td><code style="font-weight: 600;">{{ $key->key_code }}</code></td>
                <td>{{ $key->cardType->category->name }}</td>
                <td>{{ $key->cardType->name }}</td>
                <td>৳{{ number_format($key->cardType->price, 2) }}</td>
                <td>
                    <span class="status-badge {{ $key->status }}">
                        {{ ucfirst($key->status) }}
                    </span>
                </td>
                <td>{{ $key->created_at->format('M d, Y H:i') }}</td>
                <td>
                    @if($key->sold_at)
                        {{ $key->sold_at->format('M d, Y H:i') }}
                    @else
                        <span style="color: #95a5a6;">-</span>
                    @endif
                </td>
                <td>
                    @if($key->transaction)
                        <div style="font-size: 12px;">
                            @if($key->transaction->user)
                                {{-- Authenticated user purchase --}}
                                <strong>{{ $key->transaction->user->name }}</strong><br>
                                <span style="color: #95a5a6;">{{ $key->transaction->user->phone ?? $key->transaction->customer_phone }}</span>
                            @else
                                {{-- Guest purchase --}}
                                <strong>{{ $key->transaction->customer_name }}</strong><br>
                                <span style="color: #95a5a6;">{{ $key->transaction->customer_phone }}</span>
                                @if($key->transaction->customer_email)
                                    <br><span style="color: #95a5a6; font-size: 11px;">{{ $key->transaction->customer_email }}</span>
                                @endif
                            @endif
                        </div>
                    @else
                        <span style="color: #95a5a6;">-</span>
                    @endif
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    @else
    <div class="empty-state">
        <i class="fas fa-history"></i>
        <h3>No History Records</h3>
        <p>Card key history will appear here once you add keys</p>
    </div>
    @endif
</div>

@if($cardKeys->hasPages())
<div style="margin-top: 20px;">
    {{ $cardKeys->appends(request()->query())->links() }}
</div>
@endif

@endsection

