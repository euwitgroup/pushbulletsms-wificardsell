@extends('admin.layouts.app')

@section('title', 'Card Inventory')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .breadcrumb-nav a:hover {
        color: #3498db;
    }
    
    .summary-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .summary-card {
        background: white;
        border-radius: 8px;
        padding: 20px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        text-align: center;
    }
    
    .summary-value {
        font-size: 32px;
        font-weight: 700;
        color: #2c3e50;
        margin-bottom: 8px;
    }
    
    .summary-label {
        font-size: 13px;
        color: #7f8c8d;
        font-weight: 500;
    }
    
    .summary-card.total {
        background: linear-gradient(135deg, #667eea, #764ba2);
        color: white;
    }
    
    .summary-card.total .summary-value,
    .summary-card.total .summary-label {
        color: white;
    }
    
    .summary-card.available {
        background: linear-gradient(135deg, #43e97b, #38f9d7);
        color: white;
    }
    
    .summary-card.available .summary-value,
    .summary-card.available .summary-label {
        color: white;
    }
    
    .summary-card.sold {
        background: linear-gradient(135deg, #4facfe, #00f2fe);
        color: white;
    }
    
    .summary-card.sold .summary-value,
    .summary-card.sold .summary-label {
        color: white;
    }
    
    .inventory-table-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .inventory-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .inventory-table thead th {
        background: #f8f9fa;
        padding: 12px 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: #636e72;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: 1px solid #e9ecef;
    }
    
    .inventory-table tbody td {
        padding: 12px 16px;
        font-size: 13px;
        border-bottom: 1px solid #f1f3f5;
        vertical-align: middle;
    }
    
    .inventory-table tbody tr:hover {
        background: #f8f9fa;
    }
    
    .category-badge {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        background: #e3f2fd;
        color: #1976d2;
    }
    
    .stock-badge {
        display: inline-block;
        padding: 6px 12px;
        border-radius: 6px;
        font-size: 13px;
        font-weight: 700;
    }
    
    .stock-badge.high {
        background: #e8f5e9;
        color: #43a047;
    }
    
    .stock-badge.medium {
        background: #fff3e0;
        color: #f57c00;
    }
    
    .stock-badge.low {
        background: #ffebee;
        color: #c62828;
    }
    
    .progress-bar {
        width: 100%;
        height: 8px;
        background: #f1f3f5;
        border-radius: 4px;
        overflow: hidden;
        margin-top: 5px;
    }
    
    .progress-fill {
        height: 100%;
        border-radius: 4px;
        transition: width 0.3s ease;
    }
    
    .progress-fill.high {
        background: #43a047;
    }
    
    .progress-fill.medium {
        background: #f57c00;
    }
    
    .progress-fill.low {
        background: #c62828;
    }
    
    .card-image {
        width: 50px;
        height: 35px;
        object-fit: cover;
        border-radius: 6px;
        border: 2px solid #e9ecef;
    }
    
    .no-image {
        width: 50px;
        height: 35px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #f8f9fa;
        border-radius: 6px;
        color: #95a5a6;
        font-size: 16px;
    }
    
    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: #95a5a6;
    }
    
    .empty-state i {
        font-size: 64px;
        margin-bottom: 20px;
        opacity: 0.3;
    }
    
    .empty-state h3 {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 8px;
        color: #636e72;
    }
</style>

<div class="page-breadcrumb">
    <h1 class="page-title">Card Inventory</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > 
        <a href="{{ route('admin.wifi-cards.index') }}">WiFi Cards</a> > 
        <span>Inventory</span>
    </div>
</div>

<!-- Summary Cards -->
<div class="summary-grid">
    <div class="summary-card total">
        <div class="summary-value">{{ $totalKeys }}</div>
        <div class="summary-label">Total Keys</div>
    </div>
    
    <div class="summary-card available">
        <div class="summary-value">{{ $availableKeys }}</div>
        <div class="summary-label">Available</div>
    </div>
    
    <div class="summary-card sold">
        <div class="summary-value">{{ $soldKeys }}</div>
        <div class="summary-label">Sold</div>
    </div>
    
    <div class="summary-card">
        <div class="summary-value">{{ $totalCardTypes }}</div>
        <div class="summary-label">Card Types</div>
    </div>
</div>

<!-- Inventory Table -->
<div class="inventory-table-card">
    @if($inventory->count() > 0)
    <table class="inventory-table">
        <thead>
            <tr>
                <th style="width: 70px;">Image</th>
                <th>Card Type</th>
                <th>Category</th>
                <th style="width: 120px;">Price</th>
                <th style="width: 120px;">Available</th>
                <th style="width: 100px;">Sold</th>
                <th style="width: 100px;">Total</th>
                <th style="width: 200px;">Stock Level</th>
            </tr>
        </thead>
        <tbody>
            @foreach($inventory as $item)
            @php
                $stockPercentage = $item->total_keys > 0 ? ($item->available_keys / $item->total_keys) * 100 : 0;
                $stockClass = $stockPercentage > 50 ? 'high' : ($stockPercentage > 20 ? 'medium' : 'low');
            @endphp
            <tr>
                <td>
                    @if($item->image)
                    <img src="{{ asset('storage/' . $item->image) }}" alt="{{ $item->name }}" class="card-image">
                    @else
                    <div class="no-image">
                        <i class="fas fa-image"></i>
                    </div>
                    @endif
                </td>
                <td><strong>{{ $item->name }}</strong></td>
                <td>
                    <span class="category-badge">{{ $item->category->name }}</span>
                </td>
                <td>
                    <strong style="color: #43a047;">৳{{ number_format($item->price, 2) }}</strong>
                </td>
                <td>
                    <span class="stock-badge {{ $stockClass }}">{{ $item->available_keys }}</span>
                </td>
                <td>{{ $item->sold_keys }}</td>
                <td><strong>{{ $item->total_keys }}</strong></td>
                <td>
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <span style="font-size: 12px; font-weight: 600; color: #636e72;">{{ round($stockPercentage) }}%</span>
                        <div class="progress-bar" style="flex: 1;">
                            <div class="progress-fill {{ $stockClass }}" style="width: {{ $stockPercentage }}%;"></div>
                        </div>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    @else
    <div class="empty-state">
        <i class="fas fa-warehouse"></i>
        <h3>No Inventory Data</h3>
        <p>Add card keys to see inventory information</p>
    </div>
    @endif
</div>

@endsection

