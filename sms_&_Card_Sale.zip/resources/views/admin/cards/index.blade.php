@extends('admin.layouts.app')

@section('title', 'WiFi Cards Dashboard')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .breadcrumb-nav a:hover {
        color: #3498db;
    }
    
    .dashboard-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: white;
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        transition: all 0.3s ease;
    }
    
    .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    
    .stat-card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
    }
    
    .stat-icon {
        width: 48px;
        height: 48px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 22px;
        color: white;
    }
    
    .stat-icon.categories {
        background: linear-gradient(135deg, #667eea, #764ba2);
    }
    
    .stat-icon.types {
        background: linear-gradient(135deg, #f093fb, #f5576c);
    }
    
    .stat-icon.keys {
        background: linear-gradient(135deg, #4facfe, #00f2fe);
    }
    
    .stat-icon.sold {
        background: linear-gradient(135deg, #43e97b, #38f9d7);
    }
    
    .stat-icon.transactions {
        background: linear-gradient(135deg, #fa709a, #fee140);
    }
    
    .stat-icon.revenue {
        background: linear-gradient(135deg, #30cfd0, #330867);
    }
    
    .stat-value {
        font-size: 28px;
        font-weight: 700;
        color: #2c3e50;
        margin-bottom: 5px;
    }
    
    .stat-label {
        font-size: 13px;
        color: #7f8c8d;
        font-weight: 500;
    }
    
    .quick-actions {
        background: white;
        border-radius: 12px;
        padding: 25px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        margin-bottom: 25px;
    }
    
    .quick-actions h3 {
        font-size: 16px;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 20px;
    }
    
    .action-buttons {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
    }
    
    .action-btn {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 15px 20px;
        border: 2px solid #e9ecef;
        border-radius: 8px;
        background: white;
        color: #2c3e50;
        text-decoration: none;
        font-weight: 500;
        font-size: 14px;
        transition: all 0.3s ease;
    }
    
    .action-btn:hover {
        border-color: #667eea;
        background: #f8f9ff;
        transform: translateX(3px);
    }
    
    .action-btn i {
        font-size: 20px;
        color: #667eea;
    }
    
    .recent-activity {
        background: white;
        border-radius: 12px;
        padding: 25px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    
    .recent-activity h3 {
        font-size: 16px;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 20px;
    }
    
    .activity-list {
        list-style: none;
        padding: 0;
        margin: 0;
    }
    
    .activity-item {
        display: flex;
        align-items: center;
        gap: 15px;
        padding: 15px 0;
        border-bottom: 1px solid #f1f3f5;
    }
    
    .activity-item:last-child {
        border-bottom: none;
    }
    
    .activity-icon {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
        flex-shrink: 0;
    }
    
    .activity-icon.success {
        background: #e8f5e9;
        color: #43a047;
    }
    
    .activity-icon.info {
        background: #e3f2fd;
        color: #1e88e5;
    }
    
    .activity-icon.warning {
        background: #fff3e0;
        color: #fb8c00;
    }
    
    .activity-content {
        flex: 1;
    }
    
    .activity-title {
        font-size: 13px;
        font-weight: 500;
        color: #2c3e50;
        margin-bottom: 3px;
    }
    
    .activity-time {
        font-size: 11px;
        color: #95a5a6;
    }
</style>

<div class="page-breadcrumb">
    <h1 class="page-title">WiFi Cards Dashboard</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > <span>WiFi Cards</span>
    </div>
</div>

<!-- Statistics Cards -->
<div class="dashboard-grid">
    <div class="stat-card">
        <div class="stat-card-header">
            <div class="stat-icon categories">
                <i class="fas fa-th-large"></i>
            </div>
        </div>
        <div class="stat-value">{{ $totalCategories }}</div>
        <div class="stat-label">Total Categories</div>
    </div>
    
    <div class="stat-card">
        <div class="stat-card-header">
            <div class="stat-icon types">
                <i class="fas fa-tags"></i>
            </div>
        </div>
        <div class="stat-value">{{ $totalTypes }}</div>
        <div class="stat-label">Card Types</div>
    </div>
    
    <div class="stat-card">
        <div class="stat-card-header">
            <div class="stat-icon keys">
                <i class="fas fa-key"></i>
            </div>
        </div>
        <div class="stat-value">{{ $availableKeys }}</div>
        <div class="stat-label">Available Keys</div>
    </div>
    
    <div class="stat-card">
        <div class="stat-card-header">
            <div class="stat-icon sold">
                <i class="fas fa-check-circle"></i>
            </div>
        </div>
        <div class="stat-value">{{ $soldKeys }}</div>
        <div class="stat-label">Sold Keys</div>
    </div>
    
    <div class="stat-card">
        <div class="stat-card-header">
            <div class="stat-icon transactions">
                <i class="fas fa-receipt"></i>
            </div>
        </div>
        <div class="stat-value">{{ $totalTransactions }}</div>
        <div class="stat-label">Transactions</div>
    </div>
    
    <div class="stat-card">
        <div class="stat-card-header">
            <div class="stat-icon revenue">
                <i class="fas fa-dollar-sign"></i>
            </div>
        </div>
        <div class="stat-value">৳{{ number_format($totalRevenue, 2) }}</div>
        <div class="stat-label">Total Revenue</div>
    </div>
</div>

<!-- Quick Actions -->
<div class="quick-actions">
    <h3><i class="fas fa-bolt me-2"></i>Quick Actions</h3>
    <div class="action-buttons">
        <a href="{{ route('admin.card-categories.index') }}" class="action-btn">
            <i class="fas fa-th-large"></i>
            <span>Manage Categories</span>
        </a>
        <a href="{{ route('admin.card-types.index') }}" class="action-btn">
            <i class="fas fa-tags"></i>
            <span>Manage Card Types</span>
        </a>
        <a href="{{ route('admin.card-keys.index') }}" class="action-btn">
            <i class="fas fa-key"></i>
            <span>Manage Card Keys</span>
        </a>
        <a href="{{ route('admin.card-inventory.index') }}" class="action-btn">
            <i class="fas fa-warehouse"></i>
            <span>View Inventory</span>
        </a>
        <a href="{{ route('admin.card-history.index') }}" class="action-btn">
            <i class="fas fa-history"></i>
            <span>Card History</span>
        </a>
        <a href="{{ route('admin.card-transactions.index') }}" class="action-btn">
            <i class="fas fa-receipt"></i>
            <span>View Transactions</span>
        </a>
    </div>
</div>

<!-- Recent Activity -->
<div class="recent-activity">
    <h3><i class="fas fa-clock me-2"></i>Recent Activity</h3>
    <ul class="activity-list">
        @forelse($recentActivities as $activity)
        <li class="activity-item">
            <div class="activity-icon {{ $activity['type'] }}">
                <i class="fas {{ $activity['icon'] }}"></i>
            </div>
            <div class="activity-content">
                <div class="activity-title">{{ $activity['title'] }}</div>
                <div class="activity-time">{{ $activity['time'] }}</div>
            </div>
        </li>
        @empty
        <li class="activity-item">
            <div class="activity-content">
                <div class="activity-title">No recent activity</div>
            </div>
        </li>
        @endforelse
    </ul>
</div>

@endsection

