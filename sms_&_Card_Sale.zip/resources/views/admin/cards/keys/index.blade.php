@extends('admin.layouts.app')

@section('title', 'Service Card Keys')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .breadcrumb-nav a:hover {
        color: #3498db;
    }
    
    .filter-card {
        background: white;
        border-radius: 8px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .filter-row {
        display: grid;
        grid-template-columns: 1fr 1fr auto;
        gap: 15px;
        align-items: end;
    }
    
    .filter-group {
        display: flex;
        flex-direction: column;
        gap: 5px;
    }
    
    .filter-group label {
        font-size: 13px;
        font-weight: 600;
        color: #636e72;
    }
    
    .filter-group select {
        padding: 8px 12px;
        border: 1px solid #dfe6e9;
        border-radius: 4px;
        font-size: 13px;
    }
    
    .btn-add-keys {
        background: #26de81;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s ease;
        height: fit-content;
    }
    
    .btn-add-keys:hover {
        background: #20bf6b;
        transform: translateY(-1px);
    }
    
    .keys-table-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .table-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px 20px;
        border-bottom: 1px solid #f1f3f5;
    }
    
    .table-actions {
        display: flex;
        gap: 10px;
    }
    
    .btn-bulk-delete {
        background: #ff7675;
        color: white;
        border: none;
        padding: 6px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        transition: all 0.2s ease;
    }
    
    .btn-bulk-delete:hover {
        background: #d63031;
    }
    
    .keys-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .keys-table thead th {
        background: #f8f9fa;
        padding: 12px 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: #636e72;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: 1px solid #e9ecef;
    }
    
    .keys-table tbody td {
        padding: 12px 16px;
        font-size: 13px;
        border-bottom: 1px solid #f1f3f5;
        vertical-align: middle;
    }
    
    .keys-table tbody tr:hover {
        background: #f8f9fa;
    }
    
    .status-badge {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
    }
    
    .status-badge.available {
        background: #e8f5e9;
        color: #43a047;
    }
    
    .status-badge.sold {
        background: #e3f2fd;
        color: #1976d2;
    }
    
    .status-badge.expired {
        background: #ffebee;
        color: #c62828;
    }
    
    .btn-delete-key {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 12px;
        background: #ffcccc;
        color: #ee5a6f;
    }
    
    .btn-delete-key:hover {
        transform: scale(1.1);
    }
    
    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: #95a5a6;
    }
    
    .empty-state i {
        font-size: 64px;
        margin-bottom: 20px;
        opacity: 0.3;
    }
    
    .empty-state h3 {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 8px;
        color: #636e72;
    }
    
    .empty-state p {
        font-size: 14px;
        margin-bottom: 20px;
    }
</style>

<div class="page-breadcrumb">
    <h1 class="page-title">Service Card Keys</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > 
        <a href="{{ route('admin.wifi-cards.index') }}">WiFi Cards</a> > 
        <span>Service Card Keys</span>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row" style="margin-bottom: 20px;">
    <div class="col-md-4">
        <div class="stat-card" style="background: linear-gradient(135deg, #26de81 0%, #20bf6b 100%); color: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <div style="font-size: 13px; opacity: 0.9; margin-bottom: 5px;">Available Keys</div>
                    <div style="font-size: 28px; font-weight: 700;">{{ number_format($availableCount) }}</div>
                </div>
                <div style="font-size: 40px; opacity: 0.3;">
                    <i class="fas fa-check-circle"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card" style="background: linear-gradient(135deg, #f7b731 0%, #f39c12 100%); color: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <div style="font-size: 13px; opacity: 0.9; margin-bottom: 5px;">Pending Keys</div>
                    <div style="font-size: 28px; font-weight: 700;">{{ number_format($pendingCount) }}</div>
                </div>
                <div style="font-size: 40px; opacity: 0.3;">
                    <i class="fas fa-clock"></i>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="stat-card" style="background: linear-gradient(135deg, #a29bfe 0%, #6c5ce7 100%); color: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <div style="font-size: 13px; opacity: 0.9; margin-bottom: 5px;">Sold Keys</div>
                    <div style="font-size: 28px; font-weight: 700;">{{ number_format($soldCount) }}</div>
                    <a href="{{ route('admin.card-history.index') }}" style="font-size: 11px; color: rgba(255,255,255,0.9); text-decoration: underline;">
                        View in History →
                    </a>
                </div>
                <div style="font-size: 40px; opacity: 0.3;">
                    <i class="fas fa-shopping-cart"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Info Alert -->
<div style="background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%); border-left: 4px solid #2196f3; padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; display: flex; align-items: center; gap: 15px;">
    <i class="fas fa-info-circle" style="font-size: 24px; color: #2196f3;"></i>
    <div style="flex: 1;">
        <div style="font-weight: 600; color: #1976d2; margin-bottom: 5px;">Auto-Hidden Sold Keys</div>
        <div style="font-size: 13px; color: #1565c0;">
            Sold and expired card keys are automatically removed from this page. 
            You can view them in the <a href="{{ route('admin.card-history.index') }}" style="color: #0d47a1; font-weight: 600; text-decoration: underline;">Card History</a> page.
        </div>
    </div>
</div>

<!-- Filter Section -->
<div class="filter-card">
    <form method="GET" action="{{ route('admin.card-keys.index') }}">
        <div class="filter-row">
            <div class="filter-group">
                <label>Card Category</label>
                <select name="category_id" id="categorySelect" onchange="loadCardTypes(this.value)">
                    <option value="">All Categories</option>
                    @foreach($categories as $category)
                        <option value="{{ $category->id }}" {{ request('category_id') == $category->id ? 'selected' : '' }}>
                            {{ $category->name }}
                        </option>
                    @endforeach
                </select>
            </div>
            
            <div class="filter-group">
                <label>Card Type</label>
                <select name="type_id" id="typeSelect">
                    <option value="">All Types</option>
                    @foreach($cardTypes as $type)
                        <option value="{{ $type->id }}" {{ request('type_id') == $type->id ? 'selected' : '' }}>
                            {{ $type->name }}
                        </option>
                    @endforeach
                </select>
            </div>
            
            <button type="button" class="btn-add-keys" onclick="showBulkAddModal()">
                <i class="fas fa-plus"></i>
                Add Card Keys
            </button>
        </div>
    </form>
</div>

<!-- Keys Table -->
<div class="keys-table-card">
    @if($cardKeys->count() > 0)
    <div class="table-header">
        <div>
            <span style="font-size: 14px; color: #636e72;">
                Total: <strong>{{ $cardKeys->total() }}</strong> keys
                <span style="margin-left: 20px;">
                    Available: <strong style="color: #43a047;">{{ $availableCount }}</strong>
                </span>
            </span>
        </div>
        <div class="table-actions">
            <button class="btn-bulk-delete" onclick="bulkDeleteSelected()">
                <i class="fas fa-trash"></i>
                Delete Selected
            </button>
        </div>
    </div>
    
    <table class="keys-table">
        <thead>
            <tr>
                <th style="width: 50px;">
                    <input type="checkbox" id="selectAll" onchange="toggleSelectAll(this)">
                </th>
                <th>Key Code</th>
                <th>Category</th>
                <th>Card Type</th>
                <th>Price</th>
                <th style="width: 100px;">Status</th>
                <th style="width: 150px;">Sold At</th>
                <th style="width: 80px;">Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($cardKeys as $key)
            <tr>
                <td>
                    <input type="checkbox" class="key-checkbox" value="{{ $key->id }}">
                </td>
                <td><code style="font-weight: 600;">{{ $key->key_code }}</code></td>
                <td>{{ $key->cardType->category->name }}</td>
                <td>{{ $key->cardType->name }}</td>
                <td>৳{{ number_format($key->cardType->price, 2) }}</td>
                <td>
                    <span class="status-badge {{ $key->status }}">
                        {{ ucfirst($key->status) }}
                    </span>
                </td>
                <td>{{ $key->sold_at ? $key->sold_at->format('M d, Y H:i') : '-' }}</td>
                <td>
                    @if($key->status === 'available')
                    <button class="btn-delete-key" onclick="deleteKey({{ $key->id }})" title="Delete">
                        <i class="fas fa-trash"></i>
                    </button>
                    @else
                    -
                    @endif
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    @else
    <div class="empty-state">
        <i class="fas fa-key"></i>
        <h3>No Card Keys Found</h3>
        <p>Select a category and card type, then add keys</p>
        <button class="btn-add-keys" onclick="showBulkAddModal()">
            <i class="fas fa-plus"></i>
            Add Card Keys
        </button>
    </div>
    @endif
</div>

@if($cardKeys->hasPages())
<div style="margin-top: 20px;">
    {{ $cardKeys->links() }}
</div>
@endif

@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
const allCategories = @json($categories);

function loadCardTypes(categoryId) {
    const typeSelect = document.getElementById('typeSelect');
    typeSelect.innerHTML = '<option value="">All Types</option>';
    
    if (!categoryId) {
        return;
    }
    
    fetch(`/admin/card-types-by-category/${categoryId}`)
        .then(response => response.json())
        .then(types => {
            types.forEach(type => {
                const option = document.createElement('option');
                option.value = type.id;
                option.textContent = type.name;
                typeSelect.appendChild(option);
            });
        });
}

function showBulkAddModal() {
    let categoryOptions = allCategories.map(cat => `<option value="${cat.id}">${cat.name}</option>`).join('');
    
    Swal.fire({
        title: 'Add Card Keys (Bulk)',
        html: `
            <div style="text-align: left;">
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600; font-size: 13px;">Card Category *</label>
                    <select id="card_category_id" class="swal2-select" style="width: 100%; margin: 0;" onchange="loadModalCardTypes(this.value)">
                        <option value="">Select Category</option>
                        ${categoryOptions}
                    </select>
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600; font-size: 13px;">Card Type *</label>
                    <select id="card_type_id" class="swal2-select" style="width: 100%; margin: 0;">
                        <option value="">Select Card Type First</option>
                    </select>
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 600; font-size: 13px;">Card Keys (One per line) *</label>
                    <textarea id="card_keys" class="swal2-textarea" style="width: 100%; margin: 0; height: 200px; font-family: monospace;" placeholder="Enter card keys, one per line&#10;Example:&#10;ABC123XYZ&#10;DEF456UVW&#10;GHI789RST"></textarea>
                    <small style="color: #95a5a6; font-size: 11px;">Tip: Each line will be treated as one card key</small>
                </div>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'Add Keys',
        cancelButtonText: 'Cancel',
        confirmButtonColor: '#26de81',
        width: '550px',
        preConfirm: () => {
            const card_type_id = document.getElementById('card_type_id').value;
            const card_keys = document.getElementById('card_keys').value.trim();
            
            if (!card_type_id) {
                Swal.showValidationMessage('Please select a card type');
                return false;
            }
            if (!card_keys) {
                Swal.showValidationMessage('Please enter at least one card key');
                return false;
            }
            
            return { card_type_id, card_keys };
        }
    }).then((result) => {
        if (result.isConfirmed) {
            submitBulkKeys(result.value);
        }
    });
}

function loadModalCardTypes(categoryId) {
    const typeSelect = document.getElementById('card_type_id');
    typeSelect.innerHTML = '<option value="">Loading...</option>';
    
    if (!categoryId) {
        typeSelect.innerHTML = '<option value="">Select Category First</option>';
        return;
    }
    
    fetch(`/admin/card-types-by-category/${categoryId}`)
        .then(response => response.json())
        .then(types => {
            typeSelect.innerHTML = '<option value="">Select Card Type</option>';
            types.forEach(type => {
                const option = document.createElement('option');
                option.value = type.id;
                option.textContent = type.name;
                typeSelect.appendChild(option);
            });
        });
}

function submitBulkKeys(data) {
    fetch('{{ route("admin.card-keys.store") }}', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                toast: true,
                position: 'top-end',
                icon: 'success',
                title: data.message,
                showConfirmButton: false,
                timer: 3000
            });
            setTimeout(() => location.reload(), 1000);
        } else {
            Swal.fire('Error!', data.message, 'error');
        }
    })
    .catch(error => {
        Swal.fire('Error!', 'Something went wrong', 'error');
    });
}

function deleteKey(id) {
    Swal.fire({
        title: 'Delete Card Key?',
        text: "This action cannot be undone!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#c62828',
        cancelButtonColor: '#95a5a6',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch(`/admin/card-keys/${id}`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        toast: true,
                        position: 'top-end',
                        icon: 'success',
                        title: data.message,
                        showConfirmButton: false,
                        timer: 2000
                    });
                    setTimeout(() => location.reload(), 1000);
                } else {
                    Swal.fire('Error!', data.message, 'error');
                }
            });
        }
    });
}

function toggleSelectAll(checkbox) {
    const checkboxes = document.querySelectorAll('.key-checkbox');
    checkboxes.forEach(cb => cb.checked = checkbox.checked);
}

function bulkDeleteSelected() {
    const selectedIds = Array.from(document.querySelectorAll('.key-checkbox:checked')).map(cb => cb.value);
    
    if (selectedIds.length === 0) {
        Swal.fire('No Selection', 'Please select at least one key to delete', 'info');
        return;
    }
    
    Swal.fire({
        title: 'Delete Selected Keys?',
        text: `This will delete ${selectedIds.length} card key(s)!`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#c62828',
        cancelButtonColor: '#95a5a6',
        confirmButtonText: 'Yes, delete them!'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch('{{ route("admin.card-keys.bulk-delete") }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify({ ids: selectedIds })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        toast: true,
                        position: 'top-end',
                        icon: 'success',
                        title: data.message,
                        showConfirmButton: false,
                        timer: 3000
                    });
                    setTimeout(() => location.reload(), 1000);
                } else {
                    Swal.fire('Error!', data.message, 'error');
                }
            });
        }
    });
}
</script>
@endpush

