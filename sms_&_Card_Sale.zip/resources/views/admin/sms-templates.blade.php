@extends('admin.layouts.app')

@section('title', 'SMS Templates')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .table-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .btn-add-new {
        background: #26de81;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s ease;
        text-decoration: none;
    }
    
    .btn-add-new:hover {
        background: #20bf6b;
        transform: translateY(-1px);
        color: white;
    }
    
    .templates-table-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .templates-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .templates-table thead th {
        background: #f8f9fa;
        padding: 12px 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: #7f8c8d;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .templates-table tbody td {
        padding: 14px 16px;
        font-size: 13px;
        color: #2c3e50;
        border-bottom: 1px solid #f1f2f6;
        vertical-align: middle;
    }
    
    .templates-table tbody tr:hover {
        background: #fafbfc;
    }
    
    .badge-type {
        padding: 4px 10px;
        border-radius: 4px;
        font-size: 11px;
        font-weight: 500;
        display: inline-block;
    }
    
    .badge-type.promotional {
        background: #3498db;
        color: white;
    }
    
    .badge-type.transactional {
        background: #8854d0;
        color: white;
    }
    
    .badge-type.otp {
        background: #ffc107;
        color: white;
    }
    
    .status-toggle {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 22px;
    }
    
    .status-toggle input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .toggle-slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .3s;
        border-radius: 24px;
    }
    
    .toggle-slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: .3s;
        border-radius: 50%;
    }
    
    input:checked + .toggle-slider {
        background-color: #26de81;
    }
    
    input:checked + .toggle-slider:before {
        transform: translateX(18px);
    }
    
    .action-buttons {
        display: flex;
        gap: 6px;
    }
    
    .btn-action {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 12px;
    }
    
    .btn-action:hover {
        transform: scale(1.1);
    }
    
    .btn-action.edit {
        background: #ffeaa7;
        color: #fdcb6e;
    }
    
    .btn-action.delete {
        background: #ffcccc;
        color: #ee5a6f;
    }
</style>

<!-- Breadcrumb -->
<div class="page-breadcrumb">
    <h1 class="page-title">SMS Templates</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > <span>SMS Templates</span>
    </div>
</div>

<!-- Table Controls -->
<div class="table-controls">
    <button class="btn-add-new" onclick="showCreateTemplateDialog()">
        <i class="fas fa-plus"></i> Add New Template
    </button>
</div>

<!-- Templates Table -->
<div class="templates-table-card">
    <table class="templates-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Template Name</th>
                <th>Type</th>
                <th>Message</th>
                <th>Variables</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse($templates as $template)
            <tr>
                <td><strong>#{{ $template->id }}</strong></td>
                <td>{{ $template->name }}</td>
                <td><span class="badge-type {{ $template->type }}">{{ ucfirst($template->type) }}</span></td>
                <td style="max-width: 300px;">{{ $template->message }}</td>
                <td>
                    @if($template->variables)
                        <code>{{ $template->variables }}</code>
                    @else
                        -
                    @endif
                </td>
                <td>
                    <form action="{{ route('admin.sms-templates.toggle-status', $template->id) }}" method="POST" id="toggle-form-{{ $template->id }}" style="display: inline;">
                        @csrf
                    </form>
                    <label class="status-toggle">
                        <input type="checkbox" {{ $template->status ? 'checked' : '' }}
                               onchange="confirmStatusToggle(this, document.getElementById('toggle-form-{{ $template->id }}'), '{{ $template->name }}', {{ $template->status ? 'true' : 'false' }})">
                        <span class="toggle-slider"></span>
                    </label>
                </td>
                <td>
                    <div class="action-buttons">
                        <button class="btn-action edit" title="Edit" onclick="showEditTemplateDialog({{ $template->id }}, '{{ $template->name }}', '{{ $template->type }}', `{{ addslashes($template->message) }}`, '{{ $template->variables }}')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <form action="{{ route('admin.sms-templates.destroy', $template->id) }}" 
                              method="POST" 
                              class="d-inline delete-form"
                              id="delete-form-{{ $template->id }}">
                            @csrf
                            @method('DELETE')
                            <button type="button" 
                                    class="btn-action delete" 
                                    title="Delete"
                                    onclick="confirmDelete('Delete Template', 'Are you sure you want to delete {{ $template->name }}?', document.getElementById('delete-form-{{ $template->id }}'))">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="7" class="text-center py-5">
                    <i class="fas fa-inbox fa-3x text-muted mb-3" style="display: block; margin-bottom: 15px;"></i>
                    <p class="text-muted mb-3">No SMS templates found</p>
                    <button class="btn-add-new" onclick="showCreateTemplateDialog()">Create First Template</button>
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>

@push('scripts')
<script>
function showCreateTemplateDialog() {
    Swal.fire({
        title: 'Create SMS Template',
        html: `
            <div style="text-align: left;">
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 500;">Template Name</label>
                    <input type="text" id="template-name" class="swal2-input" placeholder="Enter template name" style="width: 100%; margin: 0;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 500;">Type</label>
                    <select id="template-type" class="swal2-select" style="width: 100%; margin: 0;">
                        <option value="transactional">Transactional</option>
                        <option value="promotional">Promotional</option>
                        <option value="otp">OTP</option>
                    </select>
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 500;">Message</label>
                    <textarea id="template-message" class="swal2-textarea" placeholder="Enter message (use {variable} for dynamic content)" style="width: 100%; margin: 0; height: 100px;"></textarea>
                </div>
                <div>
                    <label style="display: block; margin-bottom: 5px; font-weight: 500;">Variables (comma separated)</label>
                    <input type="text" id="template-variables" class="swal2-input" placeholder="e.g., name, amount, code" style="width: 100%; margin: 0;">
                </div>
            </div>
        `,
        showCancelButton: true,
        confirmButtonColor: '#26de81',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: '<i class="fas fa-check me-2"></i>Create Template',
        cancelButtonText: 'Cancel',
        width: '600px',
        preConfirm: () => {
            const name = document.getElementById('template-name').value;
            const type = document.getElementById('template-type').value;
            const message = document.getElementById('template-message').value;
            const variables = document.getElementById('template-variables').value;
            
            if (!name || !message) {
                Swal.showValidationMessage('Please fill in all required fields');
                return false;
            }
            
            return { name, type, message, variables };
        }
    }).then((result) => {
        if (result.isConfirmed) {
            // Create form and submit
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '{{ route("admin.sms-templates.store") }}';
            
            // CSRF token
            const csrfInput = document.createElement('input');
            csrfInput.type = 'hidden';
            csrfInput.name = '_token';
            csrfInput.value = '{{ csrf_token() }}';
            form.appendChild(csrfInput);
            
            // Form fields
            const fields = result.value;
            Object.keys(fields).forEach(key => {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = key;
                input.value = fields[key];
                form.appendChild(input);
            });
            
            // Submit
            document.body.appendChild(form);
            showLoading('Creating template...');
            form.submit();
        }
    });
}

function showEditTemplateDialog(id, name, type, message, variables) {
    Swal.fire({
        title: 'Edit SMS Template',
        html: `
            <div style="text-align: left;">
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 500;">Template Name</label>
                    <input type="text" id="template-name" class="swal2-input" value="${name}" style="width: 100%; margin: 0;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 500;">Type</label>
                    <select id="template-type" class="swal2-select" style="width: 100%; margin: 0;">
                        <option value="transactional" ${type === 'transactional' ? 'selected' : ''}>Transactional</option>
                        <option value="promotional" ${type === 'promotional' ? 'selected' : ''}>Promotional</option>
                        <option value="otp" ${type === 'otp' ? 'selected' : ''}>OTP</option>
                    </select>
                </div>
                <div style="margin-bottom: 15px;">
                    <label style="display: block; margin-bottom: 5px; font-weight: 500;">Message</label>
                    <textarea id="template-message" class="swal2-textarea" style="width: 100%; margin: 0; height: 100px;">${message}</textarea>
                </div>
                <div>
                    <label style="display: block; margin-bottom: 5px; font-weight: 500;">Variables (comma separated)</label>
                    <input type="text" id="template-variables" class="swal2-input" value="${variables || ''}" style="width: 100%; margin: 0;">
                </div>
            </div>
        `,
        showCancelButton: true,
        confirmButtonColor: '#3498db',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: '<i class="fas fa-save me-2"></i>Update Template',
        cancelButtonText: 'Cancel',
        width: '600px',
        preConfirm: () => {
            const name = document.getElementById('template-name').value;
            const type = document.getElementById('template-type').value;
            const message = document.getElementById('template-message').value;
            const variables = document.getElementById('template-variables').value;
            
            if (!name || !message) {
                Swal.showValidationMessage('Please fill in all required fields');
                return false;
            }
            
            return { name, type, message, variables };
        }
    }).then((result) => {
        if (result.isConfirmed) {
            // Create form and submit
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = `/admin/sms-templates/${id}`;
            
            // CSRF token
            const csrfInput = document.createElement('input');
            csrfInput.type = 'hidden';
            csrfInput.name = '_token';
            csrfInput.value = '{{ csrf_token() }}';
            form.appendChild(csrfInput);
            
            // Method spoofing for PUT
            const methodInput = document.createElement('input');
            methodInput.type = 'hidden';
            methodInput.name = '_method';
            methodInput.value = 'PUT';
            form.appendChild(methodInput);
            
            // Form fields
            const fields = result.value;
            Object.keys(fields).forEach(key => {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = key;
                input.value = fields[key];
                form.appendChild(input);
            });
            
            // Submit
            document.body.appendChild(form);
            showLoading('Updating template...');
            form.submit();
        }
    });
}

function confirmStatusToggle(checkbox, form, templateName, currentStatus) {
    const newStatus = !currentStatus;
    const statusText = newStatus ? 'activate' : 'deactivate';
    
    Swal.fire({
        title: 'Change Template Status?',
        html: `Are you sure you want to <strong>${statusText}</strong> ${templateName}?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: newStatus ? '#26de81' : '#ee5a6f',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: `Yes, ${statusText}!`,
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            showLoading('Updating status...');
            form.submit();
        } else {
            checkbox.checked = currentStatus;
        }
    });
}
</script>
@endpush

@endsection
