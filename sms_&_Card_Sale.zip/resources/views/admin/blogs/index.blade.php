@extends('admin.layouts.app')

@section('title', 'Blogs Management')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .breadcrumb-nav a:hover {
        color: #3498db;
    }
    
    .table-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .btn-add-new {
        background: #26de81;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s ease;
    }
    
    .btn-add-new:hover {
        background: #20bf6b;
        transform: translateY(-1px);
    }
    
    .table-filters {
        display: flex;
        gap: 10px;
    }
    
    .btn-icon {
        background: #3498db;
        color: white;
        border: none;
        padding: 6px 10px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
    }
    
    .btn-icon.red {
        background: #ee5a6f;
    }
    
    .blogs-table-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .blogs-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .blogs-table thead th {
        background: #f8f9fa;
        padding: 12px 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: #7f8c8d;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .blogs-table tbody td {
        padding: 14px 16px;
        font-size: 13px;
        color: #2c3e50;
        border-bottom: 1px solid #f1f2f6;
        vertical-align: middle;
    }
    
    .blogs-table tbody tr:hover {
        background: #fafbfc;
    }

    .blog-image {
        width: 100px;
        height: 70px;
        object-fit: cover;
        border-radius: 4px;
        border: 1px solid #ecf0f1;
    }

    .blog-category {
        background: #e7f3ff;
        color: #0066cc;
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 500;
        display: inline-block;
    }

    .featured-badge {
        background: #ffd700;
        color: #000;
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 500;
        display: inline-block;
    }
    
    .status-toggle {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 22px;
    }
    
    .status-toggle input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .toggle-slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .3s;
        border-radius: 24px;
    }
    
    .toggle-slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: .3s;
        border-radius: 50%;
    }
    
    input:checked + .toggle-slider {
        background-color: #26de81;
    }
    
    input:checked + .toggle-slider:before {
        transform: translateX(18px);
    }
    
    .action-buttons {
        display: flex;
        gap: 6px;
    }
    
    .btn-action {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 12px;
    }
    
    .btn-action:hover {
        transform: scale(1.1);
    }
    
    .btn-action.edit {
        background: #ffeaa7;
        color: #fdcb6e;
    }
    
    .btn-action.delete {
        background: #ffcccc;
        color: #ee5a6f;
    }
    
    .pagination-wrapper {
        padding: 15px;
        display: flex;
        justify-content: flex-end;
    }

    .empty-state {
        text-align: center;
        padding: 60px 20px;
    }

    .empty-state i {
        font-size: 64px;
        color: #dcdde1;
        margin-bottom: 20px;
    }

    .empty-state h4 {
        color: #7f8c8d;
        font-size: 18px;
        margin-bottom: 10px;
    }

    .empty-state p {
        color: #95a5a6;
        font-size: 14px;
    }

    /* CKEditor custom styling */
    .ck-editor__editable {
        min-height: 300px;
    }
</style>

<!-- Breadcrumb -->
<div class="page-breadcrumb">
    <h1 class="page-title">📰 Blogs Management</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > <span>Blogs</span>
    </div>
</div>

<!-- Table Controls -->
<div class="table-controls">
    <button onclick="createBlog()" class="btn-add-new">
        <i class="fas fa-plus"></i> Add New Blog
    </button>
    
    <div class="table-filters">
        <div class="search-box">
            <button class="btn-icon"><i class="fas fa-filter"></i></button>
            <button class="btn-icon red"><i class="fas fa-file-pdf"></i></button>
        </div>
    </div>
</div>

<!-- Blogs Table -->
<div class="blogs-table-card">
    <table class="blogs-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Image</th>
                <th>Title</th>
                <th>Category</th>
                <th>Status</th>
                <th>Featured</th>
                <th>Created</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
            @forelse($blogs as $index => $blog)
            <tr>
                <td>{{ $blogs->firstItem() + $index }}</td>
                <td>
                    @if($blog->image)
                        <img src="{{ asset('storage/' . $blog->image) }}" alt="{{ $blog->title }}" class="blog-image">
                    @else
                        <div class="blog-image bg-light d-flex align-items-center justify-content-center">
                            <i class="fas fa-image text-muted"></i>
                        </div>
                    @endif
                </td>
                <td>
                    <strong>{{ Str::limit($blog->title, 40) }}</strong>
                    <br>
                    <span class="blog-category">{{ $blog->category }}</span>
                </td>
                <td>{{ Str::limit($blog->excerpt ?? 'No excerpt', 40) }}</td>
                <td>
                    <label class="status-toggle">
                        <input type="checkbox" {{ $blog->is_active ? 'checked' : '' }} 
                               onchange="confirmStatusToggle(this, {{ $blog->id }}, {{ $blog->is_active ? 'true' : 'false' }})">
                        <span class="toggle-slider"></span>
                    </label>
                </td>
                <td>
                    @if($blog->is_featured)
                        <span class="featured-badge">⭐ Featured</span>
                    @else
                        -
                    @endif
                </td>
                <td style="font-size: 12px; color: #7f8c8d;">{{ $blog->created_at->format('M d, Y') }}</td>
                <td>
                    <div class="action-buttons">
                        <button onclick="editBlog({{ $blog->id }})" class="btn-action edit" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button type="button" class="btn-action delete" title="Delete" onclick="confirmDelete({{ $blog->id }})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="8">
                    <div class="empty-state">
                        <i class="fas fa-blog"></i>
                        <h4>No Blogs Found</h4>
                        <p>Create your first blog post to get started!</p>
                    </div>
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
    
    <!-- Pagination -->
    @if($blogs->hasPages())
    <div class="pagination-wrapper">
        {{ $blogs->links() }}
    </div>
    @endif
</div>

@push('scripts')
<!-- CKEditor 5 -->
<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>

<script>
let editorInstance = null;

// Status Toggle Confirmation
function confirmStatusToggle(checkbox, blogId, currentStatus) {
    const newStatus = !currentStatus;
    const statusText = newStatus ? 'activate' : 'deactivate';
    
    Swal.fire({
        title: 'Change Blog Status?',
        html: `Are you sure you want to <strong>${statusText}</strong> this blog?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: newStatus ? '#26de81' : '#ee5a6f',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: `Yes, ${statusText}!`,
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            showLoading('Updating status...');
            
            fetch(`/admin/blogs/${blogId}/toggle-status`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: data.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        window.location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: data.message
                    });
                    checkbox.checked = currentStatus;
                }
            })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'An error occurred. Please try again.'
                });
                checkbox.checked = currentStatus;
            });
        } else {
            checkbox.checked = currentStatus;
        }
    });
}

// Delete Confirmation
function confirmDelete(blogId) {
    Swal.fire({
        title: 'Delete Blog?',
        text: 'This action cannot be undone!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ee5a6f',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: '<i class="fas fa-trash me-2"></i>Yes, delete it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            showLoading('Deleting blog...');
            
            fetch(`/admin/blogs/${blogId}`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Deleted!',
                        text: data.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        window.location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: data.message
                    });
                }
            })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'An error occurred. Please try again.'
                });
            });
        }
    });
}

function showLoading(message) {
    Swal.fire({
        title: message,
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
}

// Create Blog
function createBlog() {
    Swal.fire({
        title: 'Create New Blog',
        html: `
            <form id="createBlogForm" enctype="multipart/form-data">
                <div class="mb-3 text-start">
                    <label class="form-label">Title *</label>
                    <input type="text" class="form-control" id="createTitle" name="title" required>
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Slug (Optional)</label>
                    <input type="text" class="form-control" id="createSlug" name="slug">
                    <small class="text-muted">Leave empty to auto-generate from title</small>
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Category *</label>
                    <select class="form-control" id="createCategory" name="category" required>
                        <option value="">Select Category</option>
                        <option value="SMS Marketing">SMS Marketing</option>
                        <option value="Business Tips">Business Tips</option>
                        <option value="Industry News">Industry News</option>
                        <option value="Tutorials">Tutorials</option>
                        <option value="Updates">Updates</option>
                    </select>
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Excerpt</label>
                    <textarea class="form-control" id="createExcerpt" name="excerpt" rows="2" placeholder="Short description..."></textarea>
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Content *</label>
                    <textarea class="form-control" id="createContent" name="content" rows="6"></textarea>
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Image</label>
                    <input type="file" class="form-control" id="createImage" name="image" accept="image/*">
                </div>
                <div class="mb-3 text-start">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="createFeatured" name="is_featured" value="1">
                        <label class="form-check-label" for="createFeatured">
                            Featured Post
                        </label>
                    </div>
                </div>
                <div class="mb-3 text-start">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="createActive" name="is_active" value="1" checked>
                        <label class="form-check-label" for="createActive">
                            Active
                        </label>
                    </div>
                </div>
            </form>
        `,
        width: '800px',
        showCancelButton: true,
        confirmButtonText: 'Create Blog',
        cancelButtonText: 'Cancel',
        didOpen: () => {
            // Initialize CKEditor
            ClassicEditor
                .create(document.querySelector('#createContent'))
                .then(editor => {
                    editorInstance = editor;
                })
                .catch(error => {
                    console.error(error);
                });
        },
        preConfirm: () => {
            const form = document.getElementById('createBlogForm');
            const formData = new FormData(form);

            // Get CKEditor content
            if (editorInstance) {
                formData.set('content', editorInstance.getData());
            }

            // Handle checkboxes
            const isFeatured = document.getElementById('createFeatured').checked;
            const isActive = document.getElementById('createActive').checked;
            formData.set('is_featured', isFeatured ? '1' : '0');
            formData.set('is_active', isActive ? '1' : '0');

            if (!formData.get('title')) {
                Swal.showValidationMessage('Title is required');
                return false;
            }

            if (!formData.get('category')) {
                Swal.showValidationMessage('Category is required');
                return false;
            }

            if (!editorInstance || !editorInstance.getData()) {
                Swal.showValidationMessage('Content is required');
                return false;
            }

            return formData;
        },
        willClose: () => {
            // Destroy CKEditor instance
            if (editorInstance) {
                editorInstance.destroy();
                editorInstance = null;
            }
        }
    }).then((result) => {
        if (result.isConfirmed) {
            const formData = result.value;

            Swal.fire({
                title: 'Creating...',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            fetch('{{ route('admin.blogs.store') }}', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: data.message,
                        timer: 1500
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: data.message
                    });
                }
            })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'An error occurred. Please try again.'
                });
            });
        }
    });
}

// Edit Blog
function editBlog(id) {
    Swal.fire({
        title: 'Loading...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    fetch(`/admin/blogs/${id}/edit`)
        .then(response => response.json())
        .then(blog => {
            Swal.fire({
                title: 'Edit Blog',
                html: `
                    <form id="editBlogForm" enctype="multipart/form-data">
                        <div class="mb-3 text-start">
                            <label class="form-label">Title *</label>
                            <input type="text" class="form-control" id="editTitle" name="title" value="${blog.title}" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Slug</label>
                            <input type="text" class="form-control" id="editSlug" name="slug" value="${blog.slug || ''}">
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Category *</label>
                            <select class="form-control" id="editCategory" name="category" required>
                                <option value="">Select Category</option>
                                <option value="SMS Marketing" ${blog.category === 'SMS Marketing' ? 'selected' : ''}>SMS Marketing</option>
                                <option value="Business Tips" ${blog.category === 'Business Tips' ? 'selected' : ''}>Business Tips</option>
                                <option value="Industry News" ${blog.category === 'Industry News' ? 'selected' : ''}>Industry News</option>
                                <option value="Tutorials" ${blog.category === 'Tutorials' ? 'selected' : ''}>Tutorials</option>
                                <option value="Updates" ${blog.category === 'Updates' ? 'selected' : ''}>Updates</option>
                            </select>
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Excerpt</label>
                            <textarea class="form-control" id="editExcerpt" name="excerpt" rows="2">${blog.excerpt || ''}</textarea>
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Content *</label>
                            <textarea class="form-control" id="editContent" name="content" rows="6">${blog.content}</textarea>
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Image</label>
                            <input type="file" class="form-control" id="editImage" name="image" accept="image/*">
                            ${blog.image ? `<small class="text-muted">Current: ${blog.image.split('/').pop()}</small>` : ''}
                        </div>
                        <div class="mb-3 text-start">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="editFeatured" name="is_featured" value="1" ${blog.is_featured ? 'checked' : ''}>
                                <label class="form-check-label" for="editFeatured">
                                    Featured Post
                                </label>
                            </div>
                        </div>
                        <div class="mb-3 text-start">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="editActive" name="is_active" value="1" ${blog.is_active ? 'checked' : ''}>
                                <label class="form-check-label" for="editActive">
                                    Active
                                </label>
                            </div>
                        </div>
                    </form>
                `,
                width: '800px',
                showCancelButton: true,
                confirmButtonText: 'Update Blog',
                cancelButtonText: 'Cancel',
                didOpen: () => {
                    // Initialize CKEditor
                    ClassicEditor
                        .create(document.querySelector('#editContent'))
                        .then(editor => {
                            editorInstance = editor;
                        })
                        .catch(error => {
                            console.error(error);
                        });
                },
                preConfirm: () => {
                    const form = document.getElementById('editBlogForm');
                    const formData = new FormData(form);
                    formData.append('_method', 'PUT');

                    // Get CKEditor content
                    if (editorInstance) {
                        formData.set('content', editorInstance.getData());
                    }

                    // Handle checkboxes
                    const isFeatured = document.getElementById('editFeatured').checked;
                    const isActive = document.getElementById('editActive').checked;
                    formData.set('is_featured', isFeatured ? '1' : '0');
                    formData.set('is_active', isActive ? '1' : '0');

                    if (!formData.get('title')) {
                        Swal.showValidationMessage('Title is required');
                        return false;
                    }

                    if (!formData.get('category')) {
                        Swal.showValidationMessage('Category is required');
                        return false;
                    }

                    if (!editorInstance || !editorInstance.getData()) {
                        Swal.showValidationMessage('Content is required');
                        return false;
                    }

                    return formData;
                },
                willClose: () => {
                    // Destroy CKEditor instance
                    if (editorInstance) {
                        editorInstance.destroy();
                        editorInstance = null;
                    }
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    const formData = result.value;

                    Swal.fire({
                        title: 'Updating...',
                        allowOutsideClick: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });

                    fetch(`/admin/blogs/${id}`, {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success!',
                                text: data.message,
                                timer: 1500
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error!',
                                text: data.message
                            });
                        }
                    })
                    .catch(error => {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error!',
                            text: 'An error occurred. Please try again.'
                        });
                    });
                }
            });
        })
        .catch(error => {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Failed to load blog data'
            });
        });
}

</script>
@endpush

@endsection

