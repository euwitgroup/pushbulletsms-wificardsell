@extends('admin.layouts.app')

@section('title', 'Transactions')

@section('content')

<!-- Page Header -->
<div class="mb-4">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h2><i class="fas fa-exchange-alt me-2"></i>Financial Transactions</h2>
            <p class="text-muted">View and export all payment transactions</p>
        </div>
        <div class="d-flex gap-2">
            <a href="{{ route('admin.transactions.export', ['format' => 'excel']) }}" class="btn btn-success">
                <i class="fas fa-file-excel me-1"></i>Export Excel
            </a>
            <a href="{{ route('admin.transactions.export', ['format' => 'pdf']) }}" class="btn btn-danger">
                <i class="fas fa-file-pdf me-1"></i>Export PDF
            </a>
        </div>
    </div>
</div>

<!-- Filters -->
<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="{{ route('admin.transactions') }}">
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label" style="font-size: 12px; font-weight: 600; color: #6c757d;">Type</label>
                    <select name="type" class="form-control" style="border-radius: 8px;" onchange="this.form.submit()">
                        <option value="">All Types</option>
                        <option value="credit" {{ request('type') == 'credit' ? 'selected' : '' }}>Credit</option>
                        <option value="debit" {{ request('type') == 'debit' ? 'selected' : '' }}>Debit</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label" style="font-size: 12px; font-weight: 600; color: #6c757d;">Status</label>
                    <select name="status" class="form-control" style="border-radius: 8px;" onchange="this.form.submit()">
                        <option value="">All Status</option>
                        <option value="completed" {{ request('status') == 'completed' ? 'selected' : '' }}>Completed</option>
                        <option value="pending" {{ request('status') == 'pending' ? 'selected' : '' }}>Pending</option>
                        <option value="failed" {{ request('status') == 'failed' ? 'selected' : '' }}>Failed</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label" style="font-size: 12px; font-weight: 600; color: #6c757d;">Date From</label>
                    <input type="date" name="date_from" class="form-control" style="border-radius: 8px;" value="{{ request('date_from') }}" onchange="this.form.submit()">
                </div>
                <div class="col-md-3">
                    <label class="form-label" style="font-size: 12px; font-weight: 600; color: #6c757d;">Date To</label>
                    <input type="date" name="date_to" class="form-control" style="border-radius: 8px;" value="{{ request('date_to') }}" onchange="this.form.submit()">
                </div>
            </div>
            @if(request()->hasAny(['type', 'status', 'date_from', 'date_to']))
            <div class="mt-3">
                <a href="{{ route('admin.transactions') }}" class="btn btn-sm btn-outline-secondary" style="border-radius: 6px;">
                    <i class="fas fa-times me-1"></i>Clear Filters
                </a>
            </div>
            @endif
        </form>
    </div>
</div>

<!-- Transactions Table -->
<div class="card">
    <div class="card-header bg-white">
        <h5 class="mb-0"><i class="fas fa-list me-2"></i>All Transactions</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User</th>
                    <th>Transaction ID</th>
                    <th>Type</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Details</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                    @forelse($transactions as $transaction)
                    <tr>
                        <td>#{{ $transaction->id }}</td>
                        <td>
                            <strong>{{ $transaction->user->name ?? 'N/A' }}</strong><br>
                            <small class="text-muted">{{ $transaction->user->email ?? '' }}</small>
                        </td>
                        <td><code>{{ $transaction->transaction_id }}</code></td>
                        <td>
                            <span class="badge bg-{{ $transaction->type == 'credit' ? 'success' : 'danger' }}">
                                {{ ucfirst($transaction->type) }}
                            </span>
                        </td>
                        <td class="fw-bold {{ $transaction->type == 'credit' ? 'text-success' : 'text-danger' }}">
                            {{ $transaction->type == 'credit' ? '+' : '-' }}৳{{ number_format($transaction->amount, 2) }}
                        </td>
                        <td>
                            <span class="badge bg-{{ $transaction->status == 'completed' ? 'success' : ($transaction->status == 'failed' ? 'danger' : 'warning') }}">
                                {{ ucfirst($transaction->status) }}
                            </span>
                        </td>
                        <td>
                            {{ $transaction->created_at->format('M d, Y h:i A') }}
                        </td>
                        <td>
                            @if($transaction->description)
                                <small class="text-muted">{{ Str::limit($transaction->description, 30) }}</small>
                            @else
                                <small class="text-muted">-</small>
                            @endif
                        </td>
                        <td>
                            <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#transactionModal{{ $transaction->id }}" title="View Details">
                                <i class="fas fa-eye"></i>
                            </button>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="9" class="text-center py-5">
                            <i class="fas fa-inbox fa-3x text-muted mb-3 d-block"></i>
                            <p class="text-muted">No transactions found</p>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if($transactions->hasPages())
        <div class="mt-3">
            {{ $transactions->links() }}
        </div>
        @endif
    </div>
</div>

<!-- Transaction Detail Modals -->
@foreach($transactions as $transaction)
<div class="modal fade" id="transactionModal{{ $transaction->id }}" tabindex="-1" aria-labelledby="transactionModalLabel{{ $transaction->id }}" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="transactionModalLabel{{ $transaction->id }}">
                    <i class="fas fa-receipt me-2"></i>Transaction Details
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small">Transaction ID</label>
                        <div class="fw-bold"><code>{{ $transaction->transaction_id }}</code></div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small">Internal ID</label>
                        <div class="fw-bold">#{{ $transaction->id }}</div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small">User Name</label>
                        <div class="fw-bold">{{ $transaction->user->name ?? 'N/A' }}</div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small">User Email</label>
                        <div class="fw-bold">{{ $transaction->user->email ?? 'N/A' }}</div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small">Type</label>
                        <div>
                            <span class="badge bg-{{ $transaction->type == 'credit' ? 'success' : 'danger' }} fs-6">
                                <i class="fas fa-{{ $transaction->type == 'credit' ? 'plus' : 'minus' }} me-1"></i>
                                {{ ucfirst($transaction->type) }}
                            </span>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small">Amount</label>
                        <div class="fs-4 fw-bold {{ $transaction->type == 'credit' ? 'text-success' : 'text-danger' }}">
                            {{ $transaction->type == 'credit' ? '+' : '-' }}৳{{ number_format($transaction->amount, 2) }}
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small">Status</label>
                        <div>
                            <span class="badge bg-{{ $transaction->status == 'completed' ? 'success' : ($transaction->status == 'failed' ? 'danger' : 'warning') }} fs-6">
                                {{ ucfirst($transaction->status) }}
                            </span>
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small">Date & Time</label>
                        <div class="fw-bold">
                            {{ $transaction->created_at->format('F d, Y') }}<br>
                            <small class="text-muted">{{ $transaction->created_at->format('h:i:s A') }}</small>
                        </div>
                    </div>
                </div>

                @if($transaction->description)
                <div class="row">
                    <div class="col-12 mb-3">
                        <label class="text-muted small">Description</label>
                        <div class="p-3 bg-light rounded">{{ $transaction->description }}</div>
                    </div>
                </div>
                @endif

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small">Created At</label>
                        <div class="small">{{ $transaction->created_at->diffForHumans() }}</div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="text-muted small">Updated At</label>
                        <div class="small">{{ $transaction->updated_at->diffForHumans() }}</div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    <i class="fas fa-times me-1"></i>Close
                </button>
            </div>
        </div>
    </div>
</div>
@endforeach

@endsection
