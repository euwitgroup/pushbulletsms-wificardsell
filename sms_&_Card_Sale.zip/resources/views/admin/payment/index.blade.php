@extends('admin.layouts.app')

@section('title', 'Manage Payment Methods')

@section('content')
<style>
    .payment-table-container {
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        padding: 24px;
    }
    
    .search-bar {
        display: flex;
        gap: 12px;
        align-items: center;
    }
    
    .search-input {
        flex: 1;
        border: 1px solid #e5e7eb;
        border-radius: 8px;
        padding: 10px 16px;
        font-size: 14px;
    }
    
    .btn-icon {
        width: 40px;
        height: 40px;
        border-radius: 8px;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s;
    }
    
    .btn-primary-icon {
        background: #3b82f6;
        color: white;
    }
    
    .btn-danger-icon {
        background: #ef4444;
        color: white;
    }
    
    .payment-table {
        width: 100%;
        margin-top: 20px;
    }
    
    .payment-table thead {
        background: #f9fafb;
    }
    
    .payment-table th {
        padding: 12px 16px;
        text-align: left;
        font-size: 13px;
        font-weight: 600;
        color: #6b7280;
        border-bottom: 1px solid #e5e7eb;
    }
    
    .payment-table td {
        padding: 16px;
        border-bottom: 1px solid #f3f4f6;
        font-size: 14px;
        color: #374151;
    }
    
    .payment-table tbody tr {
        transition: background 0.2s;
    }
    
    .payment-table tbody tr:hover {
        background: #f9fafb;
    }
    
    .gateway-name {
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .gateway-icon {
        width: 32px;
        height: 32px;
        border-radius: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
    }
    
    .badge-admin {
        background: #dbeafe;
        color: #1e40af;
        padding: 4px 12px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 500;
    }
    
    .toggle-switch {
        position: relative;
        display: inline-block;
        width: 48px;
        height: 24px;
    }
    
    .toggle-switch input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .toggle-slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #e5e7eb;
        transition: .3s;
        border-radius: 24px;
    }
    
    .toggle-slider:before {
        position: absolute;
        content: "";
        height: 18px;
        width: 18px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: .3s;
        border-radius: 50%;
    }
    
    input:checked + .toggle-slider {
        background-color: #8b5cf6;
    }
    
    input:checked + .toggle-slider:before {
        transform: translateX(24px);
    }
    
    .btn-edit {
        background: #fef3c7;
        color: #92400e;
        border: none;
        width: 36px;
        height: 36px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s;
    }
    
    .btn-edit:hover {
        background: #fde68a;
    }
    
    .pagination-custom {
        display: flex;
        gap: 8px;
        justify-content: center;
        margin-top: 20px;
    }
    
    .page-btn {
        width: 36px;
        height: 36px;
        border-radius: 8px;
        border: 1px solid #e5e7eb;
        background: white;
        color: #6b7280;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s;
        font-size: 14px;
    }
    
    .page-btn:hover {
        border-color: #8b5cf6;
        color: #8b5cf6;
    }
    
    .page-btn.active {
        background: #8b5cf6;
        color: white;
        border-color: #8b5cf6;
    }
    
    .pagination-custom a.page-btn {
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }
    
    .pagination-custom a.page-btn:hover:not(.active) {
        border-color: #8b5cf6;
        color: #8b5cf6;
    }
    
    /* Modal Styling */
    .modal-content {
        border: none;
        box-shadow: 0 10px 40px rgba(0,0,0,0.15);
    }
    
    .form-control-custom {
        width: 100%;
    }
    
    .gateway-fields {
        animation: fadeIn 0.3s ease-in;
    }
    
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .form-group-custom {
        margin-bottom: 20px;
    }
    
    .form-label-custom {
        font-size: 13px;
        font-weight: 500;
        color: #374151;
        margin-bottom: 8px;
        display: block;
    }
    
    .required-star {
        color: #ef4444;
        margin-left: 2px;
    }
    
    .checkbox-label {
        font-size: 14px;
        font-weight: 500;
        color: #374151;
        display: flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
        margin: 0;
    }
    
    .checkbox-custom {
        width: 18px;
        height: 18px;
        cursor: pointer;
        border-radius: 4px;
    }
    
    .info-text {
        color: #6b7280;
        font-size: 12px;
        margin-top: 4px;
    }
    
    .modal-backdrop.show {
        opacity: 0.5;
    }
</style>

<!-- Page Header -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 style="font-weight: 600; color: #1f2937; margin: 0;">Manage Payment Methods</h4>
    </div>
    <nav style="font-size: 14px; color: #6b7280;">
        <a href="{{ route('admin.dashboard') }}" style="color: #6b7280; text-decoration: none;">Home</a>
        <span class="mx-2">›</span>
        <span style="color: #1f2937;">Payment Method</span>
    </nav>
</div>

<!-- Payment Table Container -->
<div class="payment-table-container">
    <!-- Search Bar -->
    <div class="search-bar">
        <input type="text" class="search-input" placeholder="Search By Name" id="searchInput">
        <button class="btn-icon btn-primary-icon">
            <i class="fas fa-search"></i>
        </button>
        <button class="btn-icon btn-danger-icon">
            <i class="fas fa-redo"></i>
        </button>
    </div>
    
    <!-- Table -->
    <table class="payment-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Charge</th>
                <th>Limit</th>
                <th>Updated By</th>
                <th>Status</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
            @foreach($gateways as $index => $gateway)
            <tr>
                <td>{{ ($gateways->currentPage() - 1) * $gateways->perPage() + $index + 1 }}</td>
                <td>
                    <div class="gateway-name">
                        <div class="gateway-icon" style="background: {{ $gateway['color'] }}20; color: {{ $gateway['color'] }};">
                            {{ $gateway['icon'] }}
                        </div>
                        <span style="font-weight: 500;">{{ $gateway['name'] }}</span>
                    </div>
                </td>
                <td>{{ $gateway['charge'] }}</td>
                <td>{{ $gateway['limit'] }}</td>
                <td>
                    <span class="badge-admin">Super Admin</span>
                </td>
                <td>
                    <label class="toggle-switch">
                        <input type="checkbox" {{ $gateway['is_active'] ? 'checked' : '' }} onchange="toggleGateway('{{ $gateway['id'] }}', this.checked)">
                        <span class="toggle-slider"></span>
                    </label>
                </td>
                <td>
                    <button class="btn-edit" onclick="openGatewayModal('{{ $gateway['id'] }}')">
                        <i class="fas fa-edit"></i>
                    </button>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    
    <!-- Pagination -->
    @if($gateways->hasPages())
    <div class="pagination-custom">
        {{-- Previous Page Link --}}
        @if ($gateways->onFirstPage())
            <button class="page-btn" disabled style="opacity: 0.5; cursor: not-allowed;">‹</button>
        @else
            <a href="{{ $gateways->previousPageUrl() }}" class="page-btn">‹</a>
        @endif

        {{-- Pagination Elements --}}
        @foreach ($gateways->getUrlRange(1, $gateways->lastPage()) as $page => $url)
            @if ($page == $gateways->currentPage())
                <button class="page-btn active">{{ $page }}</button>
            @else
                <a href="{{ $url }}" class="page-btn">{{ $page }}</a>
            @endif
        @endforeach

        {{-- Next Page Link --}}
        @if ($gateways->hasMorePages())
            <a href="{{ $gateways->nextPageUrl() }}" class="page-btn">›</a>
        @else
            <button class="page-btn" disabled style="opacity: 0.5; cursor: not-allowed;">›</button>
        @endif
    </div>
    @endif
</div>


@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
const gatewayData = @json($allGateways->toArray());

// Custom SweetAlert2 styles
const swalStyles = `
    .swal2-popup {
        border-radius: 12px;
        padding: 0;
    }
    .swal2-title {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 24px;
        margin: 0;
        border-radius: 12px 12px 0 0;
        font-size: 18px;
    }
    .swal2-html-container {
        padding: 24px;
        margin: 0;
    }
    .swal2-actions {
        background: #f9fafb;
        padding: 16px 24px;
        margin: 0;
        border-radius: 0 0 12px 12px;
    }
    .swal2-confirm {
        background: #6366f1 !important;
        border-radius: 8px;
        padding: 10px 24px;
        font-weight: 500;
    }
    .swal2-cancel {
        border-radius: 8px;
        padding: 10px 20px;
        font-weight: 500;
    }
    .form-control-swal {
        border-radius: 8px;
        border: 1px solid #e5e7eb;
        padding: 10px 14px;
        font-size: 14px;
        width: 100%;
        margin-bottom: 8px;
    }
    .form-control-swal:focus {
        border-color: #6366f1;
        outline: none;
        box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
    }
    .form-label-swal {
        font-size: 13px;
        font-weight: 500;
        color: #374151;
        display: block;
        margin-bottom: 6px;
        text-align: left;
    }
    .info-text-swal {
        color: #6b7280;
        font-size: 12px;
        display: block;
        margin-bottom: 16px;
        text-align: left;
    }
`;

// Inject styles
const styleSheet = document.createElement("style");
styleSheet.textContent = swalStyles;
document.head.appendChild(styleSheet);

// Search functionality
document.getElementById('searchInput').addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    const rows = document.querySelectorAll('.payment-table tbody tr');
    
    rows.forEach(row => {
        const name = row.querySelector('.gateway-name span').textContent.toLowerCase();
        if (name.includes(searchTerm)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
});

// Open gateway modal with SweetAlert2
function openGatewayModal(gatewayId) {
    const gateway = gatewayData.find(g => g.id === gatewayId);
    if (!gateway) return;
    
    let htmlContent = '';
    
    // Build HTML based on gateway type
    if (gatewayId === 'rupantorpay') {
        htmlContent = `
            <div style="text-align: left;">
                <label class="form-label-swal">API Key <span style="color: #ef4444;">*</span></label>
                <input type="text" id="api_key" class="form-control-swal" placeholder="Enter RupantorPay API Key" value="${gateway.api_key || ''}">
                <small class="info-text-swal">Get your API Key from RupantorPay Dashboard</small>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div>
                        <label class="form-label-swal">Success URL</label>
                        <input type="text" id="success_url" class="form-control-swal" placeholder="https://yourdomain.com/success" value="${gateway.success_url || ''}">
                    </div>
                    <div>
                        <label class="form-label-swal">Cancel URL</label>
                        <input type="text" id="cancel_url" class="form-control-swal" placeholder="https://yourdomain.com/cancel" value="${gateway.cancel_url || ''}">
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 12px;">
                    <div>
                        <label class="form-label-swal">Minimum Payment (৳)</label>
                        <input type="number" id="minimum_payment" class="form-control-swal" placeholder="10" value="${gateway.minimum_payment || '10'}">
                        <small class="info-text-swal">Minimum amount for payment</small>
                    </div>
                    <div>
                        <label class="form-label-swal">Payment Charge (%)</label>
                        <input type="number" id="payment_charge" class="form-control-swal" placeholder="0" step="0.01" value="${gateway.payment_charge || '0'}">
                        <small class="info-text-swal">Gateway charge percentage</small>
                    </div>
                </div>
                
                <label style="display: flex; align-items: center; gap: 8px; margin-top: 12px; cursor: pointer;">
                    <input type="checkbox" id="is_sandbox" value="1" ${gateway.is_sandbox ? 'checked' : ''} style="width: 18px; height: 18px;">
                    <span style="font-size: 14px; font-weight: 500;">Enable Sandbox Mode</span>
                </label>
            </div>
        `;
    } else if (gatewayId === 'sslcommerz') {
        htmlContent = `
            <div style="text-align: left;">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div>
                        <label class="form-label-swal">Store ID <span style="color: #ef4444;">*</span></label>
                        <input type="text" id="store_id" class="form-control-swal" placeholder="Enter Store ID" value="${gateway.store_id || ''}">
                    </div>
                    <div>
                        <label class="form-label-swal">Store Password <span style="color: #ef4444;">*</span></label>
                        <input type="password" id="store_password" class="form-control-swal" placeholder="Enter Password" value="${gateway.store_password || ''}">
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 12px;">
                    <div>
                        <label class="form-label-swal">Minimum Payment (৳)</label>
                        <input type="number" id="minimum_payment" class="form-control-swal" placeholder="10" value="${gateway.minimum_payment || '10'}">
                        <small class="info-text-swal">Minimum amount for payment</small>
                    </div>
                    <div>
                        <label class="form-label-swal">Payment Charge (%)</label>
                        <input type="number" id="payment_charge" class="form-control-swal" placeholder="0" step="0.01" value="${gateway.payment_charge || '0'}">
                        <small class="info-text-swal">Gateway charge percentage</small>
                    </div>
                </div>
                
                <label style="display: flex; align-items: center; gap: 8px; margin-top: 12px; cursor: pointer;">
                    <input type="checkbox" id="is_sandbox" value="1" ${gateway.is_sandbox ? 'checked' : ''} style="width: 18px; height: 18px;">
                    <span style="font-size: 14px; font-weight: 500;">Enable Sandbox Mode</span>
                </label>
            </div>
        `;
    } else if (gatewayId === 'stripe') {
        htmlContent = `
            <div style="text-align: left;">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div>
                        <label class="form-label-swal">Publishable Key <span style="color: #ef4444;">*</span></label>
                        <input type="text" id="publishable_key" class="form-control-swal" placeholder="pk_test_..." value="${gateway.publishable_key || ''}">
                    </div>
                    <div>
                        <label class="form-label-swal">Secret Key <span style="color: #ef4444;">*</span></label>
                        <input type="password" id="secret_key" class="form-control-swal" placeholder="sk_test_..." value="${gateway.secret_key || ''}">
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 12px;">
                    <div>
                        <label class="form-label-swal">Minimum Payment (৳)</label>
                        <input type="number" id="minimum_payment" class="form-control-swal" placeholder="10" value="${gateway.minimum_payment || '10'}">
                        <small class="info-text-swal">Minimum amount for payment</small>
                    </div>
                    <div>
                        <label class="form-label-swal">Payment Charge (%)</label>
                        <input type="number" id="payment_charge" class="form-control-swal" placeholder="0" step="0.01" value="${gateway.payment_charge || '0'}">
                        <small class="info-text-swal">Gateway charge percentage</small>
                    </div>
                </div>
            </div>
        `;
    }
    
    Swal.fire({
        title: `${gateway.icon} Configure ${gateway.name}`,
        html: htmlContent,
        width: '600px',
        showCancelButton: true,
        confirmButtonText: '<i class="fas fa-save"></i> Save Settings',
        cancelButtonText: '<i class="fas fa-times"></i> Cancel',
        customClass: {
            confirmButton: 'swal2-confirm',
            cancelButton: 'swal2-cancel'
        },
        preConfirm: () => {
            const formData = {};
            
            // Get common fields
            formData.minimum_payment = document.getElementById('minimum_payment').value;
            formData.payment_charge = document.getElementById('payment_charge').value;
            
            // Get gateway-specific fields
            if (gatewayId === 'rupantorpay') {
                formData.api_key = document.getElementById('api_key').value;
                formData.success_url = document.getElementById('success_url').value;
                formData.cancel_url = document.getElementById('cancel_url').value;
                const sandboxCheckbox = document.getElementById('is_sandbox');
                formData.is_sandbox = sandboxCheckbox && sandboxCheckbox.checked ? '1' : '0';
                
                if (!formData.api_key) {
                    Swal.showValidationMessage('API Key is required');
                    return false;
                }
            } else if (gatewayId === 'sslcommerz') {
                formData.store_id = document.getElementById('store_id').value;
                formData.store_password = document.getElementById('store_password').value;
                const sandboxCheckbox = document.getElementById('is_sandbox');
                formData.is_sandbox = sandboxCheckbox && sandboxCheckbox.checked ? '1' : '0';
                
                if (!formData.store_id || !formData.store_password) {
                    Swal.showValidationMessage('Store ID and Password are required');
                    return false;
                }
            } else if (gatewayId === 'stripe') {
                formData.publishable_key = document.getElementById('publishable_key').value;
                formData.secret_key = document.getElementById('secret_key').value;
                
                if (!formData.publishable_key || !formData.secret_key) {
                    Swal.showValidationMessage('Both keys are required');
                    return false;
                }
            }
            
            return { gatewayId, formData };
        }
    }).then((result) => {
        if (result.isConfirmed) {
            saveGateway(result.value.gatewayId, result.value.formData);
        }
    });
}

// Save gateway settings
function saveGateway(gatewayId, formData) {
    Swal.fire({
        title: 'Saving...',
        text: 'Please wait',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    const form = new FormData();
    for (const [key, value] of Object.entries(formData)) {
        form.append(key, value);
    }
    
    fetch(`/admin/payment-gateway/${gatewayId}/update`, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Accept': 'application/json'
        },
        body: form
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Saved!',
                text: data.message || 'Gateway settings updated successfully',
                showConfirmButton: false,
                timer: 1500
            });
            
            // Reload page after 1.5 seconds
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: data.message || 'Failed to save settings'
            });
        }
    })
    .catch(error => {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'An error occurred while saving'
        });
    });
}

// Toggle gateway status
function toggleGateway(gatewayId, isActive) {
    const formData = new FormData();
    formData.append('active', isActive ? '1' : '0');
    
    fetch(`/admin/payment-gateway/${gatewayId}/update`, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Accept': 'application/json'
        },
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Status Updated!',
                text: `Gateway ${isActive ? 'enabled' : 'disabled'} successfully`,
                showConfirmButton: false,
                timer: 1500
            });
        } else {
            // Revert checkbox on error
            const checkbox = document.querySelector(`input[onchange*="${gatewayId}"]`);
            if (checkbox) checkbox.checked = !isActive;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        // Revert checkbox on error
        const checkbox = document.querySelector(`input[onchange*="${gatewayId}"]`);
        if (checkbox) checkbox.checked = !isActive;
    });
}
</script>
@endpush
@endsection
