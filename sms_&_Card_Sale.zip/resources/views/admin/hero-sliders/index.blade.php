@extends('admin.layouts.app')

@section('title', 'Hero Sliders')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .breadcrumb-nav a:hover {
        color: #3498db;
    }
    
    .table-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .btn-add-new {
        background: #26de81;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s ease;
    }
    
    .btn-add-new:hover {
        background: #20bf6b;
        transform: translateY(-1px);
    }
    
    .table-filters {
        display: flex;
        gap: 10px;
    }
    
    .search-box {
        position: relative;
        display: flex;
        gap: 6px;
    }
    
    .search-input {
        padding: 6px 35px 6px 12px;
        border: 1px solid #dcdde1;
        border-radius: 4px;
        font-size: 12px;
        width: 220px;
    }
    
    .btn-icon {
        background: #3498db;
        color: white;
        border: none;
        padding: 6px 10px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
    }
    
    .btn-icon.red {
        background: #ee5a6f;
    }
    
    .sliders-table-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .sliders-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .sliders-table thead th {
        background: #f8f9fa;
        padding: 12px 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: #7f8c8d;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .sliders-table tbody td {
        padding: 14px 16px;
        font-size: 13px;
        color: #2c3e50;
        border-bottom: 1px solid #f1f2f6;
        vertical-align: middle;
    }
    
    .sliders-table tbody tr:hover {
        background: #fafbfc;
    }
    
    .slider-image {
        width: 120px;
        height: 60px;
        object-fit: cover;
        border-radius: 4px;
        border: 1px solid #ecf0f1;
    }
    
    .badge-order {
        background: #8854d0;
        color: white;
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 500;
        display: inline-block;
    }
    
    .status-toggle {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 22px;
    }
    
    .status-toggle input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .toggle-slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .3s;
        border-radius: 24px;
    }
    
    .toggle-slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: .3s;
        border-radius: 50%;
    }
    
    input:checked + .toggle-slider {
        background-color: #26de81;
    }
    
    input:checked + .toggle-slider:before {
        transform: translateX(18px);
    }
    
    .action-buttons {
        display: flex;
        gap: 6px;
    }
    
    .btn-action {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 12px;
    }
    
    .btn-action:hover {
        transform: scale(1.1);
    }
    
    .btn-action.edit {
        background: #ffeaa7;
        color: #fdcb6e;
    }
    
    .btn-action.delete {
        background: #ffcccc;
        color: #ee5a6f;
    }
    
    .pagination-wrapper {
        padding: 15px;
        display: flex;
        justify-content: flex-end;
    }

    .empty-state {
        text-align: center;
        padding: 60px 20px;
    }

    .empty-state i {
        font-size: 64px;
        color: #dcdde1;
        margin-bottom: 20px;
    }

    .empty-state h4 {
        color: #7f8c8d;
        font-size: 18px;
        margin-bottom: 10px;
    }

    .empty-state p {
        color: #95a5a6;
        font-size: 14px;
    }
</style>

<!-- Breadcrumb -->
<div class="page-breadcrumb">
    <h1 class="page-title">Hero Sliders</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > <span>Hero Sliders</span>
    </div>
</div>

<!-- Table Controls -->
<div class="table-controls">
    <button onclick="openCreateModal()" class="btn-add-new">
        <i class="fas fa-plus"></i> Add New Slider
    </button>
    
    <div class="table-filters">
        <div class="search-box">
            <button class="btn-icon"><i class="fas fa-filter"></i></button>
            <button class="btn-icon red"><i class="fas fa-file-pdf"></i></button>
        </div>
    </div>
</div>

<!-- Sliders Table -->
<div class="sliders-table-card">
    <table class="sliders-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Image</th>
                <th>Title</th>
                <th>Link</th>
                <th>Order</th>
                <th>Status</th>
                <th>Created</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
            @forelse($sliders as $index => $slider)
            <tr>
                <td>{{ $sliders->firstItem() + $index }}</td>
                <td>
                    <img src="{{ asset('storage/' . $slider->image) }}" alt="Slider" class="slider-image">
                </td>
                <td>{{ $slider->title ?: '-' }}</td>
                <td>
                    @if($slider->link)
                        <a href="{{ $slider->link }}" target="_blank" class="text-primary" style="font-size: 12px;">
                            <i class="fas fa-external-link-alt"></i> View
                        </a>
                    @else
                        -
                    @endif
                </td>
                <td>
                    <span class="badge-order">#{{ $slider->order }}</span>
                </td>
                <td>
                    <label class="status-toggle">
                        <input type="checkbox" {{ $slider->is_active ? 'checked' : '' }} 
                               onchange="confirmStatusToggle(this, '{{ route('admin.hero-sliders.toggle-status', $slider->id) }}', {{ $slider->is_active ? 'true' : 'false' }})">
                        <span class="toggle-slider"></span>
                    </label>
                </td>
                <td style="font-size: 12px; color: #7f8c8d;">{{ $slider->created_at->format('M d, Y') }}</td>
                <td>
                    <div class="action-buttons">
                        <button onclick="openEditModal({{ $slider->id }})" class="btn-action edit" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        <form action="{{ route('admin.hero-sliders.destroy', $slider->id) }}" 
                              method="POST" 
                              class="d-inline delete-form"
                              id="delete-form-{{ $slider->id }}">
                            @csrf
                            @method('DELETE')
                            <button type="button" 
                                    class="btn-action delete" 
                                    title="Delete"
                                    onclick="confirmDelete('{{ $slider->id }}')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="8">
                    <div class="empty-state">
                        <i class="fas fa-images"></i>
                        <h4>No Sliders Found</h4>
                        <p>Create your first hero slider to get started!</p>
                    </div>
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
    
    <!-- Pagination -->
    @if($sliders->hasPages())
    <div class="pagination-wrapper">
        {{ $sliders->links() }}
    </div>
    @endif
</div>

@push('scripts')
<script>
// Create Modal
function openCreateModal() {
    Swal.fire({
        title: '<i class="fas fa-images text-primary me-2"></i>Add New Slider',
        html: `
            <form id="createSliderForm" enctype="multipart/form-data">
                <div class="mb-3 text-start">
                    <label class="form-label">Slider Image *</label>
                    <input type="file" class="form-control" name="image" accept="image/*" required id="createImage">
                    <small class="text-muted">Recommended: 1920x600px (Max 5MB)</small>
                    <div id="createImagePreview" class="mt-2"></div>
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Title (Optional)</label>
                    <input type="text" class="form-control" name="title" placeholder="Enter slider title">
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Link URL (Optional)</label>
                    <input type="url" class="form-control" name="link" placeholder="https://example.com">
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Display Order</label>
                    <input type="number" class="form-control" name="order" value="0" min="0">
                    <small class="text-muted">Lower numbers appear first</small>
                </div>
                <div class="mb-3 text-start">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="is_active" checked id="createActive">
                        <label class="form-check-label" for="createActive">Active</label>
                    </div>
                </div>
            </form>
        `,
        width: '600px',
        showCancelButton: true,
        confirmButtonText: '<i class="fas fa-save me-2"></i>Create Slider',
        cancelButtonText: '<i class="fas fa-times me-2"></i>Cancel',
        confirmButtonColor: '#26de81',
        cancelButtonColor: '#7f8c8d',
        didOpen: () => {
            document.getElementById('createImage').addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        document.getElementById('createImagePreview').innerHTML = 
                            `<img src="${e.target.result}" style="max-width: 100%; height: auto; border-radius: 5px; border: 1px solid #ddd;">`;
                    };
                    reader.readAsDataURL(file);
                }
            });
        },
        preConfirm: () => {
            const form = document.getElementById('createSliderForm');
            const formData = new FormData(form);
            
            if (!formData.get('image') || !formData.get('image').name) {
                Swal.showValidationMessage('Please select an image');
                return false;
            }
            
            // Handle checkbox - convert to 1 or 0
            const isActive = document.getElementById('createActive').checked;
            formData.set('is_active', isActive ? '1' : '0');
            
            return formData;
        }
    }).then((result) => {
        if (result.isConfirmed) {
            submitCreateForm(result.value);
        }
    });
}

// Submit Create Form
function submitCreateForm(formData) {
    Swal.fire({
        title: 'Creating Slider...',
        html: 'Please wait while we upload your slider',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    fetch('{{ route('admin.hero-sliders.store') }}', {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: data.message,
                showConfirmButton: false,
                timer: 1500
            }).then(() => {
                window.location.reload();
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: data.message || 'Something went wrong'
            });
        }
    })
    .catch(error => {
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: 'Failed to create slider'
        });
    });
}

// Edit Modal
function openEditModal(sliderId) {
    Swal.fire({
        title: 'Loading...',
        text: 'Please wait',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    fetch(`/admin/hero-sliders/${sliderId}/edit`)
        .then(response => response.json())
        .then(slider => {
            Swal.fire({
                title: '<i class="fas fa-edit text-warning me-2"></i>Edit Slider',
                html: `
                    <form id="editSliderForm" enctype="multipart/form-data">
                        <div class="mb-3 text-start">
                            <label class="form-label">Current Image</label>
                            <div>
                                <img src="/storage/${slider.image}" style="max-width: 100%; height: auto; border-radius: 5px; border: 1px solid #ddd;">
                            </div>
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Change Image (Optional)</label>
                            <input type="file" class="form-control" name="image" accept="image/*" id="editImage">
                            <small class="text-muted">Leave empty to keep current image</small>
                            <div id="editImagePreview" class="mt-2"></div>
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Title (Optional)</label>
                            <input type="text" class="form-control" name="title" value="${slider.title || ''}" placeholder="Enter slider title">
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Link URL (Optional)</label>
                            <input type="url" class="form-control" name="link" value="${slider.link || ''}" placeholder="https://example.com">
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Display Order</label>
                            <input type="number" class="form-control" name="order" value="${slider.order}" min="0">
                        </div>
                        <div class="mb-3 text-start">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="is_active" ${slider.is_active ? 'checked' : ''} id="editActive">
                                <label class="form-check-label" for="editActive">Active</label>
                            </div>
                        </div>
                    </form>
                `,
                width: '600px',
                showCancelButton: true,
                confirmButtonText: '<i class="fas fa-save me-2"></i>Update Slider',
                cancelButtonText: '<i class="fas fa-times me-2"></i>Cancel',
                confirmButtonColor: '#fdcb6e',
                cancelButtonColor: '#7f8c8d',
                didOpen: () => {
                    document.getElementById('editImage').addEventListener('change', function(e) {
                        const file = e.target.files[0];
                        if (file) {
                            const reader = new FileReader();
                            reader.onload = function(e) {
                                document.getElementById('editImagePreview').innerHTML = 
                                    `<img src="${e.target.result}" style="max-width: 100%; height: auto; border-radius: 5px; border: 1px solid #ddd;">`;
                            };
                            reader.readAsDataURL(file);
                        }
                    });
                },
                preConfirm: () => {
                    const form = document.getElementById('editSliderForm');
                    const formData = new FormData(form);
                    
                    // Handle checkbox - convert to 1 or 0
                    const isActive = document.getElementById('editActive').checked;
                    formData.set('is_active', isActive ? '1' : '0');
                    
                    return formData;
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    submitEditForm(sliderId, result.value);
                }
            });
        })
        .catch(error => {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Failed to load slider data'
            });
        });
}

// Submit Edit Form
function submitEditForm(sliderId, formData) {
    formData.append('_method', 'PUT');
    
    Swal.fire({
        title: 'Updating Slider...',
        html: 'Please wait',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    fetch(`/admin/hero-sliders/${sliderId}`, {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: data.message,
                showConfirmButton: false,
                timer: 1500
            }).then(() => {
                window.location.reload();
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: data.message || 'Something went wrong'
            });
        }
    })
    .catch(error => {
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: 'Failed to update slider'
        });
    });
}

// Status Toggle
function confirmStatusToggle(checkbox, url, currentStatus) {
    const newStatus = !currentStatus;
    const statusText = newStatus ? 'activate' : 'deactivate';
    
    Swal.fire({
        title: 'Change Slider Status?',
        html: `Are you sure you want to <strong>${statusText}</strong> this slider?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: newStatus ? '#26de81' : '#ee5a6f',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: `Yes, ${statusText}!`,
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            showLoading('Updating status...');
            window.location.href = url;
        } else {
            checkbox.checked = currentStatus;
        }
    });
}

// Delete Confirmation
function confirmDelete(sliderId) {
    Swal.fire({
        title: 'Delete Slider?',
        text: 'This action cannot be undone!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ee5a6f',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: '<i class="fas fa-trash me-2"></i>Yes, delete it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('delete-form-' + sliderId).submit();
        }
    });
}

function showLoading(message) {
    Swal.fire({
        title: message,
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
}
</script>
@endpush

@endsection
