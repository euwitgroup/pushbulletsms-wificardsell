@extends('admin.layouts.app')

@section('title', 'Settings')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .settings-container {
        display: flex;
        gap: 20px;
    }
    
    .settings-sidebar {
        width: 280px;
        background: white;
        border-radius: 8px;
        padding: 20px 0;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        height: fit-content;
        position: sticky;
        top: 20px;
    }
    
    .settings-menu-item {
        padding: 12px 24px;
        display: flex;
        align-items: center;
        gap: 12px;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 14px;
        color: #2c3e50;
        text-decoration: none;
    }
    
    .settings-menu-item:hover {
        background: #f8f9fa;
        color: #667eea;
    }
    
    .settings-menu-item.active {
        background: #f0f0ff;
        color: #667eea;
        border-right: 3px solid #667eea;
        font-weight: 600;
    }
    
    .settings-menu-item i {
        width: 20px;
        font-size: 16px;
    }
    
    .settings-content {
        flex: 1;
        background: white;
        border-radius: 8px;
        padding: 30px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .settings-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
        padding-bottom: 20px;
        border-bottom: 2px solid #f1f3f5;
    }
    
    .settings-title {
        font-size: 20px;
        font-weight: 700;
        color: #1a1d2e;
        margin: 0;
    }
    
    .btn-setup {
        background: #667eea;
        color: white;
        padding: 10px 20px;
        border-radius: 6px;
        border: none;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
    }
    
    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
        margin-bottom: 20px;
    }
    
    .form-group-full {
        grid-column: 1 / -1;
    }
    
    .form-group {
        margin-bottom: 20px;
    }
    
    .form-label {
        font-size: 13px;
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 8px;
        display: block;
    }
    
    .required {
        color: #ee5a6f;
        margin-left: 3px;
    }
    
    .form-control {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid #dcdde1;
        border-radius: 6px;
        font-size: 13px;
        transition: all 0.2s ease;
    }
    
    .form-control:focus {
        border-color: #667eea;
        outline: none;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    }
    
    .form-control:disabled {
        background: #f8f9fa;
        cursor: not-allowed;
    }
    
    textarea.form-control {
        resize: vertical;
        min-height: 100px;
    }
    
    .email-verified {
        position: relative;
    }
    
    .email-verified .verified-icon {
        position: absolute;
        right: 12px;
        top: 50%;
        transform: translateY(-50%);
        color: #26de81;
        font-size: 16px;
    }
    
    .btn-submit {
        background: #667eea;
        color: white;
        padding: 12px 32px;
        border-radius: 6px;
        border: none;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
    }
    
    .btn-submit:hover {
        background: #5568d3;
        transform: translateY(-2px);
    }
    
    .settings-section {
        display: none;
    }
    
    .settings-section.active {
        display: block;
    }
</style>

<!-- Page Header -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 style="font-weight: 700; color: #1a1d2e; margin: 0;">
            <i class="fas fa-cog me-2" style="color: #667eea;"></i>Settings
        </h2>
    </div>
    <div>
        <p style="color: #6c757d; font-size: 14px; margin: 0;">
            <a href="{{ route('admin.dashboard') }}" style="color: #6c757d; text-decoration: none;">Home</a> 
            <i class="fas fa-chevron-right" style="font-size: 10px; margin: 0 5px;"></i> 
            <span>Settings</span>
        </p>
    </div>
</div>

<!-- Settings Container -->
<div class="settings-container">
    <!-- Sidebar -->
    <div class="settings-sidebar">
        <a href="#" class="settings-menu-item active" data-section="basic">
            <i class="fas fa-cog"></i>
            <span>Basic Settings</span>
        </a>
        <a href="#" class="settings-menu-item" data-section="seo">
            <i class="fas fa-search"></i>
            <span>SEO Settings</span>
        </a>
        <a href="#" class="settings-menu-item" data-section="logging">
            <i class="fas fa-list-alt"></i>
            <span>Logging</span>
        </a>
        <a href="#" class="settings-menu-item" data-section="rate-limit">
            <i class="fas fa-tachometer-alt"></i>
            <span>Rate Limiting</span>
        </a>
        <a href="#" class="settings-menu-item" data-section="theme">
            <i class="fas fa-palette"></i>
            <span>Theme Settings</span>
        </a>
        <a href="#" class="settings-menu-item" data-section="storage">
            <i class="fas fa-hdd"></i>
            <span>Storage Settings</span>
        </a>
        <a href="#" class="settings-menu-item" data-section="recaptcha">
            <i class="fas fa-shield-alt"></i>
            <span>Recaptcha Settings</span>
        </a>
        <a href="#" class="settings-menu-item" data-section="social-login">
            <i class="fas fa-share-alt"></i>
            <span>Social Login Settings</span>
        </a>
        <a href="#" class="settings-menu-item" data-section="login">
            <i class="fas fa-sign-in-alt"></i>
            <span>Login Settings</span>
        </a>
        <a href="#" class="settings-menu-item" data-section="logo">
            <i class="fas fa-image"></i>
            <span>Logo Settings</span>
        </a>
        <a href="#" class="settings-menu-item" data-section="ticket">
            <i class="fas fa-ticket-alt"></i>
            <span>Ticket Settings</span>
        </a>
        <a href="#" class="settings-menu-item" data-section="mail">
            <i class="fas fa-envelope"></i>
            <span>Mail Settings</span>
        </a>
    </div>
    
    <!-- Content -->
    <div class="settings-content">
        <form action="{{ route('admin.settings.update') }}" method="POST" enctype="multipart/form-data">
    @csrf
    
            <!-- Basic Settings Section -->
            <div class="settings-section active" id="basic-section">
                <div class="settings-header">
                    <h3 class="settings-title">Basic Settings</h3>
                    <button type="button" class="btn-setup">
                        <i class="fas fa-link me-2"></i>Setup Cron Jobs
                    </button>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Site Name<span class="required">*</span></label>
                        <input type="text" 
                               name="site_name" 
                               class="form-control @error('site_name') is-invalid @enderror" 
                               value="{{ old('site_name', $settings['site_name'] ?? 'BeePost') }}"
                               placeholder="BeePost">
                        @error('site_name')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">User Site Name<span class="required">*</span></label>
                        <input type="text" 
                               name="user_site_name" 
                               class="form-control @error('user_site_name') is-invalid @enderror" 
                               value="{{ old('user_site_name', $settings['user_site_name'] ?? 'BeePost') }}"
                               placeholder="BeePost">
                        @error('user_site_name')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Phone<span class="required">*</span></label>
                        <input type="text" 
                               name="site_phone" 
                               class="form-control @error('site_phone') is-invalid @enderror" 
                               value="{{ old('site_phone', $settings['site_phone'] ?? '+12543221222') }}"
                               placeholder="+12543221222">
                        @error('site_phone')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Email<span class="required">*</span></label>
                        <div class="email-verified">
                            <input type="email" 
                                   name="site_email" 
                                   class="form-control @error('site_email') is-invalid @enderror" 
                                   value="{{ old('site_email', $settings['site_email'] ?? 'demo@beepost.test') }}"
                                   placeholder="demo@beepost.test">
                            <i class="fas fa-check-circle verified-icon"></i>
                        </div>
                        @error('site_email')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <div class="form-group form-group-full">
                    <label class="form-label">Address<span class="required">*</span></label>
                    <input type="text" 
                           name="site_address" 
                           class="form-control @error('site_address') is-invalid @enderror" 
                           value="{{ old('site_address', $settings['site_address'] ?? '3507 SE Federal Hwy') }}"
                           placeholder="3507 SE Federal Hwy">
                    @error('site_address')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Time Zone<span class="required">*</span></label>
                        <select name="timezone" class="form-control @error('timezone') is-invalid @enderror">
                            <option value="America/Cancun" {{ old('timezone', $settings['timezone'] ?? '') == 'America/Cancun' ? 'selected' : '' }}>America/Cancun</option>
                            <option value="Asia/Dhaka" {{ old('timezone', $settings['timezone'] ?? '') == 'Asia/Dhaka' ? 'selected' : '' }}>Asia/Dhaka</option>
                            <option value="Asia/Kolkata" {{ old('timezone', $settings['timezone'] ?? '') == 'Asia/Kolkata' ? 'selected' : '' }}>Asia/Kolkata</option>
                            <option value="America/New_York" {{ old('timezone', $settings['timezone'] ?? '') == 'America/New_York' ? 'selected' : '' }}>America/New_York</option>
                            <option value="Europe/London" {{ old('timezone', $settings['timezone'] ?? '') == 'Europe/London' ? 'selected' : '' }}>Europe/London</option>
                        </select>
                        @error('timezone')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Select Date Format<span class="required">*</span></label>
                        <select name="date_format" class="form-control @error('date_format') is-invalid @enderror">
                            <option value="d M, Y" {{ old('date_format', $settings['date_format'] ?? '') == 'd M, Y' ? 'selected' : '' }}>d M, Y</option>
                            <option value="m/d/Y" {{ old('date_format', $settings['date_format'] ?? '') == 'm/d/Y' ? 'selected' : '' }}>m/d/Y</option>
                            <option value="Y-m-d" {{ old('date_format', $settings['date_format'] ?? '') == 'Y-m-d' ? 'selected' : '' }}>Y-m-d</option>
                            <option value="d/m/Y" {{ old('date_format', $settings['date_format'] ?? '') == 'd/m/Y' ? 'selected' : '' }}>d/m/Y</option>
                        </select>
                        @error('date_format')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Select Time Format<span class="required">*</span></label>
                        <select name="time_format" class="form-control @error('time_format') is-invalid @enderror">
                            <option value="h:i A" {{ old('time_format', $settings['time_format'] ?? '') == 'h:i A' ? 'selected' : '' }}>h:i A</option>
                            <option value="H:i" {{ old('time_format', $settings['time_format'] ?? '') == 'H:i' ? 'selected' : '' }}>H:i (24 hour)</option>
                        </select>
                        @error('time_format')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Country<span class="required">*</span></label>
                        <select name="country" class="form-control @error('country') is-invalid @enderror">
                            <option value="Indonesia" {{ old('country', $settings['country'] ?? '') == 'Indonesia' ? 'selected' : '' }}>Indonesia</option>
                            <option value="Bangladesh" {{ old('country', $settings['country'] ?? '') == 'Bangladesh' ? 'selected' : '' }}>Bangladesh</option>
                            <option value="India" {{ old('country', $settings['country'] ?? '') == 'India' ? 'selected' : '' }}>India</option>
                            <option value="USA" {{ old('country', $settings['country'] ?? '') == 'USA' ? 'selected' : '' }}>USA</option>
                            <option value="UK" {{ old('country', $settings['country'] ?? '') == 'UK' ? 'selected' : '' }}>UK</option>
                        </select>
                        @error('country')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Data Per Page<span class="required">*</span></label>
                        <input type="number" 
                               name="data_per_page" 
                               class="form-control @error('data_per_page') is-invalid @enderror" 
                               value="{{ old('data_per_page', $settings['data_per_page'] ?? '10') }}"
                               placeholder="10">
                        @error('data_per_page')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Web Visitors<span class="required">*</span></label>
                        <input type="number" 
                               name="web_visitors" 
                               class="form-control @error('web_visitors') is-invalid @enderror" 
                               value="{{ old('web_visitors', $settings['web_visitors'] ?? '42387') }}"
                               placeholder="42387">
                        @error('web_visitors')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Maintenance Mode Title<span class="required">*</span></label>
                        <input type="text" 
                               name="maintenance_title" 
                               class="form-control @error('maintenance_title') is-invalid @enderror" 
                               value="{{ old('maintenance_title', $settings['maintenance_title'] ?? 'BeePost is Undergoing Maintenance') }}"
                               placeholder="BeePost is Undergoing Maintenance">
                        @error('maintenance_title')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Maintenance Mode Description<span class="required">*</span></label>
                    <input type="text" 
                               name="maintenance_description" 
                               class="form-control @error('maintenance_description') is-invalid @enderror" 
                               value="{{ old('maintenance_description', $settings['maintenance_description'] ?? 'We\'re hard at work making improvements to BeePost...') }}"
                               placeholder="We're hard at work making improvements...">
                        @error('maintenance_description')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <div class="form-group form-group-full">
                    <label class="form-label">Copy Right Text<span class="required">*</span></label>
                    <textarea name="copyright_text" 
                              class="form-control @error('copyright_text') is-invalid @enderror" 
                              rows="3"
                              placeholder="© 2025 Past. All rights reserved.">{{ old('copyright_text', $settings['copyright_text'] ?? '© 2025 Past. All rights reserved.') }}</textarea>
                    @error('copyright_text')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
        </div>
        
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Google Adsense Publisher Id<span class="required">*</span></label>
                        <input type="text" 
                               name="google_adsense_id" 
                               class="form-control @error('google_adsense_id') is-invalid @enderror" 
                               value="{{ old('google_adsense_id', $settings['google_adsense_id'] ?? '') }}"
                               placeholder="@@@">
                        @error('google_adsense_id')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Google Analytics Tracking Id<span class="required">*</span></label>
                        <input type="text" 
                               name="google_analytics_id" 
                               class="form-control @error('google_analytics_id') is-invalid @enderror" 
                               value="{{ old('google_analytics_id', $settings['google_analytics_id'] ?? '') }}"
                               placeholder="@@@">
                        @error('google_analytics_id')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                
                <div class="form-group form-group-full">
                    <label class="form-label">Google Map API Key<span class="required">*</span></label>
                    <input type="text" 
                           name="google_map_api_key" 
                           class="form-control @error('google_map_api_key') is-invalid @enderror" 
                           value="{{ old('google_map_api_key', $settings['google_map_api_key'] ?? '') }}"
                           placeholder="@@@@">
                    @error('google_map_api_key')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                
                <div style="margin-top: 30px;">
                    <button type="submit" class="btn-submit">
                        <i class="fas fa-save me-2"></i>Submit
                    </button>
                </div>
            </div>
            
            <!-- SEO Settings Section -->
            <div class="settings-section" id="seo-section" style="display: none;">
                <div class="settings-header">
                    <h3 class="settings-title">SEO Settings</h3>
        </div>
        
                <div class="form-group">
                    <label class="form-label">Meta Title<span class="required">*</span></label>
                    <input type="text" 
                           name="meta_title" 
                           class="form-control @error('meta_title') is-invalid @enderror" 
                           value="{{ old('meta_title', $settings['meta_title'] ?? '') }}"
                           placeholder="SMS & Card Sale - Best SMS Service">
                    @error('meta_title')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                    </div>
                
                <div class="form-group">
                    <label class="form-label">Meta Description<span class="required">*</span></label>
                    <textarea name="meta_description" 
                              class="form-control @error('meta_description') is-invalid @enderror" 
                              rows="3"
                              placeholder="Enter meta description for SEO">{{ old('meta_description', $settings['meta_description'] ?? '') }}</textarea>
                    @error('meta_description')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                
                <div class="form-group">
                    <label class="form-label">Meta Keywords<span class="required">*</span></label>
                    <input type="text" 
                           name="meta_keywords" 
                           class="form-control @error('meta_keywords') is-invalid @enderror" 
                           value="{{ old('meta_keywords', $settings['meta_keywords'] ?? '') }}"
                           placeholder="sms, bulk sms, sms gateway, card sale">
                    @error('meta_keywords')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                
                <div class="form-group">
                    <label class="form-label">OG Image URL</label>
                    <input type="url" 
                           name="og_image" 
                           class="form-control @error('og_image') is-invalid @enderror" 
                           value="{{ old('og_image', $settings['og_image'] ?? '') }}"
                           placeholder="https://example.com/og-image.jpg">
                    @error('og_image')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
                
                <div style="margin-top: 30px;">
                    <button type="submit" class="btn-submit">
                        <i class="fas fa-save me-2"></i>Submit
                    </button>
                </div>
            </div>
            
            <!-- Logging Section -->
            <div class="settings-section" id="logging-section" style="display: none;">
                <div class="settings-header">
                    <h3 class="settings-title">Logging Settings</h3>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Enable Activity Logs</label>
                        <select name="enable_activity_logs" class="form-control">
                            <option value="1" {{ old('enable_activity_logs', $settings['enable_activity_logs'] ?? '1') == '1' ? 'selected' : '' }}>Enabled</option>
                            <option value="0" {{ old('enable_activity_logs', $settings['enable_activity_logs'] ?? '1') == '0' ? 'selected' : '' }}>Disabled</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Log Retention Days</label>
                        <input type="number" 
                               name="log_retention_days" 
                               class="form-control" 
                               value="{{ old('log_retention_days', $settings['log_retention_days'] ?? '30') }}"
                               placeholder="30">
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Enable Error Logging</label>
                    <select name="enable_error_logs" class="form-control">
                        <option value="1" {{ old('enable_error_logs', $settings['enable_error_logs'] ?? '1') == '1' ? 'selected' : '' }}>Enabled</option>
                        <option value="0" {{ old('enable_error_logs', $settings['enable_error_logs'] ?? '1') == '0' ? 'selected' : '' }}>Disabled</option>
                    </select>
                </div>
                
                <div style="margin-top: 30px;">
                    <button type="submit" class="btn-submit">
                        <i class="fas fa-save me-2"></i>Submit
                    </button>
                </div>
            </div>
            
            <!-- Rate Limiting Section -->
            <div class="settings-section" id="rate-limit-section" style="display: none;">
                <div class="settings-header">
                    <h3 class="settings-title">Rate Limiting Settings</h3>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">API Rate Limit (per minute)</label>
                        <input type="number" 
                               name="api_rate_limit" 
                               class="form-control" 
                               value="{{ old('api_rate_limit', $settings['api_rate_limit'] ?? '60') }}"
                               placeholder="60">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Login Attempts (per 15 minutes)</label>
                        <input type="number" 
                               name="login_rate_limit" 
                               class="form-control" 
                               value="{{ old('login_rate_limit', $settings['login_rate_limit'] ?? '5') }}"
                               placeholder="5">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">SMS Send Limit (per hour)</label>
                        <input type="number" 
                               name="sms_rate_limit" 
                               class="form-control" 
                               value="{{ old('sms_rate_limit', $settings['sms_rate_limit'] ?? '100') }}"
                               placeholder="100">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Enable Rate Limiting</label>
                        <select name="enable_rate_limiting" class="form-control">
                            <option value="1" {{ old('enable_rate_limiting', $settings['enable_rate_limiting'] ?? '1') == '1' ? 'selected' : '' }}>Enabled</option>
                            <option value="0" {{ old('enable_rate_limiting', $settings['enable_rate_limiting'] ?? '1') == '0' ? 'selected' : '' }}>Disabled</option>
                        </select>
                    </div>
                </div>
                
                <div style="margin-top: 30px;">
                    <button type="submit" class="btn-submit">
                        <i class="fas fa-save me-2"></i>Submit
                    </button>
                </div>
            </div>
            
            <!-- Theme Settings Section -->
            <div class="settings-section" id="theme-section" style="display: none;">
                <div class="settings-header">
                    <h3 class="settings-title">Theme Settings</h3>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Primary Color</label>
                        <input type="color" 
                               name="primary_color" 
                               class="form-control" 
                               value="{{ old('primary_color', $settings['primary_color'] ?? '#667eea') }}">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Secondary Color</label>
                        <input type="color" 
                               name="secondary_color" 
                               class="form-control" 
                               value="{{ old('secondary_color', $settings['secondary_color'] ?? '#764ba2') }}">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Default Theme</label>
                        <select name="default_theme" class="form-control">
                            <option value="light" {{ old('default_theme', $settings['default_theme'] ?? 'light') == 'light' ? 'selected' : '' }}>Light</option>
                            <option value="dark" {{ old('default_theme', $settings['default_theme'] ?? 'light') == 'dark' ? 'selected' : '' }}>Dark</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Enable Dark Mode</label>
                        <select name="enable_dark_mode" class="form-control">
                            <option value="1" {{ old('enable_dark_mode', $settings['enable_dark_mode'] ?? '1') == '1' ? 'selected' : '' }}>Yes</option>
                            <option value="0" {{ old('enable_dark_mode', $settings['enable_dark_mode'] ?? '1') == '0' ? 'selected' : '' }}>No</option>
                        </select>
                    </div>
                </div>
                
                <div style="margin-top: 30px;">
                    <button type="submit" class="btn-submit">
                        <i class="fas fa-save me-2"></i>Submit
                    </button>
                </div>
            </div>
            
            <!-- Storage Settings Section -->
            <div class="settings-section" id="storage-section" style="display: none;">
                <div class="settings-header">
                    <h3 class="settings-title">Storage Settings</h3>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Storage Driver</label>
                    <select name="storage_driver" class="form-control">
                        <option value="local" {{ old('storage_driver', $settings['storage_driver'] ?? 'local') == 'local' ? 'selected' : '' }}>Local</option>
                        <option value="s3" {{ old('storage_driver', $settings['storage_driver'] ?? 'local') == 's3' ? 'selected' : '' }}>Amazon S3</option>
                        <option value="digitalocean" {{ old('storage_driver', $settings['storage_driver'] ?? 'local') == 'digitalocean' ? 'selected' : '' }}>DigitalOcean Spaces</option>
                    </select>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Max Upload Size (MB)</label>
                        <input type="number" 
                               name="max_upload_size" 
                               class="form-control" 
                               value="{{ old('max_upload_size', $settings['max_upload_size'] ?? '10') }}"
                               placeholder="10">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Allowed File Types</label>
                        <input type="text" 
                               name="allowed_file_types" 
                               class="form-control" 
                               value="{{ old('allowed_file_types', $settings['allowed_file_types'] ?? 'jpg,jpeg,png,pdf,doc,docx') }}"
                               placeholder="jpg,jpeg,png,pdf,doc,docx">
                    </div>
                </div>
                
                <div style="margin-top: 30px;">
                    <button type="submit" class="btn-submit">
                        <i class="fas fa-save me-2"></i>Submit
                    </button>
                </div>
            </div>
            
            <!-- Recaptcha Settings Section -->
            <div class="settings-section" id="recaptcha-section" style="display: none;">
                <div class="settings-header">
                    <h3 class="settings-title">Google reCAPTCHA Settings</h3>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Enable reCAPTCHA</label>
                    <select name="enable_recaptcha" class="form-control">
                        <option value="1" {{ old('enable_recaptcha', $settings['enable_recaptcha'] ?? '0') == '1' ? 'selected' : '' }}>Enabled</option>
                        <option value="0" {{ old('enable_recaptcha', $settings['enable_recaptcha'] ?? '0') == '0' ? 'selected' : '' }}>Disabled</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">reCAPTCHA Site Key</label>
                    <input type="text" 
                           name="recaptcha_site_key" 
                           class="form-control" 
                           value="{{ old('recaptcha_site_key', $settings['recaptcha_site_key'] ?? '') }}"
                           placeholder="6Lxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx">
                </div>
                
                <div class="form-group">
                    <label class="form-label">reCAPTCHA Secret Key</label>
                    <input type="text" 
                           name="recaptcha_secret_key" 
                           class="form-control" 
                           value="{{ old('recaptcha_secret_key', $settings['recaptcha_secret_key'] ?? '') }}"
                           placeholder="6Lxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx">
                </div>
                
                <div class="form-group">
                    <label class="form-label">reCAPTCHA Version</label>
                    <select name="recaptcha_version" class="form-control">
                        <option value="v2" {{ old('recaptcha_version', $settings['recaptcha_version'] ?? 'v2') == 'v2' ? 'selected' : '' }}>reCAPTCHA v2</option>
                        <option value="v3" {{ old('recaptcha_version', $settings['recaptcha_version'] ?? 'v2') == 'v3' ? 'selected' : '' }}>reCAPTCHA v3</option>
                    </select>
                </div>
                
                <div style="margin-top: 30px;">
                    <button type="submit" class="btn-submit">
                        <i class="fas fa-save me-2"></i>Submit
                    </button>
                </div>
            </div>
            
            <!-- Social Login Settings Section -->
            <div class="settings-section" id="social-login-section" style="display: none;">
                <div class="settings-header">
                    <h3 class="settings-title">Social Login Settings</h3>
                </div>
                
                <!-- Google Login -->
                <h5 style="margin-bottom: 20px; color: #2c3e50; font-size: 16px; font-weight: 600;">Google Login</h5>
                <div class="form-group">
                    <label class="form-label">Enable Google Login</label>
                    <select name="enable_google_login" class="form-control">
                        <option value="1" {{ old('enable_google_login', $settings['enable_google_login'] ?? '0') == '1' ? 'selected' : '' }}>Enabled</option>
                        <option value="0" {{ old('enable_google_login', $settings['enable_google_login'] ?? '0') == '0' ? 'selected' : '' }}>Disabled</option>
                    </select>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Google Client ID</label>
                        <input type="text" 
                               name="google_client_id" 
                               class="form-control" 
                               value="{{ old('google_client_id', $settings['google_client_id'] ?? '') }}"
                               placeholder="Enter Google Client ID">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Google Client Secret</label>
                        <input type="text" 
                               name="google_client_secret" 
                               class="form-control" 
                               value="{{ old('google_client_secret', $settings['google_client_secret'] ?? '') }}"
                               placeholder="Enter Google Client Secret">
                    </div>
                </div>
                
                <!-- Facebook Login -->
                <h5 style="margin: 30px 0 20px 0; color: #2c3e50; font-size: 16px; font-weight: 600;">Facebook Login</h5>
                <div class="form-group">
                    <label class="form-label">Enable Facebook Login</label>
                    <select name="enable_facebook_login" class="form-control">
                        <option value="1" {{ old('enable_facebook_login', $settings['enable_facebook_login'] ?? '0') == '1' ? 'selected' : '' }}>Enabled</option>
                        <option value="0" {{ old('enable_facebook_login', $settings['enable_facebook_login'] ?? '0') == '0' ? 'selected' : '' }}>Disabled</option>
                    </select>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Facebook App ID</label>
                        <input type="text" 
                               name="facebook_app_id" 
                               class="form-control" 
                               value="{{ old('facebook_app_id', $settings['facebook_app_id'] ?? '') }}"
                               placeholder="Enter Facebook App ID">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Facebook App Secret</label>
                        <input type="text" 
                               name="facebook_app_secret" 
                               class="form-control" 
                               value="{{ old('facebook_app_secret', $settings['facebook_app_secret'] ?? '') }}"
                               placeholder="Enter Facebook App Secret">
                    </div>
                </div>
                
                <div style="margin-top: 30px;">
                    <button type="submit" class="btn-submit">
                        <i class="fas fa-save me-2"></i>Submit
                    </button>
                </div>
            </div>
            
            <!-- Login Settings Section -->
            <div class="settings-section" id="login-section" style="display: none;">
                <div class="settings-header">
                    <h3 class="settings-title">Login Settings</h3>
                    <span style="font-size: 12px; color: #6c757d;">Configure registration, verification, and security settings</span>
                </div>
                
                <!-- Registration Settings -->
                <h5 style="color: #667eea; margin: 20px 0 15px 0; font-weight: 600; border-bottom: 2px solid #f0f0ff; padding-bottom: 8px;">
                    <i class="fas fa-user-plus me-2"></i>Registration Settings
                </h5>
                
                <div class="form-group">
                    <label class="form-label">Enable User Registration</label>
                    <select name="enable_registration" class="form-control">
                        <option value="1" {{ old('enable_registration', $settings['enable_registration'] ?? '1') == '1' ? 'selected' : '' }}>Enabled</option>
                        <option value="0" {{ old('enable_registration', $settings['enable_registration'] ?? '1') == '0' ? 'selected' : '' }}>Disabled</option>
                    </select>
                    <small class="form-text text-muted">Allow new users to register on your platform</small>
                </div>
                
                <!-- Verification Settings -->
                <h5 style="color: #667eea; margin: 30px 0 15px 0; font-weight: 600; border-bottom: 2px solid #f0f0ff; padding-bottom: 8px;">
                    <i class="fas fa-check-circle me-2"></i>Verification Settings
                </h5>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Email Verification</label>
                        <select name="email_verification_required" class="form-control">
                            <option value="1" {{ old('email_verification_required', $settings['email_verification_required'] ?? '0') == '1' ? 'selected' : '' }}>Required</option>
                            <option value="0" {{ old('email_verification_required', $settings['email_verification_required'] ?? '0') == '0' ? 'selected' : '' }}>Optional</option>
                        </select>
                        <small class="form-text text-muted">Email verification from user profile</small>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Phone Verification<span class="required">*</span></label>
                        <select name="phone_verification_required" class="form-control">
                            <option value="1" {{ old('phone_verification_required', $settings['phone_verification_required'] ?? '1') == '1' ? 'selected' : '' }}>Required</option>
                            <option value="0" {{ old('phone_verification_required', $settings['phone_verification_required'] ?? '1') == '0' ? 'selected' : '' }}>Optional</option>
                        </select>
                        <small class="form-text text-muted">Phone must be verified during registration</small>
                    </div>
                </div>
                
                <div class="alert alert-info" style="background: #e7f3ff; border: 1px solid #b3d9ff; border-radius: 8px; padding: 15px; margin-top: 15px;">
                    <i class="fas fa-info-circle me-2"></i>
                    <strong>Phone Verification:</strong> Uses BulkSMSBD gateway to send OTP during registration. Ensure your SMS gateway is configured properly.
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">OTP Expiry Time (minutes)</label>
                        <input type="number" 
                               name="otp_expiry_minutes" 
                               class="form-control" 
                               value="{{ old('otp_expiry_minutes', $settings['otp_expiry_minutes'] ?? '5') }}"
                               placeholder="5"
                               min="1"
                               max="30">
                        <small class="form-text text-muted">How long the OTP remains valid</small>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">OTP Length</label>
                        <input type="number" 
                               name="otp_length" 
                               class="form-control" 
                               value="{{ old('otp_length', $settings['otp_length'] ?? '6') }}"
                               placeholder="6"
                               min="4"
                               max="8">
                        <small class="form-text text-muted">Number of digits in OTP code</small>
                    </div>
                </div>
                
                <!-- Password Settings -->
                <h5 style="color: #667eea; margin: 30px 0 15px 0; font-weight: 600; border-bottom: 2px solid #f0f0ff; padding-bottom: 8px;">
                    <i class="fas fa-lock me-2"></i>Password & Security
                </h5>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Password Min Length</label>
                        <input type="number" 
                               name="password_min_length" 
                               class="form-control" 
                               value="{{ old('password_min_length', $settings['password_min_length'] ?? '8') }}"
                               placeholder="8"
                               min="6"
                               max="20">
                        <small class="form-text text-muted">Minimum characters required for passwords</small>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Session Timeout (minutes)</label>
                        <input type="number" 
                               name="session_timeout" 
                               class="form-control" 
                               value="{{ old('session_timeout', $settings['session_timeout'] ?? '120') }}"
                               placeholder="120"
                               min="5">
                        <small class="form-text text-muted">Auto logout after inactivity</small>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Max Login Attempts</label>
                    <input type="number" 
                           name="max_login_attempts" 
                           class="form-control" 
                           value="{{ old('max_login_attempts', $settings['max_login_attempts'] ?? '5') }}"
                           placeholder="5"
                           min="3"
                           max="10">
                    <small class="form-text text-muted">Maximum failed login attempts before account lockout</small>
                </div>
                
                <div style="margin-top: 30px;">
                    <button type="submit" class="btn-submit">
                        <i class="fas fa-save me-2"></i>Save Login Settings
                    </button>
                </div>
            </div>
            
            <!-- Logo Settings Section -->
            <div class="settings-section" id="logo-section" style="display: none;">
                <div class="settings-header">
                    <h3 class="settings-title">Logo Settings</h3>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Site Logo</label>
                    <input type="file" 
                           name="site_logo" 
                           class="form-control" 
                           accept="image/*">
                    @if(isset($settings['site_logo']) && $settings['site_logo'])
                        <div style="margin-top: 10px;">
                            <img src="{{ asset('storage/' . $settings['site_logo']) }}" alt="Logo" style="max-width: 200px; border: 1px solid #ddd; padding: 5px; border-radius: 4px;">
                        </div>
                    @endif
                </div>
                
                <div class="form-group">
                    <label class="form-label">Site Favicon</label>
                    <input type="file" 
                           name="site_favicon" 
                           class="form-control" 
                           accept="image/*">
                    @if(isset($settings['site_favicon']) && $settings['site_favicon'])
                        <div style="margin-top: 10px;">
                            <img src="{{ asset('storage/' . $settings['site_favicon']) }}" alt="Favicon" style="max-width: 50px; border: 1px solid #ddd; padding: 5px; border-radius: 4px;">
                        </div>
                    @endif
                </div>
                
                <div class="form-group">
                    <label class="form-label">Logo Width (px)</label>
                    <input type="number" 
                           name="logo_width" 
                           class="form-control" 
                           value="{{ old('logo_width', $settings['logo_width'] ?? '150') }}"
                           placeholder="150">
                </div>
                
                <div style="margin-top: 30px;">
                    <button type="submit" class="btn-submit">
                        <i class="fas fa-save me-2"></i>Submit
                    </button>
                </div>
            </div>
            
            <!-- Ticket Settings Section -->
            <div class="settings-section" id="ticket-section" style="display: none;">
                <div class="settings-header">
                    <h3 class="settings-title">Ticket Settings</h3>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Enable Support Tickets</label>
                    <select name="enable_tickets" class="form-control">
                        <option value="1" {{ old('enable_tickets', $settings['enable_tickets'] ?? '1') == '1' ? 'selected' : '' }}>Enabled</option>
                        <option value="0" {{ old('enable_tickets', $settings['enable_tickets'] ?? '1') == '0' ? 'selected' : '' }}>Disabled</option>
                    </select>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Default Ticket Priority</label>
                        <select name="default_ticket_priority" class="form-control">
                            <option value="low" {{ old('default_ticket_priority', $settings['default_ticket_priority'] ?? 'medium') == 'low' ? 'selected' : '' }}>Low</option>
                            <option value="medium" {{ old('default_ticket_priority', $settings['default_ticket_priority'] ?? 'medium') == 'medium' ? 'selected' : '' }}>Medium</option>
                            <option value="high" {{ old('default_ticket_priority', $settings['default_ticket_priority'] ?? 'medium') == 'high' ? 'selected' : '' }}>High</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Auto-close After (days)</label>
                        <input type="number" 
                               name="ticket_auto_close_days" 
                               class="form-control" 
                               value="{{ old('ticket_auto_close_days', $settings['ticket_auto_close_days'] ?? '30') }}"
                               placeholder="30">
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Notification Email for New Tickets</label>
                    <input type="email" 
                           name="ticket_notification_email" 
                           class="form-control" 
                           value="{{ old('ticket_notification_email', $settings['ticket_notification_email'] ?? '') }}"
                           placeholder="support@example.com">
                </div>
                
                <div style="margin-top: 30px;">
                    <button type="submit" class="btn-submit">
                        <i class="fas fa-save me-2"></i>Submit
                    </button>
                </div>
            </div>
            
            <!-- Mail Settings Section -->
            <div class="settings-section" id="mail-section" style="display: none;">
                <div class="settings-header">
                    <h3 class="settings-title">Mail Settings</h3>
                    <span style="font-size: 12px; color: #6c757d;">Configure SMTP and email settings</span>
                </div>
                
                <!-- Mail Driver -->
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Mail Driver<span class="required">*</span></label>
                        <select name="mail_driver" class="form-control" id="mail_driver">
                            <option value="smtp" {{ old('mail_driver', $settings['mail_driver'] ?? 'smtp') == 'smtp' ? 'selected' : '' }}>SMTP</option>
                            <option value="sendmail" {{ old('mail_driver', $settings['mail_driver'] ?? 'smtp') == 'sendmail' ? 'selected' : '' }}>Sendmail</option>
                            <option value="mailgun" {{ old('mail_driver', $settings['mail_driver'] ?? 'smtp') == 'mailgun' ? 'selected' : '' }}>Mailgun</option>
                            <option value="ses" {{ old('mail_driver', $settings['mail_driver'] ?? 'smtp') == 'ses' ? 'selected' : '' }}>Amazon SES</option>
                            <option value="log" {{ old('mail_driver', $settings['mail_driver'] ?? 'smtp') == 'log' ? 'selected' : '' }}>Log (Testing)</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Mail Encryption</label>
                        <select name="mail_encryption" class="form-control">
                            <option value="tls" {{ old('mail_encryption', $settings['mail_encryption'] ?? 'tls') == 'tls' ? 'selected' : '' }}>TLS</option>
                            <option value="ssl" {{ old('mail_encryption', $settings['mail_encryption'] ?? 'tls') == 'ssl' ? 'selected' : '' }}>SSL</option>
                            <option value="" {{ old('mail_encryption', $settings['mail_encryption'] ?? 'tls') == '' ? 'selected' : '' }}>None</option>
                        </select>
                    </div>
                </div>
                
                <!-- SMTP Configuration -->
                <div id="smtp-config">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Mail Host<span class="required">*</span></label>
                            <input type="text" 
                                   name="mail_host" 
                                   class="form-control" 
                                   value="{{ old('mail_host', $settings['mail_host'] ?? 'smtp.gmail.com') }}"
                                   placeholder="smtp.gmail.com">
                            <small class="form-text text-muted">Common: smtp.gmail.com, smtp-mail.outlook.com, smtp.mailtrap.io</small>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Mail Port<span class="required">*</span></label>
                            <input type="number" 
                                   name="mail_port" 
                                   class="form-control" 
                                   value="{{ old('mail_port', $settings['mail_port'] ?? '587') }}"
                                   placeholder="587">
                            <small class="form-text text-muted">Common: 587 (TLS), 465 (SSL), 25 (No encryption)</small>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Mail Username<span class="required">*</span></label>
                            <input type="text" 
                                   name="mail_username" 
                                   class="form-control" 
                                   value="{{ old('mail_username', $settings['mail_username'] ?? '') }}"
                                   placeholder="your-email@example.com">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Mail Password<span class="required">*</span></label>
                            <input type="password" 
                                   name="mail_password" 
                                   class="form-control" 
                                   value="{{ old('mail_password', $settings['mail_password'] ?? '') }}"
                                   placeholder="••••••••">
                            <small class="form-text text-muted">For Gmail, use App Password if 2FA is enabled</small>
                        </div>
                    </div>
                </div>
                
                <!-- Mail From Configuration -->
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Mail From Address<span class="required">*</span></label>
                        <input type="email" 
                               name="mail_from_address" 
                               class="form-control" 
                               value="{{ old('mail_from_address', $settings['mail_from_address'] ?? '') }}"
                               placeholder="noreply@example.com">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Mail From Name<span class="required">*</span></label>
                        <input type="text" 
                               name="mail_from_name" 
                               class="form-control" 
                               value="{{ old('mail_from_name', $settings['mail_from_name'] ?? '') }}"
                               placeholder="SMS & Card Sale">
                    </div>
                </div>
                
                <!-- Additional Mail Settings -->
                <div class="form-group">
                    <label class="form-label">Admin Email (receives system notifications)</label>
                    <input type="email" 
                           name="admin_email" 
                           class="form-control" 
                           value="{{ old('admin_email', $settings['admin_email'] ?? '') }}"
                           placeholder="admin@example.com">
                </div>
                
                <!-- Test Mail Button -->
                <div class="alert alert-info" style="background: #e7f3ff; border: 1px solid #b3d9ff; border-radius: 8px; padding: 15px; margin-top: 20px;">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-info-circle me-3" style="font-size: 20px; color: #0066cc;"></i>
                        <div style="flex: 1;">
                            <strong style="display: block; margin-bottom: 5px;">Test Your Configuration</strong>
                            <small style="color: #666;">Save your settings first, then use the test button to send a test email.</small>
                        </div>
                        <button type="button" class="btn btn-outline-primary btn-sm" id="test-mail-btn" style="white-space: nowrap;">
                            <i class="fas fa-paper-plane me-2"></i>Send Test Email
                        </button>
        </div>
    </div>
    
                <div style="margin-top: 30px;">
                    <button type="submit" class="btn-submit">
                        <i class="fas fa-save me-2"></i>Save Mail Settings
        </button>
                </div>
            </div>
        </form>
    </div>
</div>

@push('scripts')
<script>
document.querySelectorAll('.settings-menu-item').forEach(item => {
    item.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Remove active class from all items
        document.querySelectorAll('.settings-menu-item').forEach(i => i.classList.remove('active'));
        
        // Add active class to clicked item
        this.classList.add('active');
        
        // Hide all sections
        document.querySelectorAll('.settings-section').forEach(s => {
            s.style.display = 'none';
            s.classList.remove('active');
        });
        
        // Show selected section
        const section = this.dataset.section;
        const sectionElement = document.getElementById(section + '-section');
        if (sectionElement) {
            sectionElement.style.display = 'block';
            sectionElement.classList.add('active');
        }
    });
});

// Test Mail Button
document.getElementById('test-mail-btn')?.addEventListener('click', function() {
    Swal.fire({
        title: 'Send Test Email',
        input: 'email',
        inputLabel: 'Enter email address to send test email',
        inputPlaceholder: 'test@example.com',
        showCancelButton: true,
        confirmButtonText: 'Send',
        confirmButtonColor: '#667eea',
        showLoaderOnConfirm: true,
        preConfirm: (email) => {
            return fetch('{{ route("admin.settings.test-mail") }}', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                },
                body: JSON.stringify({ email: email })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(response.statusText);
                }
                return response.json();
            })
            .catch(error => {
                Swal.showValidationMessage(`Request failed: ${error}`);
            });
        },
        allowOutsideClick: () => !Swal.isLoading()
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire({
                icon: 'success',
                title: 'Email Sent!',
                text: result.value.message || 'Test email sent successfully.',
                confirmButtonColor: '#667eea'
            });
        }
    });
});
</script>
@endpush

@endsection
