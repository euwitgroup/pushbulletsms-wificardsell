<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Invoice #INV-{{ str_pad($invoice->id, 6, '0', STR_PAD_LEFT) }}</title>
    <style>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 12px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 3px solid #007bff;
        }
        .header h1 {
            color: #007bff;
            margin: 0 0 5px 0;
            font-size: 28px;
        }
        .header .invoice-number {
            font-size: 16px;
            color: #6c757d;
        }
        .company-info {
            margin-bottom: 30px;
        }
        .company-info h3 {
            margin: 0 0 10px 0;
            color: #333;
        }
        .invoice-details {
            margin-bottom: 30px;
        }
        .invoice-details table {
            width: 100%;
        }
        .invoice-details td {
            padding: 5px;
        }
        .invoice-details .label {
            font-weight: bold;
            color: #6c757d;
        }
        table.items {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table.items th {
            background: #f8f9fa;
            color: #495057;
            font-weight: bold;
            padding: 12px;
            text-align: left;
            border-bottom: 2px solid #dee2e6;
        }
        table.items td {
            padding: 12px;
            border-bottom: 1px solid #dee2e6;
        }
        table.items tfoot td {
            font-weight: bold;
            background: #f8f9fa;
            border-top: 2px solid #dee2e6;
        }
        .total {
            font-size: 18px;
            color: #007bff;
        }
        .status-badge {
            padding: 5px 15px;
            border-radius: 4px;
            font-weight: bold;
            display: inline-block;
        }
        .status-paid {
            background: #d4edda;
            color: #155724;
        }
        .status-unpaid {
            background: #fff3cd;
            color: #856404;
        }
        .status-cancelled {
            background: #f8d7da;
            color: #721c24;
        }
        .footer {
            margin-top: 50px;
            text-align: center;
            color: #6c757d;
            font-size: 11px;
            padding-top: 20px;
            border-top: 1px solid #dee2e6;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>INVOICE</h1>
        <div class="invoice-number">#INV-{{ str_pad($invoice->id, 6, '0', STR_PAD_LEFT) }}</div>
    </div>

    <table style="width: 100%; margin-bottom: 30px;">
        <tr>
            <td style="width: 50%; vertical-align: top;">
                <div class="company-info">
                    <h3>FROM</h3>
                    <strong>{{ $settings['site_name'] ?? config('app.name') }}</strong><br>
                    {{ $settings['site_email'] ?? 'admin@example.com' }}
                </div>
            </td>
            <td style="width: 50%; vertical-align: top; text-align: right;">
                <div class="company-info">
                    <h3>TO</h3>
                    <strong>{{ $invoice->user->name ?? 'N/A' }}</strong><br>
                    {{ $invoice->user->email ?? 'N/A' }}
                </div>
            </td>
        </tr>
    </table>

    <div class="invoice-details">
        <table>
            <tr>
                <td style="width: 50%;">
                    <span class="label">Invoice Date:</span><br>
                    {{ $invoice->created_at->format('F d, Y') }}
                </td>
                <td style="width: 50%; text-align: right;">
                    <span class="label">Status:</span><br>
                    <span class="status-badge status-{{ $invoice->status }}">
                        {{ ucfirst($invoice->status) }}
                    </span>
                </td>
            </tr>
        </table>
    </div>

    <table class="items">
        <thead>
            <tr>
                <th>Description</th>
                <th style="text-align: center;">Quantity</th>
                <th style="text-align: right;">Rate</th>
                <th style="text-align: right;">Amount</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <strong>{{ $invoice->description ?? 'SMS Package' }}</strong><br>
                    <small>SMS Credits Purchase</small>
                </td>
                <td style="text-align: center;">{{ $invoice->sms_count ?? 0 }}</td>
                <td style="text-align: right;">৳{{ number_format($invoice->amount / max($invoice->sms_count ?? 1, 1), 2) }}</td>
                <td style="text-align: right;">৳{{ number_format($invoice->amount, 2) }}</td>
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3" style="text-align: right;">Total Amount:</td>
                <td style="text-align: right;" class="total">৳{{ number_format($invoice->amount, 2) }}</td>
            </tr>
        </tfoot>
    </table>

    <div style="margin-top: 30px;">
        <p><strong>Payment Method:</strong> {{ ucfirst($invoice->payment_method ?? 'N/A') }}</p>
        <p><strong>Transaction ID:</strong> {{ $invoice->transaction_id }}</p>
    </div>

    <div class="footer">
        <p>Thank you for your business!</p>
        <p>{{ $settings['site_name'] ?? config('app.name') }} - {{ $settings['site_email'] ?? '' }}</p>
        <p>Generated on {{ date('F d, Y h:i A') }}</p>
    </div>
</body>
</html>
