<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Transactions Report</title>
    <style>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 12px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #4facfe;
            padding-bottom: 20px;
        }
        .header h1 {
            color: #4facfe;
            margin: 0 0 10px 0;
        }
        .header p {
            color: #6c757d;
            margin: 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th {
            background: #f8f9fa;
            color: #495057;
            font-weight: bold;
            padding: 10px;
            text-align: left;
            border-bottom: 2px solid #dee2e6;
        }
        td {
            padding: 10px;
            border-bottom: 1px solid #dee2e6;
        }
        .badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 10px;
            font-weight: bold;
        }
        .badge-credit {
            background: #d4edda;
            color: #155724;
        }
        .badge-debit {
            background: #f8d7da;
            color: #721c24;
        }
        .badge-completed {
            background: #d4edda;
            color: #155724;
        }
        .badge-pending {
            background: #fff3cd;
            color: #856404;
        }
        .badge-failed {
            background: #f8d7da;
            color: #721c24;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            color: #6c757d;
            font-size: 10px;
        }
        .amount-credit {
            color: #38ef7d;
            font-weight: bold;
        }
        .amount-debit {
            color: #fa8c79;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Financial Transactions Report</h1>
        <p>Generated on: {{ date('F d, Y h:i A') }}</p>
        <p>Total Records: {{ count($transactions) }}</p>
    </div>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Transaction ID</th>
                <th>User</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            @forelse($transactions as $transaction)
            <tr>
                <td>#{{ $transaction->id }}</td>
                <td>{{ $transaction->transaction_id }}</td>
                <td>
                    {{ $transaction->user->name ?? 'N/A' }}<br>
                    <small style="color: #6c757d;">{{ $transaction->user->email ?? '' }}</small>
                </td>
                <td>
                    <span class="badge badge-{{ $transaction->type }}">
                        {{ ucfirst($transaction->type) }}
                    </span>
                </td>
                <td class="amount-{{ $transaction->type }}">
                    {{ $transaction->type == 'credit' ? '+' : '-' }}৳{{ number_format($transaction->amount, 2) }}
                </td>
                <td>
                    <span class="badge badge-{{ $transaction->status }}">
                        {{ ucfirst($transaction->status) }}
                    </span>
                </td>
                <td>
                    {{ $transaction->created_at->format('M d, Y') }}<br>
                    <small style="color: #6c757d;">{{ $transaction->created_at->format('h:i A') }}</small>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="7" style="text-align: center; color: #6c757d;">No transactions found</td>
            </tr>
            @endforelse
        </tbody>
    </table>

    <div class="footer">
        <p>SMS & Card Sale Management System - {{ config('app.name') }}</p>
        <p>This is an automated report. For any queries, please contact support.</p>
    </div>
</body>
</html>
