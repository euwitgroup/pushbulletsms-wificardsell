@extends('admin.layouts.app')

@section('title', 'Contact Information')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .breadcrumb-nav a:hover {
        color: #3498db;
    }
    
    .table-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .btn-add-new {
        background: #26de81;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s ease;
    }
    
    .btn-add-new:hover {
        background: #20bf6b;
        transform: translateY(-1px);
    }
    
    .contacts-table-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .contacts-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .contacts-table thead th {
        background: #f8f9fa;
        padding: 12px 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: #636e72;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: 1px solid #e9ecef;
    }
    
    .contacts-table tbody td {
        padding: 12px 16px;
        font-size: 13px;
        border-bottom: 1px solid #f1f3f5;
        vertical-align: middle;
    }
    
    .contacts-table tbody tr:hover {
        background: #f8f9fa;
    }
    
    .type-badge {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 11px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }
    
    .type-badge.phone {
        background: #e3f2fd;
        color: #1976d2;
    }
    
    .type-badge.email {
        background: #f3e5f5;
        color: #7b1fa2;
    }
    
    .type-badge.address {
        background: #fff3e0;
        color: #f57c00;
    }
    
    .type-badge.hours {
        background: #e8f5e9;
        color: #388e3c;
    }
    
    .type-badge.social {
        background: #fce4ec;
        color: #c2185b;
    }
    
    .contact-icon {
        width: 35px;
        height: 35px;
        border-radius: 8px;
        background: linear-gradient(135deg, #667eea, #764ba2);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 14px;
    }
    
    .status-toggle {
        position: relative;
        display: inline-block;
        width: 44px;
        height: 24px;
    }
    
    .status-toggle input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .toggle-slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: 0.3s;
        border-radius: 24px;
    }
    
    .toggle-slider:before {
        position: absolute;
        content: "";
        height: 18px;
        width: 18px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: 0.3s;
        border-radius: 50%;
    }
    
    .status-toggle input:checked + .toggle-slider {
        background-color: #26de81;
    }
    
    .status-toggle input:checked + .toggle-slider:before {
        transform: translateX(20px);
    }
    
    .action-buttons {
        display: flex;
        gap: 6px;
    }
    
    .btn-sm {
        padding: 4px 8px;
        border-radius: 4px;
        border: none;
        cursor: pointer;
        font-size: 11px;
        display: inline-flex;
        align-items: center;
        gap: 4px;
        transition: all 0.2s ease;
    }
    
    .btn-sm.edit {
        background: #3498db;
        color: white;
    }
    
    .btn-sm.edit:hover {
        background: #2980b9;
    }
    
    .btn-sm.delete {
        background: #ee5a6f;
        color: white;
    }
    
    .btn-sm.delete:hover {
        background: #d63447;
    }
    
    .pagination-wrapper {
        padding: 15px 20px;
        background: white;
        border-top: 1px solid #e9ecef;
    }
    
    /* SweetAlert2 custom styles */
    .swal2-popup {
        border-radius: 12px;
        padding: 30px;
    }
    
    .swal2-input, .swal2-textarea, .swal2-select {
        border: 1px solid #e9ecef;
        border-radius: 6px;
        padding: 10px 15px;
        font-size: 14px;
        margin: 8px 0;
    }
    
    .swal2-input:focus, .swal2-textarea:focus, .swal2-select:focus {
        border-color: #3498db;
        box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.1);
    }
    
    .swal2-confirm {
        background: #26de81 !important;
        border-radius: 6px;
    }
    
    .swal2-cancel {
        background: #95a5a6 !important;
        border-radius: 6px;
    }
</style>

<div class="container-fluid">
    <!-- Page Breadcrumb -->
    <div class="page-breadcrumb">
        <div>
            <h4 class="page-title">Contact Information</h4>
            <div class="breadcrumb-nav">
                <a href="{{ route('admin.dashboard') }}">Dashboard</a> / Contact Information
            </div>
        </div>
    </div>

    <!-- Table Controls -->
    <div class="table-controls">
        <button class="btn-add-new" onclick="openCreateModal()">
            <i class="fas fa-plus"></i> Add New Contact Info
        </button>
    </div>

    <!-- Contacts Table -->
    <div class="contacts-table-card">
        <table class="contacts-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Icon</th>
                    <th>Type</th>
                    <th>Label</th>
                    <th>Value</th>
                    <th>Description</th>
                    <th>Order</th>
                    <th>Status</th>
                    <th>Options</th>
                </tr>
            </thead>
            <tbody>
                @forelse($contacts as $index => $contact)
                <tr>
                    <td>{{ $contacts->firstItem() + $index }}</td>
                    <td>
                        <div class="contact-icon">
                            <i class="{{ $contact->icon ?? 'fas fa-info' }}"></i>
                        </div>
                    </td>
                    <td>
                        <span class="type-badge {{ $contact->type }}">{{ $contact->type }}</span>
                    </td>
                    <td><strong>{{ $contact->label }}</strong></td>
                    <td>{{ Str::limit($contact->value, 40) }}</td>
                    <td>{{ Str::limit($contact->description ?? 'N/A', 30) }}</td>
                    <td><span style="font-weight: 600; color: #7f8c8d;">{{ $contact->order }}</span></td>
                    <td>
                        <label class="status-toggle">
                            <input type="checkbox" {{ $contact->is_active ? 'checked' : '' }} 
                                   onchange="confirmStatusToggle(this, {{ $contact->id }}, {{ $contact->is_active ? 'true' : 'false' }})">
                            <span class="toggle-slider"></span>
                        </label>
                    </td>
                    <td>
                        <div class="action-buttons">
                            <button class="btn-sm edit" onclick="editContact({{ $contact->id }})">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <form action="{{ route('admin.contact-info.destroy', $contact->id) }}" 
                                  method="POST" 
                                  onsubmit="return confirm('Are you sure you want to delete this contact info?');"
                                  style="display: inline;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn-sm delete">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="9" style="text-align: center; padding: 40px; color: #95a5a6;">
                        <i class="fas fa-info-circle" style="font-size: 48px; margin-bottom: 10px;"></i>
                        <p>No contact information found. Click "Add New Contact Info" to create one.</p>
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>

        @if($contacts->hasPages())
        <div class="pagination-wrapper">
            {{ $contacts->links() }}
        </div>
        @endif
    </div>
</div>

@push('scripts')
<script>
// Open Create Modal
function openCreateModal() {
    Swal.fire({
        title: 'Add New Contact Info',
        html: `
            <div style="text-align: left;">
                <label style="font-size: 13px; font-weight: 600; color: #636e72; display: block; margin-bottom: 5px;">Type *</label>
                <select id="type" class="swal2-select" style="width: 100%;">
                    <option value="">Select Type</option>
                    <option value="phone">Phone</option>
                    <option value="email">Email</option>
                    <option value="address">Address</option>
                    <option value="hours">Working Hours</option>
                    <option value="social">Social Media</option>
                </select>

                <label style="font-size: 13px; font-weight: 600; color: #636e72; display: block; margin: 12px 0 5px;">Label *</label>
                <input type="text" id="label" class="swal2-input" placeholder="e.g., Main Office" style="width: 100%;">

                <label style="font-size: 13px; font-weight: 600; color: #636e72; display: block; margin: 12px 0 5px;">Icon (FontAwesome class)</label>
                <input type="text" id="icon" class="swal2-input" placeholder="e.g., fas fa-phone" style="width: 100%;">

                <label style="font-size: 13px; font-weight: 600; color: #636e72; display: block; margin: 12px 0 5px;">Value *</label>
                <textarea id="value" class="swal2-textarea" placeholder="Contact value (phone, email, URL, etc.)" style="width: 100%; height: 80px;"></textarea>

                <label style="font-size: 13px; font-weight: 600; color: #636e72; display: block; margin: 12px 0 5px;">Description</label>
                <textarea id="description" class="swal2-textarea" placeholder="Additional description (optional)" style="width: 100%; height: 60px;"></textarea>

                <label style="font-size: 13px; font-weight: 600; color: #636e72; display: block; margin: 12px 0 5px;">Display Order</label>
                <input type="number" id="order" class="swal2-input" placeholder="0" value="0" style="width: 100%;">

                <label style="font-size: 13px; font-weight: 600; color: #636e72; display: flex; align-items: center; gap: 8px; margin-top: 12px;">
                    <input type="checkbox" id="is_active" checked style="width: auto; height: auto; margin: 0;">
                    Active
                </label>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: 'Create',
        cancelButtonText: 'Cancel',
        width: '600px',
        preConfirm: () => {
            const type = document.getElementById('type').value;
            const label = document.getElementById('label').value;
            const icon = document.getElementById('icon').value;
            const value = document.getElementById('value').value;
            const description = document.getElementById('description').value;
            const order = document.getElementById('order').value;
            const is_active = document.getElementById('is_active').checked ? '1' : '0';

            if (!type || !label || !value) {
                Swal.showValidationMessage('Please fill in all required fields');
                return false;
            }

            return { type, label, icon, value, description, order, is_active };
        }
    }).then((result) => {
        if (result.isConfirmed) {
            saveContact(result.value);
        }
    });
}

// Edit Contact
function editContact(id) {
    fetch(`/admin/contact-info/${id}/edit`)
        .then(response => response.json())
        .then(contact => {
            Swal.fire({
                title: 'Edit Contact Info',
                html: `
                    <div style="text-align: left;">
                        <label style="font-size: 13px; font-weight: 600; color: #636e72; display: block; margin-bottom: 5px;">Type *</label>
                        <select id="type" class="swal2-select" style="width: 100%;">
                            <option value="phone" ${contact.type === 'phone' ? 'selected' : ''}>Phone</option>
                            <option value="email" ${contact.type === 'email' ? 'selected' : ''}>Email</option>
                            <option value="address" ${contact.type === 'address' ? 'selected' : ''}>Address</option>
                            <option value="hours" ${contact.type === 'hours' ? 'selected' : ''}>Working Hours</option>
                            <option value="social" ${contact.type === 'social' ? 'selected' : ''}>Social Media</option>
                        </select>

                        <label style="font-size: 13px; font-weight: 600; color: #636e72; display: block; margin: 12px 0 5px;">Label *</label>
                        <input type="text" id="label" class="swal2-input" value="${contact.label}" style="width: 100%;">

                        <label style="font-size: 13px; font-weight: 600; color: #636e72; display: block; margin: 12px 0 5px;">Icon (FontAwesome class)</label>
                        <input type="text" id="icon" class="swal2-input" value="${contact.icon || ''}" style="width: 100%;">

                        <label style="font-size: 13px; font-weight: 600; color: #636e72; display: block; margin: 12px 0 5px;">Value *</label>
                        <textarea id="value" class="swal2-textarea" style="width: 100%; height: 80px;">${contact.value}</textarea>

                        <label style="font-size: 13px; font-weight: 600; color: #636e72; display: block; margin: 12px 0 5px;">Description</label>
                        <textarea id="description" class="swal2-textarea" style="width: 100%; height: 60px;">${contact.description || ''}</textarea>

                        <label style="font-size: 13px; font-weight: 600; color: #636e72; display: block; margin: 12px 0 5px;">Display Order</label>
                        <input type="number" id="order" class="swal2-input" value="${contact.order}" style="width: 100%;">

                        <label style="font-size: 13px; font-weight: 600; color: #636e72; display: flex; align-items: center; gap: 8px; margin-top: 12px;">
                            <input type="checkbox" id="is_active" ${contact.is_active ? 'checked' : ''} style="width: auto; height: auto; margin: 0;">
                            Active
                        </label>
                    </div>
                `,
                showCancelButton: true,
                confirmButtonText: 'Update',
                cancelButtonText: 'Cancel',
                width: '600px',
                preConfirm: () => {
                    const type = document.getElementById('type').value;
                    const label = document.getElementById('label').value;
                    const icon = document.getElementById('icon').value;
                    const value = document.getElementById('value').value;
                    const description = document.getElementById('description').value;
                    const order = document.getElementById('order').value;
                    const is_active = document.getElementById('is_active').checked ? '1' : '0';

                    if (!type || !label || !value) {
                        Swal.showValidationMessage('Please fill in all required fields');
                        return false;
                    }

                    return { type, label, icon, value, description, order, is_active };
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    updateContact(id, result.value);
                }
            });
        });
}

// Save Contact (Create)
function saveContact(data) {
    fetch('{{ route("admin.contact-info.store") }}', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: data.message,
                timer: 2000
            }).then(() => {
                location.reload();
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: data.message
            });
        }
    })
    .catch(error => {
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: 'An error occurred while saving the contact info.'
        });
    });
}

// Update Contact
function updateContact(id, data) {
    fetch(`/admin/contact-info/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: data.message,
                timer: 2000
            }).then(() => {
                location.reload();
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: data.message
            });
        }
    })
    .catch(error => {
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: 'An error occurred while updating the contact info.'
        });
    });
}

// Toggle Status
function confirmStatusToggle(checkbox, contactId, currentStatus) {
    const newStatus = !currentStatus;
    
    Swal.fire({
        title: 'Confirm Status Change',
        text: `Do you want to ${newStatus ? 'activate' : 'deactivate'} this contact info?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, change it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch(`/admin/contact-info/${contactId}/toggle-status`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: 'Status updated successfully',
                    timer: 1500,
                    showConfirmButton: false
                }).then(() => {
                    location.reload();
                });
            })
            .catch(error => {
                checkbox.checked = currentStatus;
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'Failed to update status'
                });
            });
        } else {
            checkbox.checked = currentStatus;
        }
    });
}
</script>
@endpush
@endsection

