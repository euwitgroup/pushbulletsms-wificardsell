@extends('admin.layouts.app')

@section('title', 'SMS Pricing Management')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .breadcrumb-nav a:hover {
        color: #3498db;
    }
    
    .table-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .btn-add-new {
        background: #26de81;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s ease;
    }
    
    .btn-add-new:hover {
        background: #20bf6b;
        transform: translateY(-1px);
    }
    
    .table-filters {
        display: flex;
        gap: 10px;
    }
    
    .btn-icon {
        background: #3498db;
        color: white;
        border: none;
        padding: 6px 10px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
    }
    
    .btn-icon.red {
        background: #ee5a6f;
    }
    
    .prices-table-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .prices-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .prices-table thead th {
        background: #f8f9fa;
        padding: 12px 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: #7f8c8d;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .prices-table tbody td {
        padding: 14px 16px;
        font-size: 13px;
        color: #2c3e50;
        border-bottom: 1px solid #f1f2f6;
        vertical-align: middle;
    }
    
    .prices-table tbody tr:hover {
        background: #fafbfc;
    }

    .price-badge {
        background: #26de81;
        color: white;
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 500;
        display: inline-block;
    }

    .package-type-badge {
        background: #e7f3ff;
        color: #0066cc;
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 500;
        display: inline-block;
    }

    .featured-badge {
        background: #ffd700;
        color: #000;
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 500;
        display: inline-block;
    }
    
    .status-toggle {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 22px;
    }
    
    .status-toggle input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .toggle-slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .3s;
        border-radius: 24px;
    }
    
    .toggle-slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: .3s;
        border-radius: 50%;
    }
    
    input:checked + .toggle-slider {
        background-color: #26de81;
    }
    
    input:checked + .toggle-slider:before {
        transform: translateX(18px);
    }
    
    .action-buttons {
        display: flex;
        gap: 6px;
    }
    
    .btn-action {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 12px;
    }
    
    .btn-action:hover {
        transform: scale(1.1);
    }
    
    .btn-action.edit {
        background: #ffeaa7;
        color: #fdcb6e;
    }
    
    .btn-action.delete {
        background: #ffcccc;
        color: #ee5a6f;
    }
    
    .pagination-wrapper {
        padding: 15px;
        display: flex;
        justify-content: flex-end;
    }

    .empty-state {
        text-align: center;
        padding: 60px 20px;
    }

    .empty-state i {
        font-size: 64px;
        color: #dcdde1;
        margin-bottom: 20px;
    }

    .empty-state h4 {
        color: #7f8c8d;
        font-size: 18px;
        margin-bottom: 10px;
    }

    .empty-state p {
        color: #95a5a6;
        font-size: 14px;
    }

    .badge-order {
        background: #8854d0;
        color: white;
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 500;
        display: inline-block;
    }

    /* SweetAlert form styling */
    .feature-list {
        max-height: 200px;
        overflow-y: auto;
        text-align: left;
        margin: 10px 0;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
    }

    .feature-item-input {
        display: flex;
        gap: 5px;
        margin-bottom: 5px;
    }
</style>

<!-- Breadcrumb -->
<div class="page-breadcrumb">
    <h1 class="page-title">💰 SMS Pricing Management</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > <span>SMS Pricing</span>
    </div>
</div>

<!-- Table Controls -->
<div class="table-controls">
    <button onclick="createPrice()" class="btn-add-new">
        <i class="fas fa-plus"></i> Add New Price Package
    </button>
    
    <div class="table-filters">
        <div class="search-box">
            <button class="btn-icon"><i class="fas fa-filter"></i></button>
            <button class="btn-icon red"><i class="fas fa-file-pdf"></i></button>
        </div>
    </div>
</div>

<!-- Prices Table -->
<div class="prices-table-card">
    <table class="prices-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Order</th>
                <th>Package Name</th>
                <th>Type</th>
                <th>Base Price</th>
                <th>Min. Buy</th>
                <th>Status</th>
                <th>Featured</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
            @forelse($prices as $index => $price)
            <tr>
                <td>{{ $prices->firstItem() + $index }}</td>
                <td>
                    <span class="badge-order">#{{ $price->order }}</span>
                </td>
                <td>
                    <strong>{{ $price->package_name }}</strong>
                </td>
                <td>
                    <span class="package-type-badge">{{ ucwords(str_replace('_', ' ', $price->package_type)) }}</span>
                </td>
                <td>
                    <span class="price-badge">৳{{ number_format($price->base_price, 2) }}</span>
                </td>
                <td>{{ number_format($price->minimum_buy) }} SMS</td>
                <td>
                    <label class="status-toggle">
                        <input type="checkbox" {{ $price->is_active ? 'checked' : '' }} 
                               onchange="confirmStatusToggle(this, {{ $price->id }}, {{ $price->is_active ? 'true' : 'false' }})">
                        <span class="toggle-slider"></span>
                    </label>
                </td>
                <td>
                    @if($price->is_featured)
                        <span class="featured-badge">⭐ Featured</span>
                    @else
                        -
                    @endif
                </td>
                <td>
                    <div class="action-buttons">
                        <button onclick="editPrice({{ $price->id }})" class="btn-action edit" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button type="button" class="btn-action delete" title="Delete" onclick="confirmDelete({{ $price->id }})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="9">
                    <div class="empty-state">
                        <i class="fas fa-dollar-sign"></i>
                        <h4>No SMS Price Packages Found</h4>
                        <p>Create your first SMS price package to get started!</p>
                    </div>
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
    
    <!-- Pagination -->
    @if($prices->hasPages())
    <div class="pagination-wrapper">
        {{ $prices->links() }}
    </div>
    @endif
</div>

@push('scripts')
<script>
let currentFeatures = [];

// Status Toggle Confirmation
function confirmStatusToggle(checkbox, priceId, currentStatus) {
    const newStatus = !currentStatus;
    const statusText = newStatus ? 'activate' : 'deactivate';
    
    Swal.fire({
        title: 'Change Package Status?',
        html: `Are you sure you want to <strong>${statusText}</strong> this package?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: newStatus ? '#26de81' : '#ee5a6f',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: `Yes, ${statusText}!`,
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            showLoading('Updating status...');
            
            fetch(`/admin/sms-prices/${priceId}/toggle-status`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: data.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        window.location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: data.message
                    });
                    checkbox.checked = currentStatus;
                }
            })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'An error occurred. Please try again.'
                });
                checkbox.checked = currentStatus;
            });
        } else {
            checkbox.checked = currentStatus;
        }
    });
}

// Delete Confirmation
function confirmDelete(priceId) {
    Swal.fire({
        title: 'Delete Price Package?',
        text: 'This action cannot be undone!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ee5a6f',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: '<i class="fas fa-trash me-2"></i>Yes, delete it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            showLoading('Deleting package...');
            
            fetch(`/admin/sms-prices/${priceId}`, {
                method: 'DELETE',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}',
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Deleted!',
                        text: data.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        window.location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: data.message
                    });
                }
            })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'An error occurred. Please try again.'
                });
            });
        }
    });
}

function showLoading(message) {
    Swal.fire({
        title: message,
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
}

// Create Price Package
function createPrice() {
    currentFeatures = [];
    
    Swal.fire({
        title: 'Create SMS Price Package',
        html: `
            <form id="createPriceForm">
                <div class="mb-3 text-start">
                    <label class="form-label">Package Name *</label>
                    <input type="text" class="form-control" id="createPackageName" name="package_name" required placeholder="e.g., NON MASKING 1">
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Package Type *</label>
                    <select class="form-control" id="createPackageType" name="package_type" required>
                        <option value="">Select Type</option>
                        <option value="non_masking_1">Non Masking 1</option>
                        <option value="non_masking_2">Non Masking 2</option>
                        <option value="masking">Masking</option>
                    </select>
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Base Price (BDT) *</label>
                    <input type="number" step="0.01" class="form-control" id="createBasePrice" name="base_price" required placeholder="0.35">
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Minimum Buy (SMS) *</label>
                    <input type="number" class="form-control" id="createMinBuy" name="minimum_buy" required placeholder="200">
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Order</label>
                    <input type="number" class="form-control" id="createOrder" name="order" value="0" min="0">
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Features (one per line)</label>
                    <textarea class="form-control" id="createFeatures" name="features" rows="5" placeholder="Enter features, one per line"></textarea>
                    <small class="text-muted">Each line will be a separate feature</small>
                </div>
                <div class="mb-3 text-start">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="createFeatured" name="is_featured" value="1">
                        <label class="form-check-label" for="createFeatured">
                            Featured Package
                        </label>
                    </div>
                </div>
                <div class="mb-3 text-start">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="createActive" name="is_active" value="1" checked>
                        <label class="form-check-label" for="createActive">
                            Active
                        </label>
                    </div>
                </div>
            </form>
        `,
        width: '600px',
        showCancelButton: true,
        confirmButtonText: 'Create Package',
        cancelButtonText: 'Cancel',
        preConfirm: () => {
            const form = document.getElementById('createPriceForm');
            const formData = new FormData(form);

            // Handle features - split by newlines and remove empty lines
            const featuresText = document.getElementById('createFeatures').value;
            const featuresArray = featuresText.split('\n').filter(line => line.trim() !== '');
            formData.set('features', JSON.stringify(featuresArray));

            // Handle checkboxes
            const isFeatured = document.getElementById('createFeatured').checked;
            const isActive = document.getElementById('createActive').checked;
            formData.set('is_featured', isFeatured ? '1' : '0');
            formData.set('is_active', isActive ? '1' : '0');

            if (!formData.get('package_name') || !formData.get('package_type') || !formData.get('base_price') || !formData.get('minimum_buy')) {
                Swal.showValidationMessage('Please fill in all required fields');
                return false;
            }

            return formData;
        }
    }).then((result) => {
        if (result.isConfirmed) {
            const formData = result.value;

            Swal.fire({
                title: 'Creating...',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            fetch('{{ route('admin.sms-prices.store') }}', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: data.message,
                        timer: 1500
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: data.message
                    });
                }
            })
            .catch(error => {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'An error occurred. Please try again.'
                });
            });
        }
    });
}

// Edit Price Package
function editPrice(id) {
    Swal.fire({
        title: 'Loading...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    fetch(`/admin/sms-prices/${id}/edit`)
        .then(response => response.json())
        .then(price => {
            const featuresText = price.features ? price.features.join('\n') : '';
            
            Swal.fire({
                title: 'Edit SMS Price Package',
                html: `
                    <form id="editPriceForm">
                        <div class="mb-3 text-start">
                            <label class="form-label">Package Name *</label>
                            <input type="text" class="form-control" id="editPackageName" name="package_name" value="${price.package_name}" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Package Type *</label>
                            <select class="form-control" id="editPackageType" name="package_type" required>
                                <option value="non_masking_1" ${price.package_type === 'non_masking_1' ? 'selected' : ''}>Non Masking 1</option>
                                <option value="non_masking_2" ${price.package_type === 'non_masking_2' ? 'selected' : ''}>Non Masking 2</option>
                                <option value="masking" ${price.package_type === 'masking' ? 'selected' : ''}>Masking</option>
                            </select>
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Base Price (BDT) *</label>
                            <input type="number" step="0.01" class="form-control" id="editBasePrice" name="base_price" value="${price.base_price}" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Minimum Buy (SMS) *</label>
                            <input type="number" class="form-control" id="editMinBuy" name="minimum_buy" value="${price.minimum_buy}" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Order</label>
                            <input type="number" class="form-control" id="editOrder" name="order" value="${price.order}" min="0">
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Features (one per line)</label>
                            <textarea class="form-control" id="editFeatures" name="features" rows="5">${featuresText}</textarea>
                            <small class="text-muted">Each line will be a separate feature</small>
                        </div>
                        <div class="mb-3 text-start">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="editFeatured" name="is_featured" value="1" ${price.is_featured ? 'checked' : ''}>
                                <label class="form-check-label" for="editFeatured">
                                    Featured Package
                                </label>
                            </div>
                        </div>
                        <div class="mb-3 text-start">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="editActive" name="is_active" value="1" ${price.is_active ? 'checked' : ''}>
                                <label class="form-check-label" for="editActive">
                                    Active
                                </label>
                            </div>
                        </div>
                    </form>
                `,
                width: '600px',
                showCancelButton: true,
                confirmButtonText: 'Update Package',
                cancelButtonText: 'Cancel',
                preConfirm: () => {
                    const form = document.getElementById('editPriceForm');
                    const formData = new FormData(form);
                    formData.append('_method', 'PUT');

                    // Handle features
                    const featuresText = document.getElementById('editFeatures').value;
                    const featuresArray = featuresText.split('\n').filter(line => line.trim() !== '');
                    formData.set('features', JSON.stringify(featuresArray));

                    // Handle checkboxes
                    const isFeatured = document.getElementById('editFeatured').checked;
                    const isActive = document.getElementById('editActive').checked;
                    formData.set('is_featured', isFeatured ? '1' : '0');
                    formData.set('is_active', isActive ? '1' : '0');

                    if (!formData.get('package_name') || !formData.get('package_type') || !formData.get('base_price') || !formData.get('minimum_buy')) {
                        Swal.showValidationMessage('Please fill in all required fields');
                        return false;
                    }

                    return formData;
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    const formData = result.value;

                    Swal.fire({
                        title: 'Updating...',
                        allowOutsideClick: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });

                    fetch(`/admin/sms-prices/${id}`, {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        },
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Success!',
                                text: data.message,
                                timer: 1500
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error!',
                                text: data.message
                            });
                        }
                    })
                    .catch(error => {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error!',
                            text: 'An error occurred. Please try again.'
                        });
                    });
                }
            });
        })
        .catch(error => {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Failed to load price data'
            });
        });
}
</script>
@endpush

@endsection

