@extends('admin.layouts.app')

@section('title', 'Payment Gateway')

@section('content')
<style>
    .gateway-card {
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        padding: 24px;
        margin-bottom: 20px;
    }
    
    .gateway-header {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 20px;
        padding-bottom: 16px;
        border-bottom: 1px solid #f0f0f0;
    }
    
    .gateway-logo {
        width: 48px;
        height: 48px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        color: #fff;
    }
    
    .form-control-custom {
        border-radius: 8px;
        border: 1px solid #e5e7eb;
        padding: 10px 14px;
        font-size: 14px;
        transition: all 0.2s;
    }
    
    .form-control-custom:focus {
        border-color: #6366f1;
        box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
    }
    
    .btn-primary-custom {
        background: #6366f1;
        color: white;
        border: none;
        padding: 10px 24px;
        border-radius: 8px;
        font-weight: 500;
        font-size: 14px;
        transition: all 0.2s;
    }
    
    .btn-primary-custom:hover {
        background: #4f46e5;
        transform: translateY(-1px);
    }
    
    .btn-success-custom {
        background: #10b981;
        color: white;
        border: none;
        padding: 10px 24px;
        border-radius: 8px;
        font-weight: 500;
        font-size: 14px;
        transition: all 0.2s;
    }
    
    .btn-success-custom:hover {
        background: #059669;
        transform: translateY(-1px);
    }
    
    .toggle-switch {
        position: relative;
        display: inline-block;
        width: 48px;
        height: 24px;
    }
    
    .toggle-switch input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .toggle-slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #e5e7eb;
        transition: .3s;
        border-radius: 24px;
    }
    
    .toggle-slider:before {
        position: absolute;
        content: "";
        height: 18px;
        width: 18px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: .3s;
        border-radius: 50%;
    }
    
    input:checked + .toggle-slider {
        background-color: #8b5cf6;
    }
    
    input:checked + .toggle-slider:before {
        transform: translateX(24px);
    }
    
    .badge-status {
        background: #dbeafe;
        color: #1e40af;
        padding: 6px 12px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 500;
    }
    
    .doc-card {
        background: #f9fafb;
        border-radius: 10px;
        padding: 20px;
        margin-top: 20px;
    }
</style>

<!-- Page Header -->
<div class="mb-4">
    <h4 style="font-weight: 600; color: #1f2937; margin: 0;">Manage Payment Methods</h4>
    <p style="color: #6b7280; font-size: 14px; margin-top: 4px;">Configure payment gateway settings and manage transactions</p>
</div>

<!-- Success/Error Messages -->
@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

@if(session('error'))
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-circle me-2"></i>{{ session('error') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

@if($errors->any())
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-circle me-2"></i>
    <ul class="mb-0">
        @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif

<!-- RupantorPay Card -->
<div class="gateway-card">
    <div class="gateway-header">
        <div class="gateway-logo" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
            <i class="fas fa-wallet"></i>
        </div>
        <div style="flex: 1;">
            <h5 style="margin: 0; font-weight: 600; color: #1f2937;">RupantorPay</h5>
            <small style="color: #6b7280;">Secure payment gateway for Bangladesh</small>
        </div>
        <label class="toggle-switch">
            <input type="checkbox" id="rupantorpay-toggle" {{ ($settings['rupantorpay_active'] ?? false) ? 'checked' : '' }} onchange="toggleGateway('rupantorpay', this.checked)">
            <span class="toggle-slider"></span>
        </label>
    </div>
    
    <form action="{{ route('admin.payment-gateway.update', 'rupantorpay') }}" method="POST">
        @csrf
        <div class="row">
            <div class="col-md-12 mb-3">
                <label style="font-size: 13px; font-weight: 500; color: #374151; margin-bottom: 8px; display: block;">
                    API Key (X-API-KEY) <span style="color: #ef4444;">*</span>
                </label>
                <input type="text" name="api_key" class="form-control-custom" value="{{ $settings['rupantorpay_api_key'] ?? '' }}" placeholder="Enter your API Key from RupantorPay Dashboard">
                <small style="color: #6b7280; font-size: 12px;">Get your API Key from RupantorPay Merchant Dashboard → Settings → API Keys</small>
            </div>
            
            <div class="col-md-6 mb-3">
                <label style="font-size: 13px; font-weight: 500; color: #374151; margin-bottom: 8px; display: block;">Success URL</label>
                <input type="text" name="success_url" class="form-control-custom" value="{{ $settings['rupantorpay_success_url'] ?? url('/payment/success') }}" placeholder="https://yourdomain.com/payment/success">
                <small style="color: #6b7280; font-size: 12px;">Redirect URL after successful payment</small>
            </div>
            
            <div class="col-md-6 mb-3">
                <label style="font-size: 13px; font-weight: 500; color: #374151; margin-bottom: 8px; display: block;">Cancel URL</label>
                <input type="text" name="cancel_url" class="form-control-custom" value="{{ $settings['rupantorpay_cancel_url'] ?? url('/payment/cancel') }}" placeholder="https://yourdomain.com/payment/cancel">
                <small style="color: #6b7280; font-size: 12px;">Redirect URL if payment cancelled</small>
            </div>
            
            <div class="col-md-12 mb-3">
                <label style="font-size: 13px; font-weight: 500; color: #374151; margin-bottom: 8px; display: block;">Webhook URL</label>
                <input type="text" class="form-control-custom" value="{{ url('/webhook/rupantorpay') }}" readonly onclick="this.select()" style="background: #f9fafb;">
                <small style="color: #6b7280; font-size: 12px;">Copy this URL and add it to your RupantorPay webhook settings</small>
            </div>
            
            <div class="col-md-6 mb-3">
                <label style="font-size: 13px; font-weight: 500; color: #374151; margin-bottom: 8px; display: flex; align-items: center; gap: 8px;">
                    <input type="checkbox" name="is_sandbox" value="1" {{ ($settings['rupantorpay_sandbox'] ?? true) ? 'checked' : '' }} style="width: 18px; height: 18px; cursor: pointer;">
                    Sandbox Mode (Test)
                </label>
                <small style="color: #6b7280; font-size: 12px;">Enable for testing with test credentials</small>
            </div>
        </div>
        
        <div style="display: flex; gap: 12px; margin-top: 16px;">
            <button type="submit" class="btn-primary-custom">
                <i class="fas fa-save me-2"></i>Save Settings
            </button>
            <button type="button" class="btn-success-custom" onclick="testConnection('rupantorpay')">
                <i class="fas fa-check-circle me-2"></i>Test Connection
            </button>
        </div>
    </form>
</div>
        
<!-- Documentation Card -->
<div class="doc-card">
    <h6 style="font-weight: 600; color: #1f2937; margin-bottom: 16px;">
        <i class="fas fa-book me-2"></i>Integration Documentation
    </h6>
    <p style="color: #6b7280; font-size: 14px; line-height: 1.6; margin-bottom: 16px;">
        RupantorPay is a secure payment gateway for Bangladesh. Configure your API key above to accept payments via multiple channels including bKash, Nagad, Rocket, and card payments.
    </p>
    
    <div style="background: white; padding: 16px; border-radius: 8px; border: 1px solid #e5e7eb;">
        <p style="font-size: 13px; margin: 0; color: #374151;"><strong>API Endpoint:</strong></p>
        <code style="font-size: 12px; color: #6366f1;">https://payment.rupantorpay.com/api/payment/checkout</code>
    </div>
    
    <div style="margin-top: 16px; display: flex; gap: 12px; flex-wrap: wrap;">
        <a href="https://rupantorpay.com/developers/docs" target="_blank" class="btn-primary-custom" style="display: inline-flex; align-items: center; text-decoration: none;">
            <i class="fas fa-book me-2"></i>Documentation
        </a>
        <a href="https://github.com/rupantorpay/LaravelSDK" target="_blank" class="btn-success-custom" style="display: inline-flex; align-items: center; text-decoration: none; background: #374151;">
            <i class="fab fa-github me-2"></i>Laravel SDK
        </a>
    </div>
</div>

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function toggleGateway(gateway, isActive) {
    fetch(`/admin/payment-gateway/${gateway}/update`, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify({
            is_active: isActive ? '1' : '0'
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Updated!',
                text: `Gateway ${isActive ? 'enabled' : 'disabled'} successfully`,
                showConfirmButton: false,
                timer: 1500
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById(`${gateway}-toggle`).checked = !isActive;
    });
}

function testConnection(gateway) {
    Swal.fire({
        title: 'Testing Connection...',
        html: 'Please wait while we test the gateway connection',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    fetch(`/admin/payment-gateway/${gateway}/test`, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Connection Successful!',
                text: data.message,
                confirmButtonColor: '#28a745'
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Connection Failed',
                text: data.message,
                confirmButtonColor: '#dc3545'
            });
        }
    })
    .catch(error => {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Failed to test connection: ' + error.message,
            confirmButtonColor: '#dc3545'
        });
    });
}
</script>
@endpush
@endsection
