@extends('admin.layouts.app')

@section('title', 'Why Choose Us')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .breadcrumb-nav a:hover {
        color: #3498db;
    }
    
    .table-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .btn-add-new {
        background: #26de81;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 4px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        transition: all 0.2s ease;
    }
    
    .btn-add-new:hover {
        background: #20bf6b;
        transform: translateY(-1px);
    }
    
    .table-filters {
        display: flex;
        gap: 10px;
    }
    
    .btn-icon {
        background: #3498db;
        color: white;
        border: none;
        padding: 6px 10px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
    }
    
    .btn-icon.red {
        background: #ee5a6f;
    }
    
    .features-table-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .features-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .features-table thead th {
        background: #f8f9fa;
        padding: 12px 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: #7f8c8d;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .features-table tbody td {
        padding: 14px 16px;
        font-size: 13px;
        color: #2c3e50;
        border-bottom: 1px solid #f1f2f6;
        vertical-align: middle;
    }
    
    .features-table tbody tr:hover {
        background: #fafbfc;
    }
    
    .feature-icon-preview {
        font-size: 32px;
        color: #8854d0;
    }
    
    .badge-order {
        background: #8854d0;
        color: white;
        padding: 5px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 500;
        display: inline-block;
    }
    
    .status-toggle {
        position: relative;
        display: inline-block;
        width: 40px;
        height: 22px;
    }
    
    .status-toggle input {
        opacity: 0;
        width: 0;
        height: 0;
    }
    
    .toggle-slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #ccc;
        transition: .3s;
        border-radius: 24px;
    }
    
    .toggle-slider:before {
        position: absolute;
        content: "";
        height: 16px;
        width: 16px;
        left: 3px;
        bottom: 3px;
        background-color: white;
        transition: .3s;
        border-radius: 50%;
    }
    
    input:checked + .toggle-slider {
        background-color: #26de81;
    }
    
    input:checked + .toggle-slider:before {
        transform: translateX(18px);
    }
    
    .action-buttons {
        display: flex;
        gap: 6px;
    }
    
    .btn-action {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 12px;
    }
    
    .btn-action:hover {
        transform: scale(1.1);
    }
    
    .btn-action.edit {
        background: #ffeaa7;
        color: #fdcb6e;
    }
    
    .btn-action.delete {
        background: #ffcccc;
        color: #ee5a6f;
    }
    
    .pagination-wrapper {
        padding: 15px;
        display: flex;
        justify-content: flex-end;
    }

    .empty-state {
        text-align: center;
        padding: 60px 20px;
    }

    .empty-state i {
        font-size: 64px;
        color: #dcdde1;
        margin-bottom: 20px;
    }

    .empty-state h4 {
        color: #7f8c8d;
        font-size: 18px;
        margin-bottom: 10px;
    }

    .empty-state p {
        color: #95a5a6;
        font-size: 14px;
    }
</style>

<!-- Breadcrumb -->
<div class="page-breadcrumb">
    <h1 class="page-title">Why Choose Us</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > <span>Why Choose Us</span>
    </div>
</div>

<!-- Table Controls -->
<div class="table-controls">
    <button onclick="openCreateModal()" class="btn-add-new">
        <i class="fas fa-plus"></i> Add New Feature
    </button>
    
    <div class="table-filters">
        <button class="btn-icon"><i class="fas fa-filter"></i></button>
        <button class="btn-icon red"><i class="fas fa-file-pdf"></i></button>
    </div>
</div>

<!-- Features Table -->
<div class="features-table-card">
    <table class="features-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Icon</th>
                <th>Title</th>
                <th>Description</th>
                <th>Order</th>
                <th>Status</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
            @forelse($features as $index => $feature)
            <tr>
                <td>{{ $features->firstItem() + $index }}</td>
                <td>
                    <i class="{{ $feature->icon }} feature-icon-preview"></i>
                </td>
                <td><strong>{{ $feature->title }}</strong></td>
                <td>{{ Str::limit($feature->description, 60) }}</td>
                <td>
                    <span class="badge-order">#{{ $feature->order }}</span>
                </td>
                <td>
                    <label class="status-toggle">
                        <input type="checkbox" {{ $feature->is_active ? 'checked' : '' }} 
                               onchange="confirmStatusToggle(this, '{{ route('admin.why-choose-us.toggle-status', $feature->id) }}', {{ $feature->is_active ? 'true' : 'false' }})">
                        <span class="toggle-slider"></span>
                    </label>
                </td>
                <td>
                    <div class="action-buttons">
                        <button onclick="openEditModal({{ $feature->id }})" class="btn-action edit" title="Edit">
                            <i class="fas fa-edit"></i>
                        </button>
                        <form action="{{ route('admin.why-choose-us.destroy', $feature->id) }}" 
                              method="POST" 
                              class="d-inline delete-form"
                              id="delete-form-{{ $feature->id }}">
                            @csrf
                            @method('DELETE')
                            <button type="button" 
                                    class="btn-action delete" 
                                    title="Delete"
                                    onclick="confirmDelete('{{ $feature->id }}')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="7">
                    <div class="empty-state">
                        <i class="fas fa-star"></i>
                        <h4>No Features Found</h4>
                        <p>Create your first "Why Choose Us" feature to get started!</p>
                    </div>
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
    
    <!-- Pagination -->
    @if($features->hasPages())
    <div class="pagination-wrapper">
        {{ $features->links() }}
    </div>
    @endif
</div>

@push('scripts')
<script>
// Create Modal
function openCreateModal() {
    Swal.fire({
        title: '<i class="fas fa-star text-primary me-2"></i>Add New Feature',
        html: `
            <form id="createFeatureForm">
                <div class="mb-3 text-start">
                    <label class="form-label">Icon Class * <small class="text-muted">(FontAwesome class)</small></label>
                    <input type="text" class="form-control" name="icon" placeholder="fas fa-sms" required>
                    <small class="text-muted">Example: fas fa-sms, fas fa-map-marker-alt, fas fa-users</small>
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Title *</label>
                    <input type="text" class="form-control" name="title" placeholder="Enter feature title" required>
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Description *</label>
                    <textarea class="form-control" name="description" rows="3" placeholder="Enter feature description" required></textarea>
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Display Order</label>
                    <input type="number" class="form-control" name="order" value="0" min="0">
                    <small class="text-muted">Lower numbers appear first</small>
                </div>
                <div class="mb-3 text-start">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="is_active" checked id="createActive">
                        <label class="form-check-label" for="createActive">Active</label>
                    </div>
                </div>
            </form>
        `,
        width: '600px',
        showCancelButton: true,
        confirmButtonText: '<i class="fas fa-save me-2"></i>Create Feature',
        cancelButtonText: '<i class="fas fa-times me-2"></i>Cancel',
        confirmButtonColor: '#26de81',
        cancelButtonColor: '#7f8c8d',
        preConfirm: () => {
            const form = document.getElementById('createFeatureForm');
            const formData = new FormData(form);
            
            // Handle checkbox
            const isActive = document.getElementById('createActive').checked;
            formData.set('is_active', isActive ? '1' : '0');
            
            // Convert FormData to object
            const data = {};
            formData.forEach((value, key) => data[key] = value);
            
            return data;
        }
    }).then((result) => {
        if (result.isConfirmed) {
            submitCreateForm(result.value);
        }
    });
}

// Submit Create Form
function submitCreateForm(data) {
    Swal.fire({
        title: 'Creating Feature...',
        html: 'Please wait',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    fetch('{{ route('admin.why-choose-us.store') }}', {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: data.message,
                showConfirmButton: false,
                timer: 1500
            }).then(() => {
                window.location.reload();
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: data.message || 'Something went wrong'
            });
        }
    })
    .catch(error => {
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: 'Failed to create feature'
        });
    });
}

// Edit Modal
function openEditModal(featureId) {
    Swal.fire({
        title: 'Loading...',
        text: 'Please wait',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    fetch(`/admin/why-choose-us/${featureId}/edit`)
        .then(response => response.json())
        .then(feature => {
            Swal.fire({
                title: '<i class="fas fa-edit text-warning me-2"></i>Edit Feature',
                html: `
                    <form id="editFeatureForm">
                        <div class="mb-3 text-start">
                            <label class="form-label">Icon Class *</label>
                            <input type="text" class="form-control" name="icon" value="${feature.icon}" placeholder="fas fa-sms" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Title *</label>
                            <input type="text" class="form-control" name="title" value="${feature.title}" required>
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Description *</label>
                            <textarea class="form-control" name="description" rows="3" required>${feature.description}</textarea>
                        </div>
                        <div class="mb-3 text-start">
                            <label class="form-label">Display Order</label>
                            <input type="number" class="form-control" name="order" value="${feature.order}" min="0">
                        </div>
                        <div class="mb-3 text-start">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="is_active" ${feature.is_active ? 'checked' : ''} id="editActive">
                                <label class="form-check-label" for="editActive">Active</label>
                            </div>
                        </div>
                    </form>
                `,
                width: '600px',
                showCancelButton: true,
                confirmButtonText: '<i class="fas fa-save me-2"></i>Update Feature',
                cancelButtonText: '<i class="fas fa-times me-2"></i>Cancel',
                confirmButtonColor: '#fdcb6e',
                cancelButtonColor: '#7f8c8d',
                preConfirm: () => {
                    const form = document.getElementById('editFeatureForm');
                    const formData = new FormData(form);
                    
                    // Handle checkbox
                    const isActive = document.getElementById('editActive').checked;
                    formData.set('is_active', isActive ? '1' : '0');
                    
                    // Convert FormData to object
                    const data = {};
                    formData.forEach((value, key) => data[key] = value);
                    
                    return data;
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    submitEditForm(featureId, result.value);
                }
            });
        })
        .catch(error => {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Failed to load feature data'
            });
        });
}

// Submit Edit Form
function submitEditForm(featureId, data) {
    data._method = 'PUT';
    
    Swal.fire({
        title: 'Updating Feature...',
        html: 'Please wait',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

    fetch(`/admin/why-choose-us/${featureId}`, {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: data.message,
                showConfirmButton: false,
                timer: 1500
            }).then(() => {
                window.location.reload();
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: data.message || 'Something went wrong'
            });
        }
    })
    .catch(error => {
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: 'Failed to update feature'
        });
    });
}

// Status Toggle
function confirmStatusToggle(checkbox, url, currentStatus) {
    const newStatus = !currentStatus;
    const statusText = newStatus ? 'activate' : 'deactivate';
    
    Swal.fire({
        title: 'Change Feature Status?',
        html: `Are you sure you want to <strong>${statusText}</strong> this feature?`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: newStatus ? '#26de81' : '#ee5a6f',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: `Yes, ${statusText}!`,
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            showLoading('Updating status...');
            window.location.href = url;
        } else {
            checkbox.checked = currentStatus;
        }
    });
}

// Delete Confirmation
function confirmDelete(featureId) {
    Swal.fire({
        title: 'Delete Feature?',
        text: 'This action cannot be undone!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ee5a6f',
        cancelButtonColor: '#7f8c8d',
        confirmButtonText: '<i class="fas fa-trash me-2"></i>Yes, delete it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('delete-form-' + featureId).submit();
        }
    });
}

function showLoading(message) {
    Swal.fire({
        title: message,
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
}
</script>
@endpush

@endsection

