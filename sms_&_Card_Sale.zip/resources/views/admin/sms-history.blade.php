@extends('admin.layouts.app')

@section('title', 'SMS History')

@section('content')
<style>
    body {
        background: #f5f6fa;
    }
    
    .page-breadcrumb {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .page-title {
        font-size: 18px;
        font-weight: 600;
        color: #2c3e50;
        margin: 0;
    }
    
    .breadcrumb-nav {
        font-size: 12px;
        color: #7f8c8d;
    }
    
    .breadcrumb-nav a {
        color: #7f8c8d;
        text-decoration: none;
    }
    
    .stats-mini {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 15px;
        margin-bottom: 20px;
    }
    
    .stat-mini {
        background: white;
        border-radius: 8px;
        padding: 20px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        display: flex;
        align-items: center;
        gap: 15px;
        position: relative;
        overflow: hidden;
    }
    
    .stat-mini::before {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        width: 100px;
        height: 100px;
        border-radius: 50%;
        opacity: 0.1;
    }
    
    .stat-mini.stat-sent::before {
        background: #26de81;
    }
    
    .stat-mini.stat-pending::before {
        background: #ffc107;
    }
    
    .stat-mini.stat-failed::before {
        background: #ee5a6f;
    }
    
    .stat-mini.stat-total::before {
        background: #3498db;
    }
    
    .stat-mini-icon {
        width: 50px;
        height: 50px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        color: white;
        flex-shrink: 0;
    }
    
    .stat-mini-content {
        flex: 1;
        z-index: 1;
    }
    
    .stat-mini-label {
        font-size: 12px;
        color: #7f8c8d;
        margin-bottom: 4px;
        font-weight: 500;
    }
    
    .stat-mini-value {
        font-size: 24px;
        font-weight: 700;
        color: #2c3e50;
    }
    
    .table-controls {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
    }
    
    .filter-select {
        padding: 6px 12px;
        border: 1px solid #dcdde1;
        border-radius: 4px;
        font-size: 12px;
        color: #7f8c8d;
        background: white;
    }
    
    .sms-table-card {
        background: white;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    
    .sms-table {
        width: 100%;
        border-collapse: collapse;
    }
    
    .sms-table thead th {
        background: #f8f9fa;
        padding: 12px 16px;
        text-align: left;
        font-size: 12px;
        font-weight: 600;
        color: #7f8c8d;
        border-bottom: 1px solid #ecf0f1;
    }
    
    .sms-table tbody td {
        padding: 14px 16px;
        font-size: 13px;
        color: #2c3e50;
        border-bottom: 1px solid #f1f2f6;
        vertical-align: middle;
    }
    
    .sms-table tbody tr:hover {
        background: #fafbfc;
    }
    
    .user-avatar {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        object-fit: cover;
    }
    
    .badge-status {
        padding: 4px 10px;
        border-radius: 4px;
        font-size: 11px;
        font-weight: 500;
        display: inline-block;
    }
    
    .badge-status.sent {
        background: #26de81;
        color: white;
    }
    
    .badge-status.pending {
        background: #ffc107;
        color: white;
    }
    
    .badge-status.failed {
        background: #ee5a6f;
        color: white;
    }
    
    .message-preview {
        max-width: 250px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    
    @media (max-width: 1200px) {
        .stats-mini {
            grid-template-columns: repeat(2, 1fr);
        }
    }
    
    @media (max-width: 768px) {
        .stats-mini {
            grid-template-columns: 1fr;
        }
    }
</style>

<!-- Breadcrumb -->
<div class="page-breadcrumb">
    <h1 class="page-title">SMS History</h1>
    <div class="breadcrumb-nav">
        <a href="{{ route('admin.dashboard') }}">Home</a> > <span>SMS History</span>
    </div>
</div>

<!-- Mini Stats -->
<div class="stats-mini">
    <div class="stat-mini stat-sent">
        <div class="stat-mini-icon" style="background: linear-gradient(135deg, #26de81 0%, #20bf6b 100%);">
            <i class="fas fa-check"></i>
        </div>
        <div class="stat-mini-content">
            <div class="stat-mini-label">SENT SMS</div>
            <div class="stat-mini-value">{{ $stats['sent'] }}</div>
        </div>
    </div>
    
    <div class="stat-mini stat-pending">
        <div class="stat-mini-icon" style="background: linear-gradient(135deg, #ffc107 0%, #f39c12 100%);">
            <i class="fas fa-clock"></i>
        </div>
        <div class="stat-mini-content">
            <div class="stat-mini-label">PENDING SMS</div>
            <div class="stat-mini-value">{{ $stats['pending'] }}</div>
        </div>
    </div>
    
    <div class="stat-mini stat-failed">
        <div class="stat-mini-icon" style="background: linear-gradient(135deg, #ee5a6f 0%, #d63447 100%);">
            <i class="fas fa-times"></i>
        </div>
        <div class="stat-mini-content">
            <div class="stat-mini-label">FAILED SMS</div>
            <div class="stat-mini-value">{{ $stats['failed'] }}</div>
        </div>
    </div>
    
    <div class="stat-mini stat-total">
        <div class="stat-mini-icon" style="background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);">
            <i class="fas fa-envelope"></i>
        </div>
        <div class="stat-mini-content">
            <div class="stat-mini-label">TOTAL SMS</div>
            <div class="stat-mini-value">{{ $stats['total'] }}</div>
        </div>
    </div>
</div>

<!-- Table Controls -->
<div class="table-controls">
    <div></div>
    <select class="filter-select" onchange="window.location.href='{{ route('admin.sms-history') }}?status=' + this.value">
        <option value="" {{ request('status') == '' ? 'selected' : '' }}>All Status</option>
        <option value="sent" {{ request('status') == 'sent' ? 'selected' : '' }}>Sent</option>
        <option value="pending" {{ request('status') == 'pending' ? 'selected' : '' }}>Pending</option>
        <option value="failed" {{ request('status') == 'failed' ? 'selected' : '' }}>Failed</option>
    </select>
</div>

<!-- SMS Table -->
<div class="sms-table-card">
    
    <table class="sms-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>User</th>
                <th>Recipient</th>
                <th>Gateway</th>
                <th>Message</th>
                <th>Cost</th>
                <th>Status</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            @forelse($smsHistory as $sms)
            <tr>
                <td><strong>#{{ $sms->id }}</strong></td>
                <td>
                    <div class="d-flex align-items-center" style="gap: 8px;">
                        <img src="https://ui-avatars.com/api/?name={{ urlencode($sms->user->name) }}&background=3498db&color=fff&size=32" 
                             class="user-avatar" 
                             alt="{{ $sms->user->name }}">
                        <div>
                            <div style="font-weight: 500; font-size: 13px;">{{ $sms->user->name }}</div>
                            <div style="font-size: 11px; color: #7f8c8d;">{{ Str::limit($sms->user->email, 20) }}</div>
                        </div>
                    </div>
                </td>
                <td>
                    <i class="fas fa-phone" style="font-size: 10px; color: #26de81;"></i>
                    {{ $sms->recipient }}
                </td>
                <td>
                    @if($sms->smsGateway)
                        <span class="badge" style="background: #667eea; color: white; padding: 4px 10px; border-radius: 4px; font-size: 11px;">
                            <i class="fas fa-server" style="font-size: 9px;"></i> {{ $sms->smsGateway->gateway_name }}
                        </span>
                    @else
                        <span style="font-size: 11px; color: #95a5a6;">-</span>
                    @endif
                </td>
                <td>
                    <div class="message-preview" title="{{ $sms->message }}">
                        {{ $sms->message }}
                    </div>
                </td>
                <td>
                    <span style="font-size: 12px; color: #e67e22; font-weight: 500;">৳{{ number_format($sms->cost, 2) }}</span>
                    @if($sms->sms_count > 1)
                        <div style="font-size: 10px; color: #7f8c8d;">{{ $sms->sms_count }} parts</div>
                    @endif
                </td>
                <td>
                    <span class="badge-status {{ $sms->status }}">
                        {{ ucfirst($sms->status) }}
                    </span>
                </td>
                <td>
                    <div style="font-size: 12px;">{{ $sms->created_at->format('M d, Y') }}</div>
                    <div style="font-size: 11px; color: #7f8c8d;">{{ $sms->created_at->format('h:i A') }}</div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="8" class="text-center py-5">
                    <i class="fas fa-inbox fa-3x text-muted mb-3" style="display: block; margin-bottom: 15px;"></i>
                    <p class="text-muted">No SMS history found</p>
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
    
    <!-- Pagination -->
    @if($smsHistory->hasPages())
    <div style="padding: 15px; border-top: 1px solid #f1f2f6;">
        {{ $smsHistory->links() }}
    </div>
    @endif
</div>
@endsection
