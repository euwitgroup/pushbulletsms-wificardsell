@extends('admin.layouts.app')

@section('title', 'Dashboard')

@section('content')
<style>
    /* Stat Cards */
    .stat-cards {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 12px;
        padding: 24px;
        color: #fff;
        position: relative;
        overflow: hidden;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    
    .stat-card.orange {
        background: linear-gradient(135deg, #fa8c79 0%, #ff6b6b 100%);
    }
    
    .stat-card.green {
        background: linear-gradient(135deg, #56ccf2 0%, #2f80ed 100%);
    }
    
    .stat-card.pink {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    }
    
    .stat-card.cyan {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
    }
    
    .stat-card::before {
        content: '';
        position: absolute;
        top: -50px;
        right: -50px;
        width: 200px;
        height: 200px;
        background: rgba(255,255,255,0.1);
        border-radius: 50%;
    }
    
    .stat-label {
        font-size: 13px;
        font-weight: 500;
        opacity: 0.9;
        margin-bottom: 8px;
    }
    
    .stat-value {
        font-size: 32px;
        font-weight: 700;
        margin-bottom: 12px;
        position: relative;
        z-index: 1;
    }
    
    .stat-chart {
        position: absolute;
        right: 24px;
        top: 24px;
        opacity: 0.3;
    }
    
    .stat-footer {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 12px;
        opacity: 0.9;
        position: relative;
        z-index: 1;
    }
    
    .stat-footer i {
        font-size: 11px;
    }
    
    /* Charts and Cards */
    .chart-card {
        background: #fff;
        border-radius: 12px;
        padding: 24px;
        margin-bottom: 20px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    
    .card-header-custom {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .card-title {
        font-size: 16px;
        font-weight: 700;
        color: #212529;
    }
    
    .card-subtitle {
        font-size: 13px;
        color: #6c757d;
        margin-top: 4px;
    }
    
    .card-actions {
        display: flex;
        gap: 8px;
    }
    
    .card-action-btn {
        width: 32px;
        height: 32px;
        border-radius: 8px;
        border: 1px solid #e0e0e0;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        color: #6c757d;
        transition: all 0.2s ease;
    }
    
    .card-action-btn:hover {
        background: #f8f9fa;
        color: #667eea;
        border-color: #667eea;
    }
    
    /* Table */
    .custom-table {
        width: 100%;
        font-size: 13px;
    }
    
    .custom-table thead th {
        font-weight: 600;
        color: #6c757d;
        text-transform: uppercase;
        font-size: 11px;
        letter-spacing: 0.5px;
        padding: 12px 16px;
        border-bottom: 2px solid #e9ecef;
    }
    
    .custom-table tbody td {
        padding: 14px 16px;
        vertical-align: middle;
        border-bottom: 1px solid #f1f3f5;
    }
    
    .custom-table tbody tr:hover {
        background: #f8f9fa;
    }
    
    .app-icon {
        width: 40px;
        height: 40px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        margin-right: 12px;
    }
    
    .app-name {
        font-weight: 600;
        color: #212529;
        font-size: 14px;
    }
    
    .app-desc {
        font-size: 12px;
        color: #6c757d;
    }
    
    .mini-chart {
        width: 80px;
        height: 30px;
    }
    
    .price-tag {
        font-weight: 600;
        color: #667eea;
        font-size: 14px;
    }
    
    .view-all-link {
        color: #667eea;
        text-decoration: none;
        font-weight: 600;
        font-size: 13px;
        display: inline-flex;
        align-items: center;
        gap: 4px;
        margin-top: 12px;
    }
    
    .view-all-link:hover {
        color: #764ba2;
    }
    
    /* User Activity */
    .activity-item {
        display: flex;
        gap: 12px;
        padding: 12px 0;
        border-bottom: 1px solid #f1f3f5;
    }
    
    .activity-item:last-child {
        border-bottom: none;
    }
    
    .activity-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        object-fit: cover;
    }
    
    .activity-content {
        flex: 1;
    }
    
    .activity-user {
        font-weight: 600;
        color: #212529;
        font-size: 13px;
    }
    
    .activity-text {
        font-size: 12px;
        color: #6c757d;
        margin-top: 2px;
    }
    
    .activity-time {
        font-size: 11px;
        color: #adb5bd;
        margin-top: 4px;
        display: flex;
        align-items: center;
        gap: 4px;
    }
    
    /* Project Risk */
    .project-risk-card {
        background: #fff;
        border-radius: 12px;
        padding: 24px;
        text-align: center;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        margin-bottom: 20px;
    }
    
    .risk-title {
        font-size: 14px;
        font-weight: 700;
        color: #212529;
        margin-bottom: 8px;
    }
    
    .risk-chart-wrapper {
        position: relative;
        width: 160px;
        height: 160px;
        margin: 20px auto;
    }
    
    .risk-status {
        font-size: 16px;
        font-weight: 700;
        color: #212529;
        margin-top: 12px;
    }
    
    .risk-change {
        font-size: 12px;
        color: #fa8c79;
        margin-top: 4px;
    }
    
    .risk-stats {
        display: flex;
        justify-content: space-around;
        margin-top: 20px;
        padding-top: 20px;
        border-top: 1px solid #f1f3f5;
    }
    
    .risk-stat-item {
        text-align: center;
    }
    
    .risk-stat-label {
        font-size: 11px;
        color: #6c757d;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .risk-stat-value {
        font-size: 18px;
        font-weight: 700;
        color: #212529;
        margin-top: 4px;
    }
    
    .download-report-btn {
        width: 100%;
        padding: 12px;
        background: linear-gradient(135deg, #fa8c79 0%, #ff6b6b 100%);
        color: #fff;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        font-size: 13px;
        cursor: pointer;
        margin-top: 20px;
        transition: all 0.2s ease;
    }
    
    .download-report-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(250, 140, 121, 0.4);
    }
</style>

<!-- Stat Cards -->
<div class="stat-cards">
    <div class="stat-card orange">
        <div class="stat-label">Total Revenue</div>
        <div class="stat-value">৳{{ number_format($stats['total_revenue'], 2) }}</div>
        <div class="stat-chart">
            <i class="fas fa-dollar-sign" style="font-size: 48px;"></i>
        </div>
        <div class="stat-footer">
            <i class="far fa-clock"></i>
            <span>Today: ৳{{ number_format($stats['today_revenue'], 2) }}</span>
        </div>
    </div>
    
    <div class="stat-card green">
        <div class="stat-label">SMS Sent</div>
        <div class="stat-value">{{ number_format($stats['total_sms_sent']) }}</div>
        <div class="stat-chart">
            <i class="fas fa-sms" style="font-size: 48px;"></i>
        </div>
        <div class="stat-footer">
            <i class="far fa-clock"></i>
            <span>Today: {{ number_format($stats['today_sms']) }}</span>
        </div>
    </div>
    
    <div class="stat-card pink">
        <div class="stat-label">Active Users</div>
        <div class="stat-value">{{ number_format($stats['active_users']) }}</div>
        <div class="stat-chart">
            <i class="fas fa-users" style="font-size: 48px;"></i>
        </div>
        <div class="stat-footer">
            <i class="fas fa-user-check"></i>
            <span>Total: {{ number_format($stats['total_users']) }}</span>
        </div>
    </div>
    
    <div class="stat-card cyan">
        <div class="stat-label">Pending SMS</div>
        <div class="stat-value">{{ number_format($stats['total_sms_pending']) }}</div>
        <div class="stat-chart">
            <i class="fas fa-clock" style="font-size: 48px;"></i>
        </div>
        <div class="stat-footer">
            <i class="fas fa-times-circle"></i>
            <span>Failed: {{ number_format($stats['total_sms_failed']) }}</span>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <!-- SMS Analytics Chart -->
        <div class="chart-card">
            <div class="card-header-custom">
                <div>
                    <h3 class="card-title">SMS Analytics</h3>
                    <p class="card-subtitle">Monthly SMS sending statistics for the last 12 months</p>
                </div>
                <div class="card-actions">
                    <button class="card-action-btn"><i class="fas fa-star"></i></button>
                    <button class="card-action-btn"><i class="fas fa-ellipsis-v"></i></button>
                    <button class="card-action-btn"><i class="fas fa-times"></i></button>
                </div>
            </div>
            <div style="position: relative; height: 300px;">
                <canvas id="salesChart"></canvas>
            </div>
        </div>
        
        <!-- Recent Transactions Table -->
        <div class="chart-card">
            <div class="card-header-custom">
                <div>
                    <h3 class="card-title">Recent Transactions</h3>
                </div>
                <div class="card-actions">
                    <button class="card-action-btn"><i class="fas fa-sync-alt"></i></button>
                    <button class="card-action-btn"><i class="fas fa-ellipsis-v"></i></button>
                    <button class="card-action-btn"><i class="fas fa-times"></i></button>
                </div>
            </div>
            
            <table class="custom-table">
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Transaction ID</th>
                        <th>Type</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($recent_transactions as $index => $transaction)
                    <tr>
                        <td>
                            <div class="d-flex align-items-center">
                                @php
                                    $colors = ['#667eea', '#fa8c79', '#4facfe', '#56ccf2', '#f093fb'];
                                    $color = $colors[$index % 5];
                                @endphp
                                <div class="app-icon" style="background: {{ $color }}; color: #fff;">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div>
                                    <div class="app-name">{{ $transaction->user->name }}</div>
                                    <div class="app-desc">{{ $transaction->user->email }}</div>
                                </div>
                            </div>
                        </td>
                        <td><small>{{ $transaction->transaction_id }}</small></td>
                        <td>
                            <span class="badge bg-{{ $transaction->type == 'credit' ? 'success' : 'danger' }}">
                                {{ ucfirst($transaction->type) }}
                            </span>
                        </td>
                        <td class="price-tag">৳{{ number_format($transaction->amount, 2) }}</td>
                        <td>
                            <span class="badge bg-{{ $transaction->status == 'completed' ? 'success' : 'warning' }}">
                                {{ ucfirst($transaction->status) }}
                            </span>
                        </td>
                        <td><small>{{ $transaction->created_at->format('M d, h:i A') }}</small></td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">No transactions found</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
            
            <a href="{{ route('admin.transactions') }}" class="view-all-link">
                View all Transactions <i class="fas fa-arrow-right"></i>
            </a>
        </div>
    </div>
    
    <div class="col-lg-4">
        <!-- SMS Status Overview -->
        <div class="project-risk-card">
            <h3 class="risk-title">SMS Status Overview</h3>
            
            <div class="risk-chart-wrapper">
                <canvas id="riskChart"></canvas>
            </div>
            
            @php
                $total_sms = $stats['total_sms_sent'] + $stats['total_sms_failed'] + $stats['total_sms_pending'];
                $success_rate = $total_sms > 0 ? round(($stats['total_sms_sent'] / $total_sms) * 100) : 0;
            @endphp
            
            <div class="risk-status">{{ $success_rate }}% Success Rate</div>
            <div class="risk-change">SMS Delivery Performance</div>
            
            <div class="risk-stats">
                <div class="risk-stat-item">
                    <div class="risk-stat-label">Sent</div>
                    <div class="risk-stat-value">{{ number_format($stats['total_sms_sent']) }}</div>
                </div>
                <div class="risk-stat-item">
                    <div class="risk-stat-label">Failed</div>
                    <div class="risk-stat-value">{{ number_format($stats['total_sms_failed']) }}</div>
                </div>
            </div>
            
            <a href="{{ route('admin.sms-history') }}" class="download-report-btn" style="text-decoration: none;">
                View SMS History
            </a>
        </div>
        
        <!-- Recent SMS Activity -->
        <div class="chart-card">
            <div class="card-header-custom">
                <div>
                    <h3 class="card-title">Recent SMS Activity</h3>
                </div>
                <div class="card-actions">
                    <button class="card-action-btn"><i class="fas fa-ellipsis-v"></i></button>
                </div>
            </div>
            
            <div class="activity-list">
                @forelse($recent_sms->take(5) as $index => $sms)
                    @php
                        $colors = ['667eea', 'fa8c79', '4facfe', '56ccf2', 'f093fb'];
                        $bg = $colors[$index % 5];
                    @endphp
                    <div class="activity-item">
                        <img src="https://ui-avatars.com/api/?name={{ urlencode($sms->user->name) }}&background={{ $bg }}&color=fff" class="activity-avatar">
                        <div class="activity-content">
                            <div class="activity-user">{{ $sms->user->name }}</div>
                            <div class="activity-text">{{ Str::limit($sms->message, 40) }}</div>
                            <div class="activity-time">
                                <i class="far fa-clock"></i> {{ $sms->created_at->diffForHumans() }}
                                <span class="badge bg-{{ $sms->status == 'sent' ? 'success' : ($sms->status == 'failed' ? 'danger' : 'warning') }} ms-2" style="font-size: 9px;">
                                    {{ ucfirst($sms->status) }}
                                </span>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-inbox fa-3x mb-3"></i>
                        <p>No SMS activity yet</p>
                    </div>
                @endforelse
            </div>
            
            <a href="{{ route('admin.sms-history') }}" class="view-all-link">
                View all SMS History <i class="fas fa-arrow-right"></i>
            </a>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
// SMS Analytics Chart
const salesCtx = document.getElementById('salesChart');
if (salesCtx) {
    @php
        $monthly_labels = $monthly_sms->pluck('month')->toArray();
        $monthly_counts = $monthly_sms->pluck('count')->toArray();
    @endphp
    
    new Chart(salesCtx, {
        type: 'line',
        data: {
            labels: @json($monthly_labels),
            datasets: [{
                label: 'SMS Sent',
                data: @json($monthly_counts),
                borderColor: '#667eea',
                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                tension: 0.4,
                fill: true,
                pointRadius: 4,
                pointHoverRadius: 6,
                pointBackgroundColor: '#667eea'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    backgroundColor: '#1a1d2e',
                    titleColor: '#fff',
                    bodyColor: '#fff',
                    padding: 12,
                    cornerRadius: 8
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: '#f1f3f5'
                    },
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString();
                        }
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
}

// SMS Status Doughnut Chart
const riskCtx = document.getElementById('riskChart');
if (riskCtx) {
    const sentSms = {{ $stats['total_sms_sent'] }};
    const failedSms = {{ $stats['total_sms_failed'] }};
    const pendingSms = {{ $stats['total_sms_pending'] }};
    
    new Chart(riskCtx, {
        type: 'doughnut',
        data: {
            labels: ['Sent', 'Failed', 'Pending'],
            datasets: [{
                data: [sentSms, failedSms, pendingSms],
                backgroundColor: ['#38ef7d', '#fa8c79', '#ffc107'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            cutout: '75%',
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    enabled: true,
                    backgroundColor: '#1a1d2e',
                    titleColor: '#fff',
                    bodyColor: '#fff',
                    padding: 12,
                    cornerRadius: 8,
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + context.parsed.toLocaleString();
                        }
                    }
                }
            }
        }
    });
}
</script>
@endpush
