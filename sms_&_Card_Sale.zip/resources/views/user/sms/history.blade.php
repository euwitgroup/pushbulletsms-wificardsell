@extends('layouts.app')

@section('title', 'SMS History')

@section('content')
<div class="mb-2 d-flex justify-content-between align-items-center">
    <div>
        <h5 class="mb-1"><i class="fas fa-history me-1"></i>SMS History</h5>
        <p class="text-muted small mb-0">View all your sent SMS messages</p>
    </div>
    <a href="{{ route('user.sms.create') }}" class="btn btn-primary btn-sm">
        <i class="fas fa-paper-plane me-1"></i>Send New SMS
    </a>
</div>

<div class="card border shadow-sm" style="border-radius: 5px;">
    <div class="card-body p-2">
        <div class="table-responsive">
            <table class="table table-hover table-sm mb-0">
                <thead>
                    <tr>
                        <th class="small">#</th>
                        <th class="small">Phone</th>
                        <th class="small">Message</th>
                        <th class="small">Gateway</th>
                        <th class="small">Parts</th>
                        <th class="small">Status</th>
                        <th class="small">Cost</th>
                        <th class="small">Date</th>
                        <th class="small">Action</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($smsHistory as $sms)
                    <tr style="font-size: 0.85rem;">
                        <td>{{ $sms->id }}</td>
                        <td>
                            <i class="fas fa-phone me-1"></i>
                            {{ $sms->phone_number }}
                        </td>
                        <td>
                            <div class="text-truncate" style="max-width: 200px;" title="{{ $sms->message }}">
                                {{ $sms->message }}
                            </div>
                        </td>
                        <td>
                            @if($sms->smsGateway)
                                <span class="badge bg-secondary" style="font-size: 0.7rem; border-radius: 5px;">{{ $sms->smsGateway->gateway_name }}</span>
                            @else
                                <span class="text-muted">-</span>
                            @endif
                        </td>
                        <td>{{ $sms->sms_count ?? 1 }}</td>
                        <td>
                            <span class="badge badge-status-{{ $sms->status }}" style="font-size: 0.7rem; border-radius: 5px;">
                                @if($sms->status == 'sent')
                                    <i class="fas fa-check-circle me-1"></i>
                                @elseif($sms->status == 'failed')
                                    <i class="fas fa-times-circle me-1"></i>
                                @else
                                    <i class="fas fa-clock me-1"></i>
                                @endif
                                {{ ucfirst($sms->status) }}
                            </span>
                        </td>
                        <td>৳{{ number_format($sms->cost, 2) }}</td>
                        <td>
                            <small style="font-size: 0.75rem;">{{ $sms->created_at->format('M d, Y') }}</small><br>
                            <small class="text-muted" style="font-size: 0.7rem;">{{ $sms->created_at->format('h:i A') }}</small>
                        </td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary py-0 px-1" 
                                    style="font-size: 0.75rem; border-radius: 5px;"
                                    onclick="showDetails({{ json_encode($sms) }})">
                                <i class="fas fa-eye"></i>
                            </button>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="9" class="text-center py-4">
                            <i class="fas fa-inbox fa-2x text-muted mb-2 d-block"></i>
                            <p class="text-muted mb-2">No SMS history found</p>
                            <a href="{{ route('user.sms.create') }}" class="btn btn-primary btn-sm">Send Your First SMS</a>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if($smsHistory->hasPages())
        <div class="mt-2">
            {{ $smsHistory->links() }}
        </div>
        @endif
    </div>
</div>

<!-- SMS Details Modal -->
<div class="modal fade" id="smsDetailsModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content" style="border-radius: 5px;">
            <div class="modal-header py-2">
                <h6 class="modal-title mb-0"><i class="fas fa-sms me-1"></i>SMS Details</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-2">
                <div class="mb-2">
                    <strong class="small">Phone Number:</strong>
                    <div id="detailPhone" class="small"></div>
                </div>
                <div class="mb-2">
                    <strong class="small">Message:</strong>
                    <div id="detailMessage" class="p-2 bg-light small" style="border-radius: 5px;"></div>
                </div>
                <div class="mb-2">
                    <strong class="small">Status:</strong>
                    <div id="detailStatus"></div>
                </div>
                <div class="mb-2">
                    <strong class="small">Cost:</strong>
                    <div id="detailCost" class="small"></div>
                </div>
                <div class="mb-2">
                    <strong class="small">Sent Date:</strong>
                    <div id="detailDate" class="small"></div>
                </div>
                <div class="mb-2" id="detailErrorContainer" style="display: none;">
                    <strong class="small">Error Message:</strong>
                    <div id="detailError" class="text-danger small"></div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
function showDetails(sms) {
    document.getElementById('detailPhone').textContent = sms.phone_number;
    document.getElementById('detailMessage').textContent = sms.message;
    document.getElementById('detailStatus').innerHTML = `<span class="badge badge-status-${sms.status}" style="font-size: 0.75rem; border-radius: 5px;">${sms.status.charAt(0).toUpperCase() + sms.status.slice(1)}</span>`;
    document.getElementById('detailCost').textContent = '৳' + parseFloat(sms.cost).toFixed(2);
    document.getElementById('detailDate').textContent = new Date(sms.created_at).toLocaleString();
    
    if (sms.error_message) {
        document.getElementById('detailErrorContainer').style.display = 'block';
        document.getElementById('detailError').textContent = sms.error_message;
    } else {
        document.getElementById('detailErrorContainer').style.display = 'none';
    }
    
    new bootstrap.Modal(document.getElementById('smsDetailsModal')).show();
}
</script>
@endpush
