@extends('layouts.app')

@section('title', 'Send SMS')

@section('content')
<div class="mb-2">
    <h5 class="mb-1"><i class="fas fa-paper-plane me-1"></i>Send SMS</h5>
    <p class="text-muted small mb-0">Send single or bulk SMS messages</p>
</div>

<div class="row g-2">
    <div class="col-lg-8">
        <div class="card border shadow-sm" style="border-radius: 5px;">
            <div class="card-body p-2">
                <!-- Tabs -->
                <ul class="nav nav-tabs nav-tabs-sm mb-2" id="smsTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active small" id="single-tab" data-bs-toggle="tab" data-bs-target="#single" type="button" role="tab">
                            <i class="fas fa-mobile-alt me-1"></i>Single SMS
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link small" id="bulk-tab" data-bs-toggle="tab" data-bs-target="#bulk" type="button" role="tab">
                            <i class="fas fa-users me-1"></i>Bulk SMS
                        </button>
                    </li>
                </ul>

                <div class="tab-content" id="smsTabContent">
                    <!-- Single SMS Tab -->
                    <div class="tab-pane fade show active" id="single" role="tabpanel">
                        <form action="{{ route('user.sms.store') }}" method="POST" id="singleSmsForm">
                    @csrf
                            <input type="hidden" name="type" value="single">

                            @if(auth()->user()->isKycVerified())
                                <!-- Sender ID Selection -->
                                <div class="mb-2">
                                    <label class="form-label small fw-semibold mb-1">Sender ID <span class="text-danger">*</span></label>
                                    <select name="sender_id" id="senderIdSelect" class="form-select form-select-sm @error('sender_id') is-invalid @enderror" required>
                                        <option value="">Select Sender ID</option>
                                        @foreach($gateways as $gateway)
                                            <option value="{{ $gateway->id }}" 
                                                    data-gateway="{{ $gateway->gateway_name }}" 
                                                    data-sender="{{ $gateway->sender_id }}"
                                                    data-device="{{ $gateway->device_name }}"
                                                    data-cost="{{ $gateway->cost_per_sms }}">
                                                {{ $gateway->gateway_name }} 
                                                @if($gateway->gateway_name == 'bulksmsbd')
                                                    - {{ $gateway->sender_id }}
                                                @else
                                                    - {{ $gateway->device_name ?? 'Device' }}
                                                @endif
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('sender_id')
                                        <div class="invalid-feedback small">{{ $message }}</div>
                                    @enderror
                                </div>

                                <!-- Selected Sender Display -->
                                <div id="senderIdDisplay" class="alert alert-info py-1 px-2 mb-2 small" style="display: none; border-radius: 5px;">
                                    <i class="fas fa-id-card me-1"></i><strong>Selected:</strong> <span id="selectedSenderText"></span>
                                </div>
                            @else
                                <!-- KYC Required Message -->
                                <div class="alert alert-warning py-2 px-2 mb-2" style="border-radius: 5px;">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-exclamation-triangle me-2"></i>
                                        <div class="flex-grow-1">
                                            <strong class="small">KYC Verification Required</strong>
                                            <p class="mb-0" style="font-size: 0.7rem;">You need to complete KYC verification to use custom sender IDs.</p>
                                        </div>
                                        <a href="{{ route('user.profile') }}#kyc" class="btn btn-warning btn-sm" style="font-size: 0.75rem; border-radius: 5px;">
                                            Verify Now
                                        </a>
                                    </div>
                                </div>
                            @endif

                            <!-- Phone Number -->
                            <div class="mb-2">
                                <label class="form-label small fw-semibold mb-1">Phone Number <span class="text-danger">*</span></label>
                        <input type="text" 
                               name="phone_number" 
                                       id="phoneNumber"
                                       class="form-control form-control-sm @error('phone_number') is-invalid @enderror" 
                               placeholder="+8801712345678"
                               value="{{ old('phone_number') }}"
                               required>
                                <small class="text-muted" style="font-size: 0.7rem;">Include country code</small>
                        @error('phone_number')
                                    <div class="invalid-feedback small">{{ $message }}</div>
                        @enderror
                    </div>

                            <!-- Message -->
                            <div class="mb-2">
                                <label class="form-label small fw-semibold mb-1">Message <span class="text-danger">*</span></label>
                        <textarea name="message" 
                                          id="smsMessage"
                                          class="form-control form-control-sm @error('message') is-invalid @enderror" 
                                          rows="4" 
                                  placeholder="Type your message here..."
                                  required>{{ old('message') }}</textarea>
                                
                                <!-- SMS Info -->
                                <div class="mt-2">
                                    <div class="row g-1">
                                        <div class="col-3">
                                            <div class="stat-box">
                                                <div class="stat-label">Chars</div>
                                                <div class="stat-value"><span id="charCount">0</span></div>
                                            </div>
                                        </div>
                                        <div class="col-3">
                                            <div class="stat-box">
                                                <div class="stat-label">Type</div>
                                                <div class="stat-value"><span id="encodingType">EN</span></div>
                                            </div>
                                        </div>
                                        <div class="col-3">
                                            <div class="stat-box">
                                                <div class="stat-label">SMS</div>
                                                <div class="stat-value"><span id="smsCount">0</span></div>
                                            </div>
                                        </div>
                                        <div class="col-3">
                                            <div class="stat-box stat-box-primary">
                                                <div class="stat-label">Cost</div>
                                                <div class="stat-value">৳<span id="totalCost">0</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="mt-1">
                                    <small class="text-muted" style="font-size: 0.7rem;">
                                        <i class="fas fa-info-circle me-1"></i>English: 160 chars | Bangla: 70 chars
                                    </small>
                        </div>

                        @error('message')
                                    <div class="invalid-feedback small">{{ $message }}</div>
                        @enderror
                    </div>

                            <!-- Buttons -->
                            <div class="d-flex gap-1 mt-2">
                                <button type="submit" class="btn btn-primary btn-sm" {{ !auth()->user()->isKycVerified() ? 'disabled' : '' }}>
                                    <i class="fas fa-paper-plane me-1"></i>Send SMS
                                </button>
                                <a href="{{ route('user.dashboard') }}" class="btn btn-outline-secondary btn-sm">
                                    <i class="fas fa-times me-1"></i>Cancel
                                </a>
                            </div>
                        </form>
                    </div>

                    <!-- Bulk SMS Tab -->
                    <div class="tab-pane fade" id="bulk" role="tabpanel">
                        <form action="{{ route('user.sms.bulk') }}" method="POST" enctype="multipart/form-data" id="bulkSmsForm">
                            @csrf
                            <input type="hidden" name="type" value="bulk">

                            @if(auth()->user()->isKycVerified())
                                <!-- Sender ID -->
                                <div class="mb-2">
                                    <label class="form-label small fw-semibold mb-1">Sender ID <span class="text-danger">*</span></label>
                                    <select name="sender_id" id="bulkSenderIdSelect" class="form-select form-select-sm" required>
                                        <option value="">Select Sender ID</option>
                                        @foreach($gateways as $gateway)
                                            <option value="{{ $gateway->id }}" 
                                                    data-gateway="{{ $gateway->gateway_name }}" 
                                                    data-sender="{{ $gateway->sender_id }}"
                                                    data-device="{{ $gateway->device_name }}"
                                                    data-cost="{{ $gateway->cost_per_sms }}">
                                                {{ $gateway->gateway_name }} 
                                                @if($gateway->gateway_name == 'bulksmsbd')
                                                    - {{ $gateway->sender_id }}
                                                @else
                                                    - {{ $gateway->device_name ?? 'Device' }}
                                                @endif
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <!-- Selected Sender Display -->
                                <div id="bulkSenderIdDisplay" class="alert alert-info py-1 px-2 mb-2 small" style="display: none; border-radius: 5px;">
                                    <i class="fas fa-id-card me-1"></i><strong>Selected:</strong> <span id="bulkSelectedSenderText"></span>
                                </div>
                            @else
                                <!-- KYC Required Message -->
                                <div class="alert alert-warning py-2 px-2 mb-2" style="border-radius: 5px;">
                                    <div class="d-flex align-items-center">
                                        <i class="fas fa-exclamation-triangle me-2"></i>
                                        <div class="flex-grow-1">
                                            <strong class="small">KYC Verification Required</strong>
                                            <p class="mb-0" style="font-size: 0.7rem;">You need to complete KYC verification to use custom sender IDs for bulk SMS.</p>
                                        </div>
                                        <a href="{{ route('user.profile') }}#kyc" class="btn btn-warning btn-sm" style="font-size: 0.75rem; border-radius: 5px;">
                                            Verify Now
                                        </a>
                                    </div>
                                </div>
                            @endif

                            <!-- Message (Same for All) -->
                            <div class="mb-2">
                                <label class="form-label small fw-semibold mb-1">Message <span class="text-danger">*</span></label>
                                <textarea name="message" 
                                          id="bulkSmsMessage"
                                          class="form-control form-control-sm" 
                                          rows="4" 
                                          placeholder="Type your message here (same message will be sent to all numbers)..."
                                          required>{{ old('message') }}</textarea>
                                
                                <!-- SMS Info for Bulk -->
                                <div class="mt-2">
                                    <div class="row g-1">
                                        <div class="col-3">
                                            <div class="stat-box">
                                                <div class="stat-label">Chars</div>
                                                <div class="stat-value"><span id="bulkCharCount">0</span></div>
                                            </div>
                                        </div>
                                        <div class="col-3">
                                            <div class="stat-box">
                                                <div class="stat-label">Type</div>
                                                <div class="stat-value"><span id="bulkEncodingType">EN</span></div>
                                            </div>
                                        </div>
                                        <div class="col-3">
                                            <div class="stat-box">
                                                <div class="stat-label">SMS/No.</div>
                                                <div class="stat-value"><span id="bulkSmsCount">0</span></div>
                                            </div>
                                        </div>
                                        <div class="col-3">
                                            <div class="stat-box stat-box-primary">
                                                <div class="stat-label">Cost/No.</div>
                                                <div class="stat-value">৳<span id="bulkTotalCost">0</span></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="mt-1">
                                    <small class="text-muted" style="font-size: 0.7rem;">
                                        <i class="fas fa-info-circle me-1"></i>English: 160 chars | Bangla: 70 chars
                                    </small>
                                </div>
                            </div>

                            <!-- Excel File Upload (Numbers Only) -->
                            <div class="mb-2">
                                <label class="form-label small fw-semibold mb-1">Upload Phone Numbers (Excel) <span class="text-danger">*</span></label>
                                <input type="file" 
                                       name="excel_file" 
                                       id="excelFile"
                                       class="form-control form-control-sm" 
                                       accept=".xlsx,.xls,.csv"
                                       required>
                                <small class="text-muted" style="font-size: 0.7rem;">
                                    <i class="fas fa-file-excel me-1"></i>Excel file with one column: phone_number
                                </small>
                            </div>

                            <!-- Template Download -->
                            <div class="alert alert-warning py-2 px-2 mb-2" style="border-radius: 5px;">
                                <div class="d-flex align-items-center">
                                    <i class="fas fa-download me-2"></i>
                                    <div class="flex-grow-1">
                                        <strong class="small">Need a template?</strong><br>
                                        <small style="font-size: 0.7rem;">Download sample Excel file</small>
                                    </div>
                                    <a href="{{ route('user.sms.template') }}" class="btn btn-warning btn-sm">
                                        <i class="fas fa-download me-1"></i>Download
                                    </a>
                                </div>
                            </div>

                            <!-- Guidelines -->
                            <div class="alert alert-info py-2 px-2 mb-2" style="border-radius: 5px;">
                                <h6 class="small mb-1"><i class="fas fa-info-circle me-1"></i>Guidelines:</h6>
                                <ul class="mb-0" style="font-size: 0.7rem; padding-left: 1.2rem;">
                                    <li>Excel file must have one column: <strong>phone_number</strong></li>
                                    <li>Include country code (e.g., +8801712345678)</li>
                                    <li>Same message will be sent to all numbers</li>
                                    <li>Cost calculated per number automatically</li>
                                </ul>
                            </div>

                            <!-- Buttons -->
                            <div class="d-flex gap-1 mt-2">
                                <button type="submit" class="btn btn-success btn-sm" {{ !auth()->user()->isKycVerified() ? 'disabled' : '' }}>
                                    <i class="fas fa-upload me-1"></i>Upload & Send
                        </button>
                                <a href="{{ route('user.dashboard') }}" class="btn btn-outline-secondary btn-sm">
                                    <i class="fas fa-times me-1"></i>Cancel
                        </a>
                    </div>
                </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Sidebar -->
    <div class="col-lg-4">
        <!-- Balance -->
        <div class="card mb-2 border shadow-sm" style="border-radius: 5px;">
            <div class="card-body p-2">
                <h6 class="small mb-1"><i class="fas fa-wallet me-1"></i>Your Balance</h6>
                <div class="h4 text-primary fw-bold mb-2">৳{{ number_format(auth()->user()->balance, 2) }}</div>
                
                @if(auth()->user()->balance < 10)
                <div class="alert alert-warning py-1 px-2 mb-1 small" style="border-radius: 5px;">
                    <i class="fas fa-exclamation-triangle me-1"></i>Low balance!
                </div>
                <a href="{{ route('user.payment.packages') }}" class="btn btn-success btn-sm w-100">
                    <i class="fas fa-plus-circle me-1"></i>Add Balance
                </a>
                @endif
            </div>
        </div>

        <!-- SMS Rates -->
        <div class="card mb-2 border shadow-sm" style="border-radius: 5px;">
            <div class="card-body p-2">
                <h6 class="small mb-1"><i class="fas fa-info-circle me-1"></i>SMS Rates</h6>
                <div class="mb-1">
                    <small class="text-muted" style="font-size: 0.7rem;">Cost per SMS by gateway</small>
                </div>
                @foreach($gateways as $gateway)
                <div class="d-flex justify-content-between align-items-center mb-1 p-1 bg-light" style="border-radius: 5px; font-size: 0.8rem;">
                    <span>{{ $gateway->gateway_name }}</span>
                    <span class="badge bg-primary" style="font-size: 0.7rem;">৳{{ number_format($gateway->cost_per_sms, 2) }}</span>
                </div>
                @endforeach
            </div>
        </div>

        <!-- Tips -->
        <div class="card border shadow-sm" style="border-radius: 5px;">
            <div class="card-body p-2">
                <h6 class="small mb-1"><i class="fas fa-lightbulb me-1"></i>Tips</h6>
                <ul class="mb-0" style="font-size: 0.7rem; padding-left: 1.2rem;">
                    <li>Select sender ID before sending</li>
                    <li>Check character count to save costs</li>
                    <li>Bangla: 70 chars | English: 160 chars</li>
                    <li>For bulk SMS, upload Excel with phone numbers only</li>
                    <li>Same message will be sent to all numbers</li>
                    <li>Check balance before bulk sending</li>
                </ul>
            </div>
        </div>
    </div>
</div>
@endsection

@push('styles')
<style>
    /* Tabs */
    .nav-tabs-sm .nav-link {
        color: #6c757d;
        font-weight: 600;
        border: none;
        border-bottom: 2px solid transparent;
        padding: 6px 12px;
        font-size: 0.85rem;
    }

    .nav-tabs-sm .nav-link:hover {
        border-color: transparent;
        color: #667eea;
    }

    .nav-tabs-sm .nav-link.active {
        color: #667eea;
        background: none;
        border-color: transparent transparent #667eea transparent;
    }

    /* Stat Boxes */
    .stat-box {
        background: #f8f9fa;
        padding: 6px 4px;
        border-radius: 5px;
        text-align: center;
        border: 1px solid #e9ecef;
    }

    .stat-box-primary {
        background: #667eea;
        color: white;
        border-color: #667eea;
    }

    .stat-label {
        font-size: 0.65rem;
        font-weight: 600;
        text-transform: uppercase;
        margin-bottom: 2px;
        opacity: 0.8;
    }

    .stat-value {
        font-size: 0.95rem;
        font-weight: 700;
        line-height: 1;
    }

    /* Form Elements */
    .form-control-sm, .form-select-sm {
        font-size: 0.85rem;
        padding: 0.375rem 0.5rem;
        border-radius: 5px;
    }

    .form-label {
        font-size: 0.85rem;
    }

    /* Cards */
    .card {
        border-radius: 5px !important;
    }

    /* Alerts */
    .alert {
        border-radius: 5px;
        font-size: 0.85rem;
    }

    /* Buttons */
    .btn-sm {
        font-size: 0.8rem;
        padding: 0.35rem 0.75rem;
        border-radius: 5px;
    }

    .badge {
        border-radius: 5px;
    }

    /* Remove all animations */
    *, *::before, *::after {
        transition: none !important;
        animation: none !important;
    }
</style>
@endpush

@push('scripts')
<script>
// Single SMS - Character counting and SMS calculation
const smsMessage = document.getElementById('smsMessage');
const charCount = document.getElementById('charCount');
const encodingType = document.getElementById('encodingType');
const smsCount = document.getElementById('smsCount');
const totalCost = document.getElementById('totalCost');
const senderIdSelect = document.getElementById('senderIdSelect');

// Bulk SMS - Character counting and SMS calculation
const bulkSmsMessage = document.getElementById('bulkSmsMessage');
const bulkCharCount = document.getElementById('bulkCharCount');
const bulkEncodingType = document.getElementById('bulkEncodingType');
const bulkSmsCount = document.getElementById('bulkSmsCount');
const bulkTotalCost = document.getElementById('bulkTotalCost');
const bulkSenderIdSelect = document.getElementById('bulkSenderIdSelect');

// Detect Unicode/Bangla
function containsUnicode(str) {
    return /[^\x00-\x7F]/.test(str);
}

// Calculate SMS for Single
function calculateSMS() {
    const message = smsMessage.value;
    const length = message.length;
    const isUnicode = containsUnicode(message);
    
    const selectedOption = senderIdSelect.options[senderIdSelect.selectedIndex];
    const costPerSms = selectedOption ? parseFloat(selectedOption.dataset.cost || 0) : 0;
    
    const singleLimit = isUnicode ? 70 : 160;
    const multiLimit = isUnicode ? 67 : 153;
    
    let count = 0;
    if (length === 0) {
        count = 0;
    } else if (length <= singleLimit) {
        count = 1;
    } else {
        count = Math.ceil(length / multiLimit);
    }
    
    charCount.textContent = length;
    encodingType.textContent = isUnicode ? 'BN' : 'EN';
    smsCount.textContent = count;
    totalCost.textContent = (count * costPerSms).toFixed(2);
}

// Calculate SMS for Bulk
function calculateBulkSMS() {
    const message = bulkSmsMessage.value;
    const length = message.length;
    const isUnicode = containsUnicode(message);
    
    const selectedOption = bulkSenderIdSelect.options[bulkSenderIdSelect.selectedIndex];
    const costPerSms = selectedOption ? parseFloat(selectedOption.dataset.cost || 0) : 0;
    
    const singleLimit = isUnicode ? 70 : 160;
    const multiLimit = isUnicode ? 67 : 153;
    
    let count = 0;
    if (length === 0) {
        count = 0;
    } else if (length <= singleLimit) {
        count = 1;
    } else {
        count = Math.ceil(length / multiLimit);
    }
    
    bulkCharCount.textContent = length;
    bulkEncodingType.textContent = isUnicode ? 'BN' : 'EN';
    bulkSmsCount.textContent = count;
    bulkTotalCost.textContent = (count * costPerSms).toFixed(2);
}

// Event listeners for Single SMS
if (smsMessage) {
    smsMessage.addEventListener('input', calculateSMS);
}

if (senderIdSelect) {
    senderIdSelect.addEventListener('change', function() {
    const selectedOption = this.options[this.selectedIndex];
    if (selectedOption && selectedOption.value) {
        const gateway = selectedOption.dataset.gateway;
        const sender = selectedOption.dataset.sender;
        const device = selectedOption.dataset.device;
        
        let displayText = '';
        if (gateway === 'bulksmsbd') {
            displayText = `${gateway} - ${sender}`;
        } else {
            displayText = `${gateway} - ${device || 'Default'}`;
        }
        
        document.getElementById('selectedSenderText').textContent = displayText;
        document.getElementById('senderIdDisplay').style.display = 'block';
        calculateSMS();
    } else {
        document.getElementById('senderIdDisplay').style.display = 'none';
    }
    });
}

// Event listeners for Bulk SMS
if (bulkSmsMessage) {
    bulkSmsMessage.addEventListener('input', calculateBulkSMS);
}

if (bulkSenderIdSelect) {
    bulkSenderIdSelect.addEventListener('change', function() {
    const selectedOption = this.options[this.selectedIndex];
    if (selectedOption && selectedOption.value) {
        const gateway = selectedOption.dataset.gateway;
        const sender = selectedOption.dataset.sender;
        const device = selectedOption.dataset.device;
        
        let displayText = '';
        if (gateway === 'bulksmsbd') {
            displayText = `${gateway} - ${sender}`;
        } else {
            displayText = `${gateway} - ${device || 'Default'}`;
        }
        
        document.getElementById('bulkSelectedSenderText').textContent = displayText;
        document.getElementById('bulkSenderIdDisplay').style.display = 'block';
        calculateBulkSMS();
    } else {
        document.getElementById('bulkSenderIdDisplay').style.display = 'none';
    }
    });
}

// Form validation for Single SMS
document.getElementById('singleSmsForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const selectedSender = senderIdSelect ? senderIdSelect.value : null;
    const message = smsMessage ? smsMessage.value : '';
    const phone = document.getElementById('phoneNumber').value;
    
    if (!selectedSender && senderIdSelect) {
        Swal.fire({
            icon: 'warning',
            title: 'Sender ID Required',
            text: 'Please select a Sender ID',
            confirmButtonColor: '#667eea'
        });
        return false;
    }
    
    if (!phone) {
        Swal.fire({
            icon: 'warning',
            title: 'Phone Number Required',
            text: 'Please enter a phone number',
            confirmButtonColor: '#667eea'
        });
        return false;
    }
    
    if (!message) {
        Swal.fire({
            icon: 'warning',
            title: 'Message Required',
            text: 'Please enter a message',
            confirmButtonColor: '#667eea'
        });
        return false;
    }
    
    const smsCountValue = parseInt(document.getElementById('smsCount').textContent);
    const totalCostValue = parseFloat(document.getElementById('totalCost').textContent);
    const userBalance = {{ auth()->user()->balance }};
    
    if (totalCostValue > userBalance) {
        Swal.fire({
            icon: 'error',
            title: 'Insufficient Balance',
            html: `<div class="text-center">
                <p class="mb-2">You need <strong class="text-danger">৳${totalCostValue.toFixed(2)}</strong></p>
                <p class="mb-0">Current balance: <strong class="text-success">৳${userBalance.toFixed(2)}</strong></p>
            </div>`,
            confirmButtonColor: '#667eea',
            confirmButtonText: 'Add Balance',
            showCancelButton: true,
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = '{{ route("user.payment.packages") }}';
            }
        });
        return false;
    }
    
    // Confirmation popup
    Swal.fire({
        title: 'Confirm SMS Send',
        html: `
            <div class="text-center">
                <i class="fas fa-paper-plane fa-3x text-primary mb-3"></i>
                <h5 class="mb-3">SMS Details</h5>
                <div class="d-flex justify-content-between mb-2">
                    <span>Phone Number:</span>
                    <strong>${phone}</strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>SMS Parts:</span>
                    <strong>${smsCountValue}</strong>
                </div>
                <div class="d-flex justify-content-between mb-3">
                    <span>Total Cost:</span>
                    <strong class="text-primary">৳${totalCostValue.toFixed(2)}</strong>
                </div>
                <p class="text-muted small mb-0">Are you sure you want to send this SMS?</p>
            </div>
        `,
        icon: false,
        showCancelButton: true,
        confirmButtonColor: '#28a745',
        cancelButtonColor: '#6c757d',
        confirmButtonText: '<i class="fas fa-check me-1"></i> Yes, Send SMS',
        cancelButtonText: '<i class="fas fa-times me-1"></i> Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            // Submit the form
            e.target.submit();
        }
    });
});

// Form validation for Bulk SMS
document.getElementById('bulkSmsForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const selectedSender = bulkSenderIdSelect ? bulkSenderIdSelect.value : null;
    const message = bulkSmsMessage ? bulkSmsMessage.value : '';
    const fileInput = document.getElementById('excelFile');
    
    if (!selectedSender && bulkSenderIdSelect) {
        Swal.fire({
            icon: 'warning',
            title: 'Sender ID Required',
            text: 'Please select a Sender ID',
            confirmButtonColor: '#667eea'
        });
        return false;
    }
    
    if (!message) {
        Swal.fire({
            icon: 'warning',
            title: 'Message Required',
            text: 'Please enter a message to send',
            confirmButtonColor: '#667eea'
        });
        return false;
    }
    
    if (!fileInput.files.length) {
        Swal.fire({
            icon: 'warning',
            title: 'Excel File Required',
            text: 'Please upload an Excel file with phone numbers',
            confirmButtonColor: '#667eea'
        });
        return false;
    }
    
    // Get bulk SMS details
    const bulkSmsCountValue = parseInt(document.getElementById('bulkSmsCount').textContent);
    const bulkTotalCostValue = parseFloat(document.getElementById('bulkTotalCost').textContent);
    const fileName = fileInput.files[0].name;
    
    // Confirmation popup
    Swal.fire({
        title: 'Confirm Bulk SMS Send',
        html: `
            <div class="text-center">
                <i class="fas fa-users fa-3x text-success mb-3"></i>
                <h5 class="mb-3">Bulk SMS Details</h5>
                <div class="d-flex justify-content-between mb-2">
                    <span>Excel File:</span>
                    <strong>${fileName}</strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>SMS Parts per Number:</span>
                    <strong>${bulkSmsCountValue}</strong>
                </div>
                <div class="d-flex justify-content-between mb-3">
                    <span>Cost per Number:</span>
                    <strong class="text-success">৳${bulkTotalCostValue.toFixed(2)}</strong>
                </div>
                <div class="alert alert-warning py-2 mb-0">
                    <small><i class="fas fa-info-circle me-1"></i>The same message will be sent to all numbers in the file.</small>
                </div>
            </div>
        `,
        icon: false,
        showCancelButton: true,
        confirmButtonColor: '#28a745',
        cancelButtonColor: '#6c757d',
        confirmButtonText: '<i class="fas fa-upload me-1"></i> Yes, Send Bulk SMS',
        cancelButtonText: '<i class="fas fa-times me-1"></i> Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            // Show loading
            Swal.fire({
                title: 'Processing...',
                html: 'Uploading file and sending SMS messages. Please wait...',
                allowOutsideClick: false,
                allowEscapeKey: false,
                showConfirmButton: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });
            
            // Submit the form
            e.target.submit();
        }
    });
});
</script>
@endpush
