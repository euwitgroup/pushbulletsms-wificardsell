@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
<style>
    /* Stat Cards */
    .stat-cards {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 24px;
        margin-bottom: 32px;
    }
    
    .stat-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 16px;
        padding: 28px;
        color: #fff;
        position: relative;
        overflow: hidden;
        box-shadow: 0 8px 24px rgba(102, 126, 234, 0.25);
        transition: all 0.3s ease;
    }
    
    .stat-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 32px rgba(102, 126, 234, 0.35);
    }
    
    .stat-card.green {
        background: linear-gradient(135deg, #56ccf2 0%, #2f80ed 100%);
        box-shadow: 0 8px 24px rgba(86, 204, 242, 0.25);
    }
    
    .stat-card.green:hover {
        box-shadow: 0 12px 32px rgba(86, 204, 242, 0.35);
    }
    
    .stat-card.orange {
        background: linear-gradient(135deg, #fa8c79 0%, #ff6b6b 100%);
        box-shadow: 0 8px 24px rgba(250, 140, 121, 0.25);
    }
    
    .stat-card.orange:hover {
        box-shadow: 0 12px 32px rgba(250, 140, 121, 0.35);
    }
    
    .stat-card::before {
        content: '';
        position: absolute;
        top: -60px;
        right: -60px;
        width: 240px;
        height: 240px;
        background: rgba(255,255,255,0.12);
        border-radius: 50%;
    }
    
    .stat-label {
        font-size: 14px;
        font-weight: 500;
        opacity: 0.95;
        margin-bottom: 12px;
        position: relative;
        z-index: 1;
    }
    
    .stat-value {
        font-size: 36px;
        font-weight: 700;
        margin-bottom: 16px;
        position: relative;
        z-index: 1;
        line-height: 1;
    }
    
    .stat-icon {
        position: absolute;
        right: 28px;
        top: 28px;
        opacity: 0.25;
        font-size: 56px;
    }
    
    .stat-footer {
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 13px;
        opacity: 0.95;
        position: relative;
        z-index: 1;
    }
    
    .stat-footer i {
        font-size: 12px;
    }
    
    /* Quick Actions */
    .quick-actions-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
        gap: 24px;
        margin-bottom: 32px;
    }
    
    .quick-action-card {
        background: #fff;
        border-radius: 16px;
        padding: 32px;
        text-align: center;
        box-shadow: 0 4px 16px rgba(0,0,0,0.06);
        transition: all 0.3s ease;
        cursor: pointer;
        border: 2px solid transparent;
    }
    
    .quick-action-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 24px rgba(0,0,0,0.12);
        border-color: #667eea;
    }
    
    .quick-action-icon {
        width: 80px;
        height: 80px;
        margin: 0 auto 20px;
        border-radius: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 36px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: #fff;
    }
    
    .quick-action-card.send .quick-action-icon {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
    
    .quick-action-card.buy .quick-action-icon {
        background: linear-gradient(135deg, #56ccf2 0%, #2f80ed 100%);
    }
    
    .quick-action-card.history .quick-action-icon {
        background: linear-gradient(135deg, #fa8c79 0%, #ff6b6b 100%);
    }
    
    .quick-action-card.profile .quick-action-icon {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    }
    
    .quick-action-title {
        font-size: 18px;
        font-weight: 700;
        color: #2c3e50;
        margin-bottom: 8px;
    }
    
    .quick-action-desc {
        font-size: 13px;
        color: #6c757d;
        margin-bottom: 20px;
    }
    
    /* Cards */
    .chart-card {
        background: #fff;
        border-radius: 16px;
        padding: 28px;
        margin-bottom: 24px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.06);
    }
    
    .card-header-custom {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
    }
    
    .card-title {
        font-size: 18px;
        font-weight: 700;
        color: #2c3e50;
        margin: 0;
    }
    
    .card-subtitle {
        font-size: 13px;
        color: #6c757d;
        margin-top: 4px;
    }
    
    /* Activity List */
    .activity-item {
        display: flex;
        gap: 16px;
        padding: 16px 0;
        border-bottom: 1px solid #f1f3f5;
    }
    
    .activity-item:last-child {
        border-bottom: none;
    }
    
    .activity-icon {
        width: 48px;
        height: 48px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        color: #fff;
        flex-shrink: 0;
    }
    
    .activity-content {
        flex: 1;
    }
    
    .activity-title {
        font-weight: 600;
        color: #2c3e50;
        font-size: 14px;
        margin-bottom: 4px;
    }
    
    .activity-desc {
        font-size: 13px;
        color: #6c757d;
        margin-bottom: 4px;
    }
    
    .activity-time {
        font-size: 12px;
        color: #adb5bd;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    
    .activity-badge {
        flex-shrink: 0;
        align-self: flex-start;
    }
    
    .view-all-link {
        color: #667eea;
        text-decoration: none;
        font-weight: 600;
        font-size: 14px;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        margin-top: 16px;
    }
    
    .view-all-link:hover {
        color: #764ba2;
    }
    
    .empty-state {
        text-align: center;
        padding: 48px 24px;
    }
    
    .empty-state-icon {
        font-size: 64px;
        color: #e9ecef;
        margin-bottom: 16px;
    }
    
    .empty-state-text {
        color: #6c757d;
        margin-bottom: 20px;
    }
</style>

<div class="container-fluid p-4">
    <!-- Stat Cards -->
    <div class="stat-cards">
        <div class="stat-card">
            <div class="stat-label">Current Balance</div>
            <div class="stat-value">৳{{ number_format($stats['balance'], 2) }}</div>
            <div class="stat-icon">
                <i class="fas fa-wallet"></i>
            </div>
            <div class="stat-footer">
                <i class="fas fa-info-circle"></i>
                <span>Available for SMS sending</span>
            </div>
</div>

        <div class="stat-card green">
            <div class="stat-label">SMS Sent</div>
            <div class="stat-value">{{ number_format($stats['total_sms_sent']) }}</div>
            <div class="stat-icon">
                <i class="fas fa-paper-plane"></i>
                    </div>
            <div class="stat-footer">
                <i class="fas fa-check-circle"></i>
                <span>Total messages delivered</span>
        </div>
    </div>

        <div class="stat-card orange">
            <div class="stat-label">Total Spent</div>
            <div class="stat-value">৳{{ number_format($stats['total_spent'], 2) }}</div>
            <div class="stat-icon">
                <i class="fas fa-chart-line"></i>
                    </div>
            <div class="stat-footer">
                <i class="fas fa-wallet"></i>
                <span>Lifetime spending</span>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="quick-actions-grid">
        <a href="{{ route('user.sms.create') }}" class="text-decoration-none">
            <div class="quick-action-card send">
                <div class="quick-action-icon">
                    <i class="fas fa-paper-plane"></i>
                </div>
                <div class="quick-action-title">Send SMS</div>
                <div class="quick-action-desc">Send messages to any mobile number instantly</div>
            </div>
        </a>
        
        <a href="{{ route('user.payment.packages') }}" class="text-decoration-none">
            <div class="quick-action-card buy">
                <div class="quick-action-icon">
                    <i class="fas fa-shopping-cart"></i>
        </div>
                <div class="quick-action-title">Buy Balance</div>
                <div class="quick-action-desc">Purchase SMS packages and add balance</div>
    </div>
        </a>
        
        <a href="{{ route('user.sms.history') }}" class="text-decoration-none">
            <div class="quick-action-card history">
                <div class="quick-action-icon">
                    <i class="fas fa-history"></i>
</div>
                <div class="quick-action-title">SMS History</div>
                <div class="quick-action-desc">View all sent messages and their status</div>
            </div>
        </a>
        
        <a href="{{ route('user.profile') }}" class="text-decoration-none">
            <div class="quick-action-card profile">
                <div class="quick-action-icon">
                    <i class="fas fa-user-circle"></i>
        </div>
                <div class="quick-action-title">My Profile</div>
                <div class="quick-action-desc">Manage profile and KYC verification</div>
            </div>
        </a>
</div>

<!-- Recent Activity -->
    <div class="row">
        <div class="col-lg-6">
            <!-- Recent SMS -->
            <div class="chart-card">
                <div class="card-header-custom">
                    <div>
                        <h3 class="card-title">Recent SMS Activity</h3>
                        <p class="card-subtitle">Your latest sent messages</p>
                    </div>
            </div>
                
                @if($stats['recent_sms']->count() > 0)
                    <div class="activity-list">
                        @foreach($stats['recent_sms'] as $index => $sms)
                            @php
                                $colors = ['667eea', '56ccf2', 'fa8c79', 'f093fb', '4facfe'];
                                $bg = $colors[$index % 5];
                            @endphp
                            <div class="activity-item">
                                <div class="activity-icon" style="background: #{{ $bg }};">
                                    <i class="fas fa-sms"></i>
                                </div>
                                <div class="activity-content">
                                    <div class="activity-title">{{ $sms->phone_number }}</div>
                                    <div class="activity-desc">{{ Str::limit($sms->message, 60) }}</div>
                                    <div class="activity-time">
                                        <i class="far fa-clock"></i>
                                        {{ $sms->created_at->diffForHumans() }}
                                    </div>
                                </div>
                                <div class="activity-badge">
                                    <span class="badge bg-{{ $sms->status == 'sent' ? 'success' : ($sms->status == 'failed' ? 'danger' : 'warning') }}">
                                        {{ ucfirst($sms->status) }}
                                    </span>
                                </div>
                            </div>
                        @endforeach
                    </div>
                    
                    <a href="{{ route('user.sms.history') }}" class="view-all-link">
                        View all SMS History <i class="fas fa-arrow-right"></i>
                    </a>
                @else
                    <div class="empty-state">
                        <div class="empty-state-icon">
                            <i class="fas fa-inbox"></i>
                        </div>
                        <p class="empty-state-text">No SMS sent yet. Start sending messages now!</p>
                        <a href="{{ route('user.sms.create') }}" class="btn btn-primary">
                            <i class="fas fa-paper-plane me-2"></i>Send Your First SMS
                        </a>
                    </div>
                @endif
            </div>
        </div>

        <div class="col-lg-6">
            <!-- Recent Transactions -->
            <div class="chart-card">
                <div class="card-header-custom">
                    <div>
                        <h3 class="card-title">Recent Transactions</h3>
                        <p class="card-subtitle">Your latest balance activities</p>
        </div>
    </div>

                @if($stats['recent_transactions']->count() > 0)
                    <div class="activity-list">
                        @foreach($stats['recent_transactions'] as $index => $transaction)
                            @php
                                $colors = ['667eea', '56ccf2', 'fa8c79', 'f093fb', '4facfe'];
                                $bg = $colors[$index % 5];
                            @endphp
                            <div class="activity-item">
                                <div class="activity-icon" style="background: #{{ $bg }};">
                                    <i class="fas fa-{{ $transaction->type == 'credit' ? 'plus' : 'minus' }}"></i>
                                </div>
                                <div class="activity-content">
                                    <div class="activity-title">
                                        {{ $transaction->description ?? ($transaction->type == 'credit' ? 'Balance Added' : 'Balance Deducted') }}
                                    </div>
                                    <div class="activity-desc">Transaction ID: {{ $transaction->transaction_id }}</div>
                                    <div class="activity-time">
                                        <i class="far fa-clock"></i>
                                        {{ $transaction->created_at->diffForHumans() }}
                            </div>
                                </div>
                                <div class="activity-badge">
                                    <div class="text-end">
                                        <div class="fw-bold {{ $transaction->type == 'credit' ? 'text-success' : 'text-danger' }}" style="font-size: 15px;">
                                            {{ $transaction->type == 'credit' ? '+' : '-' }}৳{{ number_format($transaction->amount, 2) }}
                                        </div>
                                        <span class="badge bg-{{ $transaction->status == 'completed' ? 'success' : 'warning' }}" style="font-size: 10px;">
                                    {{ ucfirst($transaction->status) }}
                                </span>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
                    
                    <a href="{{ route('user.transactions') }}" class="view-all-link">
                        View all Transactions <i class="fas fa-arrow-right"></i>
                    </a>
                @else
                    <div class="empty-state">
                        <div class="empty-state-icon">
                            <i class="fas fa-receipt"></i>
                        </div>
                        <p class="empty-state-text">No transactions yet. Add balance to get started!</p>
                        <a href="{{ route('user.payment.packages') }}" class="btn btn-success">
                            <i class="fas fa-shopping-cart me-2"></i>Buy Balance
                        </a>
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection
