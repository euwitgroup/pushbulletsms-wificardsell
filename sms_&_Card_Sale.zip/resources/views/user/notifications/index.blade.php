@extends('layouts.app')

@section('title', 'Notifications')

@section('content')
<style>
    .notification-item {
        padding: 15px 20px;
        border-bottom: 1px solid #f0f0f0;
        transition: all 0.2s;
        cursor: pointer;
    }
    
    .notification-item:hover {
        background: #f8f9fa;
    }
    
    .notification-item.unread {
        background: #f0f5ff;
        border-left: 3px solid #667eea;
    }
    
    .notification-icon {
        width: 45px;
        height: 45px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        color: white;
    }
    
    .notification-content {
        flex: 1;
        margin-left: 15px;
    }
    
    .notification-title {
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 3px;
        font-size: 14px;
    }
    
    .notification-message {
        color: #6c757d;
        font-size: 13px;
        line-height: 1.5;
    }
    
    .notification-time {
        color: #95a5a6;
        font-size: 12px;
        white-space: nowrap;
    }
    
    .notification-actions {
        display: flex;
        gap: 5px;
    }
    
    .btn-action {
        padding: 4px 8px;
        font-size: 12px;
        border-radius: 4px;
    }
</style>

<div class="container-fluid p-4">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 style="font-weight: 700; color: #1a1d2e;">
            <i class="fas fa-bell me-2" style="color: #667eea;"></i>Notifications
            @if($unreadCount > 0)
                <span class="badge bg-danger">{{ $unreadCount }}</span>
            @endif
        </h2>
    </div>

    <!-- Actions Bar -->
    <div class="card mb-4">
        <div class="card-body py-3">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                <div>
                    <span class="text-muted">Total: <strong>{{ $notifications->total() }}</strong></span>
                    <span class="mx-2">|</span>
                    <span class="text-muted">Unread: <strong class="text-primary">{{ $unreadCount }}</strong></span>
                </div>
                <div class="d-flex gap-2">
                    @if($unreadCount > 0)
                    <form action="{{ route('user.notifications.mark-all-read') }}" method="POST" class="d-inline">
                        @csrf
                        <button type="submit" class="btn btn-sm btn-primary">
                            <i class="fas fa-check-double me-1"></i>Mark All Read
                        </button>
                    </form>
                    @endif
                    <form action="{{ route('user.notifications.delete-all-read') }}" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete all read notifications?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-sm btn-outline-danger">
                            <i class="fas fa-trash me-1"></i>Delete All Read
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Notifications List -->
    <div class="card">
        <div class="card-body p-0">
            @forelse($notifications as $notification)
            <div class="notification-item {{ !$notification->is_read ? 'unread' : '' }}" onclick="handleNotificationClick({{ $notification->id }}, '{{ $notification->link }}')">
                <div class="d-flex align-items-start">
                    <div class="notification-icon bg-{{ $notification->color }}">
                        <i class="fas {{ $notification->icon ?? 'fa-bell' }}"></i>
                    </div>
                    <div class="notification-content">
                        <div class="notification-title">
                            {{ $notification->title }}
                            @if($notification->send_sms)
                                @if($notification->sms_sent)
                                    <span class="badge bg-success ms-2" title="SMS sent at {{ $notification->sms_sent_at->format('M d, H:i') }}">
                                        <i class="fas fa-sms me-1"></i>SMS Sent
                                    </span>
                                @elseif($notification->sms_error)
                                    <span class="badge bg-danger ms-2" title="{{ $notification->sms_error }}">
                                        <i class="fas fa-exclamation-circle me-1"></i>SMS Failed
                                    </span>
                                @else
                                    <span class="badge bg-warning ms-2">
                                        <i class="fas fa-clock me-1"></i>SMS Pending
                                    </span>
                                @endif
                            @endif
                        </div>
                        <div class="notification-message">{{ $notification->message }}</div>
                        @if($notification->smsTemplate)
                            <div class="mt-1">
                                <small class="text-muted">
                                    <i class="fas fa-file-alt me-1"></i>Template: {{ $notification->smsTemplate->name }}
                                </small>
                            </div>
                        @endif
                    </div>
                    <div class="d-flex flex-column align-items-end">
                        <div class="notification-time mb-2">{{ $notification->getTimeAgo() }}</div>
                        <div class="notification-actions">
                            @if(!$notification->is_read)
                            <form action="{{ route('user.notifications.read', $notification->id) }}" method="POST" onclick="event.stopPropagation();">
                                @csrf
                                <button type="submit" class="btn btn-sm btn-outline-primary btn-action" title="Mark as read">
                                    <i class="fas fa-check"></i>
                                </button>
                            </form>
                            @endif
                            <form action="{{ route('user.notifications.destroy', $notification->id) }}" method="POST" onclick="event.stopPropagation();" onsubmit="return confirm('Delete this notification?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-outline-danger btn-action" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            @empty
            <div class="text-center py-5">
                <i class="fas fa-bell-slash fa-3x text-muted mb-3"></i>
                <p class="text-muted">No notifications yet</p>
            </div>
            @endforelse
        </div>
    </div>

    <!-- Pagination -->
    @if($notifications->hasPages())
    <div class="d-flex justify-content-center mt-4">
        {{ $notifications->links() }}
    </div>
    @endif
</div>

@push('scripts')
<script>
function handleNotificationClick(id, link) {
    // Mark as read via AJAX
    fetch(`/user/notifications/${id}/read`, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            'Accept': 'application/json'
        }
    });
    
    // Navigate to link if exists
    if (link) {
        window.location.href = link;
    }
}
</script>
@endpush

@endsection

