@extends('layouts.app')

@section('title', 'Buy Balance')

@section('content')
<div class="mb-2">
    <h5 class="mb-1"><i class="fas fa-wallet me-1"></i>Buy Balance</h5>
    <p class="text-muted small mb-0">Choose a package or deposit custom amount</p>
</div>

<!-- Current Balance -->
<div class="balance-card mb-2">
    <div class="d-flex justify-content-between align-items-center">
    <div>
            <div class="small text-white-50 mb-1">Your Current Balance</div>
            <div class="h4 text-white mb-0 fw-bold">৳{{ number_format(auth()->user()->balance, 2) }}</div>
        </div>
        <div class="d-flex gap-2">
            <button type="button" class="btn btn-warning btn-sm" style="border-radius: 5px;" onclick="showCustomAmountPopup()">
                <i class="fas fa-plus-circle me-1"></i>Custom Deposit
            </button>
            <a href="{{ route('user.transactions') }}" class="btn btn-light btn-sm" style="border-radius: 5px;">
                <i class="fas fa-history me-1"></i>History
            </a>
        </div>
    </div>
</div>

<!-- Hidden form for custom amount submission -->
<form action="{{ route('user.payment.initiate') }}" method="POST" id="customAmountForm" style="display: none;">
    @csrf
    <input type="number" name="custom_amount" id="customAmountInput">
</form>

<!-- Packages Header -->
<div class="mb-2">
    <h6 class="mb-1"><i class="fas fa-box me-1"></i>Packages</h6>
    <p class="text-muted small mb-0" style="font-size: 0.75rem;">Choose a package that suits your needs</p>
</div>

<!-- Packages Grid -->
<div class="row g-2">
    @forelse($packages as $package)
    <div class="col-md-3 col-sm-6">
        <div class="package-card {{ $loop->index == 1 ? 'popular' : '' }}" data-package="{{ $loop->index }}">
            @if($loop->index == 1)
            <div class="popular-badge">
                <i class="fas fa-star me-1"></i>POPULAR
            </div>
            @endif
            
            <div class="package-icon">
                @if($loop->index == 0)
                    <i class="fas fa-rocket"></i>
                @elseif($loop->index == 1)
                    <i class="fas fa-fire"></i>
                @elseif($loop->index == 2)
                    <i class="fas fa-gem"></i>
                @else
                    <i class="fas fa-crown"></i>
                @endif
                </div>

            <h6 class="package-name mb-1">{{ $package->name }}</h6>
            
            <div class="package-price mb-2">
                <span class="price-amount">৳{{ number_format($package->price, 0) }}</span>
                @if($gatewayFeePercentage > 0)
                    @php
                        $gatewayFee = ($package->price * $gatewayFeePercentage) / 100;
                        $totalPrice = $package->price + $gatewayFee;
                    @endphp
                    <small class="d-block text-muted" style="font-size: 0.7rem;">+ Gateway Fee ৳{{ number_format($gatewayFee, 2) }} ({{ $gatewayFeePercentage }}%)</small>
                    <small class="d-block fw-bold" style="font-size: 0.75rem;">Total: ৳{{ number_format($totalPrice, 2) }}</small>
                @endif
            </div>

            <div class="package-sms mb-2">
                <i class="fas fa-sms me-1"></i>{{ $package->sms_count }} SMS
            </div>

            <div class="package-rate mb-2">
                <small><i class="fas fa-tag me-1"></i>৳{{ number_format($package->price / $package->sms_count, 2) }}/SMS</small>
                </div>

            @if($package->smsGateway)
            <div class="package-gateway mb-2">
                <small><i class="fas fa-server me-1"></i>{{ $package->smsGateway->gateway_name }}</small>
            </div>
            @endif

            @if($package->description)
            <p class="package-desc mb-2">{{ $package->description }}</p>
            @endif

            <form action="{{ route('user.payment.initiate') }}" method="POST" class="mt-auto">
                    @csrf
                    <input type="hidden" name="package_id" value="{{ $package->id }}">
                <button type="submit" class="btn-package">
                    <i class="fas fa-shopping-cart me-1"></i>Buy Now
                    </button>
                </form>
        </div>
    </div>
    @empty
    <div class="col-12">
        <div class="card border shadow-sm" style="border-radius: 5px;">
            <div class="card-body text-center py-4">
                <i class="fas fa-box-open fa-3x text-muted mb-2"></i>
                <h6>No Packages Available</h6>
                <p class="text-muted small mb-0">Please check back later</p>
            </div>
        </div>
    </div>
    @endforelse
</div>

<!-- Features Grid -->
<div class="row g-2 mt-2">
    <div class="col-md-3 col-sm-6">
        <div class="feature-box">
            <div class="feature-icon bg-success">
                <i class="fas fa-bolt"></i>
            </div>
            <h6 class="feature-title">Instant</h6>
            <p class="feature-desc">Balance added immediately</p>
        </div>
    </div>
    <div class="col-md-3 col-sm-6">
        <div class="feature-box">
            <div class="feature-icon bg-primary">
                <i class="fas fa-shield-alt"></i>
            </div>
            <h6 class="feature-title">Secure</h6>
            <p class="feature-desc">Protected by RupantorPay</p>
        </div>
    </div>
    <div class="col-md-3 col-sm-6">
        <div class="feature-box">
            <div class="feature-icon bg-info">
                <i class="fas fa-infinity"></i>
            </div>
            <h6 class="feature-title">No Expiry</h6>
            <p class="feature-desc">Balance never expires</p>
        </div>
    </div>
    <div class="col-md-3 col-sm-6">
        <div class="feature-box">
            <div class="feature-icon bg-warning">
                <i class="fas fa-headset"></i>
            </div>
            <h6 class="feature-title">Support</h6>
            <p class="feature-desc">24/7 help available</p>
        </div>
    </div>
</div>

<!-- Payment Info -->
<div class="card border shadow-sm mt-2" style="border-radius: 5px;">
    <div class="card-body p-2">
        <h6 class="mb-2"><i class="fas fa-info-circle me-1"></i>Payment Information</h6>
        <div class="row g-2">
            <div class="col-md-6">
                <ul class="mb-0" style="font-size: 0.8rem; padding-left: 1.2rem;">
                    <li>Secure payment via RupantorPay gateway</li>
                    <li>Multiple payment methods available</li>
                    <li>Instant balance credit after payment</li>
                </ul>
            </div>
            <div class="col-md-6">
                <ul class="mb-0" style="font-size: 0.8rem; padding-left: 1.2rem;">
                    <li>Transaction history in dashboard</li>
                    <li>Custom amount: Minimum ৳10</li>
                    <li>Contact support for any issues</li>
        </ul>
            </div>
        </div>
    </div>
</div>
@endsection

@push('styles')
<style>
/* Balance Card */
.balance-card {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    padding: 1rem;
    border-radius: 5px;
    box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
}

/* Package Cards */
.package-card {
    background: white;
    border: 2px solid #e9ecef;
    border-radius: 5px;
    padding: 1rem;
    text-align: center;
    position: relative;
    display: flex;
    flex-direction: column;
    height: 100%;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}

.package-card:hover {
    border-color: #667eea;
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.2);
}

.package-card.popular {
    border-color: #667eea;
    background: linear-gradient(180deg, #f0f3ff 0%, white 100%);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}

.popular-badge {
    position: absolute;
    top: -8px;
    right: -8px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 0.2rem 0.5rem;
    border-radius: 5px;
    font-size: 0.65rem;
    font-weight: 600;
    box-shadow: 0 2px 6px rgba(102, 126, 234, 0.4);
}

.package-icon {
    width: 50px;
    height: 50px;
    margin: 0 auto 0.5rem;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.5rem;
}

.package-name {
    font-size: 0.95rem;
    font-weight: 600;
    color: #2c3e50;
}

.package-price {
    padding: 0.5rem 0;
    border-top: 1px solid #e9ecef;
    border-bottom: 1px solid #e9ecef;
}

.price-amount {
    font-size: 1.5rem;
    font-weight: 700;
    color: #667eea;
}

.package-sms {
    font-size: 0.85rem;
    color: #6c757d;
    font-weight: 500;
}

.package-rate {
    color: #28a745;
    font-size: 0.75rem;
    font-weight: 600;
}

.package-gateway {
    color: #6c757d;
    font-size: 0.7rem;
    background: #f8f9fa;
    padding: 0.25rem 0.5rem;
    border-radius: 5px;
    display: inline-block;
}

.package-gateway small {
    color: #495057;
}

.package-desc {
    font-size: 0.75rem;
    color: #95a5a6;
    line-height: 1.4;
}

.btn-package {
    width: 100%;
    padding: 0.4rem;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    border-radius: 5px;
    font-size: 0.85rem;
    font-weight: 600;
    cursor: pointer;
}

.btn-package:hover {
    background: linear-gradient(135deg, #5568d3 0%, #6a3f8f 100%);
}

.package-card.popular .btn-package {
    background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
}

.package-card.popular .btn-package:hover {
    background: linear-gradient(135deg, #218838 0%, #1aa179 100%);
}

/* Feature Boxes */
.feature-box {
    background: white;
    border: 1px solid #e9ecef;
    border-radius: 5px;
    padding: 0.75rem;
    text-align: center;
    height: 100%;
}

.feature-icon {
    width: 40px;
    height: 40px;
    margin: 0 auto 0.5rem;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.2rem;
}

.feature-title {
    font-size: 0.85rem;
    font-weight: 600;
    margin-bottom: 0.25rem;
    color: #2c3e50;
}

.feature-desc {
    font-size: 0.7rem;
    color: #6c757d;
    margin: 0;
}

/* Remove animations */
*, *::before, *::after {
    transition: none !important;
    animation: none !important;
}

/* Responsive */
@media (max-width: 768px) {
    .package-card {
        margin-bottom: 0.5rem;
    }
}
</style>
@endpush

@push('scripts')
<script>
function showCustomAmountPopup() {
    Swal.fire({
        title: '<strong>Custom Amount Deposit</strong>',
        html: `
            <div class="text-start">
                <p class="text-muted small mb-3">Enter any amount you want to deposit to your account</p>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Enter Amount (৳)</label>
                    <input type="number" 
                           id="swal-amount-input" 
                           class="form-control" 
                           placeholder="e.g., 500"
                           min="1"
                           max="25000"
                           step="1"
                           style="border-radius: 5px;">
                    <small class="text-muted" style="font-size: 0.75rem;">
                        <i class="fas fa-info-circle me-1"></i>Minimum: ৳1 | Maximum: ৳25,000
                    </small>
                </div>
                <div class="alert alert-info py-2 mb-0" style="border-radius: 5px;">
                    <small>
                        <i class="fas fa-shield-alt me-1"></i>
                        Secure payment via RupantorPay gateway
                    </small>
                </div>
            </div>
        `,
        icon: false,
        showCancelButton: true,
        confirmButtonText: '<i class="fas fa-credit-card me-1"></i>Proceed to Payment',
        cancelButtonText: '<i class="fas fa-times me-1"></i>Cancel',
        confirmButtonColor: '#667eea',
        cancelButtonColor: '#6c757d',
        width: '500px',
        customClass: {
            popup: 'custom-swal-popup',
            confirmButton: 'btn-custom-confirm',
            cancelButton: 'btn-custom-cancel'
        },
        preConfirm: () => {
            const amount = document.getElementById('swal-amount-input').value;
            
            if (!amount) {
                Swal.showValidationMessage('Please enter an amount');
                return false;
            }
            
            const amountNum = parseFloat(amount);
            
            if (amountNum < 1) {
                Swal.showValidationMessage('Minimum deposit amount is ৳1');
                return false;
            }
            
            if (amountNum > 25000) {
                Swal.showValidationMessage('Maximum deposit amount is ৳25,000');
                return false;
            }
            
            return amountNum;
        },
        didOpen: () => {
            // Focus on input field when popup opens
            document.getElementById('swal-amount-input').focus();
            
            // Allow Enter key to submit
            document.getElementById('swal-amount-input').addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    Swal.clickConfirm();
                }
            });
        }
    }).then((result) => {
        if (result.isConfirmed) {
            const amount = result.value;
            const gatewayFeePercentage = {{ $gatewayFeePercentage }};
            const gatewayFee = (amount * gatewayFeePercentage) / 100;
            const totalAmount = amount + gatewayFee;
            
            // Show confirmation dialog
            Swal.fire({
                title: 'Confirm Deposit',
                html: `
                    <div class="text-center">
                        <i class="fas fa-wallet fa-3x text-primary mb-3"></i>
                        <h5 class="mb-2">Deposit Breakdown</h5>
                        <div class="mb-3 p-3" style="background: #f8f9fa; border-radius: 8px; display: inline-block;">
                            <div class="d-flex justify-content-between mb-2" style="min-width: 250px;">
                                <span class="text-muted">Deposit Amount:</span>
                                <strong>৳${amount.toFixed(2)}</strong>
                            </div>
                            ${gatewayFeePercentage > 0 ? `
                            <div class="d-flex justify-content-between mb-2" style="min-width: 250px;">
                                <span class="text-muted">Gateway Fee (${gatewayFeePercentage}%):</span>
                                <strong class="text-warning">৳${gatewayFee.toFixed(2)}</strong>
                            </div>
                            <hr style="margin: 8px 0;">
                            <div class="d-flex justify-content-between" style="min-width: 250px;">
                                <span class="fw-bold">Total to Pay:</span>
                                <strong class="text-primary fs-5">৳${totalAmount.toFixed(2)}</strong>
                            </div>
                            ` : `
                            <div class="d-flex justify-content-between" style="min-width: 250px;">
                                <span class="fw-bold">Total to Pay:</span>
                                <strong class="text-primary fs-5">৳${amount.toFixed(2)}</strong>
                            </div>
                            `}
                        </div>
                        <p class="text-muted small mt-2">You will be redirected to the payment gateway</p>
                    </div>
                `,
                icon: false,
                showCancelButton: true,
                confirmButtonText: '<i class="fas fa-check me-1"></i>Confirm & Pay',
                cancelButtonText: '<i class="fas fa-arrow-left me-1"></i>Go Back',
                confirmButtonColor: '#28a745',
                cancelButtonColor: '#6c757d',
                customClass: {
                    confirmButton: 'btn-custom-confirm',
                    cancelButton: 'btn-custom-cancel'
                }
            }).then((confirmResult) => {
                if (confirmResult.isConfirmed) {
                    // Submit the form
                    document.getElementById('customAmountInput').value = amount;
                    document.getElementById('customAmountForm').submit();
                } else {
                    // Go back to amount input
                    showCustomAmountPopup();
                }
            });
        }
    });
}
</script>

<style>
.custom-swal-popup {
    border-radius: 10px !important;
}

.btn-custom-confirm,
.btn-custom-cancel {
    border-radius: 5px !important;
    padding: 0.5rem 1.5rem !important;
    font-size: 0.9rem !important;
    font-weight: 600 !important;
}

.swal2-html-container {
    margin: 1rem 0 !important;
}

.swal2-validation-message {
    background: #f8d7da !important;
    color: #721c24 !important;
    border-radius: 5px !important;
    font-size: 0.85rem !important;
}
</style>
@endpush
