@extends('layouts.app')

@section('title', 'Payment Status')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card text-center">
            <div class="card-body p-5">
                @if(session('success'))
                    <div class="mb-4">
                        <i class="fas fa-check-circle fa-5x text-success"></i>
                    </div>
                    <h2 class="mb-3">Payment Successful!</h2>
                    <p class="text-muted mb-4">{{ session('success') }}</p>

                    <div class="alert alert-success">
                        <strong>Current Balance:</strong> ৳{{ number_format(auth()->user()->balance, 2) }}
                    </div>

                    <div class="alert alert-info">
                        <i class="fas fa-clock me-2"></i>
                        Redirecting to dashboard in <strong><span id="countdown">2</span></strong> seconds...
                    </div>

                    <div class="d-grid gap-2">
                        <a href="{{ route('user.dashboard') }}" class="btn btn-primary btn-lg">
                            <i class="fas fa-home me-2"></i>Go to Dashboard Now
                        </a>
                        <a href="{{ route('user.sms.create') }}" class="btn btn-outline-primary btn-lg">
                            <i class="fas fa-paper-plane me-2"></i>Send SMS
                        </a>
                    </div>

                @elseif(session('info'))
                    <div class="mb-4">
                        <i class="fas fa-info-circle fa-5x text-info"></i>
                    </div>
                    <h2 class="mb-3">Payment Processing</h2>
                    <p class="text-muted mb-4">{{ session('info') }}</p>

                    <div class="alert alert-info">
                        <i class="fas fa-clock me-2"></i>
                        <strong>Current Balance:</strong> ৳{{ number_format(auth()->user()->balance, 2) }}
                    </div>

                    <div class="alert alert-warning">
                        <small>
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            If your payment was successful but balance hasn't updated, please wait a few minutes or contact support.
                        </small>
                    </div>

                    <div class="d-grid gap-2">
                        <a href="{{ route('user.dashboard') }}" class="btn btn-primary btn-lg">
                            <i class="fas fa-home me-2"></i>Go to Dashboard
                        </a>
                        <a href="{{ route('user.transactions') }}" class="btn btn-outline-primary btn-lg">
                            <i class="fas fa-receipt me-2"></i>View Transactions
                        </a>
                    </div>

                @elseif(session('error'))
                    <div class="mb-4">
                        <i class="fas fa-exclamation-circle fa-5x text-danger"></i>
                    </div>
                    <h2 class="mb-3">Payment Verification Error</h2>
                    <p class="text-muted mb-4">{{ session('error') }}</p>

                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <strong>What to do?</strong>
                        <ul class="text-start mb-0 mt-2">
                            <li>Check your transaction history</li>
                            <li>Contact support with your payment details</li>
                            <li>Do not make duplicate payments</li>
                        </ul>
                    </div>

                    <div class="d-grid gap-2">
                        <a href="{{ route('user.dashboard') }}" class="btn btn-primary btn-lg">
                            <i class="fas fa-home me-2"></i>Go to Dashboard
                        </a>
                        <a href="{{ route('user.transactions') }}" class="btn btn-outline-secondary btn-lg">
                            <i class="fas fa-receipt me-2"></i>Check Transactions
                        </a>
                    </div>

                @else
                    <div class="mb-4">
                        <i class="fas fa-question-circle fa-5x text-warning"></i>
                    </div>
                    <h2 class="mb-3">Payment Status Unknown</h2>
                    <p class="text-muted mb-4">We couldn't determine the payment status. Please check your transaction history.</p>

                    <div class="alert alert-warning">
                        <strong>Current Balance:</strong> ৳{{ number_format(auth()->user()->balance, 2) }}
                    </div>

                    <div class="d-grid gap-2">
                        <a href="{{ route('user.dashboard') }}" class="btn btn-primary btn-lg">
                            <i class="fas fa-home me-2"></i>Go to Dashboard
                        </a>
                        <a href="{{ route('user.transactions') }}" class="btn btn-outline-primary btn-lg">
                            <i class="fas fa-receipt me-2"></i>View Transactions
                        </a>
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
// Auto-redirect after successful payment
@if(session('success'))
    let countdown = 2;
    const countdownElement = document.getElementById('countdown');
    
    const timer = setInterval(function() {
        countdown--;
        if (countdownElement) {
            countdownElement.textContent = countdown;
        }
        
        if (countdown <= 0) {
            clearInterval(timer);
            window.location.href = "{{ route('user.dashboard') }}";
        }
    }, 1000);
@endif
</script>
@endpush
