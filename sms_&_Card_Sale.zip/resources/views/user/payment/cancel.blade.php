@extends('layouts.app')

@section('title', 'Payment Cancelled')

@section('content')
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card text-center">
            <div class="card-body p-5">
                <div class="mb-4">
                    <i class="fas fa-times-circle fa-5x text-warning"></i>
                </div>
                <h2 class="mb-3">Payment Cancelled</h2>
                <p class="text-muted mb-4">Your payment was cancelled. No charges were made to your account.</p>

                <div class="d-grid gap-2">
                    <a href="{{ route('user.payment.packages') }}" class="btn btn-primary btn-lg">
                        <i class="fas fa-redo me-2"></i>Try Again
                    </a>
                    <a href="{{ route('user.dashboard') }}" class="btn btn-outline-secondary btn-lg">
                        <i class="fas fa-home me-2"></i>Go to Dashboard
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
