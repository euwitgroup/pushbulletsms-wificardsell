@extends('layouts.app')

@section('title', 'My Profile')

@section('content')
<div class="mb-2">
    <h5 class="mb-1"><i class="fas fa-user-circle me-1"></i>My Profile</h5>
    <p class="text-muted small mb-0">Manage your profile and settings</p>
</div>

<div class="row g-2">
    <div class="col-lg-3">
        <!-- Profile Sidebar -->
        <div class="card border shadow-sm" style="border-radius: 5px;">
            <div class="card-body text-center p-2">
                    <div class="profile-photo-wrapper mb-3">
                        @if($user->profile_photo)
                            <img src="{{ asset('storage/' . $user->profile_photo) }}" 
                                 alt="Profile Photo" 
                                 class="profile-photo">
                        @else
                            <div class="profile-avatar">
                                <i class="fas fa-user fa-4x"></i>
                            </div>
                        @endif
                    </div>
                    <h6 class="mb-1">{{ $user->name }}</h6>
                    <p class="text-muted small mb-1" style="font-size: 0.75rem;">{{ $user->email }}</p>
                    <p class="text-muted small mb-2" style="font-size: 0.75rem;">{{ $user->phone }}</p>
                    
                    <!-- KYC Status Badge -->
                    <div class="mb-2">
                        {!! $user->kyc_status_badge !!}
                    </div>
                    
                    <!-- Profile Stats -->
                    <div class="profile-stats">
                        <div class="stat-item">
                            <div class="stat-value">৳{{ number_format($user->balance, 2) }}</div>
                            <div class="stat-label">Balance</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-value">{{ $user->created_at->format('M Y') }}</div>
                            <div class="stat-label">Member</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-9">
            <!-- Tab Navigation -->
            <ul class="nav nav-tabs nav-tabs-sm mb-2" id="profileTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active small" id="info-tab" data-bs-toggle="tab" data-bs-target="#info" type="button" role="tab">
                        <i class="fas fa-user me-1"></i>Profile
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link small" id="password-tab" data-bs-toggle="tab" data-bs-target="#password" type="button" role="tab">
                        <i class="fas fa-lock me-1"></i>Password
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link small" id="kyc-tab" data-bs-toggle="tab" data-bs-target="#kyc" type="button" role="tab">
                        <i class="fas fa-id-card me-1"></i>KYC
                        @if($user->isKycPending())
                            <span class="badge bg-warning ms-1" style="font-size: 0.65rem; border-radius: 5px;">Pending</span>
                        @elseif($user->kycNotSubmitted())
                            <span class="badge bg-secondary ms-1" style="font-size: 0.65rem; border-radius: 5px;">Not Submitted</span>
                        @endif
                    </button>
                </li>
            </ul>

            <!-- Tab Content -->
            <div class="tab-content" id="profileTabsContent">
                <!-- Profile Information Tab -->
                <div class="tab-pane fade show active" id="info" role="tabpanel">
                    <div class="card border shadow-sm" style="border-radius: 5px;">
                        <div class="card-header py-2">
                            <h6 class="mb-0">Update Profile Information</h6>
                        </div>
                        <div class="card-body p-2">
                            <form action="{{ route('user.profile.update') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="row g-2">
                                    <!-- Profile Photo -->
                                    <div class="col-12 mb-2">
                                        <label class="form-label small mb-1">Profile Photo</label>
                                        <input type="file" class="form-control form-control-sm @error('profile_photo') is-invalid @enderror" name="profile_photo" accept="image/*">
                                        @error('profile_photo')
                                            <div class="invalid-feedback small">{{ $message }}</div>
                                        @enderror
                                        <small class="text-muted" style="font-size: 0.7rem;">Max 2MB (JPG, PNG)</small>
                                    </div>

                                    <!-- Name -->
                                    <div class="col-md-6 mb-2">
                                        <label class="form-label small mb-1">Full Name *</label>
                                        <input type="text" class="form-control form-control-sm @error('name') is-invalid @enderror" name="name" value="{{ old('name', $user->name) }}" required>
                                        @error('name')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <!-- Email -->
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Email *</label>
                                        <div class="input-group">
                                            <input type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email', $user->email) }}" required>
                                            @if($user->hasVerifiedEmail())
                                                <span class="input-group-text bg-success text-white" title="Email Verified">
                                                    <i class="fas fa-check-circle"></i>
                                                </span>
                                            @else
                                                <span class="input-group-text bg-warning text-white" title="Email Not Verified">
                                                    <i class="fas fa-exclamation-triangle"></i>
                                                </span>
                                            @endif
                                        </div>
                                        @error('email')
                                            <div class="invalid-feedback d-block">{{ $message }}</div>
                                        @enderror
                                        @if(!$user->hasVerifiedEmail())
                                            <form action="{{ route('user.profile.send-verification') }}" method="POST" class="d-inline mt-2">
                                                @csrf
                                                <button type="submit" class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-envelope me-1"></i>Send Verification Email
                                                </button>
                                            </form>
                                        @else
                                            <small class="text-success d-block mt-1">
                                                <i class="fas fa-check-circle me-1"></i>Email verified on {{ $user->email_verified_at->format('M d, Y') }}
                                            </small>
                                        @endif
                                    </div>

                                    <!-- Phone -->
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Phone Number *</label>
                                        <input type="text" class="form-control @error('phone') is-invalid @enderror" name="phone" value="{{ old('phone', $user->phone) }}" required>
                                        @error('phone')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <!-- Date of Birth -->
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Date of Birth</label>
                                        <input type="date" class="form-control @error('date_of_birth') is-invalid @enderror" name="date_of_birth" value="{{ old('date_of_birth', $user->date_of_birth?->format('Y-m-d')) }}" max="{{ date('Y-m-d') }}">
                                        @error('date_of_birth')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <!-- Gender -->
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Gender</label>
                                        <select class="form-select @error('gender') is-invalid @enderror" name="gender">
                                            <option value="">Select Gender</option>
                                            <option value="male" {{ old('gender', $user->gender) == 'male' ? 'selected' : '' }}>Male</option>
                                            <option value="female" {{ old('gender', $user->gender) == 'female' ? 'selected' : '' }}>Female</option>
                                            <option value="other" {{ old('gender', $user->gender) == 'other' ? 'selected' : '' }}>Other</option>
                                        </select>
                                        @error('gender')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <!-- Address -->
                                    <div class="col-12 mb-3">
                                        <label class="form-label">Address</label>
                                        <textarea class="form-control @error('address') is-invalid @enderror" name="address" rows="2">{{ old('address', $user->address) }}</textarea>
                                        @error('address')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <!-- City -->
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">City</label>
                                        <input type="text" class="form-control @error('city') is-invalid @enderror" name="city" value="{{ old('city', $user->city) }}">
                                        @error('city')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <!-- State -->
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">State/Division</label>
                                        <input type="text" class="form-control @error('state') is-invalid @enderror" name="state" value="{{ old('state', $user->state) }}">
                                        @error('state')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <!-- Postal Code -->
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label">Postal Code</label>
                                        <input type="text" class="form-control @error('postal_code') is-invalid @enderror" name="postal_code" value="{{ old('postal_code', $user->postal_code) }}">
                                        @error('postal_code')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <!-- Country -->
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Country *</label>
                                        <select class="form-select @error('country') is-invalid @enderror" name="country" required>
                                            <option value="Bangladesh" {{ old('country', $user->country) == 'Bangladesh' ? 'selected' : '' }}>Bangladesh</option>
                                            <option value="India" {{ old('country', $user->country) == 'India' ? 'selected' : '' }}>India</option>
                                            <option value="Pakistan" {{ old('country', $user->country) == 'Pakistan' ? 'selected' : '' }}>Pakistan</option>
                                            <option value="Other" {{ old('country', $user->country) == 'Other' ? 'selected' : '' }}>Other</option>
                                        </select>
                                        @error('country')
                                            <div class="invalid-feedback">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>

                                <div class="text-end">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save me-2"></i>Save Changes
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Change Password Tab -->
                <div class="tab-pane fade" id="password" role="tabpanel">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">Change Password</h5>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('user.profile.password') }}" method="POST">
                                @csrf
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label class="form-label">Current Password *</label>
                                            <input type="password" class="form-control @error('current_password') is-invalid @enderror" name="current_password" required>
                                            @error('current_password')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label">New Password *</label>
                                            <input type="password" class="form-control @error('new_password') is-invalid @enderror" name="new_password" required>
                                            @error('new_password')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                            <small class="text-muted">Minimum 8 characters</small>
                                        </div>

                                        <div class="mb-3">
                                            <label class="form-label">Confirm New Password *</label>
                                            <input type="password" class="form-control" name="new_password_confirmation" required>
                                        </div>

                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-lock me-2"></i>Update Password
                                        </button>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="alert alert-info">
                                            <h6><i class="fas fa-info-circle me-2"></i>Password Requirements:</h6>
                                            <ul class="mb-0">
                                                <li>Minimum 8 characters</li>
                                                <li>Use a strong, unique password</li>
                                                <li>Don't share your password</li>
                                                <li>Change regularly for security</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- KYC Verification Tab -->
                <div class="tab-pane fade" id="kyc" role="tabpanel">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">KYC Verification</h5>
                            {!! $user->kyc_status_badge !!}
                        </div>
                        <div class="card-body">
                            @if($user->isKycVerified())
                                <div class="alert alert-success">
                                    <h5><i class="fas fa-check-circle me-2"></i>KYC Verified!</h5>
                                    <p class="mb-0">Your KYC has been verified on {{ $user->kyc_verified_at->format('F d, Y') }}. All features are now unlocked.</p>
                                </div>
                            @elseif($user->isKycPending())
                                <div class="alert alert-warning">
                                    <h5><i class="fas fa-clock me-2"></i>KYC Under Review</h5>
                                    <p class="mb-1">Your KYC documents have been submitted and are currently under review.</p>
                                    <p class="mb-0"><strong>Submitted:</strong> {{ $user->kyc_submitted_at->diffForHumans() }}</p>
                                </div>
                            @elseif($user->isKycRejected())
                                <div class="alert alert-danger">
                                    <h5><i class="fas fa-times-circle me-2"></i>KYC Rejected</h5>
                                    <p class="mb-1">Your KYC verification was rejected. Please submit again with correct documents.</p>
                                    @if($user->kyc_notes)
                                        <p class="mb-0"><strong>Reason:</strong> {{ $user->kyc_notes }}</p>
                                    @endif
                                </div>
                            @endif

                            @if(!$user->isKycVerified() || $user->isKycRejected())
                                <form action="{{ route('user.profile.kyc') }}" method="POST" enctype="multipart/form-data">
                                    @csrf
                                    <div class="alert alert-info">
                                        <h6><i class="fas fa-info-circle me-2"></i>KYC Requirements:</h6>
                                        <ul class="mb-0">
                                            <li>Submit either National ID or Passport</li>
                                            <li>Documents must be clear and readable</li>
                                            <li>All information must match your profile</li>
                                            <li>Maximum file size: 5MB per document</li>
                                        </ul>
                                    </div>

                                    <div class="row">
                                        <!-- National ID Section -->
                                        <div class="col-md-6">
                                            <h6 class="mb-3">Option 1: National ID (NID)</h6>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">NID Number</label>
                                                <input type="text" class="form-control @error('nid_number') is-invalid @enderror" name="nid_number" value="{{ old('nid_number', $user->nid_number) }}">
                                                @error('nid_number')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                @enderror
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label">NID Front Side</label>
                                                @if($user->nid_front)
                                                    <div class="mb-2">
                                                        <img src="{{ asset('storage/' . $user->nid_front) }}" alt="NID Front" class="img-thumbnail" style="max-height: 150px;">
                                                        <p class="text-success small mb-0"><i class="fas fa-check me-1"></i>Already uploaded</p>
                                                    </div>
                                                @endif
                                                <input type="file" class="form-control @error('nid_front') is-invalid @enderror" name="nid_front" accept="image/*,.pdf">
                                                @error('nid_front')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                @enderror
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label">NID Back Side</label>
                                                @if($user->nid_back)
                                                    <div class="mb-2">
                                                        <img src="{{ asset('storage/' . $user->nid_back) }}" alt="NID Back" class="img-thumbnail" style="max-height: 150px;">
                                                        <p class="text-success small mb-0"><i class="fas fa-check me-1"></i>Already uploaded</p>
                                                    </div>
                                                @endif
                                                <input type="file" class="form-control @error('nid_back') is-invalid @enderror" name="nid_back" accept="image/*,.pdf">
                                                @error('nid_back')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <!-- Passport Section -->
                                        <div class="col-md-6">
                                            <h6 class="mb-3">Option 2: Passport</h6>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Passport Number</label>
                                                <input type="text" class="form-control @error('passport_number') is-invalid @enderror" name="passport_number" value="{{ old('passport_number', $user->passport_number) }}">
                                                @error('passport_number')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                @enderror
                                            </div>

                                            <div class="mb-3">
                                                <label class="form-label">Passport Photo Page</label>
                                                @if($user->passport_photo)
                                                    <div class="mb-2">
                                                        <img src="{{ asset('storage/' . $user->passport_photo) }}" alt="Passport" class="img-thumbnail" style="max-height: 150px;">
                                                        <p class="text-success small mb-0"><i class="fas fa-check me-1"></i>Already uploaded</p>
                                                    </div>
                                                @endif
                                                <input type="file" class="form-control @error('passport_photo') is-invalid @enderror" name="passport_photo" accept="image/*,.pdf">
                                                @error('passport_photo')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <!-- Optional: Driving License -->
                                        <div class="col-12">
                                            <hr>
                                            <h6 class="mb-3">Optional: Driving License (for additional verification)</h6>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Driving License</label>
                                                @if($user->driving_license)
                                                    <div class="mb-2">
                                                        <img src="{{ asset('storage/' . $user->driving_license) }}" alt="License" class="img-thumbnail" style="max-height: 150px;">
                                                        <p class="text-success small mb-0"><i class="fas fa-check me-1"></i>Already uploaded</p>
                                                    </div>
                                                @endif
                                                <input type="file" class="form-control @error('driving_license') is-invalid @enderror" name="driving_license" accept="image/*,.pdf">
                                                @error('driving_license')
                                                    <div class="invalid-feedback">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>

                                    <div class="text-end mt-3">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-paper-plane me-2"></i>Submit for Verification
                                        </button>
                                    </div>
                                </form>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.profile-photo {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    object-fit: cover;
    border: 4px solid #667eea;
}

.profile-avatar {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    margin: 0 auto;
}

.profile-stats {
    display: flex;
    justify-content: space-around;
    padding-top: 20px;
    border-top: 1px solid #e9ecef;
}

.stat-item {
    text-align: center;
}

.stat-value {
    font-size: 1.2rem;
    font-weight: 700;
    color: #667eea;
}

.stat-label {
    font-size: 0.85rem;
    color: #6c757d;
}

.nav-tabs .nav-link {
    color: #495057;
    border: none;
    border-bottom: 3px solid transparent;
    font-weight: 500;
}

.nav-tabs .nav-link:hover {
    border-bottom-color: #667eea;
}

.nav-tabs .nav-link.active {
    color: #667eea;
    border-bottom-color: #667eea;
    background: none;
}
</style>

@push('scripts')
<script>
// Show tab based on hash in URL
document.addEventListener('DOMContentLoaded', function() {
    const hash = window.location.hash;
    if (hash) {
        const tab = document.querySelector(`button[data-bs-target="${hash}"]`);
        if (tab) {
            new bootstrap.Tab(tab).show();
        }
    }
});
</script>
@endpush

@endsection

