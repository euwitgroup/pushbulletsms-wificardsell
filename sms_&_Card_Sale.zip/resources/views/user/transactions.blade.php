@extends('layouts.app')

@section('title', 'Transactions')

@section('content')
<div class="mb-2">
    <h5 class="mb-1"><i class="fas fa-receipt me-1"></i>Transaction History</h5>
    <p class="text-muted small mb-0">View all your transactions</p>
</div>

<div class="card border shadow-sm" style="border-radius: 5px;">
    <div class="card-body p-2">
        <div class="table-responsive">
            <table class="table table-hover table-sm mb-0">
                <thead>
                    <tr>
                        <th class="small">ID</th>
                        <th class="small">Description</th>
                        <th class="small">Type</th>
                        <th class="small">Amount</th>
                        <th class="small">Gateway Fee</th>
                        <th class="small">Total</th>
                        <th class="small">Status</th>
                        <th class="small">Date</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($transactions as $transaction)
                    <tr style="font-size: 0.85rem;">
                        <td>{{ $transaction->transaction_id }}</td>
                        <td>{{ $transaction->description }}</td>
                        <td>
                            <span class="badge bg-{{ $transaction->type == 'credit' ? 'success' : 'danger' }}" style="font-size: 0.7rem; border-radius: 5px;">
                                {{ ucfirst($transaction->type) }}
                            </span>
                        </td>
                        <td class="fw-bold {{ $transaction->type == 'credit' ? 'text-success' : 'text-danger' }}">
                            {{ $transaction->type == 'credit' ? '+' : '-' }}৳{{ number_format($transaction->base_amount ?? $transaction->amount, 2) }}
                        </td>
                        <td>
                            @if($transaction->gateway_fee > 0)
                                <small class="text-warning">৳{{ number_format($transaction->gateway_fee, 2) }}</small>
                                @if($transaction->gateway_fee_percentage)
                                    <small class="text-muted d-block" style="font-size: 0.65rem;">({{ $transaction->gateway_fee_percentage }}%)</small>
                                @endif
                            @else
                                <small class="text-muted">-</small>
                            @endif
                        </td>
                        <td class="fw-bold {{ $transaction->type == 'credit' ? 'text-success' : 'text-danger' }}">
                            {{ $transaction->type == 'credit' ? '+' : '-' }}৳{{ number_format($transaction->amount, 2) }}
                        </td>
                        <td>
                            <span class="badge bg-{{ $transaction->status == 'completed' ? 'success' : ($transaction->status == 'failed' ? 'danger' : 'warning') }}" style="font-size: 0.7rem; border-radius: 5px;">
                                {{ ucfirst($transaction->status) }}
                            </span>
                        </td>
                        <td>
                            <small style="font-size: 0.75rem;">{{ $transaction->created_at->format('M d, Y h:i A') }}</small>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="8" class="text-center py-4">
                            <i class="fas fa-inbox fa-2x text-muted mb-2 d-block"></i>
                            <p class="text-muted mb-0">No transactions found</p>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if($transactions->hasPages())
        <div class="mt-2">
            {{ $transactions->links() }}
        </div>
        @endif
    </div>
</div>
@endsection
