@extends('layouts.frontend')

@section('title', $siteName . ' - ' . $siteTagline)

@push('styles')
<!-- Owl Carousel -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/owl.carousel@2.3.4/dist/assets/owl.carousel.min.css">

<style>
    :root {
        --primary-color: #00c853;
        --secondary-color: #00a843;
        --dark-color: #2c3e50;
        --light-color: #f5f5f5;
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: var(--dark-color);
        overflow-x: hidden;
    }

    /* Hero Slider Section */
    .hero-section {
        position: relative;
        overflow: hidden;
    }

    .hero-slider .owl-carousel .item {
        position: relative;
        height: 600px;
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        overflow: hidden;
    }

    /* Background Image */
    .hero-slider .owl-carousel .item .slide-bg {
        position: absolute;
        width: 100%;
        height: 100%;
        object-fit: cover;
        opacity: 0.25;
        z-index: 0;
    }

    /* Geometric Shapes */
    .hero-slider .item::before {
        content: '';
        position: absolute;
        top: -50%;
        right: -10%;
        width: 80%;
        height: 150%;
        background: rgba(255, 255, 255, 0.5);
        transform: rotate(15deg);
        z-index: 1;
    }

    .hero-slider .item::after {
        content: '';
        position: absolute;
        bottom: -30%;
        left: -15%;
        width: 60%;
        height: 100%;
        background: rgba(160, 174, 192, 0.4);
        transform: rotate(-25deg);
        z-index: 1;
    }

    /* Slider Content */
    .slider-content {
        position: relative;
        z-index: 2;
        height: 100%;
        display: flex;
        align-items: center;
    }

    .slider-text {
        position: relative;
        z-index: 3;
    }

    .slider-text h1 {
        font-size: 56px;
        font-weight: 700;
        color: #1a1a1a;
        margin-bottom: 20px;
        line-height: 1.2;
        text-shadow: 2px 2px 4px rgba(255,255,255,0.9);
    }

    .slider-text p {
        font-size: 18px;
        color: #333;
        margin-bottom: 30px;
        line-height: 1.6;
        text-shadow: 1px 1px 3px rgba(255,255,255,0.9);
    }

    .slider-text .btn-register {
        background: var(--primary-color);
        color: white;
        padding: 15px 40px;
        border-radius: 50px;
        font-size: 16px;
        font-weight: 600;
        text-decoration: none;
        display: inline-block;
        transition: all 0.3s;
        border: none;
        box-shadow: 0 4px 15px rgba(0, 200, 83, 0.3);
    }

    .slider-text .btn-register:hover {
        background: var(--secondary-color);
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(0, 200, 83, 0.4);
        color: white;
    }

    .slider-image {
        position: relative;
        z-index: 2;
        text-align: center;
    }

    .slider-image img {
        max-width: 100%;
        height: auto;
        max-height: 450px;
        filter: drop-shadow(0 10px 30px rgba(0,0,0,0.2));
    }

    /* Navigation Buttons */
    .hero-slider .owl-nav button {
        background: rgba(255,255,255,0.9) !important;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        font-size: 24px;
        color: var(--primary-color) !important;
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        transition: all 0.3s;
        z-index: 10;
    }

    .hero-slider .owl-nav button:hover {
        background: white !important;
        transform: translateY(-50%) scale(1.1);
    }

    .hero-slider .owl-nav .owl-prev {
        left: 30px;
    }

    .hero-slider .owl-nav .owl-next {
        right: 30px;
    }

    /* Dots */
    .hero-slider .owl-dots {
        position: absolute;
        bottom: 30px;
        width: 100%;
        text-align: center;
        z-index: 10;
    }

    .hero-slider .owl-dot {
        width: 12px;
        height: 12px;
        background: rgba(255,255,255,0.5) !important;
        border-radius: 50%;
        margin: 0 5px;
        display: inline-block;
        transition: all 0.3s;
    }

    .hero-slider .owl-dot.active {
        background: white !important;
        width: 30px;
        border-radius: 10px;
    }

    /* Why Choose Us Section */
    .features-section {
        padding: 60px 0;
        background: #f8f9fa;
    }

    .section-title {
        text-align: center;
        margin-bottom: 60px;
    }

    .section-title h2 {
        font-size: 36px;
        font-weight: 700;
        color: var(--dark-color);
        margin-bottom: 10px;
        position: relative;
        display: inline-block;
    }

    .section-title h2::after {
        content: '';
        position: absolute;
        bottom: -10px;
        left: 50%;
        transform: translateX(-50%);
        width: 60px;
        height: 4px;
        background: var(--primary-color);
        border-radius: 2px;
    }

    /* Mobile Mockup */
    .mobile-mockup {
        position: relative;
        max-width: 350px;
        margin: 0 auto;
    }

    .mobile-mockup img {
        width: 100%;
        height: auto;
        filter: drop-shadow(0 20px 40px rgba(0,0,0,0.2));
        animation: float 3s ease-in-out infinite;
    }

    @keyframes float {
        0%, 100% {
            transform: translateY(0px);
        }
        50% {
            transform: translateY(-10px);
        }
    }

    /* Feature Item */
    .feature-item {
        display: flex;
        align-items: flex-start;
        gap: 15px;
        padding: 15px;
        border-radius: 10px;
        transition: all 0.3s;
        background: white;
    }

    .feature-item:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.08);
    }

    .feature-icon-box {
        flex-shrink: 0;
        width: 50px;
        height: 50px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #667eea, #764ba2);
        border-radius: 12px;
        font-size: 22px;
        color: white;
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
    }

    .feature-content h4 {
        font-size: 16px;
        font-weight: 600;
        margin-bottom: 5px;
        color: var(--dark-color);
    }

    .feature-content p {
        color: #666;
        line-height: 1.5;
        font-size: 13px;
        margin: 0;
    }

    /* SMS Pricing Section */
    .sms-pricing-section {
        padding: 80px 0;
        background: #ffffff;
    }

    .sms-price-card {
        background: white;
        border-radius: 15px;
        padding: 40px 30px;
        border: 2px solid #e0e0e0;
        transition: all 0.3s;
        height: 100%;
        display: flex;
        flex-direction: column;
    }

    .sms-price-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 20px 50px rgba(0,0,0,0.15);
        border-color: var(--primary-color);
    }

    .sms-price-card.featured {
        border-color: var(--primary-color);
        border-width: 3px;
        position: relative;
        transform: scale(1.05);
    }

    .sms-price-card.featured::before {
        content: 'POPULAR';
        position: absolute;
        top: -15px;
        left: 50%;
        transform: translateX(-50%);
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        color: white;
        padding: 5px 20px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 1px;
    }

    .sms-price-header {
        text-align: center;
        margin-bottom: 25px;
    }

    .sms-price-header h3 {
        font-size: 22px;
        font-weight: 700;
        color: var(--dark-color);
        margin-bottom: 10px;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    .sms-base-price {
        font-size: 42px;
        font-weight: 800;
        color: var(--primary-color);
        margin: 15px 0;
    }

    .sms-base-price span {
        font-size: 18px;
        color: #666;
        font-weight: 400;
    }

    .sms-minimum-buy {
        font-size: 14px;
        color: #666;
        margin-bottom: 20px;
    }

    .sms-pricing-tiers {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 15px;
        margin-bottom: 20px;
        text-align: left;
    }

    .sms-pricing-tiers h5 {
        font-size: 14px;
        font-weight: 600;
        color: var(--dark-color);
        margin-bottom: 10px;
    }

    .pricing-tier-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 5px 0;
        font-size: 13px;
        color: #555;
    }

    .pricing-tier-item strong {
        color: var(--primary-color);
    }

    .sms-features-list {
        list-style: none;
        padding: 0;
        margin: 0 0 25px 0;
        text-align: left;
        flex-grow: 1;
    }

    .sms-features-list li {
        padding: 8px 0;
        font-size: 13px;
        color: #555;
        display: flex;
        align-items: flex-start;
        gap: 10px;
    }

    .sms-features-list li i {
        color: var(--primary-color);
        margin-top: 3px;
        flex-shrink: 0;
    }

    .sms-buy-button {
        display: inline-block;
        width: 100%;
        padding: 14px 30px;
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        color: white;
        text-decoration: none;
        border-radius: 50px;
        font-weight: 600;
        transition: all 0.3s;
        text-align: center;
        border: none;
        cursor: pointer;
    }

    .sms-buy-button:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 30px rgba(103, 58, 183, 0.4);
        color: white;
    }

    .sms-price-card.featured .sms-buy-button {
        background: var(--dark-color);
    }

    /* Pricing Section */
    .pricing-section {
        padding: 80px 0;
        background: var(--light-color);
    }

    .pricing-card {
        background: white;
        border-radius: 15px;
        padding: 40px 30px;
        text-align: center;
        transition: all 0.3s;
        border: 2px solid transparent;
        height: 100%;
    }

    .pricing-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 15px 40px rgba(0,0,0,0.1);
        border-color: var(--primary-color);
    }

    .pricing-card.featured {
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        color: white;
        transform: scale(1.05);
    }

    .pricing-badge {
        display: inline-block;
        padding: 5px 15px;
        background: var(--primary-color);
        color: white;
        border-radius: 20px;
        font-size: 14px;
        font-weight: 600;
        margin-bottom: 20px;
    }

    .pricing-card.featured .pricing-badge {
        background: white;
        color: var(--primary-color);
    }

    .pricing-card h3 {
        font-size: 24px;
        font-weight: 700;
        margin-bottom: 15px;
    }

    .price {
        font-size: 48px;
        font-weight: 700;
        margin: 20px 0;
    }

    .price-features {
        list-style: none;
        padding: 0;
        margin: 30px 0;
        text-align: left;
    }

    .price-features li {
        padding: 10px 0;
        border-bottom: 1px solid rgba(0,0,0,0.1);
    }

    .pricing-card.featured .price-features li {
        border-bottom-color: rgba(255,255,255,0.2);
    }

    .price-features li i {
        margin-right: 10px;
        color: var(--primary-color);
    }

    .pricing-card.featured .price-features li i {
        color: white;
    }

    /* FAQ Section */
    .faq-section {
        padding: 80px 0;
        background: white;
    }

    .faq-item {
        background: white;
        border: 1px solid #e0e0e0;
        border-radius: 10px;
        margin-bottom: 15px;
        overflow: hidden;
        transition: all 0.3s;
    }

    .faq-item:hover {
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }

    .faq-question {
        padding: 20px 25px;
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: white;
        transition: all 0.3s;
    }

    .faq-question:hover {
        background: var(--light-color);
    }

    .faq-question h5 {
        margin: 0;
        font-size: 16px;
        font-weight: 600;
        color: var(--dark-color);
    }

    .faq-icon {
        font-size: 20px;
        color: var(--primary-color);
        transition: transform 0.3s;
    }

    .faq-question.active .faq-icon {
        transform: rotate(45deg);
    }

    .faq-answer {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.3s ease-out;
    }

    .faq-answer.active {
        max-height: 500px;
    }

    .faq-answer-content {
        padding: 0 25px 20px 25px;
        color: #666;
        line-height: 1.6;
    }

    /* Blog Section */
    .blog-section {
        padding: 80px 0;
        background: var(--light-color);
    }

    .blog-card {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        transition: all 0.3s;
        height: 100%;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }

    .blog-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }

    .blog-image {
        width: 100%;
        height: 200px;
        background: linear-gradient(135deg, #667eea, #764ba2);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 48px;
    }

    .blog-content {
        padding: 25px;
    }

    .blog-category {
        display: inline-block;
        padding: 5px 15px;
        background: var(--primary-color);
        color: white;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        margin-bottom: 15px;
    }

    .blog-title {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 10px;
        color: var(--dark-color);
    }

    .blog-excerpt {
        color: #666;
        font-size: 14px;
        line-height: 1.6;
        margin-bottom: 15px;
    }

    .blog-date {
        font-size: 12px;
        color: #999;
    }

    /* Comparison Section */
    .comparison-section {
        padding: 80px 0;
        background: white;
    }

    .comparison-table {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    }

    .comparison-header {
        display: grid;
        grid-template-columns: 2fr 1fr 1fr;
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        color: white;
        padding: 20px;
        font-weight: 600;
        text-align: center;
    }

    .comparison-row {
        display: grid;
        grid-template-columns: 2fr 1fr 1fr;
        padding: 20px;
        border-bottom: 1px solid #f0f0f0;
        align-items: center;
    }

    .comparison-row:last-child {
        border-bottom: none;
    }

    .comparison-row:nth-child(even) {
        background: #f9f9f9;
    }

    .comparison-feature {
        font-weight: 500;
        color: var(--dark-color);
    }

    .comparison-check {
        text-align: center;
        font-size: 24px;
    }

    .comparison-check.yes {
        color: #26de81;
    }

    .comparison-check.no {
        color: #ee5a6f;
    }

    /* Video Section */
    .video-section {
        padding: 80px 0;
        background: var(--light-color);
    }

    .video-container {
        position: relative;
        padding-bottom: 56.25%; /* 16:9 ratio */
        height: 0;
        overflow: hidden;
        border-radius: 15px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.15);
    }

    .video-container iframe {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border: 0;
    }

    /* Online Button */
    .online-btn {
        position: fixed;
        bottom: 30px;
        right: 30px;
        background: var(--primary-color);
        color: white;
        padding: 12px 30px;
        border-radius: 50px;
        font-weight: 600;
        box-shadow: 0 4px 15px rgba(0, 200, 83, 0.4);
        z-index: 999;
        text-decoration: none;
        transition: all 0.3s;
    }

    .online-btn:hover {
        background: var(--secondary-color);
        transform: translateY(-3px);
        box-shadow: 0 6px 20px rgba(0, 200, 83, 0.5);
        color: white;
    }

    /* Mobile Menu */
    @media (max-width: 991px) {
        .slider-text h1 {
            font-size: 36px;
        }

        .hero-slider .owl-carousel .item {
            height: 500px;
        }

        .slider-image img {
            max-height: 300px;
        }
    }

    @media (max-width: 767px) {
        .hero-slider .owl-carousel .item {
            height: 400px;
        }

        .slider-text h1 {
            font-size: 28px;
        }

        .slider-text p {
            font-size: 16px;
        }

        .hero-slider .owl-nav button {
            width: 40px;
            height: 40px;
            font-size: 18px;
        }

        .hero-slider .owl-nav .owl-prev {
            left: 10px;
        }

        .hero-slider .owl-nav .owl-next {
            right: 10px;
        }
    }
</style>
@endpush

@section('content')
<!-- Hero Slider Section -->
<section class="hero-section">
    @if($sliders->count() > 0)
    <div class="hero-slider">
        <div class="owl-carousel owl-theme">
            @foreach($sliders as $slider)
            <div class="item">
                <!-- Background Image -->
                <img src="{{ asset('storage/' . $slider->image) }}" alt="{{ $slider->title }}" class="slide-bg">
                
                <!-- Slider Content -->
                <div class="slider-content">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-lg-6">
                                <div class="slider-text">
                                    <h1>{{ $slider->title ?: 'বাংলাদেশের সেরা রেট ৩০ পয়সা!' }}</h1>
                                    <p>ব্যবসার ছড়ত এবং সবচাইতে সাশ্রয়ী প্রদানে {{ $siteName }} এর SMS সার্ভিস আপনাকে এনে দিবে সর্বোচ্চ সাফল্য!</p>
                                    @if($slider->link)
                                        <a href="{{ $slider->link }}" class="btn-register">
                                            SMS পাঠাতে রেজিস্ট্রেশন করুন
                                        </a>
                                    @else
                                        <a href="{{ route('register') }}" class="btn-register">
                                            SMS পাঠাতে রেজিস্ট্রেশন করুন
                                        </a>
                                    @endif
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="slider-image">
                                    <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 500 400'%3E%3Cg%3E%3Ccircle cx='350' cy='200' r='80' fill='%23ff6b6b' opacity='0.3'/%3E%3Ccircle cx='320' cy='180' r='60' fill='%23ffa500' opacity='0.5'/%3E%3Crect x='200' y='100' width='180' height='280' rx='20' fill='%23333' stroke='%23000' stroke-width='4'/%3E%3Crect x='210' y='120' width='160' height='220' rx='5' fill='%23fff'/%3E%3Crect x='220' y='140' width='140' height='80' rx='3' fill='%23ff6347'/%3E%3Crect x='230' y='150' width='60' height='20' rx='2' fill='%23fff'/%3E%3Crect x='220' y='230' width='140' height='15' rx='2' fill='%23e0e0e0'/%3E%3Crect x='220' y='250' width='100' height='15' rx='2' fill='%23e0e0e0'/%3E%3Crect x='220' y='270' width='120' height='15' rx='2' fill='%23e0e0e0'/%3E%3Ccircle cx='290' cy='345' r='25' fill='%23ff6347'/%3E%3Cpath d='M100,150 Q80,180 100,210' stroke='%23ffa500' stroke-width='3' fill='none'/%3E%3Crect x='50' y='200' width='80' height='60' rx='5' fill='%23ffa500'/%3E%3Cpath d='M60,220 L80,230 L60,240' fill='%23fff'/%3E%3Ccircle cx='420' cy='120' r='30' fill='%23ffd700'/%3E%3Cpath d='M410,120 Q420,110 430,120 Q420,130 410,120' fill='%23333'/%3E%3Ccircle cx='150' cy='100' r='25' fill='%234ecdc4'/%3E%3Cpath d='M140,100 L145,95 L155,105 L160,100' stroke='%23fff' stroke-width='2' fill='none'/%3E%3Cpath d='M400,280 Q420,260 440,280' stroke='%23ff6b6b' stroke-width='3' fill='none'/%3E%3Ccircle cx='80' cy='320' r='15' fill='%2395e1d3'/%3E%3C/g%3E%3C/svg%3E" alt="SMS Service">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
    @else
    <!-- Default Hero Content (when no sliders) -->
    <div class="item" style="height: 600px; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); position: relative; overflow: hidden;">
        <!-- Geometric Shapes -->
        <div style="content: ''; position: absolute; top: -50%; right: -10%; width: 80%; height: 150%; background: rgba(255, 255, 255, 0.5); transform: rotate(15deg); z-index: 1;"></div>
        <div style="content: ''; position: absolute; bottom: -30%; left: -15%; width: 60%; height: 100%; background: rgba(160, 174, 192, 0.4); transform: rotate(-25deg); z-index: 1;"></div>
        
        <div class="slider-content">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="slider-text">
                            <h1>বাংলাদেশের সেরা<br>রেট ৩০ পয়সা!</h1>
                            <p>ব্যবসার ছড়ত এবং সবচাইতে সাশ্রয়ী প্রদানে {{ $siteName }} এর SMS সার্ভিস আপনাকে এনে দিবে সর্বোচ্চ সাফল্য!</p>
                            <a href="{{ route('register') }}" class="btn-register">
                                SMS পাঠাতে রেজিস্ট্রেশন করুন
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="slider-image">
                            <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 500 400'%3E%3Cg%3E%3Ccircle cx='350' cy='200' r='80' fill='%23ff6b6b' opacity='0.3'/%3E%3Ccircle cx='320' cy='180' r='60' fill='%23ffa500' opacity='0.5'/%3E%3Crect x='200' y='100' width='180' height='280' rx='20' fill='%23333' stroke='%23000' stroke-width='4'/%3E%3Crect x='210' y='120' width='160' height='220' rx='5' fill='%23fff'/%3E%3Crect x='220' y='140' width='140' height='80' rx='3' fill='%23ff6347'/%3E%3Crect x='230' y='150' width='60' height='20' rx='2' fill='%23fff'/%3E%3Crect x='220' y='230' width='140' height='15' rx='2' fill='%23e0e0e0'/%3E%3Crect x='220' y='250' width='100' height='15' rx='2' fill='%23e0e0e0'/%3E%3Crect x='220' y='270' width='120' height='15' rx='2' fill='%23e0e0e0'/%3E%3Ccircle cx='290' cy='345' r='25' fill='%23ff6347'/%3E%3Cpath d='M100,150 Q80,180 100,210' stroke='%23ffa500' stroke-width='3' fill='none'/%3E%3Crect x='50' y='200' width='80' height='60' rx='5' fill='%23ffa500'/%3E%3Cpath d='M60,220 L80,230 L60,240' fill='%23fff'/%3E%3Ccircle cx='420' cy='120' r='30' fill='%23ffd700'/%3E%3Cpath d='M410,120 Q420,110 430,120 Q420,130 410,120' fill='%23333'/%3E%3Ccircle cx='150' cy='100' r='25' fill='%234ecdc4'/%3E%3Cpath d='M140,100 L145,95 L155,105 L160,100' stroke='%23fff' stroke-width='2' fill='none'/%3E%3Cpath d='M400,280 Q420,260 440,280' stroke='%23ff6b6b' stroke-width='3' fill='none'/%3E%3Ccircle cx='80' cy='320' r='15' fill='%2395e1d3'/%3E%3C/g%3E%3C/svg%3E" alt="SMS Service">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endif
</section>

<!-- Why Choose Us Section -->
<section class="features-section">
    <div class="container">
        <div class="section-title">
            <h2>Why Choose us</h2>
        </div>
        <div class="row align-items-center">
            <!-- Mobile Phone Mockup -->
            <div class="col-lg-4 mb-4 mb-lg-0">
                <div class="mobile-mockup">
                    <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 280 520'%3E%3Cdefs%3E%3ClinearGradient id='grad1' x1='0%25' y1='0%25' x2='0%25' y2='100%25'%3E%3Cstop offset='0%25' style='stop-color:%233498db;stop-opacity:1'/%3E%3Cstop offset='100%25' style='stop-color:%232980b9;stop-opacity:1'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='280' height='520' rx='35' fill='%23000'/%3E%3Crect x='8' y='8' width='264' height='504' rx='30' fill='%23fff'/%3E%3Crect x='100' y='15' width='80' height='5' rx='2.5' fill='%23ddd'/%3E%3Crect x='18' y='35' width='244' height='50' rx='12' fill='url(%23grad1)'/%3E%3Ccircle cx='35' cy='60' r='12' fill='%23fff'/%3E%3Ctext x='60' y='65' fill='%23fff' font-size='16' font-weight='bold'%3EUser%3C/text%3E%3Ccircle cx='245' cy='60' r='3' fill='%23fff'/%3E%3Ccircle cx='237' cy='60' r='3' fill='%23fff'/%3E%3Ccircle cx='229' cy='60' r='3' fill='%23fff'/%3E%3Crect x='28' y='100' width='105' height='32' rx='8' fill='%23ecf0f1'/%3E%3Ctext x='45' y='120' fill='%2327ae60' font-size='13' font-weight='bold'%3ETk 18158%3C/text%3E%3Crect x='147' y='100' width='105' height='32' rx='8' fill='%23e74c3c'/%3E%3Ctext x='168' y='120' fill='%23fff' font-size='13' font-weight='bold'%3ELogout%3C/text%3E%3Crect x='28' y='150' width='224' height='40' rx='10' fill='%233498db'/%3E%3Ctext x='105' y='175' fill='%23fff' font-size='15' font-weight='bold'%3EMessage%3C/text%3E%3Crect x='28' y='200' width='224' height='35' rx='8' fill='%23f8f9fa'/%3E%3Ctext x='40' y='222' fill='%23555' font-size='13'%3EQuick Message%3C/text%3E%3Crect x='28' y='245' width='224' height='35' rx='8' fill='%23f8f9fa'/%3E%3Ctext x='40' y='267' fill='%23555' font-size='13'%3EGroup Message%3C/text%3E%3Crect x='28' y='290' width='224' height='35' rx='8' fill='%23f8f9fa'/%3E%3Ctext x='40' y='312' fill='%23555' font-size='13'%3ESMS History%3C/text%3E%3Crect x='28' y='340' width='224' height='40' rx='10' fill='%2327ae60'/%3E%3Ctext x='80' y='365' fill='%23fff' font-size='15' font-weight='bold'%3EAccount%3C/text%3E%3Crect x='28' y='390' width='224' height='35' rx='8' fill='%23f8f9fa'/%3E%3Ctext x='40' y='412' fill='%23555' font-size='13'%3EbKash Payment%3C/text%3E%3Crect x='28' y='435' width='224' height='35' rx='8' fill='%23f8f9fa'/%3E%3Ctext x='40' y='457' fill='%23555' font-size='13'%3EPassword%3C/text%3E%3C/svg%3E" alt="Mobile App">
                </div>
            </div>
            
            <!-- Features Grid -->
            <div class="col-lg-8">
                <div class="row">
                    @forelse($features as $feature)
                    <div class="col-md-6 mb-3">
                        <div class="feature-item">
                            <div class="feature-icon-box">
                                <i class="{{ $feature->icon }}"></i>
                            </div>
                            <div class="feature-content">
                                <h4>{{ $feature->title }}</h4>
                                <p>{{ $feature->description }}</p>
                            </div>
                        </div>
                    </div>
                    @empty
                    <div class="col-12">
                        <p class="text-muted text-center">No features available yet.</p>
                    </div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
</section>

<!-- SMS Pricing Section -->
@if($smsPrices->count() > 0)
<section class="sms-pricing-section">
    <div class="container">
        <div class="section-title">
            <h2>SMS Price</h2>
        </div>
        <div class="row justify-content-center">
            @foreach($smsPrices as $price)
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="sms-price-card {{ $price->is_featured ? 'featured' : '' }}">
                    <div class="sms-price-header">
                        <h3>{{ $price->package_name }}</h3>
                        <div class="sms-base-price">
                            {{ number_format($price->base_price, 2) }} <span>BDT</span>
                        </div>
                        <div class="sms-minimum-buy">
                            Minimum Buy: {{ number_format($price->minimum_buy) }} {{ $price->minimum_buy > 1 ? 'SMS' : 'Tk' }}
                        </div>
                    </div>

                    @if($price->pricing_tiers && count($price->pricing_tiers) > 0)
                    <div class="sms-pricing-tiers">
                        <h5>Bulk Pricing:</h5>
                        @foreach($price->pricing_tiers as $tier)
                        <div class="pricing-tier-item">
                            <span>Buy {{ number_format($tier['quantity']) }}(sms)</span>
                            <strong>{{ number_format($tier['price'], 2) }} BDT</strong>
                        </div>
                        @endforeach
                    </div>
                    @endif

                    <ul class="sms-features-list">
                        @if($price->features)
                            @foreach($price->features as $feature)
                            <li>
                                <i class="fas fa-check-circle"></i>
                                <span>{{ $feature }}</span>
                            </li>
                            @endforeach
                        @endif
                    </ul>

                    <a href="{{ route('register') }}" class="sms-buy-button">
                        Buy Now
                    </a>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
@endif

<!-- Pricing Section -->
@if($packages->count() > 0)
<section id="pricing" class="pricing-section">
    <div class="container">
        <div class="section-title">
            <h2>Simple, Transparent Pricing</h2>
        </div>
        <div class="row">
            @foreach($packages as $package)
            <div class="col-md-6 col-lg-3 mb-4">
                <div class="pricing-card {{ $package->is_featured ? 'featured' : '' }}">
                    @if($package->is_featured)
                        <div class="pricing-badge">Most Popular</div>
                    @else
                        <div class="pricing-badge">{{ $package->name }}</div>
                    @endif
                    <h3>{{ $package->name }}</h3>
                    <div class="price">
                        ৳{{ number_format($package->price, 0) }}
                    </div>
                    <ul class="price-features">
                        <li><i class="fas fa-check"></i>{{ number_format($package->sms_count) }} SMS Credits</li>
                        <li><i class="fas fa-check"></i>{{ $package->smsGateway ? $package->smsGateway->gateway_name : 'Premium' }} Gateway</li>
                        <li><i class="fas fa-check"></i>Bulk SMS Support</li>
                        <li><i class="fas fa-check"></i>Real-time Reports</li>
                        <li><i class="fas fa-check"></i>24/7 Support</li>
                    </ul>
                    <a href="{{ route('register') }}" class="btn {{ $package->is_featured ? 'btn-light' : 'btn-register' }} w-100">
                        Get Started
                    </a>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
@endif

<!-- FAQ Section -->
@if($faqs->count() > 0)
<section class="faq-section">
    <div class="container">
        <div class="section-title">
            <h2>Frequently Asked Questions</h2>
        </div>
        <div class="row">
            <div class="col-lg-8 mx-auto">
                @foreach($faqs as $index => $faq)
                <div class="faq-item">
                    <div class="faq-question" onclick="toggleFaq({{ $index }})">
                        <h5>{{ $faq->question }}</h5>
                        <i class="fas fa-plus faq-icon" id="faq-icon-{{ $index }}"></i>
                    </div>
                    <div class="faq-answer" id="faq-answer-{{ $index }}">
                        <div class="faq-answer-content">
                            {{ $faq->answer }}
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
</section>
@endif

<!-- Comparison Table Section -->
@if($comparisons->count() > 0)
<section class="comparison-section">
    <div class="container">
        <div class="section-title">
            <h2>Why Choose Us Over Competitors?</h2>
            <p>See how we stack up against the competition</p>
        </div>
        <div class="comparison-table">
            <div class="comparison-header">
                <div>Feature</div>
                <div>{{ $siteName }}</div>
                <div>Others</div>
            </div>
            @foreach($comparisons as $comparison)
            <div class="comparison-row">
                <div class="comparison-feature">{{ $comparison->feature_name }}</div>
                <div class="comparison-check {{ $comparison->we_have ? 'yes' : 'no' }}">
                    <i class="fas fa-{{ $comparison->we_have ? 'check-circle' : 'times-circle' }}"></i>
                </div>
                <div class="comparison-check {{ $comparison->competitor_have ? 'yes' : 'no' }}">
                    <i class="fas fa-{{ $comparison->competitor_have ? 'check-circle' : 'times-circle' }}"></i>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
@endif

<!-- Blog Section -->
@if($blogs->count() > 0)
<section class="blog-section">
    <div class="container">
        <div class="section-title">
            <h2>Latest News & Updates</h2>
            <p>Stay updated with the latest SMS marketing tips and industry news</p>
        </div>
        <div class="row">
            @foreach($blogs as $blog)
            <div class="col-md-6 col-lg-3 mb-4">
                <div class="blog-card">
                    <div class="blog-image">
                        <i class="fas fa-newspaper"></i>
                    </div>
                    <div class="blog-content">
                        <span class="blog-category">{{ $blog->category }}</span>
                        <h4 class="blog-title">
                            <a href="{{ route('blog.show', $blog->slug) }}" style="color: inherit; text-decoration: none;">
                                {{ $blog->title }}
                            </a>
                        </h4>
                        <p class="blog-excerpt">{{ Str::limit($blog->excerpt, 80) }}</p>
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span class="blog-date">
                                <i class="far fa-calendar me-1"></i>{{ $blog->created_at->format('M d, Y') }}
                            </span>
                            <a href="{{ route('blog.show', $blog->slug) }}" style="color: #667eea; text-decoration: none; font-weight: 600; font-size: 13px;">
                                Read More <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
@endif

<!-- Video Demo Section -->
<section class="video-section">
    <div class="container">
        <div class="section-title">
            <h2>See How It Works</h2>
        </div>
        <div class="row">
            <div class="col-lg-10 mx-auto">
                <div class="video-container">
                    <iframe src="{{ $videoUrl }}" 
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                            allowfullscreen>
                    </iframe>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Online Button -->
<a href="{{ auth()->check() ? (auth()->user()->isAdmin() ? route('admin.dashboard') : route('user.dashboard')) : route('register') }}" class="online-btn">
    Online
</a>
@endsection

@push('scripts')
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Owl Carousel -->
<script src="https://cdn.jsdelivr.net/npm/owl.carousel@2.3.4/dist/owl.carousel.min.js"></script>

<script>
    $(document).ready(function(){
        // Initialize Owl Carousel
        $('.hero-slider .owl-carousel').owlCarousel({
            items: 1,
            loop: true,
            autoplay: true,
            autoplayTimeout: 5000,
            autoplayHoverPause: true,
            nav: true,
            dots: true,
            navText: ['<i class="fas fa-chevron-left"></i>', '<i class="fas fa-chevron-right"></i>'],
            animateOut: 'fadeOut',
            animateIn: 'fadeIn',
        });

        // Smooth scroll
        $('a[href^="#"]').on('click', function(e) {
            e.preventDefault();
            var target = $(this.getAttribute('href'));
            if(target.length) {
                $('html, body').stop().animate({
                    scrollTop: target.offset().top - 70
                }, 1000);
            }
        });
    });

    // FAQ Toggle Function
    function toggleFaq(index) {
        const answer = document.getElementById('faq-answer-' + index);
        const icon = document.getElementById('faq-icon-' + index);
        const question = answer.previousElementSibling;
        
        // Close all other FAQs
        document.querySelectorAll('.faq-answer').forEach((item, i) => {
            if (i !== index) {
                item.classList.remove('active');
                document.querySelectorAll('.faq-question')[i].classList.remove('active');
            }
        });
        
        // Toggle current FAQ
        answer.classList.toggle('active');
        question.classList.toggle('active');
    }
</script>
@endpush

