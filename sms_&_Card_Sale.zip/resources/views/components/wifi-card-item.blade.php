@props(['cardType'])

<div class="wifi-card-box">
    <div class="card-image-section">
        @if($cardType->image)
            <img src="{{ Storage::url($cardType->image) }}" alt="{{ $cardType->name }}">
        @else
            <div class="no-image-placeholder">
                <i class="fas fa-wifi"></i>
            </div>
        @endif
        
        @if($cardType->available_keys <= 0)
            <span class="stock-indicator out-of-stock">
                <i class="fas fa-times-circle"></i>
            </span>
        @endif
    </div>
    
    <div class="card-content-section">
        <div class="card-details-info">
            <div class="card-category">{{ $cardType->cardCategory->name }}</div>
            <div class="card-validity">{{ $cardType->validity_value }} {{ $cardType->validity_type === 'hours' ? 'Hours' : 'Days' }}</div>
        </div>
        
        <div class="card-price-section">
            <span class="price-amount">৳{{ number_format($cardType->price, 0) }}</span>
        </div>
        
        <div class="card-button-section">
            @if($cardType->available_keys > 0)
                <a href="{{ route('wifi-cards.checkout', $cardType->id) }}" class="btn-buy-now">
                    Buy Now
                </a>
            @else
                <button class="btn-buy-now disabled" disabled>
                    Out of Stock
                </button>
            @endif
        </div>
    </div>
</div>

