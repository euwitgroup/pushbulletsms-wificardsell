@php
    use App\Models\Setting;
    $siteName = Setting::get('site_name', 'SMS & Card Sale');
    $userSiteName = Setting::get('user_site_name', $siteName);
    $siteFavicon = Setting::get('site_favicon', '');
    $siteLogo = Setting::get('site_logo', '');
    $primaryColor = Setting::get('primary_color', '#667eea');
    $secondaryColor = Setting::get('secondary_color', '#764ba2');
    $metaTitle = Setting::get('meta_title', $siteName);
    $metaDescription = Setting::get('meta_description', '');
    $metaKeywords = Setting::get('meta_keywords', '');
@endphp
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    
    <!-- SEO Meta Tags -->
    <title>@yield('title', $userSiteName)</title>
    <meta name="description" content="{{ $metaDescription }}">
    <meta name="keywords" content="{{ $metaKeywords }}">
    
    <!-- Favicon -->
    @if($siteFavicon)
        <link rel="icon" type="image/x-icon" href="{{ asset('storage/' . $siteFavicon) }}">
    @endif
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    
    <style>
        :root {
            --sidebar-bg: #1a1d2e;
            --sidebar-hover: #252a3d;
            --primary-color: {{ $primaryColor }};
            --secondary-color: {{ $secondaryColor }};
            --primary-gradient: linear-gradient(135deg, {{ $primaryColor }} 0%, {{ $secondaryColor }} 100%);
            --success-gradient: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            --warning-gradient: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --info-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        }
        
        /* Enhanced Sidebar with Scrollbar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 280px;
            background: var(--sidebar-bg);
            box-shadow: 4px 0 20px rgba(0,0,0,0.1);
            z-index: 1000;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }
        
        .sidebar-header {
            padding: 24px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            flex-shrink: 0;
        }
        
        .sidebar-header h4 {
            font-weight: 700;
            font-size: 1.1rem;
            margin: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .sidebar-body {
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
            padding: 20px 0;
        }
        
        /* Custom Scrollbar */
        .sidebar-body::-webkit-scrollbar {
            width: 6px;
        }
        
        .sidebar-body::-webkit-scrollbar-track {
            background: rgba(255,255,255,0.05);
        }
        
        .sidebar-body::-webkit-scrollbar-thumb {
            background: rgba(255,255,255,0.2);
            border-radius: 10px;
        }
        
        .sidebar-body::-webkit-scrollbar-thumb:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
            flex-shrink: 0;
        }
        
        .sidebar .nav-link {
            color: rgba(255,255,255,0.7);
            padding: 12px 20px;
            margin: 4px 15px;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            font-weight: 500;
            display: flex;
            align-items: center;
        }
        
        .sidebar .nav-link i {
            width: 20px;
            margin-right: 12px;
            font-size: 1.1rem;
        }
        
        .sidebar .nav-link:hover {
            background: var(--sidebar-hover);
            color: white;
            transform: translateX(4px);
        }
        
        .sidebar .nav-link.active {
            background: #6c757d;
            color: white;
            box-shadow: 0 2px 8px rgba(108, 117, 125, 0.3);
        }
        
        /* Sidebar Section Header */
        .sidebar-section-header {
            color: rgba(255,255,255,0.4);
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 20px 20px 8px 20px;
            margin-top: 8px;
        }
        
        .sidebar-section-header:first-child {
            margin-top: 0;
        }
        
        /* Main Content Area */
        .main-content {
            margin-left: 280px;
            min-height: 100vh;
            background: #f5f6fa;
        }

        /* User Header */
        .user-header {
            background: white;
            padding: 12px 20px;
            border-bottom: 1px solid #e9ecef;
            position: sticky;
            top: 0;
            z-index: 999;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }

        .header-welcome {
            font-size: 0.95rem;
            color: #2c3e50;
            font-weight: 600;
        }

        .header-welcome i {
            color: var(--primary-color);
        }

        /* Balance Display */
        .header-balance-section {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .balance-display {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 8px 16px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
        }

        .balance-display i {
            color: white;
            font-size: 16px;
        }

        .balance-text {
            color: white;
            font-size: 13px;
            font-weight: 600;
            line-height: 1;
        }

        .balance-amount {
            color: white;
            font-size: 18px;
            font-weight: 700;
            line-height: 1;
        }

        .btn-deposit {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(245, 87, 108, 0.3);
            text-decoration: none;
        }

        .btn-deposit:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(245, 87, 108, 0.4);
            color: white;
        }

        .btn-deposit i {
            font-size: 14px;
        }

        /* Mobile Menu Toggle */
        .mobile-menu-toggle {
            display: none;
            width: 40px;
            height: 40px;
            border-radius: 8px;
            background: var(--primary-gradient);
            border: none;
            color: white;
            cursor: pointer;
            transition: all 0.3s ease;
            align-items: center;
            justify-content: center;
        }

        .mobile-menu-toggle:hover {
            transform: scale(1.05);
        }

        .mobile-menu-toggle i {
            font-size: 18px;
        }

        /* Mobile Sidebar Overlay */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 998;
        }

        .sidebar-overlay.active {
            display: block;
        }

        /* Mobile Responsive */
        @media (max-width: 991px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }

            .sidebar.mobile-open {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
            }

            .mobile-menu-toggle {
                display: flex;
            }

            .header-welcome {
                font-size: 0.85rem;
            }

            .header-welcome strong {
                display: none;
            }

            .user-header {
                padding: 10px 15px;
            }

            .btn-header-profile {
                padding: 3px 6px;
            }

            .user-avatar {
                width: 30px;
                height: 30px;
            }

            .balance-display {
                padding: 6px 12px;
            }

            .balance-text {
                font-size: 11px;
            }

            .balance-amount {
                font-size: 16px;
            }

            .btn-deposit {
                padding: 6px 16px;
                font-size: 13px;
            }
        }

        @media (max-width: 576px) {
            .header-welcome i {
                display: none;
            }

            .btn-header-action {
                width: 32px;
                height: 32px;
            }

            .user-avatar {
                width: 28px;
                height: 28px;
                font-size: 12px;
            }

            .btn-header-profile {
                padding: 3px 5px;
            }

            .btn-header-profile i.fa-chevron-down {
                font-size: 9px;
            }

            .header-actions {
                gap: 8px !important;
            }

            .balance-display {
                padding: 5px 10px;
            }

            .balance-text {
                display: none;
            }

            .balance-amount {
                font-size: 14px;
            }

            .btn-deposit {
                padding: 5px 12px;
                font-size: 12px;
            }

            .btn-deposit span {
                display: none;
            }

            .header-balance-section {
                gap: 8px;
            }
        }

        .btn-header-action {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            border: 2px solid #e9ecef;
            background: white;
            color: #495057;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            padding: 0;
        }

        .btn-header-action:hover {
            border-color: var(--primary-color);
            background: var(--primary-color);
            color: white;
            transform: scale(1.05);
        }

        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #dc3545;
            color: white;
            font-size: 10px;
            font-weight: 700;
            padding: 2px 6px;
            border-radius: 10px;
            min-width: 18px;
            text-align: center;
        }

        .btn-header-profile {
            background: white;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 4px 8px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .btn-header-profile:hover {
            border-color: var(--primary-color);
            background: #f8f9fa;
        }

        .user-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: var(--primary-gradient);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 14px;
            object-fit: cover;
            border: 2px solid #fff;
            box-shadow: 0 2px 6px rgba(0,0,0,0.12);
            flex-shrink: 0;
        }

        .user-avatar img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }

        .btn-header-profile i.fa-chevron-down {
            font-size: 10px;
            color: #6c757d;
        }

        /* Dropdown Menu Styling */
        .dropdown-menu.user-dropdown {
            min-width: 240px;
            border: none;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.15);
            padding: 0;
            margin-top: 8px;
        }

        .user-dropdown-header {
            padding: 16px 20px;
            border-bottom: 1px solid #f0f0f0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px 12px 0 0;
        }

        .user-dropdown-avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .user-dropdown-avatar img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }

        .user-dropdown-name {
            font-weight: 700;
            font-size: 15px;
            color: white;
            margin-bottom: 2px;
        }

        .user-dropdown-email {
            font-size: 12px;
            color: rgba(255,255,255,0.9);
            margin-bottom: 4px;
        }

        .user-dropdown-role {
            display: inline-block;
            font-size: 10px;
            padding: 3px 10px;
            background: rgba(255,255,255,0.2);
            border-radius: 12px;
            color: white;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .user-dropdown .dropdown-item {
            padding: 12px 20px;
            font-size: 14px;
            color: #000000;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 500;
        }

        .user-dropdown .dropdown-item span {
            color: #000000;
        }

        .user-dropdown .dropdown-item i {
            width: 20px;
            font-size: 16px;
            color: #666;
        }

        .user-dropdown .dropdown-item:hover {
            background: #f8f9fa;
            color: #000000;
        }

        .user-dropdown .dropdown-item:hover span {
            color: #000000;
        }

        .user-dropdown .dropdown-item:hover i {
            color: var(--primary-color);
        }

        .user-dropdown .dropdown-divider {
            margin: 8px 0;
            opacity: 0.1;
        }

        .user-dropdown .dropdown-item.text-danger {
            color: #dc3545;
        }

        .user-dropdown .dropdown-item.text-danger span {
            color: #dc3545;
        }

        .user-dropdown .dropdown-item.text-danger:hover {
            background: #fff5f5;
            color: #dc3545;
        }

        .user-dropdown .dropdown-item.text-danger:hover i {
            color: #dc3545;
        }

        .notification-dropdown {
            width: 380px;
            border: none;
            box-shadow: 0 8px 24px rgba(0,0,0,0.15);
            border-radius: 12px;
            padding: 0;
        }

        .notification-dropdown .dropdown-header {
            padding: 15px 20px;
            background: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
            font-weight: 600;
        }

        .notification-item-dropdown {
            padding: 12px 20px;
            border-bottom: 1px solid #f0f0f0;
            transition: background 0.2s;
            cursor: pointer;
        }

        .notification-item-dropdown:hover {
            background: #f8f9fa;
        }

        .notification-item-dropdown.unread {
            background: #f0f5ff;
        }

        .notification-icon-small {
            width: 35px;
            height: 35px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            color: white;
            flex-shrink: 0;
        }

        .notification-text {
            flex: 1;
            margin-left: 12px;
        }

        .notification-title-small {
            font-weight: 600;
            font-size: 13px;
            color: #2c3e50;
            margin-bottom: 2px;
        }

        .notification-message-small {
            font-size: 12px;
            color: #6c757d;
            line-height: 1.4;
        }

        .notification-time-small {
            font-size: 11px;
            color: #95a5a6;
        }
        
        /* Enhanced Cards */
        .card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 2px 12px rgba(0,0,0,0.06);
            margin-bottom: 24px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 24px rgba(0,0,0,0.12);
        }
        
        /* Stat Cards with Gradients */
        .stat-card {
            border-radius: 16px;
            padding: 24px;
            color: white;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -20%;
            width: 200px;
            height: 200px;
            background: rgba(255,255,255,0.1);
            border-radius: 50%;
        }
        
        .stat-card-primary {
            background: var(--primary-gradient);
        }
        
        .stat-card-success {
            background: var(--success-gradient);
        }
        
        .stat-card-warning {
            background: var(--warning-gradient);
        }
        
        .stat-card-info {
            background: var(--info-gradient);
        }
        
        /* Modern Buttons */
        .btn {
            border-radius: 10px;
            padding: 10px 24px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: var(--primary-gradient);
            border: none;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4);
        }
        
        .btn-gradient-success {
            background: var(--success-gradient);
            border: none;
            color: white;
        }
        
        .btn-gradient-info {
            background: var(--info-gradient);
            border: none;
            color: white;
        }
        
        /* Table Styling */
        .table {
            border-radius: 12px;
            overflow: hidden;
        }
        
        .table thead {
            background: #f8f9fa;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.5px;
        }
        
        .table tbody tr {
            transition: background 0.2s ease;
        }
        
        .table tbody tr:hover {
            background: #f8f9fa;
        }
        
        /* Status Badges */
        .badge-status-sent {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
            padding: 6px 12px;
            border-radius: 8px;
        }
        
        .badge-status-failed {
            background: linear-gradient(135deg, #eb3349 0%, #f45c43 100%);
            color: white;
            padding: 6px 12px;
            border-radius: 8px;
        }
        
        .badge-status-pending {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 6px 12px;
            border-radius: 8px;
        }
        
        /* User Info in Sidebar */
        .user-info {
            background: rgba(255,255,255,0.05);
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 15px;
        }
        
        .user-info .user-name {
            font-weight: 600;
            font-size: 0.95rem;
            color: white;
            margin-bottom: 8px;
        }
        
        .user-info .user-balance {
            font-size: 0.85rem;
            color: rgba(255,255,255,0.7);
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .user-info .user-balance strong {
            color: #38ef7d;
        }
        
        /* Logout Button */
        .btn-logout {
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            color: white;
            width: 100%;
            padding: 10px;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-logout:hover {
            background: rgba(255,255,255,0.2);
            color: white;
            transform: translateY(-2px);
        }

        /* SweetAlert2 Custom Styling */
        .swal2-popup {
            border-radius: 10px !important;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        }

        .swal2-title {
            font-size: 1.5rem !important;
            font-weight: 600 !important;
            color: #1a1d2e !important;
        }

        .swal2-html-container {
            font-size: 0.95rem !important;
            color: #6c757d !important;
        }

        .swal2-confirm {
            border-radius: 5px !important;
            padding: 0.5rem 2rem !important;
            font-weight: 600 !important;
        }

        .swal2-cancel {
            border-radius: 5px !important;
            padding: 0.5rem 2rem !important;
            font-weight: 600 !important;
        }

        .swal2-timer-progress-bar {
            background: var(--primary-color) !important;
        }

        .swal2-icon {
            border-width: 3px !important;
        }

        /* SweetAlert2 Toast Styling */
        .swal2-toast {
            border-radius: 10px !important;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15) !important;
        }

        .swal2-toast .swal2-title {
            font-size: 0.95rem !important;
            font-weight: 600 !important;
            color: #1a1d2e !important;
        }

        .swal2-toast .swal2-icon {
            margin: 0 0.5rem 0 0 !important;
        }
    </style>
    @stack('styles')
</head>
<body>
    <!-- Mobile Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <div class="sidebar text-white" id="sidebar">
        <!-- Sidebar Header -->
        <div class="sidebar-header">
            @if($siteLogo)
                <img src="{{ asset('storage/' . $siteLogo) }}" 
                     alt="{{ $userSiteName }}" 
                     style="max-width: {{ Setting::get('logo_width', '150') }}px; height: auto;">
            @else
                <h4>
                    <i class="fas fa-sms me-2"></i>{{ $userSiteName }}
                </h4>
            @endif
        </div>
        
        <!-- Sidebar Body with Scrollbar -->
        <div class="sidebar-body">
            <nav class="nav flex-column">
                @auth
                    @if(auth()->user()->isAdmin())
                        <!-- Admin Menu -->
                        <div class="sidebar-section-header">Main</div>
                        <a class="nav-link {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}" href="{{ route('admin.dashboard') }}">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>Dashboard</span>
                        </a>
                        
                        <div class="sidebar-section-header">User Management</div>
                        <a class="nav-link {{ request()->routeIs('admin.users.*') ? 'active' : '' }}" href="{{ route('admin.users.index') }}">
                            <i class="fas fa-users"></i>
                            <span>Users</span>
                        </a>
                        
                        <div class="sidebar-section-header">SMS Management</div>
                        <a class="nav-link {{ request()->routeIs('admin.packages.*') ? 'active' : '' }}" href="{{ route('admin.packages.index') }}">
                            <i class="fas fa-box"></i>
                            <span>SMS Packages</span>
                        </a>
                        <a class="nav-link {{ request()->routeIs('admin.sms-history') ? 'active' : '' }}" href="{{ route('admin.sms-history') }}">
                            <i class="fas fa-history"></i>
                            <span>SMS History</span>
                        </a>
                        
                        <div class="sidebar-section-header">Financial</div>
                        <a class="nav-link {{ request()->routeIs('admin.transactions') ? 'active' : '' }}" href="{{ route('admin.transactions') }}">
                            <i class="fas fa-exchange-alt"></i>
                            <span>Transactions</span>
                        </a>
                        
                        <div class="sidebar-section-header">System</div>
                        <a class="nav-link {{ request()->routeIs('admin.settings') ? 'active' : '' }}" href="{{ route('admin.settings') }}">
                            <i class="fas fa-cog"></i>
                            <span>Settings</span>
                        </a>
                    @else
                        <!-- User Menu -->
                        <div class="sidebar-section-header">Main</div>
                        <a class="nav-link {{ request()->routeIs('user.dashboard') ? 'active' : '' }}" href="{{ route('user.dashboard') }}">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>Dashboard</span>
                        </a>
                        
                        <div class="sidebar-section-header">SMS Services</div>
                        <a class="nav-link {{ request()->routeIs('user.sms.create') ? 'active' : '' }}" href="{{ route('user.sms.create') }}">
                            <i class="fas fa-paper-plane"></i>
                            <span>Send SMS</span>
                        </a>
                        <a class="nav-link {{ request()->routeIs('user.sms.history') ? 'active' : '' }}" href="{{ route('user.sms.history') }}">
                            <i class="fas fa-history"></i>
                            <span>SMS History</span>
                        </a>
                        
                        <div class="sidebar-section-header">Payments</div>
                        <a class="nav-link {{ request()->routeIs('user.payment.packages') ? 'active' : '' }}" href="{{ route('user.payment.packages') }}">
                            <i class="fas fa-wallet"></i>
                            <span>Buy Balance</span>
                        </a>
                        <a class="nav-link {{ request()->routeIs('user.transactions') ? 'active' : '' }}" href="{{ route('user.transactions') }}">
                            <i class="fas fa-receipt"></i>
                            <span>Transactions</span>
                        </a>
                        
                        <div class="sidebar-section-header">System</div>
                        <a class="nav-link {{ request()->routeIs('user.profile') ? 'active' : '' }}" href="{{ route('user.profile') }}">
                            <i class="fas fa-user-circle"></i>
                            <span>My Profile</span>
                            @if(auth()->user()->kyc_status == 'pending')
                                <span class="badge bg-warning text-dark ms-auto">KYC</span>
                            @elseif(auth()->user()->kyc_status == 'rejected')
                                <span class="badge bg-danger ms-auto">KYC</span>
                            @endif
                        </a>
                        <a class="nav-link {{ request()->routeIs('user.notifications.*') ? 'active' : '' }}" href="{{ route('user.notifications.index') }}">
                            <i class="fas fa-bell"></i>
                            <span>Notifications</span>
                            @php
                                $userUnreadCount = \App\Models\Notification::forUser(auth()->id())->unread()->count();
                            @endphp
                            @if($userUnreadCount > 0)
                                <span class="badge bg-danger ms-auto">{{ $userUnreadCount }}</span>
                            @endif
                        </a>
                    @endif
                @endauth
            </nav>
        </div>
        
        <!-- Sidebar Footer -->
        @auth
        <div class="sidebar-footer">
            <div class="user-info">
                <div class="user-name">
                    <i class="fas fa-user-circle me-2"></i>{{ auth()->user()->name }}
                </div>
                @if(!auth()->user()->isAdmin())
                <div class="user-balance">
                    <i class="fas fa-wallet"></i>
                    <span>Balance: <strong>৳{{ number_format(auth()->user()->balance, 2) }}</strong></span>
                </div>
                @endif
            </div>
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button type="submit" class="btn-logout">
                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                </button>
            </form>
        </div>
        @endauth
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- User Header -->
        @auth
        <div class="user-header">
            <div class="d-flex justify-content-between align-items-center">
                <!-- Mobile Menu Toggle & Page Title -->
                <div class="header-left d-flex align-items-center gap-3">
                    <button class="mobile-menu-toggle" id="mobileMenuToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h5 class="header-welcome mb-0">
                        <i class="fas fa-home me-2"></i>Welcome back, <strong>{{ Auth::user()->name }}</strong>
                    </h5>
                </div>

                <!-- Header Actions -->
                <div class="header-actions d-flex align-items-center gap-3">
                    <!-- Balance & Deposit Section -->
                    @if(!Auth::user()->isAdmin())
                    <div class="header-balance-section">
                        <!-- Balance Display -->
                        <div class="balance-display">
                            <i class="fas fa-wallet"></i>
                            <div>
                                <div class="balance-text">Balance</div>
                                <div class="balance-amount">৳{{ number_format(Auth::user()->balance, 2) }}</div>
                            </div>
                        </div>
                        
                        <!-- Deposit Button -->
                        <a href="{{ route('user.payment.packages') }}" class="btn-deposit">
                            <i class="fas fa-plus-circle"></i>
                            <span>Deposit</span>
                        </a>
                    </div>
                    @endif

                    <!-- Notifications Dropdown -->
                    <div class="dropdown">
                        <button class="btn btn-header-action position-relative" type="button" id="notificationDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-bell"></i>
                            <span class="notification-badge" id="user-notification-count" style="display: none;">0</span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end notification-dropdown" aria-labelledby="notificationDropdown">
                            <li class="dropdown-header d-flex justify-content-between align-items-center">
                                <strong>Notifications</strong>
                                <a href="{{ route('user.notifications.index') }}" class="text-primary" style="font-size: 12px;">View All</a>
                            </li>
                            <li><hr class="dropdown-divider m-0"></li>
                            <div id="user-notifications-list" style="max-height: 350px; overflow-y: auto;">
                                <li class="text-center py-3">
                                    <small class="text-muted">Loading...</small>
                                </li>
                            </div>
                        </ul>
                    </div>

                    <!-- User Profile Dropdown -->
                    <div class="dropdown">
                        <button class="btn btn-header-profile" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <div class="user-avatar">
                                @if(Auth::user()->profile_photo)
                                    <img src="{{ asset('storage/' . Auth::user()->profile_photo) }}" alt="{{ Auth::user()->name }}">
                                @else
                                    <i class="fas fa-user"></i>
                                @endif
                            </div>
                            <i class="fas fa-chevron-down"></i>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end user-dropdown" aria-labelledby="userDropdown">
                            <!-- User Info Header -->
                            <li class="user-dropdown-header">
                                <div class="user-dropdown-avatar">
                                    @if(Auth::user()->profile_photo)
                                        <img src="{{ asset('storage/' . Auth::user()->profile_photo) }}" alt="{{ Auth::user()->name }}">
                                    @else
                                        <i class="fas fa-user" style="color: #667eea; font-size: 24px;"></i>
                                    @endif
                                </div>
                                <div class="user-dropdown-name">{{ Auth::user()->name }}</div>
                                <div class="user-dropdown-email">{{ Auth::user()->email }}</div>
                                <span class="user-dropdown-role">{{ Auth::user()->isAdmin() ? 'Administrator' : 'User Account' }}</span>
                            </li>
                            
                            <!-- Menu Items -->
                            <li>
                                <a class="dropdown-item" href="{{ route('user.dashboard') }}">
                                    <i class="fas fa-tachometer-alt"></i>
                                    <span>Dashboard</span>
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="{{ route('user.profile') }}">
                                    <i class="fas fa-user-circle"></i>
                                    <span>My Profile</span>
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="{{ route('user.notifications.index') }}">
                                    <i class="fas fa-bell"></i>
                                    <span>Notifications</span>
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="{{ route('user.transactions') }}">
                                    <i class="fas fa-receipt"></i>
                                    <span>Transactions</span>
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="{{ route('user.sms.history') }}">
                                    <i class="fas fa-history"></i>
                                    <span>SMS History</span>
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="{{ route('user.payment.packages') }}">
                                    <i class="fas fa-shopping-cart"></i>
                                    <span>Buy Balance</span>
                                </a>
                            </li>
                            
                            <li><hr class="dropdown-divider"></li>
                            
                            <li>
                                <a class="dropdown-item text-danger" href="{{ route('logout') }}"
                                   onclick="event.preventDefault(); document.getElementById('user-logout-form').submit();">
                                    <i class="fas fa-sign-out-alt"></i>
                                    <span>Logout</span>
                                </a>
                                <form id="user-logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                    @csrf
                                </form>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        @endauth

            <div class="container-fluid p-4">
                <!-- Alerts -->
                @if(session('success'))
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                @endif

                @if(session('error'))
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i>{{ session('error') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                @endif

                @if(session('info'))
                <div class="alert alert-info alert-dismissible fade show" role="alert">
                    <i class="fas fa-info-circle me-2"></i>{{ session('info') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                @endif

                @if ($errors->any())
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <ul class="mb-0">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                @endif

                @yield('content')
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <!-- Laravel Session Messages with SweetAlert2 -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            @if(session('success'))
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast) => {
                        toast.addEventListener('mouseenter', Swal.stopTimer)
                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                    }
                });

                Toast.fire({
                    icon: 'success',
                    title: '{{ session('success') }}'
                });
            @endif

            @if(session('error'))
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: '{{ session('error') }}',
                    confirmButtonColor: '#667eea',
                    confirmButtonText: 'OK',
                    timer: 5000,
                    timerProgressBar: true,
                    showClass: {
                        popup: 'animate__animated animate__fadeInDown'
                    },
                    hideClass: {
                        popup: 'animate__animated animate__fadeOutUp'
                    }
                });
            @endif

            @if(session('warning'))
                Swal.fire({
                    icon: 'warning',
                    title: 'Warning!',
                    text: '{{ session('warning') }}',
                    confirmButtonColor: '#667eea',
                    confirmButtonText: 'OK',
                    timer: 4000,
                    timerProgressBar: true,
                    showClass: {
                        popup: 'animate__animated animate__fadeInDown'
                    },
                    hideClass: {
                        popup: 'animate__animated animate__fadeOutUp'
                    }
                });
            @endif

            @if(session('info'))
                Swal.fire({
                    icon: 'info',
                    title: 'Information',
                    text: '{{ session('info') }}',
                    confirmButtonColor: '#667eea',
                    confirmButtonText: 'OK',
                    timer: 4000,
                    timerProgressBar: true,
                    showClass: {
                        popup: 'animate__animated animate__fadeInDown'
                    },
                    hideClass: {
                        popup: 'animate__animated animate__fadeOutUp'
                    }
                });
            @endif

            @if($errors->any())
                Swal.fire({
                    icon: 'error',
                    title: 'Validation Errors',
                    html: '<ul style="text-align: left;">' +
                        @foreach($errors->all() as $error)
                            '<li>{{ $error }}</li>' +
                        @endforeach
                        '</ul>',
                    confirmButtonColor: '#667eea',
                    confirmButtonText: 'OK',
                    timer: 6000,
                    timerProgressBar: true
                });
            @endif
        });
    </script>
    
    <!-- Mobile Menu Toggle Script -->
    <script>
        // Mobile Menu Toggle
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuToggle = document.getElementById('mobileMenuToggle');
            const sidebar = document.getElementById('sidebar');
            const sidebarOverlay = document.getElementById('sidebarOverlay');

            if (mobileMenuToggle) {
                // Toggle menu on button click
                mobileMenuToggle.addEventListener('click', function() {
                    sidebar.classList.toggle('mobile-open');
                    sidebarOverlay.classList.toggle('active');
                    
                    // Change icon
                    const icon = this.querySelector('i');
                    if (sidebar.classList.contains('mobile-open')) {
                        icon.classList.remove('fa-bars');
                        icon.classList.add('fa-times');
                    } else {
                        icon.classList.remove('fa-times');
                        icon.classList.add('fa-bars');
                    }
                });

                // Close menu when clicking overlay
                sidebarOverlay.addEventListener('click', function() {
                    sidebar.classList.remove('mobile-open');
                    sidebarOverlay.classList.remove('active');
                    
                    const icon = mobileMenuToggle.querySelector('i');
                    icon.classList.remove('fa-times');
                    icon.classList.add('fa-bars');
                });

                // Close menu when clicking a link (for better UX)
                const sidebarLinks = sidebar.querySelectorAll('.nav-link');
                sidebarLinks.forEach(link => {
                    link.addEventListener('click', function() {
                        if (window.innerWidth < 992) {
                            sidebar.classList.remove('mobile-open');
                            sidebarOverlay.classList.remove('active');
                            
                            const icon = mobileMenuToggle.querySelector('i');
                            icon.classList.remove('fa-times');
                            icon.classList.add('fa-bars');
                        }
                    });
                });
            }
        });
    </script>

    <!-- User Notifications Script -->
    @auth
    <script>
        // Load notifications on page load
        document.addEventListener('DOMContentLoaded', function() {
            loadUserNotifications();
            
            // Refresh notifications every 30 seconds
            setInterval(loadUserNotifications, 30000);
        });

        function loadUserNotifications() {
            fetch('{{ route("user.notifications.recent") }}', {
                method: 'GET',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                    'Accept': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                updateNotificationCount(data.notifications.length);
                displayNotifications(data.notifications);
            })
            .catch(error => {
                console.error('Error loading notifications:', error);
            });
        }

        function updateNotificationCount(count) {
            const badge = document.getElementById('user-notification-count');
            if (count > 0) {
                badge.textContent = count > 99 ? '99+' : count;
                badge.style.display = 'block';
            } else {
                badge.style.display = 'none';
            }
        }

        function displayNotifications(notifications) {
            const listContainer = document.getElementById('user-notifications-list');
            
            if (notifications.length === 0) {
                listContainer.innerHTML = `
                    <li class="text-center py-4">
                        <i class="fas fa-bell-slash text-muted mb-2" style="font-size: 32px;"></i>
                        <p class="text-muted mb-0" style="font-size: 13px;">No notifications</p>
                    </li>
                `;
                return;
            }

            let html = '';
            notifications.forEach(notification => {
                const iconColor = getColorClass(notification.color);
                const unreadClass = notification.is_read ? '' : 'unread';
                
                html += `
                    <li class="notification-item-dropdown ${unreadClass}" onclick="handleNotificationClick(${notification.id}, '${notification.link || ''}')">
                        <div class="d-flex align-items-start">
                            <div class="notification-icon-small bg-${iconColor}">
                                <i class="fas ${notification.icon || 'fa-bell'}"></i>
                            </div>
                            <div class="notification-text">
                                <div class="notification-title-small">${escapeHtml(notification.title)}</div>
                                <div class="notification-message-small">${escapeHtml(truncate(notification.message, 80))}</div>
                                <div class="notification-time-small mt-1">
                                    <i class="far fa-clock me-1"></i>${notification.time_ago}
                                </div>
                            </div>
                        </div>
                    </li>
                `;
            });

            listContainer.innerHTML = html;
        }

        function handleNotificationClick(id, link) {
            // Mark as read
            fetch(`/user/notifications/${id}/read`, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                    'Accept': 'application/json'
                }
            });

            // Navigate if link exists
            if (link) {
                window.location.href = link;
            } else {
                window.location.href = '{{ route("user.notifications.index") }}';
            }
        }

        function getColorClass(color) {
            const colorMap = {
                'primary': 'primary',
                'success': 'success',
                'danger': 'danger',
                'warning': 'warning',
                'info': 'info',
                'secondary': 'secondary'
            };
            return colorMap[color] || 'info';
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        function truncate(str, length) {
            if (str.length <= length) return str;
            return str.substring(0, length) + '...';
        }
    </script>
    @endauth
    
    @stack('scripts')
</body>
</html>
