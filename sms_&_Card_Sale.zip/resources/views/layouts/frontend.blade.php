@php
    use App\Models\Setting;
    use App\Models\ContactInfo;
    $siteName = Setting::get('site_name', 'SMS & Card Sale');
    $siteFavicon = Setting::get('site_favicon', '');
    $siteLogo = Setting::get('site_logo', '');
    $primaryColor = Setting::get('primary_color', '#667eea');
    $secondaryColor = Setting::get('secondary_color', '#764ba2');
    $metaTitle = Setting::get('meta_title', $siteName);
    $metaDescription = Setting::get('meta_description', '');
    $metaKeywords = Setting::get('meta_keywords', '');
    $copyrightText = Setting::get('copyright_text', '© ' . date('Y') . ' ' . $siteName . '. All rights reserved.');
    
    // Fetch contact information for footer
    $footerPhones = ContactInfo::active()->byType('phone')->ordered()->limit(2)->get();
    $footerEmails = ContactInfo::active()->byType('email')->ordered()->limit(2)->get();
    $footerAddress = ContactInfo::active()->byType('address')->ordered()->first();
    $footerHours = ContactInfo::active()->byType('hours')->ordered()->first();
    $footerSocials = ContactInfo::active()->byType('social')->ordered()->get();
@endphp
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    
    <!-- SEO Meta Tags -->
    <title>@yield('title', $metaTitle)</title>
    <meta name="description" content="@yield('meta_description', $metaDescription)">
    <meta name="keywords" content="@yield('meta_keywords', $metaKeywords)">
    
    <!-- Favicon -->
    @if($siteFavicon)
        <link rel="icon" type="image/x-icon" href="{{ asset('storage/' . $siteFavicon) }}">
    @endif
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    
    <style>
        :root {
            --primary-color: {{ $primaryColor }};
            --secondary-color: {{ $secondaryColor }};
            --dark-color: #2c3e50;
            --light-color: #f8f9fa;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
        }

        /* Header Styles */
        .main-header {
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            position: sticky;
            top: 0;
            z-index: 1000;
            transition: all 0.3s ease;
        }

        .main-header.scrolled {
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }

        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
        }

        .site-logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            font-size: 24px;
            font-weight: 700;
            color: var(--dark-color);
            gap: 10px;
        }

        .site-logo img {
            max-height: 45px;
            width: auto;
        }

        .site-logo i {
            font-size: 30px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .main-nav {
            display: flex;
            align-items: center;
            gap: 35px;
        }

        .main-nav a {
            color: var(--dark-color);
            text-decoration: none;
            font-weight: 500;
            font-size: 15px;
            transition: all 0.3s ease;
            position: relative;
            padding: 5px 0;
        }

        .main-nav a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            transition: width 0.3s ease;
        }

        .main-nav a:hover::after,
        .main-nav a.active::after {
            width: 100%;
        }

        .main-nav a:hover,
        .main-nav a.active {
            color: var(--primary-color);
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .btn-header {
            padding: 10px 25px;
            border-radius: 50px;
            font-weight: 600;
            font-size: 14px;
            text-decoration: none;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }

        .btn-login {
            background: white;
            color: var(--primary-color);
            border: 2px solid var(--primary-color);
        }

        .btn-login:hover {
            background: var(--primary-color);
            color: white;
            transform: translateY(-2px);
        }

        .btn-register {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        .btn-register:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }

        .btn-dashboard {
            background: linear-gradient(135deg, #11998e, #38ef7d);
            color: white;
            box-shadow: 0 4px 15px rgba(17, 153, 142, 0.3);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .btn-dashboard:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(17, 153, 142, 0.4);
            color: white;
        }

        .mobile-menu-toggle {
            display: none;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            color: white;
            width: 40px;
            height: 40px;
            border-radius: 8px;
            cursor: pointer;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }

        /* Mobile Menu */
        .mobile-menu {
            display: none;
            position: fixed;
            top: 0;
            right: -100%;
            width: 280px;
            height: 100vh;
            background: white;
            box-shadow: -2px 0 20px rgba(0,0,0,0.1);
            transition: right 0.3s ease;
            z-index: 1001;
            flex-direction: column;
            padding: 20px;
        }

        .mobile-menu.active {
            right: 0;
        }

        .mobile-menu-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e9ecef;
        }

        .mobile-menu-close {
            background: #f8f9fa;
            border: none;
            width: 35px;
            height: 35px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--dark-color);
        }

        .mobile-nav {
            display: flex;
            flex-direction: column;
            gap: 0;
        }

        .mobile-nav a {
            color: var(--dark-color);
            text-decoration: none;
            padding: 15px 10px;
            border-bottom: 1px solid #f0f0f0;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .mobile-nav a i {
            width: 20px;
            text-align: center;
            color: var(--primary-color);
        }

        .mobile-auth-buttons {
            margin-top: auto;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .mobile-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
        }

        .mobile-overlay.active {
            display: block;
        }

        /* Footer Styles */
        .main-footer {
            background: #1a1d2e;
            color: rgba(255,255,255,0.8);
            padding: 60px 0 20px;
            margin-top: 80px;
        }

        .footer-widget h5 {
            color: white;
            font-weight: 700;
            margin-bottom: 20px;
            font-size: 18px;
        }

        .footer-widget ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .footer-widget ul li {
            margin-bottom: 12px;
        }

        .footer-widget ul li a {
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            transition: all 0.3s ease;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .footer-widget ul li a:hover {
            color: white;
            padding-left: 5px;
        }

        .footer-widget ul li a i {
            color: var(--primary-color);
            width: 16px;
        }

        .footer-about p {
            font-size: 14px;
            line-height: 1.8;
            margin-bottom: 20px;
        }

        .social-links {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }

        .social-links a {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(255,255,255,0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .social-links a:hover {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            transform: translateY(-3px);
        }

        .footer-bottom {
            margin-top: 50px;
            padding-top: 25px;
            border-top: 1px solid rgba(255,255,255,0.1);
            text-align: center;
            font-size: 14px;
        }

        .footer-bottom a {
            color: var(--primary-color);
            text-decoration: none;
        }

        /* Responsive */
        @media (max-width: 991px) {
            .main-nav {
                display: none;
            }

            .header-actions .btn-login,
            .header-actions .btn-register {
                display: none;
            }

            .mobile-menu-toggle {
                display: flex;
            }

            .mobile-menu {
                display: flex;
            }
        }

        @media (max-width: 576px) {
            .site-logo {
                font-size: 20px;
            }

            .site-logo img {
                max-height: 35px;
            }

            .btn-dashboard {
                padding: 8px 15px;
                font-size: 13px;
            }
        }
    </style>
    
    @stack('styles')
</head>
<body>
    <!-- Mobile Overlay -->
    <div class="mobile-overlay" id="mobileOverlay"></div>

    <!-- Header -->
    <header class="main-header">
        <div class="container">
            <div class="header-container">
                <!-- Logo -->
                <a href="{{ route('home') }}" class="site-logo">
                    @if($siteLogo)
                        <img src="{{ asset('storage/' . $siteLogo) }}" alt="{{ $siteName }}">
                    @else
                        <i class="fas fa-sms"></i>
                        <span>{{ $siteName }}</span>
                    @endif
                </a>

                <!-- Desktop Navigation -->
                <nav class="main-nav">
                    <a href="{{ route('home') }}" class="{{ request()->routeIs('home') ? 'active' : '' }}">Home</a>
                    <a href="{{ route('wifi-cards.index') }}" class="{{ request()->routeIs('wifi-cards.*') ? 'active' : '' }}">Wifi Cards</a>
                    <a href="{{ route('blog.index') }}" class="{{ request()->routeIs('blog.*') ? 'active' : '' }}">Blog</a>
                    <a href="{{ route('contact') }}" class="{{ request()->routeIs('contact') ? 'active' : '' }}">Contact</a>
                </nav>

                <!-- Header Actions -->
                <div class="header-actions">
                    @auth
                        <a href="{{ auth()->user()->isAdmin() ? route('admin.dashboard') : route('user.dashboard') }}" class="btn-header btn-dashboard">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>Dashboard</span>
                        </a>
                    @else
                        <a href="{{ route('login') }}" class="btn-header btn-login">Login</a>
                        <a href="{{ route('register') }}" class="btn-header btn-register">Register</a>
                    @endauth
                    
                    <!-- Mobile Menu Toggle -->
                    <button class="mobile-menu-toggle" id="mobileMenuToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                </div>
            </div>
        </div>
    </header>

    <!-- Mobile Menu -->
    <div class="mobile-menu" id="mobileMenu">
        <div class="mobile-menu-header">
            <a href="{{ route('home') }}" class="site-logo" style="font-size: 20px;">
                @if($siteLogo)
                    <img src="{{ asset('storage/' . $siteLogo) }}" alt="{{ $siteName }}" style="max-height: 35px;">
                @else
                    <i class="fas fa-sms"></i>
                    <span>{{ $siteName }}</span>
                @endif
            </a>
            <button class="mobile-menu-close" id="mobileMenuClose">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <nav class="mobile-nav">
            <a href="{{ route('home') }}">
                <i class="fas fa-home"></i>
                <span>Home</span>
            </a>
            <a href="#">
                <i class="fas fa-wifi"></i>
                <span>Wifi Cards</span>
            </a>
            <a href="{{ route('blog.index') }}">
                <i class="fas fa-blog"></i>
                <span>Blog</span>
            </a>
            <a href="{{ route('contact') }}">
                <i class="fas fa-envelope"></i>
                <span>Contact</span>
            </a>
        </nav>

        <div class="mobile-auth-buttons">
            @auth
                <a href="{{ auth()->user()->isAdmin() ? route('admin.dashboard') : route('user.dashboard') }}" class="btn-header btn-dashboard" style="justify-content: center;">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            @else
                <a href="{{ route('login') }}" class="btn-header btn-login" style="text-align: center;">Login</a>
                <a href="{{ route('register') }}" class="btn-header btn-register" style="text-align: center;">Register</a>
            @endauth
        </div>
    </div>

    <!-- Main Content -->
    <main>
        @yield('content')
    </main>

    <!-- Footer -->
    <footer class="main-footer">
        <div class="container">
            <div class="row">
                <!-- About Section -->
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="footer-widget footer-about">
                        <h5>{{ $siteName }}</h5>
                        <p>{{ $metaDescription ?: 'Send SMS instantly. Manage contacts efficiently. Grow your business effortlessly with our reliable SMS gateway service.' }}</p>
                        
                        @if($footerSocials->count() > 0)
                        <div class="social-links">
                            @foreach($footerSocials->take(6) as $social)
                                <a href="{{ $social->value }}" target="_blank" title="{{ $social->label }}">
                                    <i class="{{ $social->icon ?? 'fas fa-link' }}"></i>
                                </a>
                            @endforeach
                        </div>
                        @endif
                    </div>
                </div>

                <!-- Quick Links -->
                <div class="col-lg-2 col-md-6 mb-4">
                    <div class="footer-widget">
                        <h5>Quick Links</h5>
                        <ul>
                            <li><a href="{{ route('home') }}"><i class="fas fa-angle-right"></i> Home</a></li>
                            <li><a href="{{ route('blog.index') }}"><i class="fas fa-angle-right"></i> Blog</a></li>
                            <li><a href="{{ route('contact') }}"><i class="fas fa-angle-right"></i> Contact</a></li>
                            <li><a href="{{ route('login') }}"><i class="fas fa-angle-right"></i> Login</a></li>
                            <li><a href="{{ route('register') }}"><i class="fas fa-angle-right"></i> Register</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Services -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="footer-widget">
                        <h5>Our Services</h5>
                        <ul>
                            <li><a href="#"><i class="fas fa-angle-right"></i> Bulk SMS</a></li>
                            <li><a href="#"><i class="fas fa-angle-right"></i> Masking SMS</a></li>
                            <li><a href="#"><i class="fas fa-angle-right"></i> OTP SMS</a></li>
                            <li><a href="{{ route('wifi-cards.index') }}"><i class="fas fa-angle-right"></i> Wifi Cards</a></li>
                            <li><a href="#"><i class="fas fa-angle-right"></i> API Integration</a></li>
                        </ul>
                    </div>
                </div>

                <!-- Contact Info -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="footer-widget">
                        <h5>Contact Info</h5>
                        <ul>
                            @if($footerAddress)
                                <li>
                                    <a href="{{ route('contact') }}">
                                        <i class="{{ $footerAddress->icon ?? 'fas fa-map-marker-alt' }}"></i>
                                        {{ Str::limit($footerAddress->value, 35) }}
                                    </a>
                                </li>
                            @endif
                            
                            @foreach($footerPhones as $phone)
                                <li>
                                    <a href="tel:{{ str_replace([' ', '-'], '', $phone->value) }}">
                                        <i class="{{ $phone->icon ?? 'fas fa-phone' }}"></i>
                                        {{ $phone->value }}
                                    </a>
                                </li>
                            @endforeach
                            
                            @foreach($footerEmails as $email)
                                <li>
                                    <a href="mailto:{{ $email->value }}">
                                        <i class="{{ $email->icon ?? 'fas fa-envelope' }}"></i>
                                        {{ $email->value }}
                                    </a>
                                </li>
                            @endforeach
                            
                            @if($footerHours)
                                <li>
                                    <a href="{{ route('contact') }}">
                                        <i class="{{ $footerHours->icon ?? 'fas fa-clock' }}"></i>
                                        {{ Str::limit($footerHours->value, 30) }}
                                    </a>
                                </li>
                            @endif
                        </ul>
                    </div>
                </div>
            </div>

            <!-- Footer Bottom -->
            <div class="footer-bottom">
                <p>{!! $copyrightText !!}</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Header Scroll Effect -->
    <script>
        window.addEventListener('scroll', function() {
            const header = document.querySelector('.main-header');
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    </script>

    <!-- Mobile Menu Toggle -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuToggle = document.getElementById('mobileMenuToggle');
            const mobileMenu = document.getElementById('mobileMenu');
            const mobileMenuClose = document.getElementById('mobileMenuClose');
            const mobileOverlay = document.getElementById('mobileOverlay');

            function openMobileMenu() {
                mobileMenu.classList.add('active');
                mobileOverlay.classList.add('active');
                document.body.style.overflow = 'hidden';
            }

            function closeMobileMenu() {
                mobileMenu.classList.remove('active');
                mobileOverlay.classList.remove('active');
                document.body.style.overflow = '';
            }

            mobileMenuToggle.addEventListener('click', openMobileMenu);
            mobileMenuClose.addEventListener('click', closeMobileMenu);
            mobileOverlay.addEventListener('click', closeMobileMenu);

            // Close menu when clicking a link
            const mobileNavLinks = document.querySelectorAll('.mobile-nav a, .mobile-auth-buttons a');
            mobileNavLinks.forEach(link => {
                link.addEventListener('click', closeMobileMenu);
            });
        });
    </script>

    @stack('scripts')
</body>
</html>

