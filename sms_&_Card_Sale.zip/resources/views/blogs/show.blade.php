@extends('layouts.frontend')

@section('title', $blog->title . ' - ' . \App\Models\Setting::get('site_name', 'SMS & Card Sale'))

@push('styles')
<style>
    .blog-post-hero {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 60px 0 40px;
        color: white;
    }

    .blog-post-meta {
        display: flex;
        align-items: center;
        gap: 20px;
        margin-top: 20px;
        font-size: 14px;
    }

    .blog-post-meta span {
        display: flex;
        align-items: center;
        gap: 5px;
    }

    .blog-post-section {
        padding: 60px 0;
        background: #f8f9fa;
    }

    .blog-post-card {
        background: white;
        border-radius: 15px;
        padding: 40px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.05);
    }

    .blog-post-image {
        width: 100%;
        max-height: 500px;
        object-fit: cover;
        border-radius: 15px;
        margin-bottom: 30px;
    }

    .blog-post-category {
        display: inline-block;
        padding: 8px 20px;
        background: #667eea;
        color: white;
        border-radius: 25px;
        font-size: 14px;
        font-weight: 600;
        margin-bottom: 20px;
    }

    .blog-post-title {
        font-size: 36px;
        font-weight: 700;
        color: #2c3e50;
        margin-bottom: 20px;
        line-height: 1.3;
    }

    .blog-post-content {
        font-size: 16px;
        line-height: 1.8;
        color: #555;
    }

    .blog-post-content p {
        margin-bottom: 20px;
    }

    .blog-post-content h2 {
        font-size: 28px;
        font-weight: 700;
        color: #2c3e50;
        margin: 30px 0 15px;
    }

    .blog-post-content h3 {
        font-size: 24px;
        font-weight: 600;
        color: #2c3e50;
        margin: 25px 0 12px;
    }

    .blog-post-content ul,
    .blog-post-content ol {
        margin-bottom: 20px;
        padding-left: 25px;
    }

    .blog-post-content li {
        margin-bottom: 8px;
    }

    .blog-post-share {
        margin-top: 40px;
        padding-top: 30px;
        border-top: 2px solid #e9ecef;
    }

    .blog-post-share h4 {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 15px;
        color: #2c3e50;
    }

    .share-buttons {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }

    .share-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 20px;
        border-radius: 8px;
        color: white;
        text-decoration: none;
        font-weight: 600;
        font-size: 14px;
        transition: all 0.3s;
    }

    .share-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        color: white;
    }

    .share-btn.facebook {
        background: #1877f2;
    }

    .share-btn.twitter {
        background: #1da1f2;
    }

    .share-btn.linkedin {
        background: #0077b5;
    }

    .share-btn.whatsapp {
        background: #25d366;
    }

    /* Related Posts */
    .related-posts-section {
        margin-top: 60px;
        padding-top: 40px;
        border-top: 2px solid #e9ecef;
    }

    .related-posts-section h3 {
        font-size: 28px;
        font-weight: 700;
        color: #2c3e50;
        margin-bottom: 30px;
    }

    .related-post-card {
        background: white;
        border-radius: 12px;
        overflow: hidden;
        transition: all 0.3s;
        height: 100%;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }

    .related-post-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    }

    .related-post-image {
        width: 100%;
        height: 180px;
        background: linear-gradient(135deg, #667eea, #764ba2);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 48px;
    }

    .related-post-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .related-post-content {
        padding: 20px;
    }

    .related-post-category {
        display: inline-block;
        padding: 4px 12px;
        background: #667eea;
        color: white;
        border-radius: 15px;
        font-size: 11px;
        font-weight: 600;
        margin-bottom: 10px;
    }

    .related-post-title {
        font-size: 16px;
        font-weight: 600;
        margin-bottom: 8px;
        color: #2c3e50;
    }

    .related-post-title a {
        color: #2c3e50;
        text-decoration: none;
        transition: color 0.3s;
    }

    .related-post-title a:hover {
        color: #667eea;
    }

    .related-post-date {
        font-size: 12px;
        color: #999;
    }

    .back-to-blog {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 12px 24px;
        background: white;
        color: #667eea;
        border: 2px solid #667eea;
        border-radius: 50px;
        text-decoration: none;
        font-weight: 600;
        transition: all 0.3s;
        margin-bottom: 30px;
    }

    .back-to-blog:hover {
        background: #667eea;
        color: white;
    }
</style>
@endpush

@section('content')
<!-- Blog Post Hero -->
<section class="blog-post-hero">
    <div class="container">
        <a href="{{ route('blog.index') }}" class="back-to-blog">
            <i class="fas fa-arrow-left"></i>
            Back to Blog
        </a>
    </div>
</section>

<!-- Blog Post Section -->
<section class="blog-post-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 mx-auto">
                <div class="blog-post-card">
                    <!-- Featured Image -->
                    @if($blog->image)
                    <img src="{{ asset('storage/' . $blog->image) }}" alt="{{ $blog->title }}" class="blog-post-image">
                    @endif

                    <!-- Category -->
                    <span class="blog-post-category">{{ $blog->category }}</span>

                    <!-- Title -->
                    <h1 class="blog-post-title">{{ $blog->title }}</h1>

                    <!-- Meta Information -->
                    <div class="blog-post-meta">
                        <span>
                            <i class="far fa-calendar"></i>
                            {{ $blog->created_at->format('F d, Y') }}
                        </span>
                        <span>
                            <i class="far fa-clock"></i>
                            {{ ceil(str_word_count(strip_tags($blog->content)) / 200) }} min read
                        </span>
                    </div>

                    <hr style="margin: 30px 0; border-top: 2px solid #e9ecef;">

                    <!-- Content -->
                    <div class="blog-post-content">
                        {!! nl2br(e($blog->content)) !!}
                    </div>

                    <!-- Share Section -->
                    <div class="blog-post-share">
                        <h4>Share this post</h4>
                        <div class="share-buttons">
                            <a href="https://www.facebook.com/sharer/sharer.php?u={{ urlencode(route('blog.show', $blog->slug)) }}" 
                               target="_blank" 
                               class="share-btn facebook">
                                <i class="fab fa-facebook-f"></i>
                                Facebook
                            </a>
                            <a href="https://twitter.com/intent/tweet?url={{ urlencode(route('blog.show', $blog->slug)) }}&text={{ urlencode($blog->title) }}" 
                               target="_blank" 
                               class="share-btn twitter">
                                <i class="fab fa-twitter"></i>
                                Twitter
                            </a>
                            <a href="https://www.linkedin.com/shareArticle?mini=true&url={{ urlencode(route('blog.show', $blog->slug)) }}&title={{ urlencode($blog->title) }}" 
                               target="_blank" 
                               class="share-btn linkedin">
                                <i class="fab fa-linkedin-in"></i>
                                LinkedIn
                            </a>
                            <a href="https://wa.me/?text={{ urlencode($blog->title . ' ' . route('blog.show', $blog->slug)) }}" 
                               target="_blank" 
                               class="share-btn whatsapp">
                                <i class="fab fa-whatsapp"></i>
                                WhatsApp
                            </a>
                        </div>
                    </div>

                    <!-- Related Posts -->
                    @if($relatedBlogs->count() > 0)
                    <div class="related-posts-section">
                        <h3>Related Posts</h3>
                        <div class="row">
                            @foreach($relatedBlogs as $relatedBlog)
                            <div class="col-md-4 mb-4">
                                <div class="related-post-card">
                                    <div class="related-post-image">
                                        @if($relatedBlog->image)
                                            <img src="{{ asset('storage/' . $relatedBlog->image) }}" alt="{{ $relatedBlog->title }}">
                                        @else
                                            <i class="fas fa-newspaper"></i>
                                        @endif
                                    </div>
                                    <div class="related-post-content">
                                        <span class="related-post-category">{{ $relatedBlog->category }}</span>
                                        <h5 class="related-post-title">
                                            <a href="{{ route('blog.show', $relatedBlog->slug) }}">
                                                {{ Str::limit($relatedBlog->title, 60) }}
                                            </a>
                                        </h5>
                                        <span class="related-post-date">
                                            <i class="far fa-calendar"></i>
                                            {{ $relatedBlog->created_at->format('M d, Y') }}
                                        </span>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</section>
@endsection

