@extends('layouts.frontend')

@section('title', 'Blog - ' . \App\Models\Setting::get('site_name', 'SMS & Card Sale'))

@push('styles')
<style>
    .blog-hero {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 80px 0 60px;
        color: white;
        text-align: center;
    }

    .blog-hero h1 {
        font-size: 48px;
        font-weight: 700;
        margin-bottom: 15px;
    }

    .blog-hero p {
        font-size: 18px;
        opacity: 0.9;
    }

    .blog-section {
        padding: 60px 0;
        background: #f8f9fa;
    }

    .blog-card {
        background: white;
        border-radius: 15px;
        overflow: hidden;
        transition: all 0.3s;
        height: 100%;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        display: flex;
        flex-direction: column;
    }

    .blog-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    }

    .blog-image {
        width: 100%;
        height: 250px;
        background: linear-gradient(135deg, #667eea, #764ba2);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 64px;
        position: relative;
        overflow: hidden;
    }

    .blog-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .blog-content {
        padding: 25px;
        flex-grow: 1;
        display: flex;
        flex-direction: column;
    }

    .blog-category {
        display: inline-block;
        padding: 5px 15px;
        background: #667eea;
        color: white;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
        margin-bottom: 15px;
    }

    .blog-title {
        font-size: 20px;
        font-weight: 600;
        margin-bottom: 10px;
        color: #2c3e50;
    }

    .blog-title a {
        color: #2c3e50;
        text-decoration: none;
        transition: color 0.3s;
    }

    .blog-title a:hover {
        color: #667eea;
    }

    .blog-excerpt {
        color: #666;
        font-size: 14px;
        line-height: 1.6;
        margin-bottom: 20px;
        flex-grow: 1;
    }

    .blog-meta {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-top: 15px;
        border-top: 1px solid #e9ecef;
        font-size: 12px;
        color: #999;
    }

    .blog-date i {
        color: #667eea;
        margin-right: 5px;
    }

    .blog-read-more {
        color: #667eea;
        text-decoration: none;
        font-weight: 600;
        transition: color 0.3s;
    }

    .blog-read-more:hover {
        color: #764ba2;
    }

    .pagination {
        margin-top: 40px;
        justify-content: center;
    }

    .pagination .page-link {
        color: #667eea;
        border: 1px solid #e9ecef;
        padding: 10px 15px;
        margin: 0 3px;
        border-radius: 8px;
    }

    .pagination .page-link:hover {
        background: #667eea;
        color: white;
        border-color: #667eea;
    }

    .pagination .page-item.active .page-link {
        background: #667eea;
        border-color: #667eea;
    }

    .no-blogs {
        text-align: center;
        padding: 60px 20px;
        background: white;
        border-radius: 15px;
    }

    .no-blogs i {
        font-size: 64px;
        color: #e9ecef;
        margin-bottom: 20px;
    }

    .no-blogs h3 {
        font-size: 24px;
        color: #2c3e50;
        margin-bottom: 10px;
    }

    .no-blogs p {
        color: #999;
    }
</style>
@endpush

@section('content')
<!-- Blog Hero -->
<section class="blog-hero">
    <div class="container">
        <h1>Our Blog</h1>
        <p>Stay updated with the latest SMS marketing tips, industry news, and tutorials</p>
    </div>
</section>

<!-- Blog List Section -->
<section class="blog-section">
    <div class="container">
        @if($blogs->count() > 0)
        <div class="row">
            @foreach($blogs as $blog)
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="blog-card">
                    <div class="blog-image">
                        @if($blog->image)
                            <img src="{{ asset('storage/' . $blog->image) }}" alt="{{ $blog->title }}">
                        @else
                            <i class="fas fa-newspaper"></i>
                        @endif
                    </div>
                    <div class="blog-content">
                        <span class="blog-category">{{ $blog->category }}</span>
                        <h4 class="blog-title">
                            <a href="{{ route('blog.show', $blog->slug) }}">{{ $blog->title }}</a>
                        </h4>
                        <p class="blog-excerpt">{{ Str::limit($blog->excerpt, 120) }}</p>
                        <div class="blog-meta">
                            <span class="blog-date">
                                <i class="far fa-calendar"></i>
                                {{ $blog->created_at->format('M d, Y') }}
                            </span>
                            <a href="{{ route('blog.show', $blog->slug) }}" class="blog-read-more">
                                Read More <i class="fas fa-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>

        <!-- Pagination -->
        <div class="d-flex justify-content-center">
            {{ $blogs->links() }}
        </div>
        @else
        <div class="no-blogs">
            <i class="fas fa-newspaper"></i>
            <h3>No Blog Posts Yet</h3>
            <p>Check back later for exciting content!</p>
        </div>
        @endif
    </div>
</section>
@endsection

