@extends('install.layout')

@section('title', 'System Requirements')

@section('progress')
<div class="install-progress">
    <div class="progress-step completed">
        <div class="progress-icon">
            <i class="fas fa-check"></i>
        </div>
        <div class="progress-label">Welcome</div>
    </div>
    <div class="progress-step active">
        <div class="progress-icon">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="progress-label">Requirements</div>
    </div>
    <div class="progress-step">
        <div class="progress-icon">
            <i class="fas fa-database"></i>
        </div>
        <div class="progress-label">Database</div>
    </div>
    <div class="progress-step">
        <div class="progress-icon">
            <i class="fas fa-cog"></i>
        </div>
        <div class="progress-label">Configuration</div>
    </div>
    <div class="progress-step">
        <div class="progress-icon">
            <i class="fas fa-check"></i>
        </div>
        <div class="progress-label">Complete</div>
    </div>
</div>
@endsection

@section('content')
<h2 class="mb-4">
    <i class="fas fa-server me-2"></i>
    System Requirements Check
</h2>

<!-- PHP Requirements -->
<div class="card mb-4">
    <div class="card-header">
        <i class="fas fa-code me-2"></i>
        PHP Version & Extensions
    </div>
    <div class="card-body">
        <!-- PHP Version -->
        @foreach($requirements['php'] as $req)
        <div class="requirement-item">
            <div>
                <strong>{{ $req['name'] }}</strong>
                <br>
                <small class="text-muted">Current: {{ $req['current'] }} | Required: {{ $req['required'] }}</small>
            </div>
            <div>
                @if($req['status'])
                    <span class="status-badge status-success">
                        <i class="fas fa-check me-1"></i> Passed
                    </span>
                @else
                    <span class="status-badge status-error">
                        <i class="fas fa-times me-1"></i> Failed
                    </span>
                @endif
            </div>
        </div>
        @endforeach

        <!-- PHP Extensions -->
        <hr class="my-3">
        <h6 class="mb-3">Required PHP Extensions:</h6>
        <div class="row">
            @foreach($requirements['extensions'] as $ext)
            <div class="col-md-4 col-sm-6 mb-2">
                <div class="d-flex align-items-center">
                    @if($ext['status'])
                        <i class="fas fa-check-circle text-success me-2"></i>
                    @else
                        <i class="fas fa-times-circle text-danger me-2"></i>
                    @endif
                    <span>{{ $ext['name'] }}</span>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>

<!-- Directory Permissions -->
<div class="card mb-4">
    <div class="card-header">
        <i class="fas fa-folder-open me-2"></i>
        Directory Permissions
    </div>
    <div class="card-body">
        @foreach($permissions as $perm)
        <div class="permission-item">
            <div>
                <strong>{{ $perm['name'] }}</strong>
                <br>
                <small class="text-muted font-monospace">{{ $perm['path'] }}</small>
                <br>
                <small class="text-muted">Permission: {{ $perm['permission'] }}</small>
            </div>
            <div>
                @if($perm['status'])
                    <span class="status-badge status-success">
                        <i class="fas fa-check me-1"></i> Writable
                    </span>
                @else
                    <span class="status-badge status-error">
                        <i class="fas fa-times me-1"></i> Not Writable
                    </span>
                @endif
            </div>
        </div>
        @endforeach
    </div>
</div>

<!-- Status Messages -->
@if(!$allRequirementsMet)
<div class="alert alert-danger" role="alert">
    <i class="fas fa-exclamation-triangle me-2"></i>
    <strong>Requirements Not Met!</strong> Please fix the above issues before continuing.
    <hr>
    <small>Install required PHP version/extensions or contact your hosting provider for assistance.</small>
</div>
@endif

@if(!$allPermissionsMet)
<div class="alert alert-danger" role="alert">
    <i class="fas fa-exclamation-triangle me-2"></i>
    <strong>Permission Issues Detected!</strong> Please set write permissions for the directories above.
    <hr>
    <small>Run: <code>chmod -R 775 storage bootstrap/cache</code></small>
</div>
@endif

@if($allRequirementsMet && $allPermissionsMet)
<div class="alert alert-success" role="alert">
    <i class="fas fa-check-circle me-2"></i>
    <strong>All Requirements Met!</strong> Your server meets all the requirements. You can proceed to the next step.
</div>
@endif

<!-- Navigation Buttons -->
<div class="d-flex justify-content-between mt-4">
    <a href="{{ route('install.index') }}" class="btn btn-outline-secondary">
        <i class="fas fa-arrow-left me-2"></i>
        Back
    </a>
    
    @if($allRequirementsMet && $allPermissionsMet)
    <a href="{{ route('install.database') }}" class="btn btn-install">
        Next Step
        <i class="fas fa-arrow-right ms-2"></i>
    </a>
    @else
    <button type="button" class="btn btn-install" disabled>
        Fix Issues First
        <i class="fas fa-lock ms-2"></i>
    </button>
    @endif
</div>
@endsection

