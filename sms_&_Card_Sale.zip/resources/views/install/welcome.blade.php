@extends('install.layout')

@section('title', 'Welcome')

@section('progress')
<div class="install-progress">
    <div class="progress-step active">
        <div class="progress-icon">
            <i class="fas fa-home"></i>
        </div>
        <div class="progress-label">Welcome</div>
    </div>
    <div class="progress-step">
        <div class="progress-icon">
            <i class="fas fa-check-circle"></i>
        </div>
        <div class="progress-label">Requirements</div>
    </div>
    <div class="progress-step">
        <div class="progress-icon">
            <i class="fas fa-database"></i>
        </div>
        <div class="progress-label">Database</div>
    </div>
    <div class="progress-step">
        <div class="progress-icon">
            <i class="fas fa-cog"></i>
        </div>
        <div class="progress-label">Configuration</div>
    </div>
    <div class="progress-step">
        <div class="progress-icon">
            <i class="fas fa-check"></i>
        </div>
        <div class="progress-label">Complete</div>
    </div>
</div>
@endsection

@section('content')
<div class="text-center">
    <i class="fas fa-rocket fa-5x text-primary mb-4"></i>
    <h2 class="mb-4">Welcome to SMS & Card Sale Installation</h2>
    <p class="lead mb-4">Thank you for choosing SMS & Card Sale. This wizard will help you set up your application in just a few minutes.</p>
    
    <div class="card">
        <div class="card-body">
            <h5 class="card-title mb-4">Before you begin, please make sure you have:</h5>
            <div class="row text-start">
                <div class="col-md-6">
                    <ul class="list-unstyled">
                        <li class="mb-3">
                            <i class="fas fa-check-circle text-success me-2"></i>
                            <strong>PHP 8.1</strong> or higher installed
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-check-circle text-success me-2"></i>
                            <strong>MySQL 5.7</strong> or higher installed
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-check-circle text-success me-2"></i>
                            Required <strong>PHP extensions</strong> enabled
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-check-circle text-success me-2"></i>
                            <strong>Composer</strong> dependencies installed
                        </li>
                    </ul>
                </div>
                <div class="col-md-6">
                    <ul class="list-unstyled">
                        <li class="mb-3">
                            <i class="fas fa-check-circle text-success me-2"></i>
                            Database <strong>name and credentials</strong> ready
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-check-circle text-success me-2"></i>
                            <strong>Writable permissions</strong> for storage folders
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-check-circle text-success me-2"></i>
                            Your domain <strong>SSL certificate</strong> (recommended)
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-check-circle text-success me-2"></i>
                            <strong>15 minutes</strong> of your time
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="alert alert-info mt-4" role="alert">
        <i class="fas fa-info-circle me-2"></i>
        <strong>Note:</strong> Make sure you have backed up any existing database before proceeding.
    </div>

    <div class="mt-4">
        <a href="{{ route('install.requirements') }}" class="btn btn-install btn-lg">
            <i class="fas fa-arrow-right me-2"></i>
            Start Installation
        </a>
    </div>
</div>
@endsection

