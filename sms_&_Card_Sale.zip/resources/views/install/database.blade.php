@extends('install.layout')

@section('title', 'Database Configuration')

@section('progress')
<div class="install-progress">
    <div class="progress-step completed">
        <div class="progress-icon">
            <i class="fas fa-check"></i>
        </div>
        <div class="progress-label">Welcome</div>
    </div>
    <div class="progress-step completed">
        <div class="progress-icon">
            <i class="fas fa-check"></i>
        </div>
        <div class="progress-label">Requirements</div>
    </div>
    <div class="progress-step active">
        <div class="progress-icon">
            <i class="fas fa-database"></i>
        </div>
        <div class="progress-label">Database</div>
    </div>
    <div class="progress-step">
        <div class="progress-icon">
            <i class="fas fa-cog"></i>
        </div>
        <div class="progress-label">Configuration</div>
    </div>
    <div class="progress-step">
        <div class="progress-icon">
            <i class="fas fa-check"></i>
        </div>
        <div class="progress-label">Complete</div>
    </div>
</div>
@endsection

@section('content')
<h2 class="mb-4">
    <i class="fas fa-database me-2"></i>
    Database Configuration
</h2>

<div class="alert alert-info" role="alert">
    <i class="fas fa-info-circle me-2"></i>
    <strong>Database Setup:</strong> Please enter your MySQL database credentials. Make sure the database already exists.
</div>

<form id="databaseForm">
    @csrf
    
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-server me-2"></i>
            Database Connection Details
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-8 mb-3">
                    <label for="db_host" class="form-label">Database Host</label>
                    <input type="text" class="form-control" id="db_host" name="db_host" value="127.0.0.1" required>
                    <small class="text-muted">Usually "127.0.0.1" or "localhost"</small>
                </div>

                <div class="col-md-4 mb-3">
                    <label for="db_port" class="form-label">Port</label>
                    <input type="number" class="form-control" id="db_port" name="db_port" value="3306" required>
                    <small class="text-muted">Default: 3306</small>
                </div>
            </div>

            <div class="mb-3">
                <label for="db_name" class="form-label">Database Name</label>
                <input type="text" class="form-control" id="db_name" name="db_name" placeholder="sms_card_sale" required>
                <small class="text-muted">The database must already exist</small>
            </div>

            <div class="mb-3">
                <label for="db_username" class="form-label">Database Username</label>
                <input type="text" class="form-control" id="db_username" name="db_username" placeholder="root" required>
            </div>

            <div class="mb-3">
                <label for="db_password" class="form-label">Database Password</label>
                <input type="password" class="form-control" id="db_password" name="db_password" placeholder="••••••••">
                <small class="text-muted">Leave blank if no password</small>
            </div>

            <div class="d-grid gap-2 mt-4">
                <button type="button" id="testConnectionBtn" class="btn btn-outline-primary">
                    <i class="fas fa-plug me-2"></i>
                    Test Database Connection
                </button>
            </div>

            <div id="connectionResult" class="mt-3"></div>
        </div>
    </div>

    <div class="alert alert-warning" role="alert">
        <i class="fas fa-exclamation-triangle me-2"></i>
        <strong>Warning:</strong> This will run database migrations and seeders. Make sure you have backed up any existing data.
    </div>

    <div class="d-flex justify-content-between">
        <a href="{{ route('install.requirements') }}" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i>
            Back
        </a>
        
        <button type="submit" id="setupDatabaseBtn" class="btn btn-install" disabled>
            <span id="setupBtnText">
                Setup Database & Continue
                <i class="fas fa-arrow-right ms-2"></i>
            </span>
            <span id="setupBtnLoading" style="display: none;">
                <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                Setting up database...
            </span>
        </button>
    </div>
</form>
@endsection

@push('scripts')
<script>
$(document).ready(function() {
    let connectionTested = false;

    // Test database connection
    $('#testConnectionBtn').click(function() {
        const btn = $(this);
        const originalText = btn.html();
        
        btn.prop('disabled', true);
        btn.html('<span class="spinner-border spinner-border-sm me-2"></span>Testing connection...');
        
        $('#connectionResult').html('');

        $.ajax({
            url: '{{ route("install.test-database") }}',
            method: 'POST',
            data: {
                _token: $('input[name="_token"]').val(),
                db_host: $('#db_host').val(),
                db_port: $('#db_port').val(),
                db_name: $('#db_name').val(),
                db_username: $('#db_username').val(),
                db_password: $('#db_password').val()
            },
            success: function(response) {
                $('#connectionResult').html(
                    '<div class="alert alert-success">' +
                    '<i class="fas fa-check-circle me-2"></i>' +
                    response.message +
                    '</div>'
                );
                connectionTested = true;
                $('#setupDatabaseBtn').prop('disabled', false);
            },
            error: function(xhr) {
                $('#connectionResult').html(
                    '<div class="alert alert-danger">' +
                    '<i class="fas fa-times-circle me-2"></i>' +
                    (xhr.responseJSON ? xhr.responseJSON.message : 'Connection failed!') +
                    '</div>'
                );
                connectionTested = false;
                $('#setupDatabaseBtn').prop('disabled', true);
            },
            complete: function() {
                btn.prop('disabled', false);
                btn.html(originalText);
            }
        });
    });

    // Setup database
    $('#databaseForm').submit(function(e) {
        e.preventDefault();

        if (!connectionTested) {
            Swal.fire({
                icon: 'warning',
                title: 'Test Connection First',
                text: 'Please test the database connection before proceeding.',
            });
            return;
        }

        Swal.fire({
            title: 'Setup Database?',
            text: 'This will create all database tables and seed initial data.',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes, proceed!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                setupDatabase();
            }
        });
    });

    function setupDatabase() {
        $('#setupDatabaseBtn').prop('disabled', true);
        $('#setupBtnText').hide();
        $('#setupBtnLoading').show();

        $.ajax({
            url: '{{ route("install.setup-database") }}',
            method: 'POST',
            data: {
                _token: $('input[name="_token"]').val(),
                db_host: $('#db_host').val(),
                db_port: $('#db_port').val(),
                db_name: $('#db_name').val(),
                db_username: $('#db_username').val(),
                db_password: $('#db_password').val()
            },
            success: function(response) {
                Swal.fire({
                    icon: 'success',
                    title: 'Database Setup Complete!',
                    text: response.message,
                    timer: 2000,
                    showConfirmButton: false
                }).then(() => {
                    window.location.href = '{{ route("install.site-config") }}';
                });
            },
            error: function(xhr) {
                Swal.fire({
                    icon: 'error',
                    title: 'Setup Failed',
                    text: xhr.responseJSON ? xhr.responseJSON.message : 'An error occurred during database setup.',
                });
                
                $('#setupDatabaseBtn').prop('disabled', false);
                $('#setupBtnText').show();
                $('#setupBtnLoading').hide();
            }
        });
    }
});
</script>
@endpush

