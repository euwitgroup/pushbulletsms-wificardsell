@extends('install.layout')

@section('title', 'Site Configuration')

@section('progress')
<div class="install-progress">
    <div class="progress-step completed">
        <div class="progress-icon">
            <i class="fas fa-check"></i>
        </div>
        <div class="progress-label">Welcome</div>
    </div>
    <div class="progress-step completed">
        <div class="progress-icon">
            <i class="fas fa-check"></i>
        </div>
        <div class="progress-label">Requirements</div>
    </div>
    <div class="progress-step completed">
        <div class="progress-icon">
            <i class="fas fa-check"></i>
        </div>
        <div class="progress-label">Database</div>
    </div>
    <div class="progress-step active">
        <div class="progress-icon">
            <i class="fas fa-cog"></i>
        </div>
        <div class="progress-label">Configuration</div>
    </div>
    <div class="progress-step">
        <div class="progress-icon">
            <i class="fas fa-check"></i>
        </div>
        <div class="progress-label">Complete</div>
    </div>
</div>
@endsection

@section('content')
<h2 class="mb-4">
    <i class="fas fa-cog me-2"></i>
    Site Configuration
</h2>

<div class="alert alert-info" role="alert">
    <i class="fas fa-info-circle me-2"></i>
    <strong>Final Step:</strong> Configure your site settings and create your admin account.
</div>

<form id="siteConfigForm">
    @csrf
    
    <!-- Site Settings -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-globe me-2"></i>
            Site Settings
        </div>
        <div class="card-body">
            <div class="mb-3">
                <label for="app_name" class="form-label">Site Name <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="app_name" name="app_name" value="SMS & Card Sale" required>
                <small class="text-muted">The name of your website</small>
            </div>

            <div class="mb-3">
                <label for="app_url" class="form-label">Site URL <span class="text-danger">*</span></label>
                <input type="url" class="form-control" id="app_url" name="app_url" value="{{ url('/') }}" required>
                <small class="text-muted">Your domain URL (e.g., https://yourdomain.com)</small>
            </div>
        </div>
    </div>

    <!-- Admin Account -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-user-shield me-2"></i>
            Administrator Account
        </div>
        <div class="card-body">
            <div class="mb-3">
                <label for="admin_email" class="form-label">Admin Email <span class="text-danger">*</span></label>
                <input type="email" class="form-control" id="admin_email" name="admin_email" placeholder="admin@example.com" required>
                <small class="text-muted">This will be your login email</small>
            </div>

            <div class="mb-3">
                <label for="admin_password" class="form-label">Admin Password <span class="text-danger">*</span></label>
                <input type="password" class="form-control" id="admin_password" name="admin_password" required minlength="8">
                <small class="text-muted">Minimum 8 characters</small>
            </div>

            <div class="mb-3">
                <label for="admin_password_confirmation" class="form-label">Confirm Password <span class="text-danger">*</span></label>
                <input type="password" class="form-control" id="admin_password_confirmation" name="admin_password_confirmation" required minlength="8">
            </div>

            <div class="alert alert-warning mt-3" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <strong>Important:</strong> Please remember these credentials. You'll need them to access the admin panel.
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-between">
        <a href="{{ route('install.database') }}" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i>
            Back
        </a>
        
        <button type="submit" id="finishBtn" class="btn btn-install">
            <span id="finishBtnText">
                Finish Installation
                <i class="fas fa-check ms-2"></i>
            </span>
            <span id="finishBtnLoading" style="display: none;">
                <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                Finalizing...
            </span>
        </button>
    </div>
</form>
@endsection

@push('scripts')
<script>
$(document).ready(function() {
    $('#siteConfigForm').submit(function(e) {
        e.preventDefault();

        // Validate passwords match
        const password = $('#admin_password').val();
        const confirmPassword = $('#admin_password_confirmation').val();

        if (password !== confirmPassword) {
            Swal.fire({
                icon: 'error',
                title: 'Passwords Don\'t Match',
                text: 'Please make sure both passwords are identical.',
            });
            return;
        }

        if (password.length < 8) {
            Swal.fire({
                icon: 'error',
                title: 'Password Too Short',
                text: 'Password must be at least 8 characters long.',
            });
            return;
        }

        Swal.fire({
            title: 'Complete Installation?',
            text: 'This will finalize the installation with your settings.',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes, complete it!',
            cancelButtonText: 'Wait, let me review'
        }).then((result) => {
            if (result.isConfirmed) {
                finishInstallation();
            }
        });
    });

    function finishInstallation() {
        $('#finishBtn').prop('disabled', true);
        $('#finishBtnText').hide();
        $('#finishBtnLoading').show();

        $.ajax({
            url: '{{ route("install.save-site-config") }}',
            method: 'POST',
            data: $('#siteConfigForm').serialize(),
            success: function(response) {
                // Show success and redirect
                Swal.fire({
                    icon: 'success',
                    title: 'Installation Complete!',
                    text: 'Your site is now ready to use.',
                    timer: 2000,
                    showConfirmButton: false
                }).then(() => {
                    window.location.href = '{{ route("install.complete") }}';
                });
            },
            error: function(xhr) {
                let errorMessage = 'An error occurred during installation.';
                
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                } else if (xhr.responseJSON && xhr.responseJSON.errors) {
                    errorMessage = Object.values(xhr.responseJSON.errors).flat().join('<br>');
                }

                Swal.fire({
                    icon: 'error',
                    title: 'Installation Failed',
                    html: errorMessage,
                });
                
                $('#finishBtn').prop('disabled', false);
                $('#finishBtnText').show();
                $('#finishBtnLoading').hide();
            }
        });
    }
});
</script>
@endpush

