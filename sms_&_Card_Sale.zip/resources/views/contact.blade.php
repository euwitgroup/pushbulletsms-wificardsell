@extends('layouts.frontend')

@section('title', 'Contact Us - ' . \App\Models\Setting::get('site_name', 'SMS & Card Sale'))

@push('styles')
<style>
    .contact-hero {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 80px 0 60px;
        color: white;
        text-align: center;
    }

    .contact-hero h1 {
        font-size: 48px;
        font-weight: 700;
        margin-bottom: 15px;
    }

    .contact-hero p {
        font-size: 18px;
        opacity: 0.9;
    }

    .contact-section {
        padding: 60px 0;
        background: #f8f9fa;
    }

    .contact-info-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 25px;
        margin-bottom: 50px;
    }

    .contact-card {
        background: white;
        border-radius: 15px;
        padding: 30px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.05);
        transition: all 0.3s;
    }

    .contact-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }

    .contact-card-icon {
        width: 60px;
        height: 60px;
        border-radius: 12px;
        background: linear-gradient(135deg, #667eea, #764ba2);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 24px;
        margin-bottom: 20px;
    }

    .contact-card h3 {
        font-size: 18px;
        font-weight: 700;
        color: #2c3e50;
        margin-bottom: 10px;
    }

    .contact-card-value {
        color: #555;
        font-size: 15px;
        margin-bottom: 8px;
        word-wrap: break-word;
    }

    .contact-card-value a {
        color: #667eea;
        text-decoration: none;
        transition: color 0.3s;
    }

    .contact-card-value a:hover {
        color: #764ba2;
        text-decoration: underline;
    }

    .contact-card-description {
        color: #999;
        font-size: 13px;
        margin-top: 10px;
    }

    .social-links-section {
        background: white;
        border-radius: 15px;
        padding: 40px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.05);
        text-align: center;
    }

    .social-links-section h2 {
        font-size: 28px;
        font-weight: 700;
        color: #2c3e50;
        margin-bottom: 10px;
    }

    .social-links-section p {
        color: #666;
        margin-bottom: 30px;
    }

    .social-links-grid {
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        gap: 15px;
    }

    .social-link {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        padding: 12px 24px;
        border-radius: 50px;
        color: white;
        text-decoration: none;
        font-weight: 600;
        font-size: 14px;
        transition: all 0.3s;
    }

    .social-link:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 20px rgba(0,0,0,0.2);
        color: white;
    }

    .social-link.facebook {
        background: #1877f2;
    }

    .social-link.twitter {
        background: #1da1f2;
    }

    .social-link.linkedin {
        background: #0077b5;
    }

    .social-link.instagram {
        background: linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%);
    }

    .social-link.youtube {
        background: #ff0000;
    }

    .social-link.whatsapp {
        background: #25d366;
    }

    .social-link i {
        font-size: 18px;
    }

    .map-section {
        background: white;
        border-radius: 15px;
        padding: 40px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.05);
        margin-top: 30px;
    }

    .map-section h2 {
        font-size: 28px;
        font-weight: 700;
        color: #2c3e50;
        margin-bottom: 20px;
        text-align: center;
    }

    .map-container {
        width: 100%;
        height: 400px;
        border-radius: 12px;
        overflow: hidden;
    }

    .copyright-section {
        background: white;
        border-radius: 15px;
        padding: 30px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.05);
        margin-top: 30px;
        text-align: center;
    }

    .copyright-section h3 {
        font-size: 20px;
        font-weight: 700;
        color: #2c3e50;
        margin-bottom: 15px;
    }

    .copyright-section p {
        color: #666;
        line-height: 1.8;
        margin-bottom: 10px;
    }

    .copyright-section .copyright-text {
        padding-top: 20px;
        border-top: 1px solid #e9ecef;
        margin-top: 20px;
        color: #999;
        font-size: 14px;
    }

    @media (max-width: 768px) {
        .contact-hero h1 {
            font-size: 36px;
        }

        .contact-info-grid {
            grid-template-columns: 1fr;
        }

        .social-links-grid {
            flex-direction: column;
            align-items: center;
        }

        .social-link {
            width: 200px;
            justify-content: center;
        }
    }
</style>
@endpush

@section('content')
<!-- Contact Hero -->
<section class="contact-hero">
    <div class="container">
        <h1>Get In Touch</h1>
        <p>We're here to help! Reach out to us through any of the following channels</p>
    </div>
</section>

<!-- Contact Section -->
<section class="contact-section">
    <div class="container">
        <!-- Contact Info Grid -->
        <div class="contact-info-grid">
            <!-- Phone Numbers -->
            @foreach($phones as $phone)
            <div class="contact-card">
                <div class="contact-card-icon">
                    <i class="{{ $phone->icon ?? 'fas fa-phone' }}"></i>
                </div>
                <h3>{{ $phone->label }}</h3>
                <div class="contact-card-value">
                    <a href="tel:{{ str_replace([' ', '-'], '', $phone->value) }}">{{ $phone->value }}</a>
                </div>
                @if($phone->description)
                <div class="contact-card-description">{{ $phone->description }}</div>
                @endif
            </div>
            @endforeach

            <!-- Email Addresses -->
            @foreach($emails as $email)
            <div class="contact-card">
                <div class="contact-card-icon">
                    <i class="{{ $email->icon ?? 'fas fa-envelope' }}"></i>
                </div>
                <h3>{{ $email->label }}</h3>
                <div class="contact-card-value">
                    <a href="mailto:{{ $email->value }}">{{ $email->value }}</a>
                </div>
                @if($email->description)
                <div class="contact-card-description">{{ $email->description }}</div>
                @endif
            </div>
            @endforeach

            <!-- Addresses -->
            @foreach($addresses as $address)
            <div class="contact-card">
                <div class="contact-card-icon">
                    <i class="{{ $address->icon ?? 'fas fa-map-marker-alt' }}"></i>
                </div>
                <h3>{{ $address->label }}</h3>
                <div class="contact-card-value">
                    {{ $address->value }}
                </div>
                @if($address->description)
                <div class="contact-card-description">{{ $address->description }}</div>
                @endif
            </div>
            @endforeach

            <!-- Working Hours -->
            @foreach($hours as $hour)
            <div class="contact-card">
                <div class="contact-card-icon">
                    <i class="{{ $hour->icon ?? 'fas fa-clock' }}"></i>
                </div>
                <h3>{{ $hour->label }}</h3>
                <div class="contact-card-value">
                    {{ $hour->value }}
                </div>
                @if($hour->description)
                <div class="contact-card-description">{{ $hour->description }}</div>
                @endif
            </div>
            @endforeach
        </div>

        <!-- Social Media Links -->
        @if($socials->count() > 0)
        <div class="social-links-section">
            <h2>Connect With Us</h2>
            <p>Follow us on social media for the latest updates and news</p>
            <div class="social-links-grid">
                @foreach($socials as $social)
                    @php
                        $socialClass = strtolower($social->label);
                    @endphp
                    <a href="{{ $social->value }}" 
                       target="_blank" 
                       class="social-link {{ $socialClass }}"
                       title="{{ $social->description ?? $social->label }}">
                        <i class="{{ $social->icon ?? 'fas fa-link' }}"></i>
                        <span>{{ $social->label }}</span>
                    </a>
                @endforeach
            </div>
        </div>
        @endif

        <!-- Map Section (Optional - you can integrate Google Maps) -->
        @if($addresses->count() > 0)
        <div class="map-section">
            <h2>Find Us Here</h2>
            <div class="map-container">
                <!-- You can integrate Google Maps here -->
                <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3651.9040424156726!2d90.37568931543455!3d23.750837594620956!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b8bd7c24e5f5%3A0x123456789abcdef!2sDhanmondi%2C%20Dhaka%2C%20Bangladesh!5e0!3m2!1sen!2sbd!4v1234567890123!5m2!1sen!2sbd" 
                    width="100%" 
                    height="100%" 
                    style="border:0;" 
                    allowfullscreen="" 
                    loading="lazy" 
                    referrerpolicy="no-referrer-when-downgrade">
                </iframe>
            </div>
        </div>
        @endif

        <!-- Copyright Section -->
        <div class="copyright-section">
            <h3>About Our Service</h3>
            <p>
                {{ \App\Models\Setting::get('site_name', 'SMS & Card Sale') }} is your trusted partner for SMS services and WiFi card solutions. 
                We provide reliable, fast, and cost-effective communication services to businesses across Bangladesh.
            </p>
            <p>
                With years of experience in the industry, we pride ourselves on excellent customer service, 
                competitive pricing, and cutting-edge technology solutions.
            </p>
            <div class="copyright-text">
                <p>&copy; {{ date('Y') }} {{ \App\Models\Setting::get('site_name', 'SMS & Card Sale') }}. All rights reserved.</p>
                <p>Developed with <i class="fas fa-heart" style="color: #e74c3c;"></i> by {{ \App\Models\Setting::get('site_name', 'SMS & Card Sale') }} Team</p>
            </div>
        </div>
    </div>
</section>
@endsection

