@extends('auth.layouts.auth')

@section('title', 'Login')

@section('content')
<div class="auth-form-header">
    <h2>Welcome Back!</h2>
    <p>Login to continue to your account</p>
</div>

@if($errors->any())
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong><i class="fas fa-exclamation-circle me-2"></i>Error!</strong>
    <ul class="mb-0 mt-2">
        @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

@if(session('error'))
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-circle me-2"></i>{{ session('error') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

@if(session('info'))
<div class="alert alert-info alert-dismissible fade show" role="alert">
    <i class="fas fa-info-circle me-2"></i>{{ session('info') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

@php
    $enableGoogleLogin = \App\Models\Setting::get('enable_google_login', '0');
    $enableFacebookLogin = \App\Models\Setting::get('enable_facebook_login', '0');
    $hasGoogleRoute = Route::has('auth.google');
    $hasFacebookRoute = Route::has('auth.facebook');
@endphp

<!-- Social Login Buttons -->
@if(($enableGoogleLogin == '1' && $hasGoogleRoute) || ($enableFacebookLogin == '1' && $hasFacebookRoute))
<div class="social-login">
    @if($enableGoogleLogin == '1' && $hasGoogleRoute)
    <a href="{{ route('auth.google') }}" class="btn btn-social btn-google w-100 mb-2">
        <i class="fab fa-google me-2"></i>Continue with Google
    </a>
    @endif
    
    @if($enableFacebookLogin == '1' && $hasFacebookRoute)
    <a href="{{ route('auth.facebook') }}" class="btn btn-social btn-facebook w-100">
        <i class="fab fa-facebook me-2"></i>Continue with Facebook
    </a>
    @endif
</div>

<div class="divider">
    <span>OR</span>
</div>
@endif

<form method="POST" action="{{ route('login') }}" id="loginForm">
    @csrf

    <div class="mb-3">
        <label class="form-label">Email Address</label>
        <div class="input-group">
            <span class="input-group-text">
                <i class="fas fa-envelope"></i>
            </span>
            <input type="email" 
                   class="form-control @error('email') is-invalid @enderror" 
                   name="email" 
                   value="{{ old('email') }}" 
                   placeholder="Enter your email"
                   required 
                   autofocus>
        </div>
        @error('email')
            <small class="text-danger">{{ $message }}</small>
        @enderror
    </div>

    <div class="mb-3">
        <label class="form-label">Password</label>
        <div class="input-group">
            <span class="input-group-text">
                <i class="fas fa-lock"></i>
            </span>
            <input type="password" 
                   class="form-control @error('password') is-invalid @enderror" 
                   name="password" 
                   placeholder="Enter your password"
                   required>
        </div>
        @error('password')
            <small class="text-danger">{{ $message }}</small>
        @enderror
    </div>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="remember" id="remember">
            <label class="form-check-label" for="remember">
                Remember me
            </label>
        </div>
        <a href="{{ route('password.request') }}" class="text-decoration-none">
            Forgot Password?
        </a>
    </div>

    @php
        $enableRecaptcha = \App\Models\Setting::get('enable_recaptcha', '0');
        $recaptchaSiteKey = \App\Models\Setting::get('recaptcha_site_key', '');
        $recaptchaVersion = \App\Models\Setting::get('recaptcha_version', 'v2');
    @endphp

    @if($enableRecaptcha == '1' && $recaptchaSiteKey)
        @if($recaptchaVersion == 'v2')
        <div class="mb-3">
            <div class="g-recaptcha" data-sitekey="{{ $recaptchaSiteKey }}"></div>
            @error('g-recaptcha-response')
                <small class="text-danger">{{ $message }}</small>
            @enderror
        </div>
        @endif
    @endif

    <button type="submit" class="btn btn-primary w-100 mb-3">
        <i class="fas fa-sign-in-alt me-2"></i>Login
    </button>
</form>

<div class="auth-footer">
    Don't have an account? <a href="{{ route('register') }}">Create Account</a>
</div>
@endsection

@section('extra-js')
@if($enableRecaptcha == '1' && $recaptchaSiteKey)
    @if($recaptchaVersion == 'v2')
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    @elseif($recaptchaVersion == 'v3')
    <script src="https://www.google.com/recaptcha/api.js?render={{ $recaptchaSiteKey }}"></script>
    <script>
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            grecaptcha.ready(function() {
                grecaptcha.execute('{{ $recaptchaSiteKey }}', {action: 'login'}).then(function(token) {
                    document.getElementById('loginForm').innerHTML += '<input type="hidden" name="g-recaptcha-response" value="' + token + '">';
                    document.getElementById('loginForm').submit();
                });
            });
        });
    </script>
    @endif
@endif

<script>
// Display any flash messages with SweetAlert2
@if(session('success'))
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
    });
    Toast.fire({ icon: 'success', title: '{{ session('success') }}' });
@endif
</script>
@endsection
