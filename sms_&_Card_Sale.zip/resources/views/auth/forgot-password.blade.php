@extends('auth.layouts.auth')

@section('title', 'Forgot Password')

@section('content')
<div class="auth-form-header">
    <h2>Forgot Password?</h2>
    <p>Enter your phone number to reset your password</p>
</div>

@if($errors->any())
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong><i class="fas fa-exclamation-circle me-2"></i>Error!</strong>
    <ul class="mb-0 mt-2">
        @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

@if(session('error'))
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-circle me-2"></i>{{ session('error') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

<div class="text-center mb-4">
    <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 20px;">
        <i class="fas fa-key" style="font-size: 40px; color: white;"></i>
    </div>
    <p class="text-muted">
        Don't worry! Enter your registered phone number and we'll send you an OTP to reset your password.
    </p>
</div>

<form method="POST" action="{{ route('password.send-otp') }}" id="forgotForm">
    @csrf

    <div class="mb-4">
        <label class="form-label">Phone Number</label>
        <div class="input-group">
            <span class="input-group-text">
                <i class="fas fa-phone"></i>
            </span>
            <input type="text" 
                   class="form-control @error('phone') is-invalid @enderror" 
                   name="phone" 
                   value="{{ old('phone') }}" 
                   placeholder="01XXXXXXXXX"
                   required 
                   autofocus>
        </div>
        @error('phone')
            <small class="text-danger">{{ $message }}</small>
        @enderror
        <small class="text-muted">Enter your 11-digit registered phone number</small>
    </div>

    <button type="submit" class="btn btn-primary w-100 mb-3">
        <i class="fas fa-paper-plane me-2"></i>Send OTP
    </button>
</form>

<div class="auth-footer">
    <a href="{{ route('login') }}"><i class="fas fa-arrow-left me-2"></i>Back to Login</a>
</div>
@endsection

@section('extra-js')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const forgotForm = document.getElementById('forgotForm');
    
    forgotForm.addEventListener('submit', function(e) {
        const submitBtn = forgotForm.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Sending OTP...';
    });
});
</script>
@endsection

