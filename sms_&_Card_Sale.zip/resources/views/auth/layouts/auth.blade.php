<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title') - {{ \App\Models\Setting::get('site_name', 'SMS & Card Sale') }}</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            height: 100vh;
            overflow: hidden;
        }

        .auth-container {
            display: flex;
            height: 100vh;
        }

        /* Left Side - Image & Info */
        .auth-left {
            flex: 1;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: white;
            padding: 60px 40px;
            position: relative;
            overflow: hidden;
        }

        .auth-left::before {
            content: '';
            position: absolute;
            width: 500px;
            height: 500px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            top: -250px;
            left: -250px;
        }

        .auth-left::after {
            content: '';
            position: absolute;
            width: 400px;
            height: 400px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            bottom: -200px;
            right: -200px;
        }

        .auth-left-content {
            position: relative;
            z-index: 1;
            text-align: center;
            max-width: 500px;
        }

        .auth-logo {
            font-size: 48px;
            margin-bottom: 30px;
            animation: float 3s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
        }

        .auth-left h1 {
            font-size: 42px;
            font-weight: 700;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }

        .auth-left p {
            font-size: 18px;
            opacity: 0.95;
            line-height: 1.6;
            margin-bottom: 30px;
        }

        .auth-features {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-top: 40px;
        }

        .auth-feature {
            background: rgba(255, 255, 255, 0.2);
            padding: 20px;
            border-radius: 15px;
            backdrop-filter: blur(10px);
            transition: transform 0.3s;
        }

        .auth-feature:hover {
            transform: translateY(-5px);
        }

        .auth-feature i {
            font-size: 30px;
            margin-bottom: 10px;
            display: block;
        }

        .auth-feature h5 {
            font-size: 16px;
            margin: 0;
            font-weight: 600;
        }

        /* Right Side - Form */
        .auth-right {
            flex: 1;
            background: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px;
            overflow-y: auto;
        }

        .auth-form-container {
            width: 100%;
            max-width: 450px;
        }

        .auth-form-header {
            margin-bottom: 30px;
        }

        .auth-form-header h2 {
            font-size: 32px;
            color: #2c3e50;
            margin-bottom: 10px;
            font-weight: 700;
        }

        .auth-form-header p {
            color: #7f8c8d;
            font-size: 15px;
        }

        .form-control {
            border-radius: 10px;
            border: 2px solid #e0e0e0;
            padding: 12px 15px;
            font-size: 14px;
            transition: all 0.3s;
        }

        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .input-group-text {
            background: #f8f9fa;
            border: 2px solid #e0e0e0;
            border-radius: 10px 0 0 10px;
            border-right: none;
        }

        .input-group .form-control {
            border-left: none;
            border-radius: 0 10px 10px 0;
        }

        .input-group:focus-within .input-group-text {
            border-color: #667eea;
            background: rgba(102, 126, 234, 0.05);
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 10px;
            padding: 12px;
            font-weight: 600;
            font-size: 15px;
            transition: transform 0.2s;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .social-login {
            margin: 20px 0;
        }

        .btn-social {
            border-radius: 10px;
            border: 2px solid #e0e0e0;
            padding: 10px;
            font-weight: 500;
            transition: all 0.3s;
        }

        .btn-google {
            background: white;
            color: #333;
        }

        .btn-google:hover {
            background: #f8f9fa;
            border-color: #DB4437;
            color: #DB4437;
        }

        .btn-facebook {
            background: white;
            color: #333;
        }

        .btn-facebook:hover {
            background: #f8f9fa;
            border-color: #1877f2;
            color: #1877f2;
        }

        .divider {
            text-align: center;
            margin: 25px 0;
            position: relative;
        }

        .divider::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 1px;
            background: #e0e0e0;
        }

        .divider span {
            background: white;
            padding: 0 15px;
            position: relative;
            color: #7f8c8d;
            font-size: 14px;
        }

        .auth-footer {
            text-align: center;
            margin-top: 25px;
            color: #7f8c8d;
            font-size: 14px;
        }

        .auth-footer a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }

        .auth-footer a:hover {
            text-decoration: underline;
        }

        /* Mobile Responsive */
        @media (max-width: 968px) {
            .auth-left {
                display: none;
            }
            
            .auth-right {
                flex: 1;
            }
        }

        @media (max-width: 576px) {
            .auth-right {
                padding: 20px;
            }
            
            .auth-form-header h2 {
                font-size: 24px;
            }
        }
    </style>
    
    @yield('extra-css')
</head>
<body>
    <div class="auth-container">
        <!-- Left Side - Image & Info -->
        <div class="auth-left">
            <div class="auth-left-content">
                <div class="auth-logo">
                    <i class="fas fa-sms"></i>
                </div>
                <h1>{{ \App\Models\Setting::get('site_name', 'SMS & Card Sale') }}</h1>
                <p>{{ \App\Models\Setting::get('site_tagline', 'Send SMS instantly. Manage contacts efficiently. Grow your business effortlessly.') }}</p>
                
                <div class="auth-features">
                    <div class="auth-feature">
                        <i class="fas fa-bolt"></i>
                        <h5>Instant Delivery</h5>
                    </div>
                    <div class="auth-feature">
                        <i class="fas fa-shield-alt"></i>
                        <h5>Secure & Reliable</h5>
                    </div>
                    <div class="auth-feature">
                        <i class="fas fa-chart-line"></i>
                        <h5>Real-time Analytics</h5>
                    </div>
                    <div class="auth-feature">
                        <i class="fas fa-headset"></i>
                        <h5>24/7 Support</h5>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Side - Form -->
        <div class="auth-right">
            <div class="auth-form-container">
                @yield('content')
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    @yield('extra-js')
</body>
</html>

