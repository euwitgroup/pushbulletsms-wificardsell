@extends('auth.layouts.auth')

@section('title', 'Register')

@section('content')
<div class="auth-form-header">
    <h2>Create Account</h2>
    <p>Join us today and start sending SMS</p>
</div>

@if($errors->any())
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong><i class="fas fa-exclamation-circle me-2"></i>Error!</strong>
    <ul class="mb-0 mt-2">
        @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

@php
    $enableGoogleLogin = \App\Models\Setting::get('enable_google_login', '0');
    $enableFacebookLogin = \App\Models\Setting::get('enable_facebook_login', '0');
    $hasGoogleRoute = Route::has('auth.google');
    $hasFacebookRoute = Route::has('auth.facebook');
    $phoneVerificationRequired = \App\Models\Setting::get('phone_verification_required', '1');
@endphp

<!-- Social Login Buttons -->
@if(($enableGoogleLogin == '1' && $hasGoogleRoute) || ($enableFacebookLogin == '1' && $hasFacebookRoute))
<div class="social-login">
    @if($enableGoogleLogin == '1' && $hasGoogleRoute)
    <a href="{{ route('auth.google') }}" class="btn btn-social btn-google w-100 mb-2">
        <i class="fab fa-google me-2"></i>Continue with Google
    </a>
    @endif
    
    @if($enableFacebookLogin == '1' && $hasFacebookRoute)
    <a href="{{ route('auth.facebook') }}" class="btn btn-social btn-facebook w-100">
        <i class="fab fa-facebook me-2"></i>Continue with Facebook
    </a>
    @endif
</div>

<div class="divider">
    <span>OR</span>
</div>
@endif

<form method="POST" action="{{ route('register') }}" id="registerForm">
    @csrf

    <div class="mb-3">
        <label class="form-label">Full Name</label>
        <div class="input-group">
            <span class="input-group-text">
                <i class="fas fa-user"></i>
            </span>
            <input type="text" 
                   class="form-control @error('name') is-invalid @enderror" 
                   name="name" 
                   value="{{ old('name') }}" 
                   placeholder="Enter your full name"
                   required 
                   autofocus>
        </div>
        @error('name')
            <small class="text-danger">{{ $message }}</small>
        @enderror
    </div>

    <div class="mb-3">
        <label class="form-label">Email Address</label>
        <div class="input-group">
            <span class="input-group-text">
                <i class="fas fa-envelope"></i>
            </span>
            <input type="email" 
                   class="form-control @error('email') is-invalid @enderror" 
                   name="email" 
                   value="{{ old('email') }}" 
                   placeholder="Enter your email"
                   required>
        </div>
        @error('email')
            <small class="text-danger">{{ $message }}</small>
        @enderror
    </div>

    <div class="mb-3">
        <label class="form-label">Phone Number</label>
        <div class="input-group">
            <span class="input-group-text">
                <i class="fas fa-phone"></i>
            </span>
            <input type="text" 
                   class="form-control @error('phone') is-invalid @enderror" 
                   name="phone" 
                   id="phoneInput"
                   value="{{ old('phone') }}" 
                   placeholder="01XXXXXXXXX"
                   required>
        </div>
        @error('phone')
            <small class="text-danger">{{ $message }}</small>
        @enderror
        <small class="text-muted">Enter 11-digit Bangladeshi number (e.g., 01712345678)</small>
    </div>

    <div class="mb-3">
        <label class="form-label">Password</label>
        <div class="input-group">
            <span class="input-group-text">
                <i class="fas fa-lock"></i>
            </span>
            <input type="password" 
                   class="form-control @error('password') is-invalid @enderror" 
                   name="password" 
                   placeholder="Enter your password"
                   required>
        </div>
        @error('password')
            <small class="text-danger">{{ $message }}</small>
        @enderror
    </div>

    <div class="mb-3">
        <label class="form-label">Confirm Password</label>
        <div class="input-group">
            <span class="input-group-text">
                <i class="fas fa-lock"></i>
            </span>
            <input type="password" 
                   class="form-control" 
                   name="password_confirmation" 
                   placeholder="Confirm your password"
                   required>
        </div>
    </div>

    @php
        $enableRecaptcha = \App\Models\Setting::get('enable_recaptcha', '0');
        $recaptchaSiteKey = \App\Models\Setting::get('recaptcha_site_key', '');
        $recaptchaVersion = \App\Models\Setting::get('recaptcha_version', 'v2');
    @endphp

    @if($enableRecaptcha == '1' && $recaptchaSiteKey)
        @if($recaptchaVersion == 'v2')
        <div class="mb-3">
            <div class="g-recaptcha" data-sitekey="{{ $recaptchaSiteKey }}"></div>
            @error('g-recaptcha-response')
                <small class="text-danger">{{ $message }}</small>
            @enderror
        </div>
        @endif
    @endif

    <button type="submit" class="btn btn-primary w-100 mb-3">
        <i class="fas fa-user-plus me-2"></i>Create Account
    </button>
</form>

<div class="auth-footer">
    Already have an account? <a href="{{ route('login') }}">Login</a>
</div>
@endsection

@section('extra-js')
@if($enableRecaptcha == '1' && $recaptchaSiteKey)
    @if($recaptchaVersion == 'v2')
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    @elseif($recaptchaVersion == 'v3')
    <script src="https://www.google.com/recaptcha/api.js?render={{ $recaptchaSiteKey }}"></script>
    <script>
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            e.preventDefault();
            grecaptcha.ready(function() {
                grecaptcha.execute('{{ $recaptchaSiteKey }}', {action: 'register'}).then(function(token) {
                    document.getElementById('registerForm').innerHTML += '<input type="hidden" name="g-recaptcha-response" value="' + token + '">';
                    document.getElementById('registerForm').submit();
                });
            });
        });
    </script>
    @endif
@endif
@endsection
