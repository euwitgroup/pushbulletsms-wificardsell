@extends('auth.layouts.auth')

@section('title', 'Verify OTP')

@section('content')
<div class="auth-form-header">
    <h2>Verify OTP</h2>
    <p>We've sent a verification code to your phone</p>
</div>

@if($errors->any())
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong><i class="fas fa-exclamation-circle me-2"></i>Error!</strong>
    <ul class="mb-0 mt-2">
        @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

@if(session('error'))
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-circle me-2"></i>{{ session('error') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

<div class="text-center mb-4">
    <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 20px;">
        <i class="fas fa-mobile-alt" style="font-size: 40px; color: white;"></i>
    </div>
    <p class="text-muted">
        Enter the 6-digit code sent to<br>
        <strong>{{ session('otp_phone', 'your phone') }}</strong>
    </p>
</div>

<form method="POST" action="{{ route('verify.otp.submit') }}" id="otpForm">
    @csrf

    <div class="mb-4">
        <label class="form-label text-center d-block">Enter OTP</label>
        <div class="d-flex justify-content-center gap-2" id="otpInputs">
            <input type="text" class="form-control text-center otp-input" maxlength="1" style="width: 50px; height: 50px; font-size: 24px; font-weight: bold;" data-index="0">
            <input type="text" class="form-control text-center otp-input" maxlength="1" style="width: 50px; height: 50px; font-size: 24px; font-weight: bold;" data-index="1">
            <input type="text" class="form-control text-center otp-input" maxlength="1" style="width: 50px; height: 50px; font-size: 24px; font-weight: bold;" data-index="2">
            <input type="text" class="form-control text-center otp-input" maxlength="1" style="width: 50px; height: 50px; font-size: 24px; font-weight: bold;" data-index="3">
            <input type="text" class="form-control text-center otp-input" maxlength="1" style="width: 50px; height: 50px; font-size: 24px; font-weight: bold;" data-index="4">
            <input type="text" class="form-control text-center otp-input" maxlength="1" style="width: 50px; height: 50px; font-size: 24px; font-weight: bold;" data-index="5">
        </div>
        <input type="hidden" name="otp" id="otpValue">
        @error('otp')
            <small class="text-danger d-block text-center mt-2">{{ $message }}</small>
        @enderror
    </div>

    <button type="submit" class="btn btn-primary w-100 mb-3" id="verifyBtn">
        <i class="fas fa-check-circle me-2"></i>Verify OTP
    </button>
</form>

<div class="text-center mt-3">
    <p class="text-muted mb-2">Didn't receive the code?</p>
    <form method="POST" action="{{ route('resend.otp') }}" id="resendForm">
        @csrf
        <button type="submit" class="btn btn-link text-decoration-none" id="resendBtn">
            <i class="fas fa-redo me-2"></i>Resend OTP
        </button>
    </form>
</div>

<div class="auth-footer">
    <a href="{{ route('register') }}"><i class="fas fa-arrow-left me-2"></i>Back to Registration</a>
</div>
@endsection

@section('extra-js')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const otpInputs = document.querySelectorAll('.otp-input');
    const otpValue = document.getElementById('otpValue');
    const otpForm = document.getElementById('otpForm');
    
    // Focus first input
    otpInputs[0].focus();
    
    // Handle input
    otpInputs.forEach((input, index) => {
        input.addEventListener('input', function(e) {
            const value = e.target.value;
            
            if (value.length === 1 && index < otpInputs.length - 1) {
                otpInputs[index + 1].focus();
            }
            
            // Update hidden field
            updateOtpValue();
            
            // Auto-submit if all filled
            if (index === otpInputs.length - 1 && value.length === 1) {
                const allFilled = Array.from(otpInputs).every(inp => inp.value.length === 1);
                if (allFilled) {
                    setTimeout(() => otpForm.submit(), 500);
                }
            }
        });
        
        input.addEventListener('keydown', function(e) {
            // Handle backspace
            if (e.key === 'Backspace' && !e.target.value && index > 0) {
                otpInputs[index - 1].focus();
            }
            
            // Handle paste
            if (e.key === 'v' && (e.ctrlKey || e.metaKey)) {
                e.preventDefault();
                navigator.clipboard.readText().then(text => {
                    const digits = text.replace(/\D/g, '').slice(0, 6);
                    digits.split('').forEach((digit, i) => {
                        if (otpInputs[i]) {
                            otpInputs[i].value = digit;
                        }
                    });
                    updateOtpValue();
                    if (digits.length === 6) {
                        otpInputs[5].focus();
                    }
                });
            }
        });
    });
    
    function updateOtpValue() {
        const otp = Array.from(otpInputs).map(input => input.value).join('');
        otpValue.value = otp;
    }
    
    // Resend OTP handler
    const resendForm = document.getElementById('resendForm');
    const resendBtn = document.getElementById('resendBtn');
    
    resendForm.addEventListener('submit', function(e) {
        e.preventDefault();
        resendBtn.disabled = true;
        resendBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Sending...';
        
        fetch(resendForm.action, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('[name="csrf-token"]').content,
                'Accept': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                Swal.fire({
                    icon: 'success',
                    title: 'OTP Sent!',
                    text: data.message,
                    timer: 3000
                });
                // Clear inputs
                otpInputs.forEach(input => input.value = '');
                otpInputs[0].focus();
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: data.message
                });
            }
        })
        .catch(error => {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Failed to resend OTP. Please try again.'
            });
        })
        .finally(() => {
            resendBtn.disabled = false;
            resendBtn.innerHTML = '<i class="fas fa-redo me-2"></i>Resend OTP';
        });
    });
});
</script>
@endsection

