@extends('auth.layouts.auth')

@section('title', 'Reset Password')

@section('content')
<div class="auth-form-header">
    <h2>Reset Password</h2>
    <p>Enter OTP and your new password</p>
</div>

@if($errors->any())
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong><i class="fas fa-exclamation-circle me-2"></i>Error!</strong>
    <ul class="mb-0 mt-2">
        @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

@if(session('success'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

@if(session('error'))
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-circle me-2"></i>{{ session('error') }}
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
@endif

<div class="text-center mb-4">
    <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 20px;">
        <i class="fas fa-lock-open" style="font-size: 40px; color: white;"></i>
    </div>
    <p class="text-muted">
        We've sent an OTP to your phone number
    </p>
</div>

<form method="POST" action="{{ route('password.update') }}" id="resetForm">
    @csrf

    <div class="mb-3">
        <label class="form-label">Enter OTP</label>
        <div class="d-flex justify-content-center gap-2 mb-3" id="otpInputs">
            <input type="text" class="form-control text-center otp-input" maxlength="1" style="width: 45px; height: 45px; font-size: 20px; font-weight: bold;" data-index="0">
            <input type="text" class="form-control text-center otp-input" maxlength="1" style="width: 45px; height: 45px; font-size: 20px; font-weight: bold;" data-index="1">
            <input type="text" class="form-control text-center otp-input" maxlength="1" style="width: 45px; height: 45px; font-size: 20px; font-weight: bold;" data-index="2">
            <input type="text" class="form-control text-center otp-input" maxlength="1" style="width: 45px; height: 45px; font-size: 20px; font-weight: bold;" data-index="3">
            <input type="text" class="form-control text-center otp-input" maxlength="1" style="width: 45px; height: 45px; font-size: 20px; font-weight: bold;" data-index="4">
            <input type="text" class="form-control text-center otp-input" maxlength="1" style="width: 45px; height: 45px; font-size: 20px; font-weight: bold;" data-index="5">
        </div>
        <input type="hidden" name="otp" id="otpValue">
        @error('otp')
            <small class="text-danger d-block text-center">{{ $message }}</small>
        @enderror
    </div>

    <div class="mb-3">
        <label class="form-label">New Password</label>
        <div class="input-group">
            <span class="input-group-text">
                <i class="fas fa-lock"></i>
            </span>
            <input type="password" 
                   class="form-control @error('password') is-invalid @enderror" 
                   name="password" 
                   placeholder="Enter new password"
                   required>
        </div>
        @error('password')
            <small class="text-danger">{{ $message }}</small>
        @enderror
    </div>

    <div class="mb-4">
        <label class="form-label">Confirm New Password</label>
        <div class="input-group">
            <span class="input-group-text">
                <i class="fas fa-lock"></i>
            </span>
            <input type="password" 
                   class="form-control" 
                   name="password_confirmation" 
                   placeholder="Confirm new password"
                   required>
        </div>
    </div>

    <button type="submit" class="btn btn-primary w-100 mb-3">
        <i class="fas fa-check-circle me-2"></i>Reset Password
    </button>
</form>

<div class="auth-footer">
    <a href="{{ route('password.request') }}"><i class="fas fa-arrow-left me-2"></i>Try Different Number</a>
</div>
@endsection

@section('extra-js')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const otpInputs = document.querySelectorAll('.otp-input');
    const otpValue = document.getElementById('otpValue');
    
    // Focus first input
    otpInputs[0].focus();
    
    // Handle input
    otpInputs.forEach((input, index) => {
        input.addEventListener('input', function(e) {
            const value = e.target.value;
            
            if (value.length === 1 && index < otpInputs.length - 1) {
                otpInputs[index + 1].focus();
            }
            
            // Update hidden field
            updateOtpValue();
        });
        
        input.addEventListener('keydown', function(e) {
            // Handle backspace
            if (e.key === 'Backspace' && !e.target.value && index > 0) {
                otpInputs[index - 1].focus();
            }
            
            // Handle paste
            if (e.key === 'v' && (e.ctrlKey || e.metaKey)) {
                e.preventDefault();
                navigator.clipboard.readText().then(text => {
                    const digits = text.replace(/\D/g, '').slice(0, 6);
                    digits.split('').forEach((digit, i) => {
                        if (otpInputs[i]) {
                            otpInputs[i].value = digit;
                        }
                    });
                    updateOtpValue();
                    if (digits.length === 6) {
                        otpInputs[5].focus();
                    }
                });
            }
        });
    });
    
    function updateOtpValue() {
        const otp = Array.from(otpInputs).map(input => input.value).join('');
        otpValue.value = otp;
    }
});
</script>
@endsection

