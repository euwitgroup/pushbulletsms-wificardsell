@php
    use App\Models\Setting;
    $siteName = Setting::get('site_name', 'SMS & Card Sale');
    $siteLogo = Setting::get('site_logo', '');
    $enableRecaptcha = Setting::get('enable_recaptcha', '0');
    $recaptchaSiteKey = Setting::get('recaptcha_site_key', '');
    $recaptchaVersion = Setting::get('recaptcha_version', 'v2');
    $enableGoogleLogin = Setting::get('enable_google_login', '0');
    $enableFacebookLogin = Setting::get('enable_facebook_login', '0');
    $enableRegistration = Setting::get('enable_registration', '1');
    $primaryColor = Setting::get('primary_color', '#667eea');
    $secondaryColor = Setting::get('secondary_color', '#764ba2');
@endphp

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Login - {{ $siteName }}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    @if($enableRecaptcha == '1' && $recaptchaVersion == 'v2')
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    @elseif($enableRecaptcha == '1' && $recaptchaVersion == 'v3')
    <script src="https://www.google.com/recaptcha/api.js?render={{ $recaptchaSiteKey }}"></script>
    @endif
    
    <style>
        :root {
            --primary-color: {{ $primaryColor }};
            --secondary-color: {{ $secondaryColor }};
        }
        
        body {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        }
        
        .login-card {
            border: none;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            backdrop-filter: blur(10px);
        }
        
        .logo-section {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .logo-section img {
            max-width: 150px;
            margin-bottom: 15px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            border: none;
            padding: 12px;
            font-weight: 600;
        }
        
        .btn-primary:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            transition: all 0.3s;
        }
        
        .social-login {
            margin: 20px 0;
        }
        
        .btn-google {
            background: #db4437;
            color: white;
            border: none;
        }
        
        .btn-facebook {
            background: #4267B2;
            color: white;
            border: none;
        }
        
        .divider {
            display: flex;
            align-items: center;
            text-align: center;
            margin: 20px 0;
        }
        
        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            border-bottom: 1px solid #dee2e6;
        }
        
        .divider span {
            padding: 0 10px;
            color: #6c757d;
            font-size: 14px;
        }
        
        .input-group-text {
            background: #f8f9fa;
            border-right: none;
        }
        
        .form-control {
            border-left: none;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        
        .demo-credentials {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
        }
        
        .demo-credentials strong {
            color: var(--primary-color);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card login-card">
                    <div class="card-body p-5">
                        <div class="logo-section">
                            @if($siteLogo)
                                <img src="{{ asset('storage/' . $siteLogo) }}" alt="{{ $siteName }}">
                            @else
                                <i class="fas fa-sms fa-3x mb-3" style="color: var(--primary-color);"></i>
                            @endif
                            <h3>{{ $siteName }}</h3>
                            <p class="text-muted">Login to your account</p>
                        </div>

                        @if ($errors->any())
                        <div class="alert alert-danger">
                            @foreach ($errors->all() as $error)
                                <div>{{ $error }}</div>
                            @endforeach
                        </div>
                        @endif

                        @if(session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                        @endif
                        
                        @if(session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                        @endif

                        <!-- Social Login Buttons -->
                        @php
                            $hasGoogleRoute = Route::has('auth.google');
                            $hasFacebookRoute = Route::has('auth.facebook');
                        @endphp
                        
                        @if(($enableGoogleLogin == '1' && $hasGoogleRoute) || ($enableFacebookLogin == '1' && $hasFacebookRoute))
                        <div class="social-login">
                            @if($enableGoogleLogin == '1' && $hasGoogleRoute)
                            <a href="{{ route('auth.google') }}" class="btn btn-google w-100 mb-2">
                                <i class="fab fa-google me-2"></i>Continue with Google
                            </a>
                            @endif
                            
                            @if($enableFacebookLogin == '1' && $hasFacebookRoute)
                            <a href="{{ route('auth.facebook') }}" class="btn btn-facebook w-100">
                                <i class="fab fa-facebook me-2"></i>Continue with Facebook
                            </a>
                            @endif
                        </div>
                        
                        <div class="divider">
                            <span>OR</span>
                        </div>
                        @endif

                        <form method="POST" action="{{ route('login') }}" id="loginForm">
                            @csrf

                            <div class="mb-3">
                                <label class="form-label">Email Address</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                    <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" 
                                           value="{{ old('email') }}" required autofocus placeholder="Enter your email">
                                </div>
                                @error('email')
                                    <div class="text-danger small mt-1">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                    <input type="password" name="password" class="form-control @error('password') is-invalid @enderror" 
                                           required placeholder="Enter your password">
                                </div>
                                @error('password')
                                    <div class="text-danger small mt-1">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="mb-3 d-flex justify-content-between align-items-center">
                                <div class="form-check">
                                    <input type="checkbox" name="remember" class="form-check-input" id="remember">
                                    <label class="form-check-label" for="remember">Remember Me</label>
                                </div>
                                <a href="#" style="color: var(--primary-color); text-decoration: none; font-size: 14px;">Forgot Password?</a>
                            </div>

                            @if($enableRecaptcha == '1' && $recaptchaVersion == 'v2')
                            <div class="mb-3">
                                <div class="g-recaptcha" data-sitekey="{{ $recaptchaSiteKey }}"></div>
                                @error('g-recaptcha-response')
                                    <div class="text-danger small mt-1">{{ $message }}</div>
                                @enderror
                            </div>
                            @endif

                            <button type="submit" class="btn btn-primary w-100 mb-3">
                                <i class="fas fa-sign-in-alt me-2"></i>Login
                            </button>

                            @if($enableRegistration == '1')
                            <div class="text-center">
                                <p class="mb-0">Don't have an account? <a href="{{ route('register') }}" style="color: var(--primary-color);">Register here</a></p>
                            </div>
                            @endif
                        </form>

                        <!-- Demo Credentials -->
                        <div class="demo-credentials">
                            <div class="small text-muted">
                                <strong>Demo Credentials:</strong><br>
                                <i class="fas fa-user-shield me-1"></i> Admin: admin@example.com / password<br>
                                <i class="fas fa-user me-1"></i> User: user@example.com / password
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    @if($enableRecaptcha == '1' && $recaptchaVersion == 'v3')
    <script>
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const form = this;
            
            grecaptcha.ready(function() {
                grecaptcha.execute('{{ $recaptchaSiteKey }}', {action: 'login'}).then(function(token) {
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'g-recaptcha-response';
                    input.value = token;
                    form.appendChild(input);
                    form.submit();
                });
            });
        });
    </script>
    @endif
</body>
</html>
