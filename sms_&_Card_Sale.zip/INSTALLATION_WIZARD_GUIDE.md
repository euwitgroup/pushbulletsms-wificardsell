# 🎯 Web-Based Installation Wizard

## ✨ Automatic Installation System

Your SMS & Card Sale application now includes a **comprehensive web-based installation wizard** that automatically:

- ✅ Checks all system requirements
- ✅ Validates directory permissions  
- ✅ Tests database connections
- ✅ Creates database tables
- ✅ Seeds initial data
- ✅ Configures site settings
- ✅ Creates admin account
- ✅ Optimizes for production

---

## 🚀 How to Use the Installation Wizard

### Step 1: Upload Your Files

Upload all project files to your server (e.g., `/var/www/sms-card-sale/`)

### Step 2: Set Basic Permissions

```bash
chmod -R 775 storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache
```

### Step 3: Access the Installer

Navigate to your domain in a web browser:

```
https://yourdomain.com/install
```

### Step 4: Follow the Wizard

The installation wizard has **5 easy steps**:

#### 📍 Step 1: Welcome
- Introduction and requirements overview
- Click "Start Installation"

#### 📍 Step 2: Requirements Check  
- Automatic verification of:
  - PHP version (>= 8.1)
  - Required PHP extensions
  - Directory write permissions
- All checks must pass to continue

#### 📍 Step 3: Database Configuration
- Enter your database credentials:
  - Host (usually 127.0.0.1 or localhost)
  - Port (default: 3306)
  - Database name
  - Username
  - Password
- Test connection before proceeding
- Automatic migration and seeding

#### 📍 Step 4: Site Configuration
- Set site name and URL
- Create admin account:
  - Admin email
  - Admin password
- Configuration is saved to `.env`

#### 📍 Step 5: Installation Complete
- Success message with next steps
- Links to visit site and login
- Security reminders

---

## 📋 What the Installer Does Automatically

### System Checks
- ✅ PHP version validation
- ✅ Extension availability check
- ✅ Write permission verification
- ✅ Database connectivity test

### Database Setup
- ✅ Validates credentials
- ✅ Runs `php artisan migrate --force`
- ✅ Runs `php artisan db:seed --force`
- ✅ Creates all necessary tables
- ✅ Populates initial data

### Configuration
- ✅ Updates `.env` file
- ✅ Generates `APP_KEY`
- ✅ Sets production environment (`APP_ENV=production`)
- ✅ Disables debug mode (`APP_DEBUG=false`)
- ✅ Updates admin credentials

### Optimization
- ✅ Creates storage symlink
- ✅ Caches configuration
- ✅ Caches routes
- ✅ Caches views
- ✅ Creates installation lock file

---

## 🔐 Security Features

### Installation Lock
After successful installation, a lock file is created at:
```
storage/installed
```

This prevents the installer from being accessed again.

### Automatic Protection
The installer:
- Sets `APP_ENV=production`
- Sets `APP_DEBUG=false`
- Hashes admin password with bcrypt
- Validates all inputs
- Uses CSRF protection

---

## 🛠️ Installation Requirements

### Server Requirements
- **PHP**: 8.1 or higher
- **MySQL**: 5.7 or higher
- **Web Server**: Apache/Nginx
- **Composer**: Installed
- **Node.js**: Installed (for assets)

### Required PHP Extensions
- OpenSSL
- PDO
- Mbstring
- Tokenizer
- XML
- Ctype
- JSON
- BCMath
- Fileinfo
- GD
- Curl
- Zip

### Directory Permissions
Writable (775):
- `storage/app`
- `storage/framework`
- `storage/logs`
- `bootstrap/cache`

---

## 📝 Manual Installation Alternative

If you prefer manual installation, follow **DEPLOYMENT_GUIDE.md** instead.

---

## 🔄 Re-installing

### To Run Installer Again:

1. Delete the lock file:
```bash
rm storage/installed
```

2. Drop and recreate database:
```bash
mysql -u root -p
DROP DATABASE your_database;
CREATE DATABASE your_database;
```

3. Clear all caches:
```bash
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear
```

4. Access `/install` again

---

## ⚠️ Post-Installation

### Important: Disable Installer

For security, you should disable the installer after successful installation:

**Option 1: Delete Installation Views**
```bash
rm -rf resources/views/install
```

**Option 2: Comment Out Installation Routes**

In `routes/web.php`, comment out the installation routes:

```php
// Route::prefix('install')->name('install.')->group(function () {
//     ...
// });
```

**Option 3: Keep Lock File**

The installer is automatically disabled if `storage/installed` exists. Just keep this file.

---

## 🚦 Access URLs

| URL | Purpose |
|-----|---------|
| `/install` | Start installation |
| `/install/requirements` | Check requirements |
| `/install/database` | Configure database |
| `/install/site-config` | Configure site |
| `/install/complete` | Installation complete |
| `/` | Home page |
| `/login` | Admin login |

---

## 🐛 Troubleshooting

### "Installation Already Completed" Error

**Solution**: Delete `storage/installed` file to run installer again

### Permission Denied Errors

**Solution**: 
```bash
sudo chmod -R 775 storage bootstrap/cache
sudo chown -R www-data:www-data storage bootstrap/cache
```

### Database Connection Failed

**Solution**: 
- Verify database exists
- Check credentials
- Ensure MySQL is running: `sudo systemctl status mysql`
- Test connection: `mysql -u username -p -h host database_name`

### White Screen / 500 Error

**Solution**:
```bash
# Check Laravel logs
tail -100 storage/logs/laravel.log

# Check web server logs
sudo tail -100 /var/log/nginx/error.log
# OR
sudo tail -100 /var/log/apache2/error.log
```

### Extension Not Found

**Solution**: Install missing PHP extensions
```bash
# For PHP 8.2 on Ubuntu
sudo apt install php8.2-extensionname
sudo systemctl restart php8.2-fpm
sudo systemctl restart nginx
```

---

## 💡 Tips for Smooth Installation

1. **Prepare in Advance**:
   - Have database credentials ready
   - Choose a strong admin password
   - Know your site's final URL

2. **Test First**:
   - Test on a staging server first
   - Backup any existing data

3. **Use Chrome/Firefox**:
   - Modern browsers work best
   - Enable JavaScript

4. **Check Requirements First**:
   - Review server requirements before starting
   - Install missing extensions beforehand

5. **Have SSH Access**:
   - Helpful for troubleshooting
   - Required for permission fixes

---

## 📊 Installation Time

**Total Time**: 5-10 minutes

- Step 1 (Welcome): 30 seconds
- Step 2 (Requirements): 1 minute
- Step 3 (Database): 2-3 minutes
- Step 4 (Configuration): 1-2 minutes
- Step 5 (Complete): 1 minute

---

## 🎉 Success!

Once installation is complete:

1. ✅ Visit your site: `https://yourdomain.com`
2. ✅ Login to admin: `https://yourdomain.com/login`
3. ✅ Configure payment gateway in `.env`
4. ✅ Set up SMS gateways in admin panel
5. ✅ Configure email settings in `.env`
6. ✅ Review site settings in admin panel

---

## 📚 Additional Resources

- **Deployment Guide**: See `DEPLOYMENT_GUIDE.md`
- **Pre-Deployment Checklist**: See `PRE_DEPLOYMENT_CHECKLIST.md`
- **Quick Setup**: See `QUICK_PRODUCTION_SETUP.md`
- **README**: See `README.md`

---

## 🆘 Need Help?

1. Check Laravel logs: `storage/logs/laravel.log`
2. Review deployment guide
3. Check server logs
4. Verify all requirements met

---

**Installation Wizard Version**: 1.0  
**Last Updated**: November 2, 2025  
**Compatible With**: Laravel 9.x, PHP 8.1+

